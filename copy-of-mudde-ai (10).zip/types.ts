// Fix: Added AiProvider enum definition
export enum AiProvider {
    GOOGLE = 'google',
    OPENAI = 'openai',
    OPENROUTER = 'openrouter',
    ANTHROPIC = 'anthropic',
    XAI = 'xai',
    REPLICATE = 'replicate',
    FREEPIK = 'freepik',
    FALAI = 'falai',
    PERPLEXITY = 'perplexity',
}
// Fix: Removed circular import: import { AiProvider } from './types';

export enum AppStatus {
  IDLE = 'idle',
  AUTOMATION_TRIGGERED = 'automation_triggered',
  FETCHING_SOURCE = 'fetching_source',
  GENERATING_STRATEGY = 'generating_strategy',
  AWAITING_STRATEGY_SELECTION = 'awaiting_strategy_selection',
  GENERATING_ARTICLE = 'generating_article',
  GENERATING_IMAGE = 'generating_image',
  OPTIMIZING_ARTICLE = 'optimizing_article',
  READY_TO_PUBLISH = 'ready_to_publish',
  PUBLISHING = 'publishing',
  GENERATING_SOCIAL_POSTS = 'generating_social_posts',
  PUBLISHED = 'published',
  ERROR = 'error',
}

export enum SubscriptionPlan {
  FREE = 'free',
  CREATOR = 'creator',
  PRO = 'pro',
  AGENCY = 'agency'
}

export interface UserSubscription {
    plan: SubscriptionPlan;
    postsGeneratedThisMonth: number;
    renewalDate: number; // timestamp
    featureCredits?: {
        socialGraphics: number;
        socialVideo: number;
    };
    commentingActionsThisMonth?: number;
}


export interface StoredUser {
    username: string;
    passwordHash: string;
    displayName: string;
    email: string;
    subscription: UserSubscription;
    avatarUrl?: string;
}

export interface User extends Omit<StoredUser, 'passwordHash'> {}

export interface ApiKeys {
  google: string;
  googleClientId: string;
  openAI: string;
  anthropic: string;
  openRouter: string;
  xai: string;
  replicate: string;
  dataforseo: string;
  freepik: string;
  falai: string;
  perplexity: string;
  mailgun: string;
  sendgrid: string;
  tenweb: string;
}

export interface GeminiModelConfig {
    temperature?: number;
    topK?: number;
    topP?: number;
    maxOutputTokens?: number;
}

export interface ModelConfig {
  textProvider: AiProvider;
  textModel: string;
  imageProvider: AiProvider;
  imageModel: string;
  videoProvider?: AiProvider;
  videoModel?: string;
  geminiConfig?: GeminiModelConfig;
}

export interface SocialMediaAccount {
    id: string;
    name: string;
    isAutomationEnabled: boolean;
    isConnected: boolean;
    clientId?: string;
    clientSecret?: string;
    accessToken?: string | null;
    status: 'connected' | 'disconnected' | 'needs_reauth';
    statusMessage?: string;
    destinationType?: 'page' | 'group' | 'profile';
    destinationId?: string;
}

export interface WhatsAppAccount {
    id: string;
    name: string;
    isAutomationEnabled: boolean;
    isConnected: boolean;
    accessToken: string;
    phoneNumberId: string;
    destination: string;
    destinationType: 'number' | 'group';
    status: 'connected' | 'disconnected' | 'needs_reauth';
    statusMessage?: string;
}

export interface TelegramAccount {
    id: string;
    name: string;
    isAutomationEnabled: boolean;
    isConnected: boolean;
    botToken: string;
    chatId: string;
    status: 'connected' | 'disconnected' | 'needs_reauth';
    statusMessage?: string;
}

export interface SocialMediaSettings {
    twitter?: SocialMediaAccount[];
    facebook?: SocialMediaAccount[];
    linkedin?: SocialMediaAccount[];
    instagram?: SocialMediaAccount[];
    pinterest?: SocialMediaAccount[];
    whatsapp?: WhatsAppAccount[];
    youtube?: SocialMediaAccount[];
    tiktok?: SocialMediaAccount[];
    telegram?: TelegramAccount[];
    snapchat?: SocialMediaAccount[];
}


export interface PostHistoryItem {
  id: string;
  topic: string;
  url: string;
  date: number; // timestamp
  type: 'Keyword' | 'RSS' | 'Video' | 'Google Sheet' | 'Social Graphic' | 'Social Video' | 'Email Marketing' | 'Email Digest';
  socialMediaPosts?: Record<string, SocialMediaPost>;
  socialGraphics?: Record<string, { imageUrl: string, caption: string }>;
  socialVideos?: Record<string, { videoUrl: string, caption: string }>;
  emailCampaign?: EmailMarketingCampaign;
}

export interface SocialMediaPost {
    content: string;
    hashtags: string[];
}

export interface RssItem {
  guid: string;
  title: string;
  link: string;
  contentSnippet: string;
}

export interface VideoSource {
    id: string;
    url: string;
    type: 'channel' | 'video';
    name: string;
    processedVideoGuids: string[];
}

export interface Draft {
    id: string;
    date: number; // timestamp
    sourceTopic: string;
    sourceDetails: {
        type: 'keyword' | 'rss' | 'video' | 'google_sheet';
        value: any; // string for keyword, RssItem for rss, etc.
        source?: any;
        videoItem?: RssItem;
    };
    blogPost: BlogPost;
    // Fix: Added brief property to Draft type
    brief: StrategicBrief;
}

export interface SeoChecklist {
    titleLength: boolean;
    metaDescriptionLength: boolean;
    keywordInTitle: boolean;
    keywordInMetaDescription: boolean;
    keywordInSlug: boolean;
    keywordInContent: boolean;
    keywordInHeadings: boolean;
    sufficientInternalLinks: boolean;
    sufficientExternalLinks: boolean;
    imageAltText: boolean;
    contentLength: boolean;
    faqSection: boolean;
    schemaMarkupValid: boolean;
    readability: boolean;
    authorMentioned: boolean;
    firstPersonExperience: boolean;
    aboutTheAuthorSection: boolean;
}

export interface SeoScoreResult {
  score: number;
  checklist: SeoChecklist;
}

export interface BlogPost {
  title: string;
  content: string;
  imageUrl: string;
  seoTitle: string;
  metaDescription: string;
  slug: string;
  excerpt: string;
  categories: string[];
  tags: string[];
  imagePrompt: string;
  imageAltText: string;
  focusKeyword: string;
}

export interface StrategicBrief {
  topic: string;
  focusKeyword: string;
  keywordCluster: string[];
  targetAudience: string;
  contentAngle: string;
  entities: string[];
  competitorUrls: string[];
  internalLinks: { title: string; link: string }[];
  seoTitle: string;
  metaDescription: string;
  slug: string;
  imagePrompt: string;
  imageAltText: string;
  categories: string[];
  tags: string[];
  faq: { question: string; answer: string }[];
  wordCount: number;
  brandGuideline: string;
  brandLogo?: string;
  brandColors?: string[];
  brandFonts?: string[];
  promoLink1?: string;
  promoLink2?: string;
  authorName: string;
  authorBio: string;
  nicheTargeting?: string;
}

export interface ReferenceItem {
    id: string;
    type: 'url' | 'file';
    value: string; // URL or base64 content
    name: string;
    mimeType: string | null;
}

export interface CharacterReference {
    id: string;
    name: string;
    visualReferenceImage?: string; // base64
    visualReferenceText: string;
    personality: string;
}


export interface WordPressAuthor {
  id: number;
  name: string;
  bio: string;
}

export interface WordPressCategory {
  id: number;
  name: string;
}

export interface RecurringSchedule {
    id: string;
    type: 'weekly' | 'monthly';
    days: number[];
    time: string;
    isEnabled: boolean;
    lastRun?: number;
}

export interface BacklinksHistoryItem {
    id: string;
    date: number;
    prospectUrl: string;
    status: 'sent' | 'failed' | 'no_reply' | 'replied' | 'link_placed';
    errorMessage?: string;
}

export interface CommentingProspect {
    id: string;
    prospectUrl: string;
    prospectTitle: string;
    prospectDescription: string;
    status: 'found' | 'comment_generated' | 'commented' | 'error';
    sourcePostUrl: string; // The URL of our post that gives context
    generatedComment?: string;
}

export interface SocialCommentingProspect {
    id: string;
    platform: 'twitter' | 'facebook' | 'linkedin' | 'instagram' | 'pinterest' | 'tiktok';
    prospectPostUrl: string;
    prospectPostAuthor: string;
    prospectPostContent: string;
    status: 'found' | 'comment_generated' | 'posted' | 'error';
    sourcePostUrl: string;
    generatedComment?: string;
    postingAccountId: string;
    postingAccountName: string;
}


export interface MonitoredBacklink {
    id: string;
    url: string; // The URL of the page that should contain the backlink
    targetUrl: string; // The URL on our site it should link to
    status: 'pending' | 'active' | 'inactive' | 'not_found';
    anchorText: string | null;
    dateFound: number;
    lastChecked: number | null;
    domainAuthority: number | null; // e.g., Moz DA or Ahrefs DR
}

export interface PostPerformanceData {
    postId: string;
    title: string;
    url: string;
    focusKeyword: string;
    searchConsole: {
        clicks: number;
        impressions: number;
        ctr: number;
        position: number;
    };
    analytics: {
        pageviews: number;
        users: number;
        avgTimeOnPage: number; // in seconds
    };
}

export interface AnalyticsInsight {
    insights: string[];
    recommendations: { text: string; pro: boolean }[];
}

export interface MailchimpAudience {
    id: string;
    name: string;
}

export interface MailchimpAccount {
    isConnected: boolean;
    apiKey: string;
    serverPrefix: string;
    status: 'disconnected' | 'connected' | 'error';
    statusMessage?: string;
    availableAudiences?: MailchimpAudience[];
    defaultAudienceId?: string;
}


export interface EmailMarketingCampaign {
    subject: string;
    body: string; // HTML body
}

// Fix: Add LogLevel type export
export type LogLevel = 'SUCCESS' | 'ERROR' | 'INFO' | 'WARN';

export interface LogEntry {
    timestamp: number;
    message: string;
// Fix: Use LogLevel type
    type: LogLevel;
    siteId?: string;
}

export interface MCPServer {
    id: string;
    name: string;
    url: string;
    status: 'connected' | 'disconnected' | 'error' | 'connecting';
    statusMessage?: string;
}

export interface SelfTestResult {
    id: string;
    status: 'untested' | 'running' | 'pass' | 'fail';
    message?: string;
}

export interface PerformanceRecommendation {
    id: string;
    type: 'cache' | 'plugin' | 'image' | 'security';
    title: string;
    description: string;
    action: string;
    actionLabel: string;
}


export interface HostingStatus {
    isConnected: boolean;
    provider: '10web' | null;
    siteTitle: string;
    performance: {
        score: number;
        lastChecked: string;
    };
    security: {
        status: 'secure' | 'vulnerable';
        lastScan: string;
        vulnerabilities: number;
    };
    backups: {
        lastBackup: string;
        // Fix: Changed 'failed' to 'fail' to match the StatCard component's prop type
        status: 'ok' | 'fail';
    };
    performanceHistory: { date: string, score: number }[];
    recommendations: PerformanceRecommendation[];
}

// Fix: Add WebsitePlan interface
export interface WebsitePlan {
    nameSuggestions: string[];
    taglineSuggestions: string[];
    corePages: string[];
    colorPalette: { hex: string, name: string }[];
    typography: { heading: string, body: string };
    businessType: string;
    keywords: string[];
}

// Fix: Add AutomationStep interface export
export interface AutomationStep {
  title: string;
  icon: React.FC<React.SVGProps<SVGSVGElement> & { title?: string }>;
}


export interface Site {
  id: string;
  name: string;
  wordpressUrl: string;
  wordpressUsername: string;
  applicationPassword: string;
  brandGuideline: string;
  brandLogo?: string;
  brandColors?: string[];
  brandFonts?: string[];
  promoLink1?: string;
  promoLink2?: string;
  nicheTargeting?: string;
  keywordList: string;
  videoSources: VideoSource[];
  references: ReferenceItem[];
  characterLibrary?: CharacterReference[];
  authorName: string;
  authorId?: number;
  availableAuthors: WordPressAuthor[];
  availableCategories: WordPressCategory[];
  history: PostHistoryItem[];
  isAutomationEnabled: boolean;
  automationTrigger: 'interval' | 'schedule';
  automationIntervalHours: number;
  lastAutoPilotRun?: number;
  recurringSchedules: RecurringSchedule[];
  isAutoPublishEnabled: boolean;
  drafts: Draft[];
  isDraftNotificationEnabled: boolean;
  draftNotificationMethods: ('whatsapp' | 'telegram' | 'email')[];
  draftNotificationEmail: string;
  masterAutomationSource: 'keyword' | 'rss' | 'video' | 'google_sheet';
  intervalGenerationSource: 'keyword' | 'rss' | 'video';
  scheduleGenerationSource: 'keyword' | 'rss' | 'video';
  rssFeedUrl: string;
  processedRssGuids: string[];
  googleSheetUrl: string;
  googleSheetProcessedRows: number[];
  isLocalSeoEnabled?: boolean;
  localSeoBusinessName?: string;
  localSeoServiceArea?: string;
  localSeoPhoneNumber?: string;
  socialMediaSettings: SocialMediaSettings;
  seoDataProvider: 'google_search' | 'standalone_gemini' | 'standalone_openai' | 'standalone_xai' | 'standalone_perplexity' | 'standalone_openrouter' | 'dataforseo_gemini' | 'dataforseo_openai' | 'dataforseo_xai' | 'dataforseo_perplexity';
  dataforseoSeedKeywords: string;
  dataforseoTargetLocation: string;
  dataforseoTargetLanguage: string;
  dataforseoSearchVolumeMin: number;
  dataforseoSearchVolumeMax: number;
  dataforseoKeywordDifficultyMin: number;
  dataforseoKeywordDifficultyMax: number;
  modelConfig: ModelConfig;
  blogPostAutomationModelConfig?: ModelConfig;
  socialGraphicAutomationModelConfig?: ModelConfig;
  socialVideoAutomationModelConfig?: ModelConfig;
  apiKeys: ApiKeys;
  apiUsage?: Partial<Record<keyof ApiKeys, number>>;
  fetchedModels?: Partial<Record<AiProvider, { text: string[], image: string[], video?: string[] }>>;
  isSocialGraphicAutomationEnabled: boolean;
  socialGraphicAutomationTrigger: 'interval' | 'schedule';
  socialGraphicAutomationIntervalHours: number;
  lastSocialGraphicAutoPilotRun?: number;
  socialGraphicRecurringSchedules: RecurringSchedule[];
  socialGraphicGenerationSource: 'keyword' | 'rss' | 'video';
  isSocialVideoAutomationEnabled: boolean;
  socialVideoAutomationTrigger: 'interval' | 'schedule';
  socialVideoAutomationIntervalHours: number;
  lastSocialVideoAutoPilotRun?: number;
  socialVideoRecurringSchedules: RecurringSchedule[];
  socialVideoGenerationSource: 'keyword' | 'rss' | 'video';
  googleDrive?: {
    isConnected: boolean;
    userEmail: string;
  };
   googleAnalytics?: {
    isConnected: boolean;
    userEmail: string;
  };
  isBacklinksAutomationEnabled: boolean;
  backlinksCompetitors: string; // comma-separated list of competitor domains
  backlinksOwnDomain: string;
  backlinksEmailProvider: 'mailgun' | 'sendgrid';
  backlinksFromName: string;
  backlinksFromEmail: string;
  backlinksEmailSubject: string;
  backlinksEmailBody: string; // Template with placeholders like [Personalization]
  backlinksHistory: BacklinksHistoryItem[];
  backlinksIntervalHours: number;
  commentingProspects: CommentingProspect[];
  isSocialCommentingEnabled: boolean;
  socialCommentingKeywords: string; // newline-separated
  socialCommentingGuideline: string;
  socialCommentingProspects: SocialCommentingProspect[];
  monitoredBacklinks: MonitoredBacklink[];
  isBacklinkMonitoringEnabled: boolean;
  isEmailFollowUpEnabled: boolean;
  isSocialFollowUpEnabled: boolean;
  emailMarketingSettings?: {
    fromName: string;
    fromEmail: string;
    targetList: string; // e.g., Mailchimp Audience ID
  };
  emailMarketingModelConfig?: ModelConfig;
  isEmailMarketingAutomationEnabled?: boolean;
  emailMarketingAutomationTrigger?: 'interval' | 'schedule';
  emailMarketingAutomationIntervalHours?: number;
  lastEmailMarketingAutoPilotRun?: number;
  emailMarketingRecurringSchedules?: RecurringSchedule[];
  isDigestAutomationEnabled?: boolean;
  digestRecurringSchedules?: RecurringSchedule[];
  processedDigestGuids?: string[];
  digestAutomationModelConfig?: ModelConfig;
  mailchimp?: MailchimpAccount;
  automationLock?: {
    jobType: string;
    lockedAt: number; // timestamp
  } | null;
  hosting?: {
    isConnected: boolean;
    status?: HostingStatus;
  }
}