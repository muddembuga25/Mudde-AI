

import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { Routes, Route, NavLink as RouterNavLink, useNavigate } from 'react-router-dom';
import { useSitesContext } from './contexts/SitesContext';
import { useAuth } from './contexts/AuthContext';
import { useGodMode } from './contexts/GodModeContext';
import { useAutomatedJobs } from './hooks/useAutomatedJobs';
import type { Site, PostHistoryItem, Draft, LogEntry, RssItem, SocialMediaAccount, WhatsAppAccount, TelegramAccount, PostPerformanceData, BlogPost, StrategicBrief, SeoScoreResult, SocialMediaSettings, SelfTestResult } from './types';
import { AppStatus } from './types';
import * as oauthService from './services/oauthService';
import * as mcpApiService from './services/mcpApiService';
import * as googleDriveService from './services/googleDriveService';
import { PLAN_LIMITS } from './constants';
import { calculateSeoScore } from './services/seoService';
import { WelcomeScreen } from './components/WelcomeScreen';


import {
  ArrowLeftOnRectangleIcon, Bars3Icon, UserIcon, XIcon,
  HomeIcon, DocumentTextIcon, PhotoIcon, VideoCameraIcon, ClockIcon,
  ArchiveBoxIcon, PenIcon, ServerIcon, KeyIcon, UsersIcon,
  ArrowPathIcon, ChartBarIcon, LinkIcon, SparklesIcon,
  GoogleSheetsIcon, RssIcon, MailIcon, HostingIcon, ShieldCheckIcon, ShareIcon,
  WordPressIcon, ExclamationTriangleIcon, ChevronDownIcon, BoltIcon, CheckCircleIcon, SpinnerIcon
} from './components/Icons';

import { DashboardTab } from './components/DashboardTab';
import { KeywordContentTab } from './components/KeywordContentTab';
import { RssContentTab } from './components/RssContentTab';
import { VideoContentTab } from './components/VideoContentTab';
import { GoogleSheetContentTab } from './components/GoogleSheetContentTab';
import { HistoryTab } from './components/HistoryTab';
import { DraftsTab } from './components/DraftsTab';
import { AutomationDashboard } from './components/AutomationDashboard';
import { WordPressTab } from './components/WordPressTab';
import { SettingsTab } from './components/SettingsTab';
import { APIKeysTab } from './components/APIKeysTab';
import { SocialMediaTab } from './components/SocialMediaTab';
import { ReferencesTab } from './components/ReferencesTab';
import { BacklinksTab } from './components/BacklinksTab';
import { SocialGraphicsTab } from './components/SocialGraphicsTab';
import { SocialVideoTab } from './components/SocialVideoTab';
import { EmailMarketingTab } from './components/EmailMarketingTab';
import { AnalyticsTab } from './components/AnalyticsTab';
import { BillingTab } from './components/BillingTab';
import { ClientsTab } from './components/ClientsTab';
import { MCPTab } from './components/MCPTab';
import { HostingTab } from './components/HostingTab';
import { IntegrationsTab } from './components/IntegrationsTab';
import { ProfileModal } from './components/ProfileModal';
import { HistoryDetailViewer } from './components/HistoryDetailViewer';
import { PublishSuccessViewer } from './components/PublishSuccessViewer';
import { ArticleViewer } from './components/ArticleViewer';
import { GlobalAutomationTracker } from './components/GlobalAutomationTracker';
import { GeminiLiveAssistant } from './components/GeminiLiveAssistant';
import { WebsiteCreatorTab } from './components/WebsiteCreatorTab';
import { CommandPalette } from './components/GodMode/CommandPalette';
// Fix: Import `AutomationStep` from `AutomationProcessVisualizer` where it is defined, instead of from `types.ts`.
import { AutomationProcessVisualizer, type AutomationStep } from './components/AutomationProcessVisualizer';

type ModalType = 'delete' | 'history-detail' | 'profile';

// Fix: Add explicit types for navigation items to resolve type inference issues.
interface BaseNavItem {
  id: string;
  label: string;
  icon: React.FC<React.SVGProps<SVGSVGElement>>;
}

interface NavLinkItem extends BaseNavItem {
  path: string;
  title: string;
  description: string;
}

interface NavGroupItem extends BaseNavItem {
  subItems: NavLinkItem[];
}

type NavItem = NavLinkItem | NavGroupItem;


const navItems: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: HomeIcon, path: '/', title: "Dashboard", description: "An overview of your site's content automation and performance." },
    { id: 'website-creator', label: 'AI Website Builder', icon: SparklesIcon, path: '/website-creator', title: "AI Website Builder", description: "Go from idea to a live, AI-generated WordPress site in minutes, powered by 10Web." },
    { id: 'content', label: 'Content', icon: PenIcon, subItems: [
        { id: 'content-keywords', label: 'Keyword', icon: DocumentTextIcon, path: '/content/keywords', title: "Keyword Content", description: "Enter one keyword or topic per line. The AI will write an article for the first available keyword." },
        { id: 'content-rss', label: 'RSS Feed', icon: RssIcon, path: '/content/rss', title: "RSS Feed Content", description: "Provide an RSS feed URL. The app will fetch the latest items for you to generate content from." },
        { id: 'content-video', label: 'Video', icon: VideoCameraIcon, path: '/content/video', title: "Video Content", description: "Add YouTube channel URLs or individual video URLs as a source for content ideas." },
        { id: 'content-sheets', label: 'Google Sheet', icon: GoogleSheetsIcon, path: '/content/sheets', title: "Google Sheet Content", description: "Connect a public Google Sheet. The AI will use the first column as the topic." },
    ]},
    { id: 'social-graphics', label: 'Social Graphics', icon: PhotoIcon, path: '/social-graphics', title: "Social Graphics Generator", description: "Create and publish a one-off social media graphic." },
    { id: 'social-videos', label: 'Social Videos', icon: VideoCameraIcon, path: '/social-videos', title: "Social Video Generator", description: "Create and publish a one-off short-form video for social media." },
    { id: 'email-marketing', label: 'Email Marketing', icon: MailIcon, path: '/email-marketing', title: "Email Marketing Generator", description: "Create and send a one-off email campaign to your audience." },
    { id: 'drafts', label: 'Drafts', icon: DocumentTextIcon, path: '/drafts', title: "Generated Drafts", description: "These posts were generated by your automation workflow and are ready for your review." },
    { id: 'history', label: 'History', icon: ArchiveBoxIcon, path: '/history', title: "Content History", description: "Browse all the blog posts and social media content that have been generated for this site." },
    { id: 'analytics', label: 'Analytics', icon: ChartBarIcon, path: '/analytics', title: "Analytics Dashboard", description: "Review your content's performance and get AI-driven advice." },
    { id: 'authority', label: 'Authority', icon: LinkIcon, path: '/authority', title: "Authority Building", description: "Tools to help build your website's authority through backlinks and engagement." },
    { id: 'automation', label: 'Automation', icon: ClockIcon, path: '/automation', title: "Automation Configuration", description: "Set up and manage all automated content workflows for your site." },
    { id: 'settings', label: 'Settings', icon: SparklesIcon, subItems: [
        { id: 'settings-general', label: 'General', icon: SparklesIcon, path: '/settings/general', title: "General Settings", description: "Manage this workflow's core configuration, including AI models and SEO data providers." },
        { id: 'settings-wordpress', label: 'WordPress', icon: WordPressIcon, path: '/settings/wordpress', title: "WordPress Integration", description: "Connect your WordPress site to enable direct publishing." },
        { id: 'settings-social', label: 'Social Media', icon: ShareIcon, path: '/settings/social', title: "Social Media Connections", description: "Add multiple accounts, enter developer credentials, and connect to enable automatic sharing." },
        { id: 'settings-references', label: 'Knowledge Base', icon: ArchiveBoxIcon, path: '/settings/references', title: "Knowledge & Branding", description: "Manage a persistent knowledge base and brand identity for this site." },
        { id: 'settings-keys', label: 'API Keys', icon: KeyIcon, path: '/settings/keys', title: "API Keys & Spend", description: "Manage your API keys and monitor your estimated spend across all services." },
        { id: 'settings-integrations', label: 'Integrations', icon: ShieldCheckIcon, path: '/settings/integrations', title: "Integrations Status", description: "Check the status of all your connections to ensure the application is ready to automate." },
        { id: 'settings-hosting', label: 'Hosting', icon: HostingIcon, path: '/settings/hosting', title: "10Web Hosting Integration", description: "Deploy, manage, and optimize your site with AI-powered hosting." },
    ]},
    { id: 'billing', label: 'Billing', icon: UsersIcon, path: '/billing', title: "Billing & Plans", description: "Manage your subscription plan and view your current usage." },
    { id: 'clients', label: 'Clients', icon: UsersIcon, path: '/clients', title: "Client Management", description: "This feature is available for Agency plans. Manage your client sites from a central dashboard." },
    { id: 'mcp', label: 'MCP', icon: ServerIcon, path: '/mcp', title: "Master Control Panel (MCP)", description: "Developer tools for inspecting state and triggering actions." },
];

// Fix: Use a type guard ('subItems' in item) with flatMap to correctly flatten the navItems array.
// This resolves the complex type error and the subsequent property access errors.
const allNavItems = navItems.flatMap(item => ('subItems' in item ? item.subItems : [item]));

const PageWrapper: React.FC<{ 
    title: string; 
    description?: string; 
    children: React.ReactNode; 
    siteName?: string;
    isEditing: boolean;
    editedName: string;
    onNameChange: (name: string) => void;
    onStartEditing: () => void;
    onCommitEdit: () => void;
    onKeyDown: (e: React.KeyboardEvent<HTMLInputElement>) => void;
}> = ({ 
    title, description, children, siteName, 
    isEditing, editedName, onNameChange, onStartEditing, onCommitEdit, onKeyDown
}) => (
    <>
        <div className="page-header">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <div className="flex items-center gap-3 min-w-0">
                    <h2 className="text-2xl font-bold text-white truncate">{title}</h2>
                    {siteName && (
                        <div className="flex items-center gap-2 text-2xl font-bold text-text-secondary group">
                            <span>for</span>
                            {isEditing ? (
                                <input
                                    type="text"
                                    value={editedName}
                                    onChange={(e) => onNameChange(e.target.value)}
                                    onKeyDown={onKeyDown}
                                    onBlur={onCommitEdit}
                                    className="input-base text-2xl font-bold !bg-panel-light p-1 rounded-md"
                                    autoFocus
                                    onFocus={(e) => e.target.select()}
                                />
                            ) : (
                                <>
                                    <span className="text-white truncate" title={siteName}>{siteName}</span>
                                    <button onClick={onStartEditing} className="p-1 opacity-0 group-hover:opacity-100 focus:opacity-100 transition-opacity" title="Rename workflow">
                                        <PenIcon className="h-5 w-5 text-text-secondary hover:text-white" />
                                    </button>
                                </>
                            )}
                        </div>
                    )}
                </div>
                {description && <p className="text-sm text-text-secondary mt-1 sm:mt-0 sm:text-right max-w-sm">{description}</p>}
            </div>
        </div>
        <div className="animate-fade-in-up">
            {children}
        </div>
    </>
);


export const MainApp: React.FC = () => {
    const { currentUser, logout, incrementPostCount } = useAuth();
    const { 
        sites, setSites, selectedSite, selectedSiteId, setSelectedSiteId, 
        isSaved, isSaving, isLoading, handleSiteUpdate, handleMultipleSiteUpdates, 
        handleAddNewSite, handleDeleteSite, handleResetAllSitesSpend 
    } = useSitesContext();
     const { toggleGodMode } = useGodMode();

    const [modal, setModal] = useState<ModalType | null>(null);
    const [selectedHistoryItem, setSelectedHistoryItem] = useState<PostHistoryItem | null>(null);
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [expandedNavItems, setExpandedNavItems] = useState<Record<string, boolean>>({ content: true, settings: true });
    const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);

    // Global App State for generation/publishing flow
    const [appStatus, setAppStatus] = useState<AppStatus>(AppStatus.IDLE);
    const [statusMessage, setStatusMessage] = useState('');
    const [currentBlogPost, setCurrentBlogPost] = useState<BlogPost | null>(null);
    const [currentBrief, setCurrentBrief] = useState<StrategicBrief | null>(null);
    const [currentSeoScore, setCurrentSeoScore] = useState<SeoScoreResult | null>(null);
    const [publishedPostUrl, setPublishedPostUrl] = useState<string | null>(null);
    const [publishingLog, setPublishingLog] = useState<any[]>([]);
    const [currentDraft, setCurrentDraft] = useState<Draft | null>(null);

    // Automation state
    const [logs, setLogs] = useState<LogEntry[]>([]);
    const [automationStates, setAutomationStates] = useState<Record<string, { siteId: string; status: AppStatus; statusMessage: string; topic: string | null }>>({});
    
    // Per-tab fetched data cache is now co-located in each tab component.
    const [mcpServers, setMcpServers] = useState<any[]>([]);
    const [activeMCPServerId, setActiveMCPServerId] = useState<string | null>(null);
    const [mcpActiveView, setMcpActiveView] = useState<'state' | 'logs' | 'actions' | 'servers' | 'selftest' | 'dataforseo'>('selftest');
    const [mcpTestResults, setMcpTestResults] = useState<Record<string, SelfTestResult>>({});
    
    // Workflow renaming state
    const [isEditingSiteName, setIsEditingSiteName] = useState(false);
    const [editedSiteName, setEditedSiteName] = useState('');

    // Google OAuth State
    const [googleApiLoaded, setGoogleApiLoaded] = useState(false);
    const [googleAccessToken, setGoogleAccessToken] = useState<string | null>(null);


    const navigate = useNavigate();

    const canAddSite = useMemo(() => {
        if (!currentUser) return false;
        const planLimits = PLAN_LIMITS[currentUser.subscription.plan];
        return sites.length < planLimits.sites;
    }, [sites, currentUser]);

    const isPostLimitReached = useMemo(() => {
        if (!currentUser) return true;
        const planLimits = PLAN_LIMITS[currentUser.subscription.plan];
        return currentUser.subscription.postsGeneratedThisMonth >= planLimits.posts;
    }, [currentUser]);

    const addLog = useCallback((message: string, type: LogEntry['type'], siteId: string) => {
        setLogs(prev => [{ timestamp: Date.now(), message, type, siteId }, ...prev].slice(0, 200));
    }, []);
    
     const handleAutomationProgress = useCallback((update: { siteId: string; status: AppStatus; statusMessage: string; topic?: string }) => {
        if ([AppStatus.PUBLISHED, AppStatus.ERROR, AppStatus.IDLE].includes(update.status)) {
            // Persist the final state for a few seconds before clearing
            setTimeout(() => {
                setAutomationStates(prev => {
                    const newStates = { ...prev };
                    delete newStates[update.siteId];
                    return newStates;
                });
            }, 5000);
        }
        setAutomationStates(prev => ({
            ...prev,
            [update.siteId]: {
                ...prev[update.siteId],
                siteId: update.siteId,
                status: update.status,
                statusMessage: update.statusMessage,
                ...(update.topic && { topic: update.topic }),
            }
        }));
    }, []);

    const { isBacklinksJobRunning, runBacklinksJobNow } = useAutomatedJobs(sites, setSites, addLog, handleAutomationProgress);

    const [error, setError] = useState<string | null>(null);
    const errorTimeoutRef = useRef<number | null>(null);
    
    useEffect(() => {
        if (error && errorTimeoutRef.current) clearTimeout(errorTimeoutRef.current);
        if (error) { errorTimeoutRef.current = window.setTimeout(() => setError(null), 8000); }
        return () => { if (errorTimeoutRef.current) clearTimeout(errorTimeoutRef.current); }
    }, [error]);
    
    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if ((event.metaKey || event.ctrlKey) && event.key === 'k') {
                event.preventDefault();
                setIsCommandPaletteOpen(p => !p);
            }
             if ((event.metaKey || event.ctrlKey) && event.key === 'g') {
                event.preventDefault();
                toggleGodMode();
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [toggleGodMode]);

    useEffect(() => {
        if (selectedSite && !isEditingSiteName) {
            setEditedSiteName(selectedSite.name);
        }
    }, [selectedSite, isEditingSiteName]);

    const handleRenameSite = useCallback(() => {
        if (selectedSite && editedSiteName.trim() && editedSiteName.trim() !== selectedSite.name) {
            handleSiteUpdate('name', editedSiteName.trim());
        }
        setIsEditingSiteName(false);
    }, [selectedSite, editedSiteName, handleSiteUpdate]);

    const handleRenameKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            handleRenameSite();
        }
        if (e.key === 'Escape') {
            setIsEditingSiteName(false);
            if (selectedSite) {
                setEditedSiteName(selectedSite.name);
            }
        }
    };


    const handleViewHistoryDetails = (item: PostHistoryItem) => {
        setSelectedHistoryItem(item);
        setModal('history-detail');
    };

    const resetGenerationState = useCallback(() => {
        setAppStatus(AppStatus.IDLE);
        setStatusMessage('');
        setCurrentBlogPost(null);
        setCurrentBrief(null);
        setCurrentSeoScore(null);
        setPublishedPostUrl(null);
        setPublishingLog([]);
        setCurrentDraft(null);
        // Navigate back to dashboard on reset if not already there
        if (window.location.pathname !== '/') {
            navigate('/');
        }
    }, [navigate]);

    const handleGenerateAndScore = useCallback(async (topic: string, sourceType: any, sourceDetails: any, site: Site, options?: any) => {
        if (!site || !currentUser) return;
        const planLimits = PLAN_LIMITS[currentUser.subscription.plan];
        if (currentUser.subscription.postsGeneratedThisMonth >= planLimits.posts) {
            setError(`You have reached your monthly limit of ${planLimits.posts} posts. Please upgrade your plan to generate more.`);
            return;
        }

        resetGenerationState();
        setAppStatus(AppStatus.GENERATING_STRATEGY);
        try {
            const progressCallback = (update: { status: AppStatus; message: string; }) => {
                setAppStatus(update.status);
                setStatusMessage(update.message);
            };
            const { draft, score, updatedSite } = await mcpApiService.runManualGenerationPipeline(site.id, sourceType, sourceDetails, options, progressCallback);
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
            setCurrentBlogPost(draft.blogPost);
            setCurrentBrief(draft.brief);
            setCurrentSeoScore(score);
            setCurrentDraft(draft);
            setAppStatus(AppStatus.READY_TO_PUBLISH);
        } catch (e: any) {
            setError(e.message);
            setAppStatus(AppStatus.ERROR);
        }
    }, [resetGenerationState, setSites, setError, currentUser]);
    
    const handlePublish = useCallback(async (editedPost: BlogPost) => {
        if (!selectedSite || !currentDraft) return;
        setAppStatus(AppStatus.PUBLISHING);
        setStatusMessage('Publishing post...');
        try {
            const { postUrl, publishingLog, updatedSite } = await mcpApiService.publishPostAndFollowUps(selectedSite.id, currentDraft, editedPost);
            setSites(prev => prev.map(s => s.id === selectedSite.id ? updatedSite : s));
            setPublishedPostUrl(postUrl);
            setPublishingLog(publishingLog);
            incrementPostCount();
            setAppStatus(AppStatus.PUBLISHED);
        } catch (e: any) {
            setError(e.message);
            setAppStatus(AppStatus.ERROR);
        }
    }, [selectedSite, currentDraft, setSites, incrementPostCount, setError]);

    // Handle OAuth Callback
    const [isConnectingSocial, setIsConnectingSocial] = useState<string | null>(null);
    useEffect(() => {
        const result = oauthService.handleOAuthCallback();
        if (result) {
            const { platform, siteId, accountId, code } = result;
            setIsConnectingSocial(`${platform}-${accountId}`);
            mcpApiService.exchangeCodeForToken(siteId, platform as any, accountId, code)
                .then(({ updatedSite }) => {
                    setSites(prev => prev.map(s => s.id === siteId ? updatedSite : s));
                    navigate('/settings/social');
                })
                .catch(e => setError(e.message))
                .finally(() => setIsConnectingSocial(null));
        }
    }, [setSites, setError, navigate]);

    const handleConnectSocial = (platform: keyof Omit<SocialMediaSettings, 'whatsapp' | 'telegram'>, accountId: string) => {
        if (!selectedSite) return;
        const account = (selectedSite.socialMediaSettings[platform] as SocialMediaAccount[])?.find(a => a.id === accountId);
        if (account?.clientId) {
            oauthService.redirectToAuth(platform, account.clientId, selectedSite.id, accountId);
        } else {
            setError(`Client ID for this ${platform} account is missing.`);
        }
    };

    const handleReviewDraft = (draftId: string) => {
        if (!selectedSite) return;
        const draftToReview = selectedSite.drafts.find(d => d.id === draftId);
        if (draftToReview) {
            resetGenerationState();
            setCurrentBlogPost(draftToReview.blogPost);
            setCurrentBrief(draftToReview.brief);
            const score = calculateSeoScore(draftToReview.blogPost, draftToReview.brief);
            setCurrentSeoScore(score);
            setCurrentDraft(draftToReview);
            setAppStatus(AppStatus.READY_TO_PUBLISH);
        }
    };

    const handleDiscardDraft = (draftId: string) => {
        if (!selectedSite) return;
        const updatedDrafts = selectedSite.drafts.filter(d => d.id !== draftId);
        handleSiteUpdate('drafts', updatedDrafts);
    };
    
    const [performanceData, setPerformanceData] = useState<PostPerformanceData[] | undefined>(undefined);
    const [isFetchingPerformance, setIsFetchingPerformance] = useState(false);

    const fetchPerformanceData = useCallback(async () => {
        if (selectedSite && selectedSite.googleAnalytics?.isConnected) {
            setIsFetchingPerformance(true);
            setError(null);
            try {
                const { performanceData: data } = await mcpApiService.fetchPerformanceData(selectedSite.id);
                setPerformanceData(data);
            } catch (e: any) {
                setError(e.message);
            } finally {
                setIsFetchingPerformance(false);
            }
        } else {
            setPerformanceData(undefined);
        }
    }, [selectedSite, setError]);

    useEffect(() => {
        fetchPerformanceData();
    }, [fetchPerformanceData]);

    // --- Google API and OAuth ---
    useEffect(() => {
        googleDriveService.loadGapi()
            .then(() => setGoogleApiLoaded(true))
            .catch(err => setError("Failed to load Google API scripts. Integration features may not work."));
    }, [setError]);

    const handleGoogleConnect = useCallback((scope: string, callback: (tokenResponse: any) => void) => {
        if (!googleApiLoaded) {
            setError("Google API is not loaded yet. Please try again in a moment.");
            return;
        }
        if (!selectedSite?.apiKeys.googleClientId) {
            setError("Google Client ID is not configured in Settings > API Keys.");
            return;
        }

        const client = google.accounts.oauth2.initTokenClient({
            client_id: selectedSite.apiKeys.googleClientId,
            scope: scope,
            callback: (tokenResponse: any) => {
                if (tokenResponse && tokenResponse.access_token) {
                    callback(tokenResponse);
                } else {
                    setError('Failed to get access token from Google.');
                }
            },
            error_callback: (err: any) => setError(`Google authentication error: ${err.type}`),
        });
        client.requestAccessToken({ prompt: 'consent' });
    }, [googleApiLoaded, selectedSite, setError]);

    const handleConnectGoogleDrive = useCallback(() => {
        handleGoogleConnect('https://www.googleapis.com/auth/drive.file', async (tokenResponse) => {
            if (selectedSite) {
                setGoogleAccessToken(tokenResponse.access_token);
                const res = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', { headers: { 'Authorization': `Bearer ${tokenResponse.access_token}` } });
                const userInfo = await res.json();
                const { updatedSite } = await mcpApiService.connectGoogleDrive(selectedSite.id, userInfo.email);
                handleMultipleSiteUpdates(updatedSite);
            }
        });
    }, [handleGoogleConnect, selectedSite, handleMultipleSiteUpdates]);
    
    const handleConnectGoogleAnalytics = useCallback(() => {
        handleGoogleConnect('https://www.googleapis.com/auth/analytics.readonly', async (tokenResponse) => {
            if (selectedSite) {
                setGoogleAccessToken(tokenResponse.access_token);
                const res = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', { headers: { 'Authorization': `Bearer ${tokenResponse.access_token}` } });
                const userInfo = await res.json();
                const { updatedSite } = await mcpApiService.connectGoogleAnalytics(selectedSite.id, userInfo.email);
                handleMultipleSiteUpdates(updatedSite);
                fetchPerformanceData();
            }
        });
    }, [handleGoogleConnect, selectedSite, handleMultipleSiteUpdates, fetchPerformanceData]);
    
    const handleGoogleDisconnect = (disconnectServiceFn: (siteId: string) => Promise<{ updatedSite: Site }>) => {
        if (googleAccessToken) {
            google.accounts.oauth2.revoke(googleAccessToken, async () => {
                if (selectedSite) {
                    const { updatedSite } = await disconnectServiceFn(selectedSite.id);
                    handleMultipleSiteUpdates(updatedSite);
                    setGoogleAccessToken(null);
                }
            });
        } else if (selectedSite) { // Fallback if token is not in state
            disconnectServiceFn(selectedSite.id).then(({ updatedSite }) => handleMultipleSiteUpdates(updatedSite));
        }
    };

    const handleShowGooglePicker = useCallback(() => {
        if (!googleAccessToken || !selectedSite?.apiKeys.google) {
            setError("Please connect to Google Drive first or ensure a Google API key is set in settings.");
            return;
        }
        googleDriveService.createPicker(
            selectedSite.apiKeys.google,
            googleAccessToken,
            async (docs) => {
                for (const doc of docs) {
                    const { updatedSite } = await mcpApiService.addDriveFileReference(selectedSite.id, { id: doc.id, name: doc.name, mimeType: doc.mimeType });
                    handleMultipleSiteUpdates(updatedSite);
                }
            },
            () => {} // onCancel
        );
    }, [googleAccessToken, selectedSite, setError, handleMultipleSiteUpdates]);
    
    const handleSaveToDrive = useCallback(async (title: string, content: string) => {
        if (!googleAccessToken) {
            setError("Cannot save to drive: Not connected to Google Drive.");
            throw new Error("Not connected to Google Drive.");
        }
        await googleDriveService.createDocFromHtml(title, content, googleAccessToken);
    }, [googleAccessToken, setError]);

    const handleVerifySocial = useCallback(async (platform: oauthService.SocialPlatform, accountId: string) => {
        if (!selectedSite) return;
        try {
            const { updatedSite } = await mcpApiService.verifySocialConnection(selectedSite.id, platform, accountId);
            handleMultipleSiteUpdates(updatedSite);
        } catch (e: any) {
            setError(`Verification failed for ${platform}: ${e.message}`);
        }
    }, [selectedSite, handleMultipleSiteUpdates, setError]);
    
    const handleVerifyCredentialedSocial = useCallback(async (platform: 'whatsapp' | 'telegram', account: WhatsAppAccount | TelegramAccount) => {
        if (!selectedSite) return;
        try {
            const { updatedSite } = await mcpApiService.verifyCredentialedSocialConnection(selectedSite.id, platform, account.id);
            handleMultipleSiteUpdates(updatedSite);
        } catch (e: any) {
            setError(`Verification failed for ${platform}: ${e.message}`);
        }
    }, [selectedSite, handleMultipleSiteUpdates, setError]);
    
    const renderContent = () => {
        if (appStatus === AppStatus.PUBLISHED) {
            return <PublishSuccessViewer publishedPostUrl={publishedPostUrl} publishingLog={publishingLog} onReset={resetGenerationState} />;
        }
        if (appStatus !== AppStatus.IDLE && appStatus !== AppStatus.ERROR) {
            if (currentBlogPost && currentBrief && selectedSite && currentUser) {
                return <ArticleViewer
                    blogPost={currentBlogPost} brief={currentBrief} seoScore={currentSeoScore} status={appStatus} statusMessage={statusMessage} site={selectedSite}
                    currentUser={currentUser} onPublish={handlePublish} onCancel={resetGenerationState} onSaveToDrive={handleSaveToDrive}
                />;
            }

            // If we are in a generation state but the blog post isn't ready yet, show a progress screen.
            if (appStatus !== AppStatus.READY_TO_PUBLISH) {
                const steps: AutomationStep[] = [
                    { title: 'Strategy', icon: SparklesIcon },
                    { title: 'Writing', icon: PenIcon },
                    { title: 'Image', icon: PhotoIcon },
                    { title: 'SEO', icon: ShieldCheckIcon },
                ];

                const statusToStepMap: Partial<Record<AppStatus, number>> = {
                    [AppStatus.GENERATING_STRATEGY]: 0,
                    [AppStatus.GENERATING_ARTICLE]: 1,
                    [AppStatus.GENERATING_IMAGE]: 2,
                    [AppStatus.OPTIMIZING_ARTICLE]: 3,
                };

                const currentStepIndex = statusToStepMap[appStatus] ?? -1;

                return (
                     <div className="flex items-center justify-center h-full w-full">
                        <div className="text-center bg-panel/50 p-8 rounded-2xl border border-border max-w-2xl mx-auto animate-fade-in-up">
                            <h2 className="text-2xl font-bold text-white mb-2">Generating Your Article...</h2>
                            <p className="text-text-secondary mb-8">The AI is working. This may take a moment.</p>
                            <AutomationProcessVisualizer
                                steps={steps}
                                currentStepIndex={currentStepIndex}
                                layout="horizontal"
                            />
                        </div>
                    </div>
                );
            }
        }

        if (!selectedSite) {
            return (
                <div className="flex items-center justify-center h-full w-full">
                    <div className="text-center">
                        <p className="text-text-secondary">Please select a workflow from the sidebar.</p>
                    </div>
                </div>
            );
        }
        
        return (
            <Routes>
                {allNavItems.map(item => (
                    <Route
                        key={item.id}
                        path={item.path}
                        element={
                            <PageWrapper 
                                title={item.title || item.label} 
                                description={item.description}
                                siteName={selectedSite.name}
                                isEditing={isEditingSiteName}
                                editedName={editedSiteName}
                                onNameChange={setEditedSiteName}
                                onStartEditing={() => setIsEditingSiteName(true)}
                                onCommitEdit={handleRenameSite}
                                onKeyDown={handleRenameKeyDown}
                            >
                                {(() => {
                                    switch (item.path) {
                                        case '/': return <DashboardTab site={selectedSite} />;
                                        case '/website-creator': return <WebsiteCreatorTab />;
                                        case '/content/keywords': return <KeywordContentTab site={selectedSite} onSiteUpdate={handleSiteUpdate} onGenerateAndScore={handleGenerateAndScore} setError={setError} isPostLimitReached={isPostLimitReached} />;
                                        case '/content/rss': return <RssContentTab site={selectedSite} onSiteUpdate={handleSiteUpdate} onGenerateAndScore={handleGenerateAndScore} setError={setError} isPostLimitReached={isPostLimitReached} />;
                                        case '/content/video': return <VideoContentTab site={selectedSite} onSiteUpdate={handleSiteUpdate} onGenerateAndScore={handleGenerateAndScore} setError={setError} isPostLimitReached={isPostLimitReached} />;
                                        case '/content/sheets': return <GoogleSheetContentTab site={selectedSite} onSiteUpdate={handleSiteUpdate} onGenerateAndScore={handleGenerateAndScore} setError={setError} isPostLimitReached={isPostLimitReached} />;
                                        case '/social-graphics': return <SocialGraphicsTab site={selectedSite} onSiteUpdate={handleSiteUpdate} setError={setError} addLog={addLog} />;
                                        case '/social-videos': return <SocialVideoTab site={selectedSite} onSiteUpdate={handleSiteUpdate} setSites={setSites} setError={setError} addLog={addLog} />;
                                        case '/email-marketing': return <EmailMarketingTab site={selectedSite} onSiteUpdate={handleSiteUpdate} setSites={setSites} setError={setError} addLog={addLog} />;
                                        case '/drafts': return <DraftsTab drafts={selectedSite.drafts || []} onReview={handleReviewDraft} onDiscard={handleDiscardDraft} />;
                                        case '/history': return <HistoryTab history={selectedSite.history || []} onViewDetails={handleViewHistoryDetails} />;
                                        case '/analytics': return <AnalyticsTab site={selectedSite} currentUser={currentUser} performanceData={performanceData} isFetching={isFetchingPerformance} onConnect={handleConnectGoogleAnalytics} onDisconnect={() => handleGoogleDisconnect(mcpApiService.disconnectGoogleAnalytics)} setError={setError} logApiUsage={() => {}} />;
                                        case '/authority': return <BacklinksTab site={selectedSite} currentUser={currentUser} onSiteUpdate={handleSiteUpdate} onRunBacklinksJob={runBacklinksJobNow} isBacklinksJobRunning={isBacklinksJobRunning} setError={setError} />;
                                        case '/automation': return <AutomationDashboard site={selectedSite} onSiteUpdate={handleSiteUpdate} onMultipleSiteUpdates={handleMultipleSiteUpdates} />;
                                        case '/settings/general': return <SettingsTab site={selectedSite} onSiteUpdate={handleSiteUpdate} onMultipleSiteUpdates={handleMultipleSiteUpdates} onOpenDeleteDialog={() => setModal('delete')} logApiUsage={() => {}} setError={setError} onConnectGoogleDrive={handleConnectGoogleDrive} onDisconnectGoogleDrive={() => handleGoogleDisconnect(mcpApiService.disconnectGoogleDrive)} onShowGooglePicker={handleShowGooglePicker} />;
                                        case '/settings/wordpress': return <WordPressTab site={selectedSite} onSiteUpdate={handleSiteUpdate} onMultipleSiteUpdates={handleMultipleSiteUpdates} setError={setError} />;
                                        case '/settings/social': return <SocialMediaTab site={selectedSite} onSiteUpdate={handleSiteUpdate} isConnectingSocial={isConnectingSocial} onConnect={handleConnectSocial} onVerify={handleVerifySocial} onVerifyCredentials={handleVerifyCredentialedSocial} />;
                                        case '/settings/references': return <ReferencesTab site={selectedSite} onSiteUpdate={handleSiteUpdate} setError={setError} onConnectGoogleDrive={handleConnectGoogleDrive} onDisconnectGoogleDrive={() => handleGoogleDisconnect(mcpApiService.disconnectGoogleDrive)} onShowGooglePicker={handleShowGooglePicker} />;
                                        case '/settings/keys': return <APIKeysTab sites={sites} selectedSite={selectedSite} onSiteUpdate={handleSiteUpdate} onResetAllSitesSpend={handleResetAllSitesSpend} setError={setError} />;
                                        case '/settings/integrations': return <IntegrationsTab site={selectedSite} onSiteUpdate={handleSiteUpdate} />;
                                        case '/settings/hosting': return <HostingTab site={selectedSite} onSiteUpdate={handleSiteUpdate} />;
                                        case '/billing': return <BillingTab />;
                                        case '/clients': return <ClientsTab />;
                                        case '/mcp': return <MCPTab sites={sites} selectedSite={selectedSite} currentUser={currentUser} logs={logs} runBacklinksJobNow={runBacklinksJobNow} isBacklinksJobRunning={isBacklinksJobRunning} mcpServers={mcpServers} activeMCPServerId={activeMCPServerId} onAddServer={() => {}} onDeleteServer={() => {}} onConnectServer={() => {}} onDisconnectServer={() => {}} activeView={mcpActiveView} setActiveView={setMcpActiveView} filteredLogs={null} testResults={mcpTestResults} setTestResults={setMcpTestResults} />;
                                        default: return null;
                                    }
                                })()}
                            </PageWrapper>
                        }
                    />
                ))}
            </Routes>
        );
    };

    if (isLoading) {
        return <div className="h-full flex items-center justify-center"><p>Loading sites...</p></div>;
    }
    
    if (sites.length === 0) {
        return <WelcomeScreen onCreateWorkflow={handleAddNewSite} />;
    }
    
    const NavLink: React.FC<{ item: NavLinkItem; isSubItem?: boolean }> = ({ item, isSubItem = false }) => {
        const Icon = item.icon;
        return (
          <RouterNavLink
            to={item.path}
            end
            onClick={() => setIsSidebarOpen(false)}
            className={({ isActive }) =>
              `w-full flex items-center gap-3 rounded-md text-sm transition-colors ${
                isActive ? 'bg-purple-600/20 text-purple-300 font-semibold' : 'text-text-secondary hover:bg-gray-700/50 hover:text-white'
              } ${isSubItem ? 'pl-11 pr-3 py-2' : 'px-3 py-2.5'}`
            }
          >
            <Icon className="h-5 w-5 flex-shrink-0" />
            <span className="truncate">{item.label}</span>
          </RouterNavLink>
        );
    };

    const sidebarContent = (
      <div className="flex flex-col h-full bg-panel border-r border-border">
          <div className="p-4 border-b border-border">
             <div className="relative">
                <select value={selectedSiteId || ''} onChange={(e) => setSelectedSiteId(e.target.value)} className="input-base w-full appearance-none pr-8" disabled={sites.length === 0}>
                {sites.map(site => <option key={site.id} value={site.id}>{site.name}</option>)}
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                    <ChevronDownIcon className="h-4 w-4" />
                </div>
            </div>
            <button onClick={handleAddNewSite} className="w-full btn btn-secondary mt-2 text-sm disabled:opacity-50 disabled:cursor-not-allowed" disabled={!canAddSite} title={!canAddSite ? "Workflow limit reached for your current plan" : ""}>Add New Workflow</button>
          </div>
          <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
             {navItems.map(item => (
                <div key={item.id}>
                    {'subItems' in item ? (
                        <>
                            <button onClick={() => setExpandedNavItems(prev => ({...prev, [item.id]: !prev[item.id]}))} className="w-full flex items-center justify-between gap-3 px-3 py-2.5 rounded-md text-sm text-text-secondary hover:bg-gray-700/50 hover:text-white">
                                <div className="flex items-center gap-3"><item.icon className="h-5 w-5 flex-shrink-0" /> <span className="truncate font-medium">{item.label}</span></div>
                                <ChevronDownIcon className={`h-4 w-4 transition-transform chevron-rotate ${!expandedNavItems[item.id] ? '' : 'rotate-180'}`} />
                            </button>
                            <div className={`site-list-container ${!expandedNavItems[item.id] ? 'collapsed' : ''}`}>
                                <div className="overflow-hidden"><div className="pt-1 space-y-1">{item.subItems.map(sub => <NavLink key={sub.id} item={sub} isSubItem />)}</div></div>
                            </div>
                        </>
                    ) : ( <NavLink item={item as NavLinkItem} /> )}
                </div>
             ))}
          </nav>
          <div className="p-4 border-t border-border mt-auto">
             <button onClick={toggleGodMode} title="Toggle God Mode (Cmd+G)" className="w-full btn btn-secondary mb-3 text-yellow-300 border-yellow-500/50 hover:bg-yellow-900/40">
                <BoltIcon className="h-5 w-5"/>
                <span>God Mode</span>
            </button>
             <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                    {isSaving ? <SpinnerIcon className="h-4 w-4 animate-spin text-yellow-400" /> : <CheckCircleIcon className={`h-4 w-4 transition-colors duration-300 ${isSaved ? 'text-green-400' : 'text-text-secondary'}`} />}
                    <span className={`font-semibold transition-colors duration-300 ${isSaved ? 'text-green-400' : 'text-text-secondary'}`}>
                        {isSaving ? 'Saving...' : isSaved ? 'Saved' : 'Synced'}
                    </span>
                </div>
                <div className="flex items-center gap-3">
                    <button onClick={() => setModal('profile')} className="text-text-secondary hover:text-white"><UserIcon className="h-5 w-5"/></button>
                    <button onClick={logout} className="text-text-secondary hover:text-white"><ArrowLeftOnRectangleIcon className="h-5 w-5"/></button>
                </div>
             </div>
          </div>
      </div>
    );

    return (
        <div className="h-full flex bg-background text-text-primary">
            {/* Mobile Sidebar */}
            <div className={`fixed inset-0 z-40 lg:hidden transition-opacity ${isSidebarOpen ? 'bg-black/60 opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={() => setIsSidebarOpen(false)}></div>
            <div className={`fixed inset-y-0 left-0 w-64 z-50 transform transition-transform lg:hidden ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
                {sidebarContent}
            </div>

            {/* Desktop Sidebar */}
            <aside className="hidden lg:block w-64 flex-shrink-0">
                {sidebarContent}
            </aside>
            
            <main className="flex-1 flex flex-col overflow-hidden">
                 <header className="lg:hidden p-3 border-b border-border flex items-center justify-between flex-shrink-0">
                    <button onClick={() => setIsSidebarOpen(true)} className="p-2"><Bars3Icon className="h-6 w-6" /></button>
                    <h1 className="text-lg font-bold">{selectedSite?.name || 'Mudde AI'}</h1>
                    <button onClick={toggleGodMode} className="p-2 text-yellow-300"><BoltIcon className="h-6 w-6"/></button>
                 </header>
                <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
                    {error && (
                        <div className="bg-red-900/30 border border-red-500/50 text-red-300 px-3 py-2.5 rounded-lg flex items-center gap-3 text-sm mb-6 animate-fade-in">
                            <ExclamationTriangleIcon className="h-5 w-5 flex-shrink-0" />
                            <span>{error}</span>
                        </div>
                    )}
                    {renderContent()}
                </div>
            </main>

            {modal === 'profile' && currentUser && <ProfileModal isOpen={modal === 'profile'} onClose={() => setModal(null)} />}
            {modal === 'history-detail' && selectedHistoryItem && <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in" onClick={() => setModal(null)}><div className="bg-panel rounded-lg shadow-2xl w-full max-w-3xl p-6 border border-border animate-modal-pop max-h-[90vh] overflow-y-auto" onClick={e=>e.stopPropagation()}><HistoryDetailViewer post={selectedHistoryItem} /></div></div>}
            {modal === 'delete' && (
                 <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
                    <div className="bg-panel rounded-lg shadow-2xl w-full max-w-md p-6 border border-red-500/50 animate-modal-pop">
                        <div className="flex items-start gap-4">
                            <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-900/50 sm:mx-0 sm:h-10 sm:w-10"> <ExclamationTriangleIcon className="h-6 w-6 text-red-400" /> </div>
                            <div className="mt-0 text-left flex-1">
                                <h3 className="text-lg leading-6 font-bold text-white">Delete "{selectedSite?.name}"?</h3>
                                <div className="mt-2"> <p className="text-sm text-text-secondary"> Are you sure you want to delete this workflow? This action cannot be undone. </p> </div>
                            </div>
                        </div>
                        <div className="mt-5 sm:mt-4 sm:flex sm:flex-row-reverse gap-3">
                            <button type="button" className="w-full btn bg-red-600 hover:bg-red-700 text-white sm:w-auto" onClick={() => { handleDeleteSite(selectedSiteId!); setModal(null); }}> Delete </button>
                            <button type="button" className="mt-3 w-full btn btn-secondary sm:mt-0 sm:w-auto" onClick={() => setModal(null)}> Cancel </button>
                        </div>
                    </div>
                </div>
            )}
            <GlobalAutomationTracker automationStates={automationStates} sites={sites} onClose={(siteId) => setAutomationStates(prev => { const n = {...prev}; delete n[siteId]; return n; })} />
            {selectedSite && <GeminiLiveAssistant site={selectedSite} findNextTopic={async () => null} onGenerateAndScore={handleGenerateAndScore} onTriggerAutomation={async () => {}} />}
            <CommandPalette isOpen={isCommandPaletteOpen} setIsOpen={setIsCommandPaletteOpen} />
        </div>
    );
};