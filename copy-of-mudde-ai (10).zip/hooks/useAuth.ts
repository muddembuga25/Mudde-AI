import { useState, useEffect, useCallback } from 'react';
import type { User, StoredUser, UserSubscription } from '../types';
import { SubscriptionPlan } from '../types';
import * as mcpApiService from '../services/mcpApiService';

const JWT_KEY = 'mcp-jwt';

export const useAuth = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const persistSession = (user: User, token: string) => {
      setCurrentUser(user);
      localStorage.setItem(JWT_KEY, token);
  }
  
  useEffect(() => {
    const validateSession = async () => {
        const token = localStorage.getItem(JWT_KEY);
        if (token) {
            try {
                const user = await mcpApiService.validateToken(token);
                if (user) {
                    setCurrentUser(user);
                } else {
                    localStorage.removeItem(JWT_KEY);
                }
            } catch (e) {
                console.error("Session validation failed:", e);
                localStorage.removeItem(JWT_KEY);
            }
        }
        setIsLoading(false);
    };
    validateSession();
  }, []);
  
  const login = useCallback(async (username: string, password: string) => {
    setError(null);
    try {
        const { user, token } = await mcpApiService.login(username, password);
        persistSession(user, token);
    } catch (e: any) {
        const message = e.message || "An unknown error occurred during login.";
        setError(message);
        throw e;
    }
  }, []);

  const signup = useCallback(async (details: Omit<StoredUser, 'passwordHash' | 'subscription' | 'avatarUrl'> & { password: string}) => {
    const { username, password, displayName, email } = details;
    setError(null);
    if (!username.trim() || !password.trim() || !displayName.trim() || !email.trim()) {
        const msg = "All fields are required.";
        setError(msg);
        throw new Error(msg);
    }

    try {
        const { user, token } = await mcpApiService.signup(details);
        persistSession(user, token);
    } catch (e: any) {
        const message = e.message || "An unknown error occurred during signup.";
        setError(message);
        throw e;
    }
  }, []);

  const loginWithGoogle = useCallback(async () => {
    setError(null);
    const googleUsername = "Google User";
    const googlePassword = "simulated_google_password";
    try {
        await login(googleUsername, googlePassword);
    } catch (e) {
        await signup({
            username: googleUsername,
            displayName: 'Google User',
            email: 'google.user@example.com',
            password: googlePassword
        });
    }
  }, [login, signup]);

  const logout = useCallback(() => {
    setCurrentUser(null);
    localStorage.removeItem(JWT_KEY);
  }, []);
  
  const updateSubscription = useCallback((newPlan: SubscriptionPlan) => {
    setError(null);
    setCurrentUser(prevUser => {
      if (!prevUser) return null;
      // In a real app, this would be a server call that returns the updated user object.
      const newSubscription = {
          ...prevUser.subscription,
          plan: newPlan,
          // Reset usage when plan changes
          postsGeneratedThisMonth: 0, 
          renewalDate: Date.now() + 30 * 24 * 60 * 60 * 1000,
      };
      const updatedUser = { ...prevUser, subscription: newSubscription };
      // mcpApiService.updateUser(updatedUser); // Future implementation
      persistSession(updatedUser, localStorage.getItem(JWT_KEY)!);
      return updatedUser;
    });
  }, []);

  const incrementPostCount = useCallback(() => {
    setCurrentUser(prevUser => {
        if (!prevUser) return null;
        const newCount = prevUser.subscription.postsGeneratedThisMonth + 1;
        const updatedSubscription = { ...prevUser.subscription, postsGeneratedThisMonth: newCount };
        const updatedUser = { ...prevUser, subscription: updatedSubscription };
        // mcpApiService.updateUser(updatedUser); // Future implementation
        persistSession(updatedUser, localStorage.getItem(JWT_KEY)!);
        return updatedUser;
    });
  }, []);

  const updateProfile = useCallback(async (updates: Partial<Pick<User, 'displayName' | 'email' | 'avatarUrl'>>) => {
    setError(null);
    setCurrentUser(prevUser => {
        if (!prevUser) return null;
        const updatedUser = { ...prevUser, ...updates };
        // mcpApiService.updateUser(updatedUser); // Future implementation
        persistSession(updatedUser, localStorage.getItem(JWT_KEY)!);
        return updatedUser;
    });
  }, []);

  const changePassword = useCallback(async (currentPassword: string, newPassword: string) => {
    if (!currentUser) return;
    setError(null);
    console.log("Simulating password change for user:", currentUser.username);
    // mcpApiService.changePassword(currentUser.username, currentPassword, newPassword); // Future implementation
  }, [currentUser]);

  const useFeatureCredit = useCallback((feature: 'socialGraphics' | 'socialVideo') => {
    setCurrentUser(prevUser => {
        if (!prevUser) return null;
        const currentCredits = prevUser.subscription.featureCredits || { socialGraphics: 0, socialVideo: 0 };
        if (currentCredits[feature] > 0) {
            const newCredits = { ...currentCredits, [feature]: currentCredits[feature] - 1 };
            const updatedSubscription = { ...prevUser.subscription, featureCredits: newCredits };
            const updatedUser = { ...prevUser, subscription: updatedSubscription };
            // mcpApiService.updateUser(updatedUser); // Future implementation
            persistSession(updatedUser, localStorage.getItem(JWT_KEY)!);
            return updatedUser;
        }
        return prevUser;
    });
  }, []);

  const incrementCommentingActions = useCallback(() => {
      setCurrentUser(prevUser => {
          if (!prevUser) return null;
          const currentCount = prevUser.subscription.commentingActionsThisMonth || 0;
          const updatedSubscription = { ...prevUser.subscription, commentingActionsThisMonth: currentCount + 1 };
          const updatedUser = { ...prevUser, subscription: updatedSubscription };
          // mcpApiService.updateUser(updatedUser); // Future implementation
          persistSession(updatedUser, localStorage.getItem(JWT_KEY)!);
          return updatedUser;
      });
  }, []);

  return { currentUser, login, signup, loginWithGoogle, logout, updateProfile, changePassword, error, setError, updateSubscription, incrementPostCount, isLoading, useFeatureCredit, incrementCommentingActions };
};