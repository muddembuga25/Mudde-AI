import React, { useEffect, useRef, useCallback, useState } from 'react';
import { AppStatus, AiProvider, type ApiKeys } from '../types';
import type { Site, PostHistoryItem, Draft, SocialMediaPost, SocialMediaAccount, RssItem, BacklinksHistoryItem, MonitoredBacklink, EmailMarketingCampaign, LogLevel, RecurringSchedule } from '../types';
import * as mcpApiService from '../services/mcpApiService';
import * as aiService from '../services/aiService'; // Keep for non-proxied calls if any

// Helper function to calculate the next valid scheduled run time after a given timestamp.
function calculateNextScheduledRun(rule: { type: 'weekly' | 'monthly', days: number[], time: string }, lastRunTimestamp: number): number {
    const [hour, minute] = rule.time.split(':').map(Number);
    const sortedDays = rule.days.slice().sort((a, b) => a - b);

    // Start checking from the last known run time.
    // If never run before (0), start checking from now to find the next valid time.
    const cursor = new Date(lastRunTimestamp || Date.now()); 
    cursor.setHours(hour, minute, 0, 0);

    // If the scheduled time on the last run day is on or before the last run,
    // we must start checking from the next day to prevent re-triggering.
    if (cursor.getTime() <= lastRunTimestamp) {
        cursor.setDate(cursor.getDate() + 1);
    }
    
    let attempts = 0; // Safety break to prevent infinite loops in weird date scenarios
    while (attempts < 400) {
        if (rule.type === 'weekly') {
            if (sortedDays.includes(cursor.getDay())) {
                return cursor.getTime(); // Found the next valid weekday
            }
        } else { // monthly
            // Check if the cursor's day is a valid scheduled day for its month
            if (sortedDays.includes(cursor.getDate())) {
                // Double-check that this day actually exists in the current month (e.g., no Feb 30)
                const tempDate = new Date(cursor.getTime());
                tempDate.setDate(cursor.getDate());
                if (tempDate.getMonth() === cursor.getMonth()) {
                     return cursor.getTime();
                }
            }
        }
        cursor.setDate(cursor.getDate() + 1);
        attempts++;
    }
    
    return Infinity; // Should not happen
}

const aiProviderToApiKey = (provider: AiProvider): keyof ApiKeys => {
    switch (provider) {
        case AiProvider.GOOGLE: return 'google';
        case AiProvider.OPENAI: return 'openAI';
        case AiProvider.OPENROUTER: return 'openRouter';
        case AiProvider.ANTHROPIC: return 'anthropic';
        case AiProvider.XAI: return 'xai';
        case AiProvider.REPLICATE: return 'replicate';
        case AiProvider.FREEPIK: return 'freepik';
        case AiProvider.FALAI: return 'falai';
        case AiProvider.PERPLEXITY: return 'perplexity';
        default: return 'google';
    }
};

function isSiteReadyForJob(site: Site, jobType: 'blog' | 'social_graphic' | 'social_video' | 'email_marketing' | 'email_digest'): { ready: boolean; message: string } {
    const missingFields: string[] = [];

    // Common checks for all content-generating jobs
    const source = site.masterAutomationSource;
    if (!source) {
        missingFields.push("Master Automation Source is not selected");
    } else {
        switch (source) {
            case 'keyword':
                if (!site.keywordList || site.keywordList.split('\n').filter(k => k.trim() && !k.trim().startsWith('[DONE]')).length === 0) {
                    missingFields.push("Keyword List is empty or all keywords are processed");
                }
                break;
            case 'rss':
                if (!site.rssFeedUrl) missingFields.push("RSS Feed URL");
                break;
            case 'video':
                if (!site.videoSources || site.videoSources.length === 0) missingFields.push("Video Sources");
                break;
            case 'google_sheet':
                if (!site.googleSheetUrl) missingFields.push("Google Sheet URL");
                break;
        }
    }

    // Job-specific checks
    switch (jobType) {
        case 'blog':
            if (site.isAutoPublishEnabled) {
                if (!site.wordpressUrl) missingFields.push("WordPress URL");
                if (!site.wordpressUsername) missingFields.push("WordPress Username");
                if (!site.applicationPassword) missingFields.push("WordPress Application Password");
                if (!site.authorId) missingFields.push("Default WordPress Author");
            }
            const blogTextProvider = site.blogPostAutomationModelConfig?.textProvider || site.modelConfig.textProvider;
            const blogImageProvider = site.blogPostAutomationModelConfig?.imageProvider || site.modelConfig.imageProvider;
            if (!site.apiKeys[aiProviderToApiKey(blogTextProvider)]) missingFields.push(`${blogTextProvider} API Key`);
            if (!site.apiKeys[aiProviderToApiKey(blogImageProvider)]) missingFields.push(`${blogImageProvider} API Key`);
            break;
        
        case 'social_graphic':
            const graphicTextProvider = site.socialGraphicAutomationModelConfig?.textProvider || site.modelConfig.textProvider;
            const graphicImageProvider = site.socialGraphicAutomationModelConfig?.imageProvider || site.modelConfig.imageProvider;
            if (!site.apiKeys[aiProviderToApiKey(graphicTextProvider)]) missingFields.push(`${graphicTextProvider} API Key for text`);
            if (!site.apiKeys[aiProviderToApiKey(graphicImageProvider)]) missingFields.push(`${graphicImageProvider} API Key for image`);
            const hasSocialAccount = Object.values(site.socialMediaSettings).flat().some(acc => acc.isConnected && acc.isAutomationEnabled);
            if (!hasSocialAccount) missingFields.push("At least one connected and enabled Social Media Account");
            break;
            
        case 'social_video':
            const videoTextProvider = site.socialVideoAutomationModelConfig?.textProvider || site.modelConfig.textProvider;
            const videoVideoProvider = site.socialVideoAutomationModelConfig?.videoProvider || site.modelConfig.videoProvider;
            if (!videoVideoProvider) {
                 missingFields.push('Video Generation Provider in Model Config');
            } else {
                 if (!site.apiKeys[aiProviderToApiKey(videoTextProvider)]) missingFields.push(`${videoTextProvider} API Key for text`);
                if (!site.apiKeys[aiProviderToApiKey(videoVideoProvider)]) missingFields.push(`${videoVideoProvider} API Key for video`);
            }
            const hasVideoSocialAccount = Object.values(site.socialMediaSettings).flat().some(acc => acc.isConnected && acc.isAutomationEnabled);
            if (!hasVideoSocialAccount) missingFields.push("At least one connected and enabled Social Media Account");
            break;

        case 'email_marketing':
            const emailTextProvider = site.emailMarketingModelConfig?.textProvider || site.modelConfig.textProvider;
            if (!site.apiKeys[aiProviderToApiKey(emailTextProvider)]) missingFields.push(`${emailTextProvider} API Key`);
            if (!site.mailchimp?.isConnected || !site.mailchimp.defaultAudienceId) {
                missingFields.push("Connected Mailchimp account with a default audience");
            }
            break;
        
        case 'email_digest':
            if (site.masterAutomationSource !== 'rss' || !site.rssFeedUrl) {
                 missingFields.push("Master Automation Source set to 'RSS Feed' with a valid URL");
            }
            const digestTextProvider = site.digestAutomationModelConfig?.textProvider || site.modelConfig.textProvider;
            if (!site.apiKeys[aiProviderToApiKey(digestTextProvider)]) missingFields.push(`${digestTextProvider} API Key`);
            if (!site.mailchimp?.isConnected || !site.mailchimp.defaultAudienceId) {
                missingFields.push("Connected Mailchimp account with a default audience");
            }
            break;
    }

    if (missingFields.length > 0) {
        return {
            ready: false,
            message: `Automation skipped. Missing required fields: ${missingFields.join(', ')}.`
        };
    }

    return { ready: true, message: "" };
}

export const useAutomatedJobs = (
    sites: Site[], 
    setSites: (updater: (prevSites: Site[]) => Site[]) => void,
    addLog: (message: string, type: LogLevel, siteId?: string) => void,
    onProgress: (update: { siteId: string, status: AppStatus, statusMessage: string, topic?: string }) => void
) => {
    const processingJobs = useRef<Set<string>>(new Set());
    const sitesRef = useRef(sites);
    const [isBacklinksJobRunning, setIsBacklinksJobRunning] = useState(false);

    useEffect(() => {
        sitesRef.current = sites;
    }, [sites]);

    const updateSiteState = useCallback((updatedSite: Site) => {
        setSites(prevSites => prevSites.map(s => s.id === updatedSite.id ? updatedSite : s));
    }, [setSites]);
    
    const processAutomatedPost = useCallback(async (site: Site, recurringScheduleId: string | null) => {
        addLog(`[Blog Post] Automation triggered for "${site.name}".`, 'INFO', site.id);
        onProgress({ siteId: site.id, status: AppStatus.AUTOMATION_TRIGGERED, statusMessage: "Automation triggered..." });
        try {
            const progressCallback = (update: { status: AppStatus; message: string; topic?: string }) => {
                onProgress({ siteId: site.id, status: update.status, statusMessage: update.message, topic: update.topic });
                if(update.topic) {
                    addLog(`[${update.topic}] ${update.message}`, 'INFO', site.id);
                } else {
                    addLog(`[Blog Post] ${update.message}`, 'INFO', site.id);
                }
            };
            const updatedSite = await mcpApiService.runBlogPostAutomation(site.id, recurringScheduleId, progressCallback);
            updateSiteState(updatedSite);
            addLog(`[Blog Post] Job completed successfully for "${site.name}".`, 'SUCCESS', site.id);
            onProgress({ siteId: site.id, status: AppStatus.PUBLISHED, statusMessage: "Published successfully!" });
        } catch (error: any) {
            addLog(`[Blog Post] Job failed for site "${site.name}": ${error.message}`, 'ERROR', site.id);
            onProgress({ siteId: site.id, status: AppStatus.ERROR, statusMessage: error.message });
        }
    }, [addLog, updateSiteState, onProgress]);

    const processAutomatedSocialMedia = useCallback(async (site: Site, recurringScheduleId: string | null) => {
        addLog(`[Social Graphic] Automation triggered for "${site.name}".`, 'INFO', site.id);
        onProgress({ siteId: site.id, status: AppStatus.GENERATING_IMAGE, statusMessage: "Social Graphic job triggered..." });
        try {
            const progressCallback = (update: { status: AppStatus; message: string; topic?: string }) => {
                onProgress({ siteId: site.id, status: update.status, statusMessage: update.message, topic: update.topic });
                addLog(`[Social Graphic] ${update.message}`, 'INFO', site.id);
            };
            const updatedSite = await mcpApiService.runSocialGraphicAutomation(site.id, recurringScheduleId, progressCallback);
            updateSiteState(updatedSite);
            addLog(`[Social Graphic] Job completed successfully for "${site.name}".`, 'SUCCESS', site.id);
            onProgress({ siteId: site.id, status: AppStatus.PUBLISHED, statusMessage: "Social Graphic published!" });
        } catch (error: any) {
            addLog(`[Social Graphic] Job failed for site "${site.name}": ${error.message}`, 'ERROR', site.id);
            onProgress({ siteId: site.id, status: AppStatus.ERROR, statusMessage: error.message });
        }
    }, [addLog, updateSiteState, onProgress]);

    const processAutomatedSocialVideo = useCallback(async (site: Site, recurringScheduleId: string | null) => {
        addLog(`[Social Video] Automation triggered for "${site.name}".`, 'INFO', site.id);
        onProgress({ siteId: site.id, status: AppStatus.GENERATING_IMAGE, statusMessage: "Social Video job triggered..." });
        try {
            const progressCallback = (update: { status: AppStatus; message: string; topic?: string }) => {
                onProgress({ siteId: site.id, status: update.status, statusMessage: update.message, topic: update.topic });
                addLog(`[Social Video] ${update.message}`, 'INFO', site.id);
            };
            const updatedSite = await mcpApiService.runSocialVideoAutomation(site.id, recurringScheduleId, progressCallback);
            updateSiteState(updatedSite);
            addLog(`[Social Video] Job completed successfully for "${site.name}".`, 'SUCCESS', site.id);
            onProgress({ siteId: site.id, status: AppStatus.PUBLISHED, statusMessage: "Social Video published!" });
        } catch (error: any) {
            addLog(`[Social Video] Job failed for site "${site.name}": ${error.message}`, 'ERROR', site.id);
            onProgress({ siteId: site.id, status: AppStatus.ERROR, statusMessage: error.message });
        }
    }, [addLog, updateSiteState, onProgress]);

    const processAutomatedEmailMarketing = useCallback(async (site: Site, recurringScheduleId: string | null) => {
        addLog(`[Email Marketing] Automation triggered for "${site.name}".`, 'INFO', site.id);
        onProgress({ siteId: site.id, status: AppStatus.GENERATING_ARTICLE, statusMessage: "Email Marketing job triggered..." });
        try {
            const progressCallback = (update: { status: AppStatus; message: string; topic?: string }) => {
                onProgress({ siteId: site.id, status: update.status, statusMessage: update.message, topic: update.topic });
                addLog(`[Email Marketing] ${update.message}`, 'INFO', site.id);
            };
            const updatedSite = await mcpApiService.runEmailMarketingAutomation(site.id, recurringScheduleId, progressCallback);
            updateSiteState(updatedSite);
            addLog(`[Email Marketing] Job completed successfully for "${site.name}".`, 'SUCCESS', site.id);
            onProgress({ siteId: site.id, status: AppStatus.PUBLISHED, statusMessage: "Email sent!" });
        } catch (error: any) {
            addLog(`[Email Marketing] Job failed for site "${site.name}": ${error.message}`, 'ERROR', site.id);
            onProgress({ siteId: site.id, status: AppStatus.ERROR, statusMessage: error.message });
        }
    }, [addLog, updateSiteState, onProgress]);

    const processAutomatedDigest = useCallback(async (site: Site, recurringScheduleId: string | null) => {
        addLog(`[Email Digest] Automation triggered for "${site.name}".`, 'INFO', site.id);
        onProgress({ siteId: site.id, status: AppStatus.GENERATING_ARTICLE, statusMessage: "Email Digest job triggered..." });
        try {
             const progressCallback = (update: { status: AppStatus; message: string; topic?: string }) => {
                onProgress({ siteId: site.id, status: update.status, statusMessage: update.message, topic: update.topic });
                addLog(`[Email Digest] ${update.message}`, 'INFO', site.id);
            };
            const updatedSite = await mcpApiService.runDigestAutomation(site.id, recurringScheduleId, progressCallback);
            updateSiteState(updatedSite);
            addLog(`[Email Digest] Job completed successfully for "${site.name}".`, 'SUCCESS', site.id);
            onProgress({ siteId: site.id, status: AppStatus.PUBLISHED, statusMessage: "Digest sent!" });
        } catch (error: any) {
            addLog(`[Email Digest] Job failed for site "${site.name}": ${error.message}`, 'ERROR', site.id);
            onProgress({ siteId: site.id, status: AppStatus.ERROR, statusMessage: error.message });
        }
    }, [addLog, updateSiteState, onProgress]);

    const processAutomatedBacklinks = useCallback(async (site: Site) => {
        addLog(`[Backlinks] Automation triggered for "${site.name}".`, 'INFO', site.id);
        // This would call mcpApiService.runBacklinksAutomation in a real app.
        console.log("Simulating backlinks job for", site.name);
    }, [addLog]);

    const runScheduler = useCallback(async () => {
        const currentSites = sitesRef.current;
        const now = Date.now();

        for (const site of currentSites) {
            let jobTriggeredForSite = false;

            // --- Check Blog Post Automation ---
            const blogJobKey = `${site.id}-blog`;
            if (site.isAutomationEnabled && !processingJobs.current.has(blogJobKey)) {
                const readiness = isSiteReadyForJob(site, 'blog');
                if (!readiness.ready) {
                    addLog(`[Blog Post] ${readiness.message}`, 'WARN', site.id);
                } else {
                    let shouldTrigger = false;
                    let scheduleId: string | null = null;
                    let nextRunTimestamp: number | null = null;

                    if (site.automationTrigger === 'interval') {
                        const interval = (site.automationIntervalHours || 24) * 3600 * 1000;
                        if (now - (site.lastAutoPilotRun || 0) >= interval) {
                            shouldTrigger = true;
                        }
                    } else { // schedule
                        for (const rule of site.recurringSchedules || []) {
                            if (!rule.isEnabled) continue;
                            const nextScheduledRun = calculateNextScheduledRun(rule, rule.lastRun || 0);
                            if (now >= nextScheduledRun) {
                                shouldTrigger = true;
                                scheduleId = rule.id;
                                nextRunTimestamp = nextScheduledRun;
                                break;
                            }
                        }
                    }
                    
                    if (shouldTrigger) {
                        processingJobs.current.add(blogJobKey);
                        const updatedSite = { ...site };
                        if (scheduleId && nextRunTimestamp) {
                            updatedSite.recurringSchedules = updatedSite.recurringSchedules.map(s => s.id === scheduleId ? { ...s, lastRun: nextRunTimestamp } : s);
                        } else {
                            updatedSite.lastAutoPilotRun = now;
                        }
                        updateSiteState(updatedSite);
                        processAutomatedPost(updatedSite, scheduleId).finally(() => processingJobs.current.delete(blogJobKey));
                        jobTriggeredForSite = true;
                    }
                }
            }
            if (jobTriggeredForSite) continue;

            // --- Check Social Graphic Automation ---
            const socialGraphicJobKey = `${site.id}-social-graphic`;
            if (site.isSocialGraphicAutomationEnabled && !processingJobs.current.has(socialGraphicJobKey)) {
                const readiness = isSiteReadyForJob(site, 'social_graphic');
                if (!readiness.ready) {
                    addLog(`[Social Graphic] ${readiness.message}`, 'WARN', site.id);
                } else {
                    let shouldTrigger = false;
                    let scheduleId: string | null = null;
                    let nextRunTimestamp: number | null = null;

                    if (site.socialGraphicAutomationTrigger === 'interval') {
                        const interval = (site.socialGraphicAutomationIntervalHours || 48) * 3600 * 1000;
                        if (now - (site.lastSocialGraphicAutoPilotRun || 0) >= interval) {
                            shouldTrigger = true;
                        }
                    } else { // schedule
                        for (const rule of site.socialGraphicRecurringSchedules || []) {
                            if (!rule.isEnabled) continue;
                            const nextScheduledRun = calculateNextScheduledRun(rule, rule.lastRun || 0);
                            if (now >= nextScheduledRun) {
                                shouldTrigger = true;
                                scheduleId = rule.id;
                                nextRunTimestamp = nextScheduledRun;
                                break;
                            }
                        }
                    }

                    if (shouldTrigger) {
                        processingJobs.current.add(socialGraphicJobKey);
                        const updatedSite = { ...site };
                        if (scheduleId && nextRunTimestamp) {
                            updatedSite.socialGraphicRecurringSchedules = updatedSite.socialGraphicRecurringSchedules.map(s => s.id === scheduleId ? { ...s, lastRun: nextRunTimestamp } : s);
                        } else {
                            updatedSite.lastSocialGraphicAutoPilotRun = now;
                        }
                        updateSiteState(updatedSite);
                        processAutomatedSocialMedia(updatedSite, scheduleId).finally(() => processingJobs.current.delete(socialGraphicJobKey));
                        jobTriggeredForSite = true;
                    }
                }
            }
            if (jobTriggeredForSite) continue;
            
            // --- Check Social Video Automation ---
            const socialVideoJobKey = `${site.id}-social-video`;
            if (site.isSocialVideoAutomationEnabled && !processingJobs.current.has(socialVideoJobKey)) {
                const readiness = isSiteReadyForJob(site, 'social_video');
                if (!readiness.ready) {
                    addLog(`[Social Video] ${readiness.message}`, 'WARN', site.id);
                } else {
                    let shouldTrigger = false;
                    let scheduleId: string | null = null;
                    let nextRunTimestamp: number | null = null;

                    if (site.socialVideoAutomationTrigger === 'interval') {
                        const interval = (site.socialVideoAutomationIntervalHours || 72) * 3600 * 1000;
                        if (now - (site.lastSocialVideoAutoPilotRun || 0) >= interval) {
                            shouldTrigger = true;
                        }
                    } else { // schedule
                        for (const rule of site.socialVideoRecurringSchedules || []) {
                            if (!rule.isEnabled) continue;
                            const nextScheduledRun = calculateNextScheduledRun(rule, rule.lastRun || 0);
                            if (now >= nextScheduledRun) {
                                shouldTrigger = true;
                                scheduleId = rule.id;
                                nextRunTimestamp = nextScheduledRun;
                                break;
                            }
                        }
                    }

                    if (shouldTrigger) {
                        processingJobs.current.add(socialVideoJobKey);
                        const updatedSite = { ...site };
                        if (scheduleId && nextRunTimestamp) {
                            updatedSite.socialVideoRecurringSchedules = updatedSite.socialVideoRecurringSchedules.map(s => s.id === scheduleId ? { ...s, lastRun: nextRunTimestamp } : s);
                        } else {
                            updatedSite.lastSocialVideoAutoPilotRun = now;
                        }
                        updateSiteState(updatedSite);
                        processAutomatedSocialVideo(updatedSite, scheduleId).finally(() => processingJobs.current.delete(socialVideoJobKey));
                        jobTriggeredForSite = true;
                    }
                }
            }
            if (jobTriggeredForSite) continue;

            // --- Check Email Marketing Automation ---
            const emailJobKey = `${site.id}-email-marketing`;
            if (site.isEmailMarketingAutomationEnabled && !processingJobs.current.has(emailJobKey)) {
                const readiness = isSiteReadyForJob(site, 'email_marketing');
                if (!readiness.ready) {
                    addLog(`[Email Marketing] ${readiness.message}`, 'WARN', site.id);
                } else {
                    let shouldTrigger = false;
                    let scheduleId: string | null = null;
                    let nextRunTimestamp: number | null = null;

                    if (site.emailMarketingAutomationTrigger === 'interval') {
                        const interval = (site.emailMarketingAutomationIntervalHours || 168) * 3600 * 1000;
                        if (now - (site.lastEmailMarketingAutoPilotRun || 0) >= interval) {
                            shouldTrigger = true;
                        }
                    } else { // schedule
                        for (const rule of site.emailMarketingRecurringSchedules || []) {
                            if (!rule.isEnabled) continue;
                            const nextScheduledRun = calculateNextScheduledRun(rule, rule.lastRun || 0);
                            if (now >= nextScheduledRun) {
                                shouldTrigger = true;
                                scheduleId = rule.id;
                                nextRunTimestamp = nextScheduledRun;
                                break;
                            }
                        }
                    }
                    
                    if (shouldTrigger) {
                        processingJobs.current.add(emailJobKey);
                        const updatedSite = { ...site };
                        if (scheduleId && nextRunTimestamp) {
                            updatedSite.emailMarketingRecurringSchedules = updatedSite.emailMarketingRecurringSchedules!.map(s => s.id === scheduleId ? { ...s, lastRun: nextRunTimestamp } : s);
                        } else {
                            updatedSite.lastEmailMarketingAutoPilotRun = now;
                        }
                        updateSiteState(updatedSite);
                        processAutomatedEmailMarketing(updatedSite, scheduleId).finally(() => processingJobs.current.delete(emailJobKey));
                        jobTriggeredForSite = true;
                    }
                }
            }
            if (jobTriggeredForSite) continue;

            // --- Check Weekly Digest Automation ---
            const digestJobKey = `${site.id}-digest`;
            if (site.isDigestAutomationEnabled && !processingJobs.current.has(digestJobKey)) {
                const readiness = isSiteReadyForJob(site, 'email_digest');
                if (!readiness.ready) {
                    addLog(`[Email Digest] ${readiness.message}`, 'WARN', site.id);
                } else {
                    for (const rule of site.digestRecurringSchedules || []) {
                        if (!rule.isEnabled) continue;
                        const nextScheduledRun = calculateNextScheduledRun(rule, rule.lastRun || 0);
                        if (now >= nextScheduledRun) {
                            processingJobs.current.add(digestJobKey);
                            const updatedSite = { ...site };
                            updatedSite.digestRecurringSchedules = updatedSite.digestRecurringSchedules!.map(s => s.id === rule.id ? { ...s, lastRun: nextScheduledRun } : s);
                            updateSiteState(updatedSite);
                            processAutomatedDigest(updatedSite, rule.id).finally(() => processingJobs.current.delete(digestJobKey));
                            jobTriggeredForSite = true;
                            break;
                        }
                    }
                }
            }
        }
    }, [updateSiteState, processAutomatedPost, processAutomatedSocialMedia, processAutomatedSocialVideo, processAutomatedEmailMarketing, processAutomatedDigest, addLog, onProgress]);
    
    const runBacklinksJobNow = useCallback((siteId: string) => {
        const site = sitesRef.current.find(s => s.id === siteId);
        if (site) {
            processAutomatedBacklinks(site);
        }
    }, [processAutomatedBacklinks]);

    useEffect(() => {
        const schedulerIntervalRef = window.setInterval(runScheduler, 60000); // Check every minute
        return () => clearInterval(schedulerIntervalRef);
    }, [runScheduler]);

    return { isBacklinksJobRunning, runBacklinksJobNow };
};