import React, { useState, useCallback, useEffect } from 'react';
import type { Site, EmailMarketingCampaign, PostHistoryItem, Site as ClientSite } from '../types';
import * as aiService from '../services/aiService';
import { useAuth } from '../contexts/AuthContext';
import { PLAN_LIMITS } from '../constants';
import { HtmlRenderer } from './HtmlRenderer';
import { SparklesIcon, MailIcon, ArchiveBoxIcon, LightbulbIcon, PaperAirplaneIcon, MailchimpIcon } from './Icons';

interface EmailMarketingTabProps {
    site: ClientSite;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    setSites: (updater: (prevSites: Site[]) => Site[]) => void;
    setError: (error: string | null) => void;
    addLog: (message: string, type: 'SUCCESS' | 'ERROR' | 'INFO', siteId: string) => void;
}

interface GenerationResult {
    campaign: EmailMarketingCampaign;
}

const LockedFeature: React.FC<{ title: string; message: string; requiredPlan: string; }> = ({ title, message, requiredPlan }) => (
    <div className="text-center p-8 bg-panel/50 rounded-2xl border-2 border-dashed border-border animate-fade-in max-w-lg mx-auto">
        <SparklesIcon className="mx-auto h-12 w-12 text-text-secondary" />
        <h3 className="mt-4 text-lg font-medium text-white">{title}</h3>
        <p className="mt-1 text-sm text-text-secondary">{message}</p>
        <div className="mt-4 text-xs font-bold text-yellow-400 bg-yellow-900/50 px-3 py-1.5 rounded-full inline-block">
            Requires {requiredPlan} Plan
        </div>
    </div>
);

export const EmailMarketingTab: React.FC<EmailMarketingTabProps> = ({ site, onSiteUpdate, setSites, setError, addLog }) => {
    const { currentUser } = useAuth();
    const [prompt, setPrompt] = useState('');
    const [isSuggestingPrompt, setIsSuggestingPrompt] = useState(false);
    const [result, setResult] = useState<GenerationResult | { error: string } | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [isSending, setIsSending] = useState(false);

    const handleSuggestPrompt = useCallback(async () => {
        setIsSuggestingPrompt(true);
        setError(null);
        try {
            const { ideas, updatedSite } = await aiService.brainstormContentIdeas(site.id, 'newsletter', 'email_campaign');
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
            if (ideas.length > 0) {
                setPrompt(ideas[0]);
            }
        } catch (error: any) {
            setError(error.message || "Failed to suggest a topic.");
        } finally {
            setIsSuggestingPrompt(false);
        }
    }, [site.id, setSites, setError]);

    useEffect(() => {
        if (!prompt) {
            handleSuggestPrompt();
        }
    }, [handleSuggestPrompt, prompt]);

    const handleGenerate = async () => {
        if (!prompt.trim()) {
            setError("Please provide a topic.");
            return;
        }
        setIsLoading(true);
        setResult(null);
        setError(null);

        try {
            const { campaign, updatedSite } = await aiService.generateManualEmailCampaign(site.id, prompt);
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
            setResult({ campaign });
        } catch (error: any) {
            console.error(`Error generating email campaign:`, error);
            setResult({ error: error.message || 'Generation failed.' });
        } finally {
            setIsLoading(false);
        }
    };

    const handleSendAndRecord = async () => {
        if (!result || !('campaign' in result)) {
            setError("Please generate a campaign first.");
            return;
        }
        setIsSending(true);
        setError(null);
        try {
            const { updatedSite } = await aiService.sendAndRecordEmailCampaign(site.id, result.campaign);
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
            addLog(`Email campaign "${result.campaign.subject}" sent and saved to history.`, 'SUCCESS', site.id);
            handleDiscard(); // Clear after sending
        } catch (e: any) {
            setError(e.message || "Failed to send email campaign.");
            addLog(`Failed to send email campaign: ${e.message}`, 'ERROR', site.id);
        } finally {
            setIsSending(false);
        }
    };

    const handleSaveToHistory = () => {
        if (!result || !('campaign' in result)) return;
        const { campaign } = result;
        const newHistoryItem: PostHistoryItem = {
            id: crypto.randomUUID(),
            topic: campaign.subject,
            url: '#',
            date: Date.now(),
            type: 'Email Marketing',
            emailCampaign: campaign,
        };
        onSiteUpdate('history', [newHistoryItem, ...site.history]);
        addLog(`Email campaign "${campaign.subject}" saved to history.`, 'SUCCESS', site.id);
        handleDiscard();
    };

    const handleDiscard = () => {
        setResult(null);
        setPrompt('');
        handleSuggestPrompt();
    };

    if (!currentUser) return null;
    const planFeatures = PLAN_LIMITS[currentUser.subscription.plan].features;
    if (!planFeatures.emailMarketing) {
        return <LockedFeature title="Email Marketing Generator" message="This feature is available on the Pro plan and above." requiredPlan="Pro+" />;
    }

    const isMailchimpConnected = site.mailchimp?.isConnected === true;

    return (
        <div className="w-full max-w-5xl mx-auto space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
                <div className="md:col-span-4 content-panel space-y-6">
                    <div>
                        <div className="flex justify-between items-center mb-2">
                            <label className="text-sm font-medium text-text-primary">1. Topic/Prompt</label>
                            {/* Fix: Moved title prop from LightbulbIcon to the parent button */}
                            <button onClick={handleSuggestPrompt} disabled={isSuggestingPrompt || isLoading} title="Suggest Topic" className="btn text-xs px-3 py-1.5 flex items-center justify-center gap-1.5 bg-teal-600/80 hover:bg-teal-500 text-white shadow-lg shadow-teal-900/50">
                                <LightbulbIcon className="h-4 w-4" /> Suggest
                            </button>
                        </div>
                        <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="e.g., A weekly update on AI in marketing..." className="input-base w-full p-4 text-sm leading-relaxed" rows={4} />
                    </div>
                    
                    <button onClick={handleGenerate} disabled={isLoading || isSending || !prompt.trim()} className="w-full btn btn-primary text-base flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-wait">
                        {isLoading ? 'Generating...' : <><MailIcon /> 2. Generate Campaign</>}
                    </button>
                    
                    {result && 'campaign' in result && (
                        <div className="pt-4 border-t border-border-subtle space-y-3 animate-fade-in">
                            <h3 className="text-sm font-medium text-text-primary">3. Actions</h3>
                            <div className="p-3 rounded-lg bg-panel border border-border-subtle">
                                <div className="flex items-center gap-3">
                                    <MailchimpIcon className="h-6 w-6 text-yellow-400" />
                                    <div>
                                        <p className="text-sm font-semibold text-white">Mailchimp Status</p>
                                        <p className={`text-xs ${isMailchimpConnected ? 'text-green-400' : 'text-yellow-400'}`}>
                                            {isMailchimpConnected ? `Connected (${site.mailchimp?.availableAudiences?.length} audiences)` : 'Not Connected'}
                                        </p>
                                    </div>
                                </div>
                                {!isMailchimpConnected && <p className="text-xs text-text-secondary mt-2">Connect Mailchimp in the Automation tab to send emails.</p>}
                            </div>
                            <button onClick={handleSendAndRecord} disabled={isSending || !isMailchimpConnected} className="w-full btn btn-primary text-sm flex items-center justify-center gap-2 disabled:opacity-50">
                                {isSending ? 'Sending...' : <><PaperAirplaneIcon className="h-4 w-4" /> Send Now</>}
                            </button>
                             <button onClick={handleSaveToHistory} disabled={isSending} className="w-full btn btn-secondary text-sm flex items-center justify-center gap-2">
                                <ArchiveBoxIcon className="h-4 w-4" /> Save to History (without sending)
                            </button>
                        </div>
                    )}
                </div>

                <div className="md:col-span-8 content-panel">
                    <h3 className="text-xl font-bold text-white mb-4">Email Preview</h3>
                    {isLoading && <div className="text-center py-16 text-text-secondary">Generating campaign...</div>}
                    {result && 'error' in result && <div className="text-center py-16 text-red-400">{result.error}</div>}
                    {result && 'campaign' in result ? (
                        <div className="space-y-4 animate-fade-in">
                            <div>
                                <label className="text-sm font-medium text-text-primary">Subject</label>
                                <input readOnly value={result.campaign.subject} className="input-base mt-2 bg-panel" />
                            </div>
                            <div>
                                <label className="text-sm font-medium text-text-primary">Body</label>
                                <div className="mt-2 p-4 bg-white rounded-md border border-border h-96 overflow-y-auto">
                                    <HtmlRenderer content={result.campaign.body} />
                                </div>
                            </div>
                        </div>
                    ) : (
                        <div className="text-center py-16 text-text-secondary">Your generated email will appear here.</div>
                    )}
                </div>
            </div>
        </div>
    );
};