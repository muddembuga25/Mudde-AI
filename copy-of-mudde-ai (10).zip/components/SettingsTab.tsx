import React from 'react';
import type { Site, ModelConfig, ApiKeys, ReferenceItem } from '../types';
import { SeoDataProviderPanel } from './SeoDataProviderPanel';
import { ModelConfigPanel } from './ModelConfigPanel';


// --- PROPS INTERFACE ---
interface SettingsTabProps {
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    onMultipleSiteUpdates: (updates: Partial<Site>) => void;
    onOpenDeleteDialog: () => void;
    logApiUsage: (provider: keyof ApiKeys, cost: number) => void;
    setError: (error: string | null) => void;
    onConnectGoogleDrive: () => void;
    onDisconnectGoogleDrive: () => void;
    onShowGooglePicker: () => void;
}

// --- SUB-COMPONENTS FOR SETTINGS SECTIONS ---

const WorkflowDetailsPanel: React.FC<Pick<SettingsTabProps, 'site' | 'onSiteUpdate'>> = ({ site, onSiteUpdate }) => (
    <div className="content-panel">
        <h2 className="text-xl font-bold text-white">Workflow Details</h2>
        <p className="text-sm text-text-secondary mt-1">Basic information for this workflow configuration.</p>
        <div className="space-y-4 mt-6">
            <div>
                <label htmlFor="site-name" className="block text-sm font-medium text-text-primary mb-2">Workflow Name</label>
                <input id="site-name" type="text" value={site.name} onChange={(e) => onSiteUpdate('name', e.target.value)} placeholder="e.g., My Awesome Blog" className="input-base px-4 py-2" />
            </div>
        </div>
    </div>
);

const DangerZonePanel: React.FC<Pick<SettingsTabProps, 'site' | 'onOpenDeleteDialog'>> = ({ site, onOpenDeleteDialog }) => (
    <div className="mt-8 pt-8 border-t border-red-500/30">
        <h2 className="text-xl font-bold text-red-400">Danger Zone</h2>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mt-4 gap-4">
            <div className="flex-grow">
                <p className="text-sm text-text-secondary"> Permanently delete the "<strong>{site.name}</strong>" workflow. This will remove all associated settings, keyword lists, and history. This action cannot be undone.</p>
            </div>
            <button onClick={onOpenDeleteDialog} className="w-full sm:w-auto flex-shrink-0 btn bg-red-600 hover:bg-red-700 text-white font-bold text-sm"> Delete This Workflow </button>
        </div>
    </div>
);


// --- MAIN SETTINGS TAB COMPONENT ---
export const SettingsTab: React.FC<SettingsTabProps> = (props) => {
    return (
        <div className="space-y-8 max-w-4xl mx-auto">
            <WorkflowDetailsPanel {...props} />
            <SeoDataProviderPanel site={props.site} onSiteUpdate={props.onSiteUpdate} />
            <ModelConfigPanel site={props.site} onSiteUpdate={props.onSiteUpdate} />
            <DangerZonePanel {...props} />
        </div>
    );
};