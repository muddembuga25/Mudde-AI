import React, { useState, useCallback } from 'react';
import type { Site, ReferenceItem, ApiKeys, Site as ClientSite, CharacterReference } from '../types';
import * as aiService from '../services/aiService';
import { LinkIcon, PhotoIcon, DocumentTextIcon, ArrowUpTrayIcon, XIcon, GoogleDriveIcon, GoogleIcon, TrashIcon, UserIcon, PlusIcon, PenIcon } from './Icons';
import { useSitesContext } from '../contexts/SitesContext';

interface ReferencesTabProps {
    site: ClientSite;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    setError: (error: string | null) => void;
    onConnectGoogleDrive: () => void;
    onDisconnectGoogleDrive: () => void;
    onShowGooglePicker: () => void;
}

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};

const BrandingPanel: React.FC<Pick<ReferencesTabProps, 'site' | 'onSiteUpdate'>> = ({ site, onSiteUpdate }) => {
    
    const handleLogoChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files && event.target.files[0]) {
            const file = event.target.files[0];
            const base64 = await fileToBase64(file);
            onSiteUpdate('brandLogo', base64);
        }
    };

    const handleRemoveLogo = () => {
        onSiteUpdate('brandLogo', '');
    };

    const handleColorChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const colors = event.target.value.split(',').map(c => c.trim()).filter(Boolean);
        onSiteUpdate('brandColors', colors);
    };

    const handleFontChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const fonts = event.target.value.split(',').map(f => f.trim()).filter(Boolean);
        onSiteUpdate('brandFonts', fonts);
    };

    return (
        <div className="content-panel">
            <h2 className="text-xl font-bold text-white">Branding Materials</h2>
            <p className="text-sm text-text-secondary mt-1">Upload your logo and define brand elements. The AI will use these to maintain brand consistency in generated content and images.</p>
            
            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                {/* Logo Uploader */}
                <div>
                    <label className="block text-sm font-medium text-text-primary mb-2">Brand Logo</label>
                    <div className="mt-2 flex items-center gap-4">
                        <div className="w-20 h-20 bg-panel-light rounded-lg border border-border flex items-center justify-center p-1">
                            {site.brandLogo ? <img src={site.brandLogo} alt="Brand Logo" className="max-w-full max-h-full object-contain" /> : <PhotoIcon className="h-8 w-8 text-text-secondary" />}
                        </div>
                        <div className="flex-1 space-y-2">
                            <label htmlFor="logo-upload" className="btn btn-secondary text-sm w-full cursor-pointer text-center block">
                                Upload Logo
                            </label>
                            <input id="logo-upload" type="file" accept="image/png, image/jpeg, image/webp, image/svg+xml" className="hidden" onChange={handleLogoChange} />
                            {site.brandLogo && <button onClick={handleRemoveLogo} className="btn bg-red-900/40 hover:bg-red-800/60 text-red-300 text-sm w-full">Remove</button>}
                        </div>
                    </div>
                </div>

                {/* Colors and Fonts */}
                <div className="space-y-4">
                    <div>
                        <label htmlFor="brand-colors" className="block text-sm font-medium text-text-primary mb-2">Brand Colors</label>
                        <input id="brand-colors" type="text" value={(site.brandColors || []).join(', ')} onChange={handleColorChange} placeholder="#FFFFFF, #0A0A0F, #A855F7" className="input-base" />
                        <div className="flex flex-wrap gap-2 mt-2 h-6 items-center">
                            {(site.brandColors || []).map(color => (
                                <div key={color} className="h-6 w-6 rounded-full border-2 border-panel" style={{ backgroundColor: color }} title={color} />
                            ))}
                        </div>
                    </div>
                    <div>
                        <label htmlFor="brand-fonts" className="block text-sm font-medium text-text-primary mb-2">Brand Fonts</label>
                        <input id="brand-fonts" type="text" value={(site.brandFonts || []).join(', ')} onChange={handleFontChange} placeholder="Inter, Roboto, Open Sans" className="input-base" />
                    </div>
                </div>
            </div>
        </div>
    );
};


const KnowledgeBasePanel: React.FC<Pick<ReferencesTabProps, 'site' | 'onSiteUpdate' | 'onConnectGoogleDrive' | 'onDisconnectGoogleDrive' | 'onShowGooglePicker'>> = ({ site, onSiteUpdate, onConnectGoogleDrive, onDisconnectGoogleDrive, onShowGooglePicker }) => {
    const [newUrl, setNewUrl] = useState('');
    
    const handleAddUrl = () => {
        if (!newUrl.trim()) return;
        const newRef: ReferenceItem = { id: crypto.randomUUID(), type: 'url', value: newUrl, name: newUrl, mimeType: 'text/uri-list' };
        onSiteUpdate('references', [...site.references, newRef]);
        setNewUrl('');
    };
    
    const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files && event.target.files[0]) {
            const file = event.target.files[0];
            const base64 = await fileToBase64(file);
            const newRef: ReferenceItem = { id: crypto.randomUUID(), type: 'file', value: base64, name: file.name, mimeType: file.type };
            onSiteUpdate('references', [...site.references, newRef]);
            // Reset the input so the same file can be uploaded again
            event.target.value = '';
        }
    };
    
    const handleRemoveReference = (id: string) => {
        onSiteUpdate('references', site.references.filter(ref => ref.id !== id));
    };
    
    const isGoogleDriveConnected = site.googleDrive?.isConnected === true;

    return (
        <div className="content-panel">
            <h2 className="text-xl font-bold text-white">Knowledge Base</h2>
            <p className="text-sm text-text-secondary mt-1">Provide reference documents, URLs, and other materials. The AI will consult this knowledge base to ensure content accuracy and context.</p>

            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg border border-border-subtle bg-panel space-y-3">
                    <h3 className="font-semibold text-text-primary">Upload Files</h3>
                    <p className="text-xs text-text-secondary">Upload documents (.pdf, .txt, .md) or images (.png, .jpg).</p>
                    <label htmlFor="file-upload" className="w-full btn btn-secondary text-sm flex items-center justify-center gap-2 cursor-pointer"> <ArrowUpTrayIcon className="h-4 w-4" /> Upload from Computer </label>
                    <input id="file-upload" type="file" className="hidden" onChange={handleFileChange} />
                </div>
                 <div className="p-4 rounded-lg border border-border-subtle bg-panel space-y-3">
                    <h3 className="font-semibold text-text-primary">Add from URL</h3>
                    <p className="text-xs text-text-secondary">Provide a public URL for the AI to scrape for context.</p>
                     <div className="flex items-center gap-2">
                        <input type="url" value={newUrl} onChange={e => setNewUrl(e.target.value)} placeholder="https://example.com/about" className="input-base flex-grow text-sm" />
                        <button onClick={handleAddUrl} className="btn btn-secondary text-sm flex-shrink-0">Add</button>
                    </div>
                </div>
                 <div className="md:col-span-2 p-4 rounded-lg border border-border-subtle bg-panel space-y-3">
                    <h3 className="font-semibold text-text-primary flex items-center gap-2"><GoogleDriveIcon className="h-5 w-5"/> Google Drive</h3>
                    <p className="text-xs text-text-secondary">Connect your Google account to directly import files from Google Drive as references.</p>
                    {isGoogleDriveConnected ? (
                        <div className="flex items-center gap-3">
                            <button onClick={onShowGooglePicker} className="btn btn-secondary text-sm flex-1">Import from Drive</button>
                            <button onClick={onDisconnectGoogleDrive} className="btn bg-red-900/40 hover:bg-red-800/60 text-red-300 text-sm flex-1">Disconnect</button>
                        </div>
                    ) : (
                        <button onClick={onConnectGoogleDrive} className="w-full btn btn-secondary text-sm flex items-center justify-center gap-2"> <GoogleIcon className="h-4 w-4" /> Connect Google Drive </button>
                    )}
                 </div>
            </div>

            <div className="mt-6 pt-6 border-t border-border-subtle">
                <h3 className="text-lg font-semibold text-white">Reference Library</h3>
                <div className="mt-4 space-y-2">
                    {site.references.length === 0 ? <p className="text-sm text-text-secondary text-center py-4">No references added yet.</p> : (
                        site.references.map(ref => {
                            const Icon = ref.type === 'url' ? LinkIcon : ref.mimeType?.startsWith('image') ? PhotoIcon : DocumentTextIcon;
                            return (
                                <div key={ref.id} className="bg-panel-light p-3 rounded-lg flex items-center justify-between gap-4 border border-border">
                                    <div className="flex items-center gap-3 min-w-0">
                                        <Icon className="h-5 w-5 text-text-secondary flex-shrink-0" />
                                        <span className="text-sm text-text-primary truncate">{ref.name}</span>
                                    </div>
                                    <button onClick={() => handleRemoveReference(ref.id)} className="text-red-500 hover:text-red-400"><XIcon className="h-4 w-4" /></button>
                                </div>
                            );
                        })
                    )}
                </div>
            </div>
        </div>
    );
};

const CharacterLibraryPanel: React.FC<Pick<ReferencesTabProps, 'site' | 'onSiteUpdate'>> = ({ site, onSiteUpdate }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingChar, setEditingChar] = useState<Partial<CharacterReference> & { id?: string } | null>(null);

    const handleOpenModal = (char?: CharacterReference) => {
        setEditingChar(char || {});
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingChar(null);
    };
    
    const handleSave = () => {
        if (!editingChar || !editingChar.name?.trim()) return;

        const library = site.characterLibrary || [];

        if (editingChar.id) { // Editing existing
            onSiteUpdate('characterLibrary', library.map(c => c.id === editingChar.id ? editingChar as CharacterReference : c));
        } else { // Adding new
            onSiteUpdate('characterLibrary', [...library, { ...editingChar, id: crypto.randomUUID() } as CharacterReference]);
        }
        handleCloseModal();
    };

    const handleDelete = (id: string) => {
        if (window.confirm("Are you sure you want to delete this character?")) {
            onSiteUpdate('characterLibrary', (site.characterLibrary || []).filter(c => c.id !== id));
        }
    };
    
    return (
        <div className="content-panel">
            <div className="flex justify-between items-center">
                <div>
                    <h2 className="text-xl font-bold text-white">Character Library</h2>
                    <p className="text-sm text-text-secondary mt-1">Create consistent characters for your AI-generated images and stories.</p>
                </div>
                <button onClick={() => handleOpenModal()} className="btn btn-primary flex items-center gap-2">
                    <PlusIcon className="h-5 w-5" /> Add Character
                </button>
            </div>
            <div className="mt-6 space-y-3">
                {(site.characterLibrary || []).length === 0 ? (
                    <p className="text-center text-sm text-text-secondary py-4">No characters created yet.</p>
                ) : (
                    (site.characterLibrary || []).map(char => (
                        <div key={char.id} className="bg-panel-light p-3 rounded-lg flex items-center gap-4 border border-border">
                            {char.visualReferenceImage ? (
                                <img src={char.visualReferenceImage} alt={char.name} className="h-12 w-12 rounded-full object-cover bg-panel"/>
                            ) : (
                                <div className="h-12 w-12 rounded-full bg-panel flex items-center justify-center"><UserIcon className="h-6 w-6 text-text-secondary"/></div>
                            )}
                            <div className="flex-1">
                                <p className="font-semibold text-text-primary">{char.name}</p>
                                <p className="text-xs text-text-secondary truncate">{char.personality || 'No personality defined'}</p>
                            </div>
                            <div className="flex items-center gap-2">
                                <button onClick={() => handleOpenModal(char)} className="btn btn-secondary p-2"><PenIcon className="h-4 w-4"/></button>
                                <button onClick={() => handleDelete(char.id)} className="btn bg-red-900/40 hover:bg-red-800/60 p-2 text-red-300"><TrashIcon className="h-4 w-4"/></button>
                            </div>
                        </div>
                    ))
                )}
            </div>
            {isModalOpen && editingChar && (
                 <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
                    <div className="bg-panel rounded-lg shadow-2xl w-full max-w-lg p-6 border border-border animate-modal-pop">
                         <h3 className="text-lg font-bold text-white">{editingChar.id ? 'Edit' : 'Add'} Character</h3>
                         <div className="mt-4 space-y-4">
                             <input type="text" placeholder="Character Name" value={editingChar.name || ''} onChange={e => setEditingChar(p => ({...p, name: e.target.value}))} className="input-base"/>
                             <textarea placeholder="Personality description (e.g., cheerful, optimistic, loves coffee)" value={editingChar.personality || ''} onChange={e => setEditingChar(p => ({...p, personality: e.target.value}))} className="input-base" rows={3}/>
                             <textarea placeholder="Visual description (e.g., 'A robot with a red helmet and blue eyes, cartoon style')" value={editingChar.visualReferenceText || ''} onChange={e => setEditingChar(p => ({...p, visualReferenceText: e.target.value}))} className="input-base" rows={3}/>
                         </div>
                         <div className="mt-4 flex justify-end gap-3">
                             <button onClick={handleCloseModal} className="btn btn-secondary">Cancel</button>
                             <button onClick={handleSave} className="btn btn-primary">Save Character</button>
                         </div>
                    </div>
                 </div>
            )}
        </div>
    );
};

export const ReferencesTab: React.FC<ReferencesTabProps> = (props) => {
    return (
        <div className="space-y-8 max-w-4xl mx-auto">
            <BrandingPanel {...props} />
            <KnowledgeBasePanel {...props} />
            <CharacterLibraryPanel {...props} />
        </div>
    );
};