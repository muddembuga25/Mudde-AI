import React from 'react';
import { LogoIcon, PlusIcon, SparklesIcon } from './Icons';

interface WelcomeScreenProps {
  onCreateWorkflow: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onCreateWorkflow }) => {
  return (
    <div className="flex items-center justify-center h-full w-full">
      <div className="text-center bg-panel/50 p-12 rounded-2xl border border-border max-w-2xl mx-auto animate-fade-in-up">
        <div className="relative inline-block mb-6">
            <div className="absolute -inset-2 bg-purple-500/20 rounded-full blur-xl"></div>
            <div className="relative bg-panel p-4 rounded-full border border-border">
                <LogoIcon />
            </div>
        </div>
        
        <h2 className="text-3xl font-extrabold text-white">Welcome to Mudde AI!</h2>
        <p className="mt-3 text-lg text-text-secondary max-w-lg mx-auto">
          Ready to supercharge your content creation? The first step is to create a 'Workflow'.
        </p>
        <p className="mt-2 text-sm text-text-secondary max-w-lg mx-auto">
          A Workflow is a dedicated workspace for each website you want to manage, containing its own branding, content sources, and automation settings.
        </p>
        
        <div className="mt-8">
          <button 
            onClick={onCreateWorkflow} 
            className="btn btn-primary text-lg py-3 px-6 shadow-2xl shadow-indigo-500/30 animate-pulse-bright"
          >
            <PlusIcon className="h-6 w-6 mr-2" />
            Create Your First Workflow
          </button>
        </div>
        
        <div className="mt-12 text-sm text-text-secondary flex items-center justify-center gap-2">
            <SparklesIcon className="h-4 w-4 text-purple-400" />
            <span>Let's create something amazing together.</span>
        </div>
      </div>
    </div>
  );
};