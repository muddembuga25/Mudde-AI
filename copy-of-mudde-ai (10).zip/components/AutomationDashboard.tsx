import React, { useState, useCallback, useRef, useMemo } from 'react';
import type { Site, RecurringSchedule, MailchimpAccount } from '../types';
import { AiProvider } from '../types';
import { AVAILABLE_MODELS, PLAN_LIMITS } from '../constants';
import { providerDisplayNames } from '../constants';
import { ClockIcon, CalendarDaysIcon, DocumentTextIcon, RssIcon, VideoCameraIcon, TrashIcon, ChevronDownIcon, WhatsAppIcon, TelegramIcon, MailIcon, ShareIcon, PhotoIcon, GoogleSheetsIcon, MailchimpIcon, KeyIcon, XIcon, PenIcon, SparklesIcon, WordPressIcon, CheckCircleIcon, ShieldCheckIcon } from './Icons';
import { useAuth } from '../contexts/AuthContext';
import * as mcpApiService from '../services/mcpApiService';

interface AutomationDashboardProps {
  site: Site;
  onSiteUpdate: (field: keyof Site, value: any) => void;
  onMultipleSiteUpdates: (updates: Partial<Site>) => void;
}

const ScheduleManager: React.FC<{
    schedules: RecurringSchedule[];
    onAdd: (schedule: Omit<RecurringSchedule, 'id' | 'isEnabled'>) => void;
    onDelete: (id: string) => void;
    onToggle: (id: string, isEnabled: boolean) => void;
}> = ({ schedules, onAdd, onDelete, onToggle }) => {
    const [newSchedule, setNewSchedule] = useState<Omit<RecurringSchedule, 'id' | 'isEnabled'>>({ type: 'weekly', days: [], time: '09:00' });
    
    const handleAdd = () => {
        if (newSchedule.days.length === 0 || !newSchedule.time) {
            alert("Please select at least one day and set a time.");
            return;
        }
        onAdd(newSchedule);
        setNewSchedule({ type: 'weekly', days: [], time: '09:00' });
    };
    
    const handleWeekDayToggle = (day: number) => {
        setNewSchedule(prev => {
            const newDays = prev.days.includes(day) ? prev.days.filter(d => d !== day) : [...prev.days, day];
            return { ...prev, days: newDays.sort((a: number, b: number) => a - b) };
        });
    };
    
    const handleMonthDaysChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const days = e.target.value.split(',').map(d => parseInt(d.trim())).filter(d => !isNaN(d) && d >= 1 && d <= 31);
        setNewSchedule(prev => ({ ...prev, days: [...new Set(days)].sort((a: number, b: number) => a - b) }));
    };

    const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    const formatSchedule = (schedule: RecurringSchedule) => {
        const time = ` at ${schedule.time}`;
        if (schedule.type === 'weekly') {
            if (schedule.days.length === 7) return `Every day${time}`;
            if (schedule.days.length === 0) return `Weekly (no days selected)${time}`;
            return `Weekly on ${schedule.days.map(d => weekDays[d]).join(', ')}${time}`;
        }
        if (schedule.type === 'monthly') {
            if (schedule.days.length === 0) return `Monthly (no days selected)${time}`;
            return `On day(s) ${schedule.days.join(', ')} of the month${time}`;
        }
        return 'Invalid Schedule';
    };

    return (
        <div className="space-y-8 p-4 bg-panel rounded-lg border border-border-subtle">
            <div>
                <h4 className="text-md font-semibold text-white">Add New Schedule</h4>
                <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-6 items-end">
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-text-primary">Schedule Type</label>
                            <div className="mt-2 grid grid-cols-2 gap-2 bg-panel-light rounded-lg p-1 w-full">
                                <button onClick={() => setNewSchedule(p => ({ ...p, type: 'weekly', days: [] }))} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors ${newSchedule.type === 'weekly' ? 'bg-purple-600 text-white' : 'text-text-secondary hover:bg-gray-700/50'}`}>Weekly</button>
                                <button onClick={() => setNewSchedule(p => ({ ...p, type: 'monthly', days: [] }))} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors ${newSchedule.type === 'monthly' ? 'bg-purple-600 text-white' : 'text-text-secondary hover:bg-gray-700/50'}`}>Monthly</button>
                            </div>
                        </div>
                        {newSchedule.type === 'weekly' ? (
                            <div>
                                <label className="block text-sm font-medium text-text-primary">Day(s) of the Week</label>
                                <div className="mt-2 flex flex-wrap gap-2">{weekDays.map((day, index) => (<button key={day} onClick={() => handleWeekDayToggle(index)} className={`w-10 h-10 text-sm font-semibold rounded-md transition-colors flex items-center justify-center ${newSchedule.days.includes(index) ? 'bg-purple-600 text-white' : 'bg-gray-700/50 text-text-secondary hover:bg-gray-700'}`}>{day}</button>))}</div>
                            </div>
                        ) : (
                            <div>
                                <label htmlFor="month-days" className="block text-sm font-medium text-text-primary">Day(s) of the Month</label>
                                <input id="month-days" type="text" value={newSchedule.days.join(', ')} onChange={handleMonthDaysChange} placeholder="e.g., 1, 15, 30" className="input-base mt-2 px-3 py-2" />
                            </div>
                        )}
                    </div>
                    <div className="grid grid-cols-2 gap-4 items-end">
                        <div>
                            <label htmlFor="schedule-time" className="block text-sm font-medium text-text-primary">Time</label>
                            <input id="schedule-time" type="time" value={newSchedule.time} onChange={(e) => setNewSchedule(p => ({ ...p, time: e.target.value }))} className="input-base mt-2 px-3 py-2" />
                        </div>
                        <button onClick={handleAdd} className="btn btn-primary w-full">Add Schedule</button>
                    </div>
                </div>
            </div>
            <div className="mt-6 pt-6 border-t border-border-subtle space-y-3">
                <h4 className="text-md font-semibold text-white">Current Schedules</h4>
                {schedules.length === 0 ? <p className="text-text-secondary text-sm">No schedules set.</p> : (
                    schedules.map(schedule => (
                        <div key={schedule.id} className="bg-panel-light p-3 rounded-lg flex items-center justify-between gap-4 border border-border">
                            <span className="font-medium text-text-secondary text-sm">{formatSchedule(schedule)}</span>
                            <div className="flex items-center gap-4">
                                <label className="relative inline-flex items-center cursor-pointer"><input type="checkbox" className="sr-only peer" checked={schedule.isEnabled} onChange={(e) => onToggle(schedule.id, e.target.checked)} /><div className="w-9 h-5 bg-gray-600 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-purple-600"></div></label>
                                <button onClick={() => onDelete(schedule.id)} className="text-red-500 hover:text-red-400 transition-colors"><TrashIcon className="h-5 w-5" /></button>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};


const WorkflowOption: React.FC<{
    title: string;
    description: string;
    isActive: boolean;
    onClick: () => void;
    disabled?: boolean;
    badge?: string;
}> = ({ title, description, isActive, onClick, disabled = false, badge }) => (
    <div className="relative">
        <button
            onClick={onClick}
            disabled={disabled}
            className={`w-full text-left p-4 rounded-lg border-2 transition-all ${
                isActive ? 'border-purple-500 bg-purple-900/20 shadow-lg shadow-purple-900/20' : 'border-border hover:border-gray-600'
            } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
            <div className="flex items-center">
                <div className={`w-5 h-5 rounded-full border-2 flex-shrink-0 flex items-center justify-center mr-4 ${isActive ? 'border-purple-400 bg-purple-500' : 'border-gray-500'}`}>
                    {isActive && <div className="w-2 h-2 rounded-full bg-white"></div>}
                </div>
                <div>
                    <p className="font-semibold text-white">{title}</p>
                    <p className="text-sm text-text-secondary">{description}</p>
                </div>
            </div>
        </button>
        {badge && (
            <div className="absolute top-3 right-3 text-xs font-bold text-yellow-400 bg-yellow-900/50 px-2 py-1 rounded-full pointer-events-none">
                {badge}
            </div>
        )}
    </div>
);

const AutomationModelConfig: React.FC<{
    site: Site;
    config: any;
    onConfigChange: (newConfig: any) => void;
    title: string;
    tasks: ('text' | 'image' | 'video')[];
}> = ({ site, config, onConfigChange, title, tasks }) => {
    
    const handleModelConfigUpdate = (field: string, value: any) => {
        const newConfig = { ...config, [field]: value };
        
        const setDefaults = (provider: AiProvider, type: 'text' | 'image' | 'video') => {
          const fetchedProviderModels = site.fetchedModels?.[provider];
          
          if (fetchedProviderModels) {
              if (type === 'text' && fetchedProviderModels.text.length > 0) {
                  newConfig.textModel = fetchedProviderModels.text[0];
                  return;
              }
              if (type === 'image' && fetchedProviderModels.image.length > 0) {
                  newConfig.imageModel = fetchedProviderModels.image[0];
                  return;
              }
              if (type === 'video' && fetchedProviderModels.video && fetchedProviderModels.video.length > 0) {
                  newConfig.videoModel = fetchedProviderModels.video[0];
                  return;
              }
          }
    
          const models = AVAILABLE_MODELS[provider as keyof typeof AVAILABLE_MODELS];
          if (type === 'text' && models.text.length > 0) newConfig.textModel = models.text[0];
          else if (type === 'image' && models.image.length > 0) newConfig.imageModel = models.image[0];
          else if (type === 'video' && models.video && models.video.length > 0) newConfig.videoModel = models.video[0];
          else if (type === 'image') newConfig.imageModel = '';
          else if (type === 'video') newConfig.videoModel = '';
        };
  
        if (field === 'textProvider') setDefaults(value, 'text');
        if (field === 'imageProvider') setDefaults(value, 'image');
        if (field === 'videoProvider') setDefaults(value, 'video');

        onConfigChange(newConfig);
    };

    const textModelsForProvider = site.fetchedModels?.[config.textProvider]?.text || AVAILABLE_MODELS[config.textProvider as keyof typeof AVAILABLE_MODELS]?.text || [];
    const imageModelsForProvider = config.imageProvider ? (site.fetchedModels?.[config.imageProvider]?.image || AVAILABLE_MODELS[config.imageProvider as keyof typeof AVAILABLE_MODELS]?.image || []) : [];
    const videoProviders = (Object.keys(AVAILABLE_MODELS) as AiProvider[]).filter(p => AVAILABLE_MODELS[p as keyof typeof AVAILABLE_MODELS].video && AVAILABLE_MODELS[p as keyof typeof AVAILABLE_MODELS].video!.length > 0);
    const videoModelsForProvider = config.videoProvider ? (site.fetchedModels?.[config.videoProvider]?.video || AVAILABLE_MODELS[config.videoProvider as keyof typeof AVAILABLE_MODELS]?.video || []) : [];


    return (
        <div className="p-4 bg-panel rounded-lg border border-border-subtle animate-fade-in">
            <h3 className="text-lg font-bold text-white">{title}</h3>
            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-6">
                {tasks.includes('text') && (
                    <div className="space-y-3">
                        <h4 className="font-semibold text-text-primary">Text Generation</h4>
                        <div>
                            <label className="block text-sm font-medium text-text-secondary mb-2">Provider</label>
                            <select value={config.textProvider} onChange={e => handleModelConfigUpdate('textProvider', e.target.value)} className="input-base px-4 py-2 w-full text-sm">
                                <option value={AiProvider.GOOGLE}>Google Gemini (Default)</option>
                                <option value={AiProvider.OPENAI}>OpenAI</option>
                                <option value={AiProvider.ANTHROPIC}>Anthropic Claude</option>
                                <option value={AiProvider.OPENROUTER}>OpenRouter</option>
                                <option value={AiProvider.XAI}>X.AI Grok</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-text-secondary mb-2">Model</label>
                            <input type="text" list={`text-models-list-${title.replace(/\s+/g, '-')}`} value={config.textModel} onChange={e => handleModelConfigUpdate('textModel', e.target.value)} className="input-base px-4 py-2 w-full text-sm" placeholder="Select or type model" />
                            <datalist id={`text-models-list-${title.replace(/\s+/g, '-')}`}>
                                {textModelsForProvider.map(model => <option key={model} value={model} />)}
                            </datalist>
                        </div>
                    </div>
                )}
                {tasks.includes('image') && (
                    <div className="space-y-3">
                        <h4 className="font-semibold text-text-primary">Image Generation</h4>
                        <div>
                            <label className="block text-sm font-medium text-text-secondary mb-2">Provider</label>
                            <select value={config.imageProvider} onChange={e => handleModelConfigUpdate('imageProvider', e.target.value)} className="input-base px-4 py-2 w-full text-sm">
                                <option value={AiProvider.GOOGLE}>Google Gemini (Default)</option>
                                <option value={AiProvider.OPENAI}>OpenAI</option>
                                <option value={AiProvider.OPENROUTER}>OpenRouter</option>
                                <option value={AiProvider.REPLICATE}>Replicate</option>
                                <option value={AiProvider.FREEPIK}>Freepik</option>
                                <option value={AiProvider.FALAI}>Fal.ai</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-text-secondary mb-2">Model</label>
                            <input type="text" list={`image-models-list-${title.replace(/\s+/g, '-')}`} value={config.imageModel} onChange={e => handleModelConfigUpdate('imageModel', e.target.value)} className="input-base px-4 py-2 w-full text-sm" placeholder="Select or type model" disabled={!config.imageProvider || imageModelsForProvider.length === 0} />
                             <datalist id={`image-models-list-${title.replace(/\s+/g, '-')}`}>
                                {imageModelsForProvider.map(model => <option key={model} value={model} />)}
                            </datalist>
                            {imageModelsForProvider.length === 0 && config.imageProvider && (
                                <p className="text-xs text-yellow-400 bg-yellow-900/30 p-2 rounded-md mt-2">
                                    Provider '{providerDisplayNames[config.imageProvider]}' does not offer image models.
                                </p>
                            )}
                        </div>
                    </div>
                )}
                {tasks.includes('video') && (
                    <div className="space-y-3">
                        <h4 className="font-semibold text-text-primary">Video Generation</h4>
                        <div>
                            <label className="block text-sm font-medium text-text-secondary mb-2">Provider</label>
                            <select value={config.videoProvider || ''} onChange={e => handleModelConfigUpdate('videoProvider', e.target.value)} className="input-base px-4 py-2 w-full text-sm">
                                {videoProviders.map(p => <option key={p} value={p}>{providerDisplayNames[p]}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-text-secondary mb-2">Model</label>
                            <input type="text" list={`video-models-list-${title.replace(/\s+/g, '-')}`} value={config.videoModel || ''} onChange={e => handleModelConfigUpdate('videoModel', e.target.value)} className="input-base px-4 py-2 w-full text-sm" placeholder="Select or type model" disabled={!config.videoProvider || videoModelsForProvider.length === 0} />
                             <datalist id={`video-models-list-${title.replace(/\s+/g, '-')}`}>
                                {videoModelsForProvider.map(model => <option key={model} value={model} />)}
                            </datalist>
                            {videoModelsForProvider.length === 0 && config.videoProvider && (
                                <p className="text-xs text-yellow-400 bg-yellow-900/30 p-2 rounded-md mt-2">
                                    Provider '{providerDisplayNames[config.videoProvider]}' does not offer video models.
                                </p>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};


export const AutomationDashboard: React.FC<AutomationDashboardProps> = ({ site, onSiteUpdate, onMultipleSiteUpdates }) => {
    const { currentUser } = useAuth();
    const [isConnectingMailchimp, setIsConnectingMailchimp] = useState(false);

    if (!currentUser) return null;
    const planFeatures = PLAN_LIMITS[currentUser.subscription.plan].features;

    const blogWorkflowState = !site.isAutomationEnabled 
        ? 'off' 
        : site.isAutoPublishEnabled 
            ? 'automatic' 
            : 'review';
            
    const handleNotificationMethodToggle = (method: 'whatsapp' | 'telegram' | 'email') => {
        const currentMethods = site.draftNotificationMethods || [];
        const newMethods = currentMethods.includes(method)
            ? currentMethods.filter(m => m !== method)
            : [...currentMethods, method];
        onSiteUpdate('draftNotificationMethods', newMethods);
    };

    const handleConnectMailchimp = useCallback(async () => {
        const { apiKey, serverPrefix } = site.mailchimp || {};
        if (!apiKey || !serverPrefix) return;
        setIsConnectingMailchimp(true);
        try {
            const { updatedSite } = await mcpApiService.connectMailchimp(site.id, apiKey, serverPrefix);
            onMultipleSiteUpdates(updatedSite);
        } catch (e) {
            console.error("Mailchimp connection failed", e);
        } finally {
            setIsConnectingMailchimp(false);
        }
    }, [site.id, site.mailchimp, onMultipleSiteUpdates]);

    const handleDisconnectMailchimp = useCallback(async () => {
        setIsConnectingMailchimp(true);
        try {
            const { updatedSite } = await mcpApiService.disconnectMailchimp(site.id);
            onMultipleSiteUpdates(updatedSite);
        } finally {
            setIsConnectingMailchimp(false);
        }
    }, [site.id, onMultipleSiteUpdates]);
    
    const isDataforseoDiscoveryActive = site.seoDataProvider.startsWith('dataforseo') && !!site.apiKeys.dataforseo && !!site.dataforseoSeedKeywords;

    return (
        <div className="space-y-6 max-w-4xl mx-auto">
            <div className="content-panel">
                <h2 className="text-xl font-bold text-white">Master Automation Content Source</h2>
                <p className="text-sm text-text-secondary mt-1">Select the single source of topics for all of your automations. When an automation runs, it will pick the next available item from this list.</p>
                <div className="mt-4 grid grid-cols-1 sm:grid-cols-4 gap-2 bg-panel-light rounded-lg p-1 w-full">
                    <button onClick={() => onSiteUpdate('masterAutomationSource', 'keyword')} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${site.masterAutomationSource === 'keyword' ? 'bg-purple-600 text-white shadow-sm' : 'text-text-secondary hover:bg-gray-700/50'}`}><DocumentTextIcon className="h-5 w-5" /> Keyword List</button>
                    <button onClick={() => onSiteUpdate('masterAutomationSource', 'rss')} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${site.masterAutomationSource === 'rss' ? 'bg-purple-600 text-white shadow-sm' : 'text-text-secondary hover:bg-gray-700/50'}`}><RssIcon className="h-5 w-5" /> RSS Feed</button>
                    <button onClick={() => onSiteUpdate('masterAutomationSource', 'video')} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${site.masterAutomationSource === 'video' ? 'bg-purple-600 text-white shadow-sm' : 'text-text-secondary hover:bg-gray-700/50'}`}><VideoCameraIcon className="h-5 w-5" /> Video Source</button>
                    <button onClick={() => onSiteUpdate('masterAutomationSource', 'google_sheet')} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${site.masterAutomationSource === 'google_sheet' ? 'bg-purple-600 text-white shadow-sm' : 'text-text-secondary hover:bg-gray-700/50'}`}><GoogleSheetsIcon className="h-5 w-5" /> Google Sheet</button>
                </div>
                {site.masterAutomationSource === 'keyword' && (
                    <div className="mt-3 text-xs p-2 rounded-md bg-panel-light border border-border-subtle">
                        {isDataforseoDiscoveryActive ? (
                            <p className="text-green-300">✅ DataForSEO Discovery is active. The system will use your master content source as a seed to find optimal keywords.</p>
                        ) : (
                            <p className="text-text-secondary">ⓘ The system will use the next available keyword from the list in the 'Blog Posts' tab.</p>
                        )}
                    </div>
                )}
            </div>
            
            {/* Blog Post Automation Section */}
            <details className="content-panel p-0 overflow-hidden" open>
                <summary className="w-full flex items-center justify-between p-6 cursor-pointer">
                    <div className='text-left'><h2 className="text-xl font-bold text-white">Blog Post Automation</h2><p className="text-sm text-text-secondary mt-1">Automatically generate and publish full blog articles.</p></div>
                    <ChevronDownIcon className="h-6 w-6 text-text-secondary transition-transform chevron-rotate" />
                </summary>
                <div className="p-6 border-t border-border-subtle animate-fade-in space-y-6">
                    <div>
                        <h3 className="text-md font-semibold text-white">Workflow Selection</h3>
                        <p className="text-sm text-text-secondary mt-1">Choose your preferred method for automated content creation.</p>
                        <div className="mt-4 space-y-3">
                            <WorkflowOption title="Disabled" description="No posts will be generated automatically." isActive={blogWorkflowState === 'off'} onClick={() => onSiteUpdate('isAutomationEnabled', false)} />
                            <WorkflowOption title="Fully Automatic" description="AI generates and publishes articles directly to your site." isActive={blogWorkflowState === 'automatic'} onClick={() => onMultipleSiteUpdates({ isAutomationEnabled: true, isAutoPublishEnabled: true })} disabled={!planFeatures.autoPublish} badge={!planFeatures.autoPublish ? "CREATOR+" : undefined} />
                            <div className="bg-panel-light/30 rounded-lg">
                                <WorkflowOption title="Human-in-the-Loop" description="AI generates articles and saves them as drafts for your review." isActive={blogWorkflowState === 'review'} onClick={() => onMultipleSiteUpdates({ isAutomationEnabled: true, isAutoPublishEnabled: false })} />
                                {blogWorkflowState === 'review' && (
                                    <div className="p-4 border-t border-purple-500/30 animate-fade-in space-y-4">
                                        <div className="flex items-center justify-between">
                                            <p className="font-semibold text-text-primary">Notify when new draft is ready</p>
                                            <label className="relative inline-flex items-center cursor-pointer">
                                                <input type="checkbox" className="sr-only peer" checked={site.isDraftNotificationEnabled} onChange={e => onSiteUpdate('isDraftNotificationEnabled', e.target.checked)} />
                                                <div className="w-11 h-6 bg-gray-600/50 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                                            </label>
                                        </div>
                                        {site.isDraftNotificationEnabled && (
                                            <div className="pl-4 border-l-2 border-border-subtle space-y-4 pt-2 animate-fade-in">
                                                <div>
                                                    <label className="block text-sm font-medium text-text-primary mb-2">Notification Methods</label>
                                                    <div className="flex flex-wrap gap-3">
                                                        <button onClick={() => handleNotificationMethodToggle('whatsapp')} className={`btn text-sm flex items-center gap-2 ${site.draftNotificationMethods.includes('whatsapp') ? 'btn-primary' : 'btn-secondary'}`}><WhatsAppIcon className="h-4 w-4" /> WhatsApp</button>
                                                        <button onClick={() => handleNotificationMethodToggle('telegram')} className={`btn text-sm flex items-center gap-2 ${site.draftNotificationMethods.includes('telegram') ? 'btn-primary' : 'btn-secondary'}`}><TelegramIcon className="h-4 w-4" /> Telegram</button>
                                                        <button onClick={() => handleNotificationMethodToggle('email')} className={`btn text-sm flex items-center gap-2 ${site.draftNotificationMethods.includes('email') ? 'btn-primary' : 'btn-secondary'}`}><MailIcon className="h-4 w-4" /> Email</button>
                                                    </div>
                                                </div>
                                                {site.draftNotificationMethods.includes('email') && (
                                                    <div className="animate-fade-in">
                                                        <label htmlFor="notification-email" className="block text-sm font-medium text-text-primary mb-2">Notification Email Address</label>
                                                        <input id="notification-email" type="email" value={site.draftNotificationEmail || ''} onChange={e => onSiteUpdate('draftNotificationEmail', e.target.value)} placeholder="your.email@example.com" className="input-base px-4 py-2" />
                                                    </div>
                                                )}
                                                 {(site.draftNotificationMethods.includes('whatsapp') || site.draftNotificationMethods.includes('telegram')) && (
                                                    <p className="text-xs text-text-secondary">Note: Notifications will be sent to the first connected and enabled account for the selected platform in your Social Media settings.</p>
                                                 )}
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>
                        </div>

                        <div>
                            <h3 className="text-md font-semibold text-white">Local SEO Targeting (Optional)</h3>
                            <p className="text-sm text-text-secondary mt-1">Tailor content strategy for a specific geographic area.</p>
                            <div className="mt-4 p-4 bg-panel rounded-lg border border-border-subtle space-y-4">
                                <div className="flex items-center justify-between">
                                    <p className="font-semibold text-text-primary">Enable Local Targeting</p>
                                    <label className="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" className="sr-only peer" checked={site.isLocalSeoEnabled} onChange={e => onSiteUpdate('isLocalSeoEnabled', e.target.checked)} />
                                        <div className="w-11 h-6 bg-gray-600/50 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                                    </label>
                                </div>
                                {site.isLocalSeoEnabled && (
                                    <div className="pt-4 border-t border-border-subtle space-y-4 animate-fade-in">
                                        <div>
                                            <label htmlFor="local-business-name" className="block text-sm font-medium text-text-primary mb-2">Business Name (Optional)</label>
                                            <input id="local-business-name" type="text" value={site.localSeoBusinessName || ''} onChange={e => onSiteUpdate('localSeoBusinessName', e.target.value)} placeholder="e.g., Sydney Harbour Coffee Roasters" className="input-base px-4 py-2" />
                                        </div>
                                        <div>
                                            <label htmlFor="local-service-area" className="block text-sm font-medium text-text-primary mb-2">Business Location or Service Area</label>
                                            <input id="local-service-area" type="text" value={site.localSeoServiceArea || ''} onChange={e => onSiteUpdate('localSeoServiceArea', e.target.value)} placeholder="e.g., 123 Main St, Sydney or Plumber in Parramatta" className="input-base px-4 py-2" />
                                            <p className="text-xs text-text-secondary mt-1">Be specific. This is the most important field for local targeting.</p>
                                        </div>
                                         <div>
                                            <label htmlFor="local-phone-number" className="block text-sm font-medium text-text-primary mb-2">Phone Number (Optional)</label>
                                            <input id="local-phone-number" type="tel" value={site.localSeoPhoneNumber || ''} onChange={e => onSiteUpdate('localSeoPhoneNumber', e.target.value)} placeholder="e.g., +61 2 9123 4567" className="input-base px-4 py-2" />
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>

                        {site.isAutomationEnabled && (
                            <div className="pt-6 border-t border-border-subtle space-y-6 animate-fade-in">
                                 <div>
                                    <h3 className="text-md font-semibold text-white">Follow-up Actions</h3>
                                    <p className="text-sm text-text-secondary mt-1">Automatically trigger additional marketing actions after a post is published.</p>
                                    <div className={`mt-4 p-4 rounded-lg border border-border-subtle space-y-4 ${!planFeatures.postPublishFollowups ? 'opacity-60' : ''}`}>
                                        <div className="flex items-center justify-between">
                                            <p className="font-semibold text-text-primary">Enable Social Media Follow-up</p>
                                            <label className="relative inline-flex items-center cursor-pointer">
                                                <input type="checkbox" className="sr-only peer" checked={site.isSocialFollowUpEnabled} onChange={e => onSiteUpdate('isSocialFollowUpEnabled', e.target.checked)} disabled={!planFeatures.postPublishFollowups} />
                                                <div className="w-11 h-6 bg-gray-600/50 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                                            </label>
                                        </div>
                                        {!planFeatures.postPublishFollowups && <p className="text-xs text-yellow-400">Requires a paid plan.</p>}
                                        {site.isSocialFollowUpEnabled && planFeatures.postPublishFollowups && (
                                            <div className="pt-4 border-t border-border-subtle animate-fade-in">
                                                <p className="text-xs text-text-secondary">
                                                    After a blog post is published, corresponding social media posts will be automatically published to all connected and enabled accounts.
                                                </p>
                                            </div>
                                        )}
                                    </div>
                                    <div className={`mt-4 p-4 rounded-lg border border-border-subtle space-y-4 ${!planFeatures.emailMarketing ? 'opacity-60' : ''}`}>
                                        <div className="flex items-center justify-between">
                                            <p className="font-semibold text-text-primary">Enable Email Marketing Follow-up</p>
                                            <label className="relative inline-flex items-center cursor-pointer">
                                                <input type="checkbox" className="sr-only peer" checked={site.isEmailFollowUpEnabled} onChange={e => onSiteUpdate('isEmailFollowUpEnabled', e.target.checked)} disabled={!planFeatures.emailMarketing}/>
                                                <div className="w-11 h-6 bg-gray-600/50 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                                            </label>
                                        </div>
                                         {!planFeatures.emailMarketing && <p className="text-xs text-yellow-400">Requires PRO+ plan.</p>}
                                        {site.isEmailFollowUpEnabled && planFeatures.emailMarketing && (
                                            <div className="pt-4 border-t border-border-subtle animate-fade-in space-y-6">
                                                <div>
                                                    <h4 className="text-lg font-bold text-white mb-4">Email Service Integration</h4>
                                                    <div className="p-4 rounded-lg border border-border-subtle space-y-4 bg-panel">
                                                        <div className="flex items-center gap-3">
                                                            <MailchimpIcon className="h-8 w-8 text-yellow-400"/>
                                                            <div>
                                                                <h5 className="font-bold text-white">Mailchimp</h5>
                                                                <p className="text-xs text-text-secondary">Connect to send campaigns directly to your audience.</p>
                                                            </div>
                                                        </div>
                                                        {site.mailchimp?.status === 'error' && <p className="text-xs text-red-400 bg-red-900/30 p-2 rounded-md border border-red-500/30">{site.mailchimp.statusMessage}</p>}
                                                        {site.mailchimp?.status === 'connected' && <p className="text-xs text-green-400 bg-green-900/30 p-2 rounded-md border border-green-500/30">{site.mailchimp.statusMessage}</p>}
                                                        <div className="space-y-3">
                                                            <div>
                                                                <label className="block text-sm font-medium text-text-secondary mb-1">API Key</label>
                                                                <input type="password" value={site.mailchimp?.apiKey || ''} onChange={e => onSiteUpdate('mailchimp', {...site.mailchimp, apiKey: e.target.value})} className="input-base text-sm" placeholder="Enter your Mailchimp API Key" disabled={site.mailchimp?.isConnected} />
                                                            </div>
                                                            <div>
                                                                <label className="block text-sm font-medium text-text-secondary mb-1">Server Prefix</label>
                                                                <input type="text" value={site.mailchimp?.serverPrefix || ''} onChange={e => onSiteUpdate('mailchimp', {...site.mailchimp, serverPrefix: e.target.value})} className="input-base text-sm" placeholder="e.g., us19 (from end of API key)" disabled={site.mailchimp?.isConnected} />
                                                            </div>
                                                            {site.mailchimp?.isConnected && (
                                                                <div>
                                                                    <label className="block text-sm font-medium text-text-secondary mb-1">Default Audience</label>
                                                                    <select value={site.mailchimp.defaultAudienceId || ''} onChange={e => onSiteUpdate('mailchimp', {...site.mailchimp, defaultAudienceId: e.target.value})} className="input-base w-full text-sm">
                                                                        <option value="" disabled>Select an audience</option>
                                                                        {site.mailchimp.availableAudiences?.map(aud => <option key={aud.id} value={aud.id}>{aud.name}</option>)}
                                                                    </select>
                                                                </div>
                                                            )}
                                                            {site.mailchimp?.isConnected ? (
                                                                <button onClick={handleDisconnectMailchimp} className="btn btn-secondary w-full text-sm" disabled={isConnectingMailchimp}>{isConnectingMailchimp ? 'Working...' : 'Disconnect'}</button>
                                                            ) : (
                                                                <button onClick={handleConnectMailchimp} className="btn btn-primary w-full text-sm" disabled={isConnectingMailchimp || !site.mailchimp?.apiKey || !site.mailchimp?.serverPrefix}>{isConnectingMailchimp ? 'Connecting...' : 'Connect to Mailchimp'}</button>
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                                <AutomationModelConfig
                                                    site={site}
                                                    title="Email Generation Models"
                                                    config={site.emailMarketingModelConfig || site.modelConfig}
                                                    onConfigChange={(newConfig) => onSiteUpdate('emailMarketingModelConfig', newConfig)}
                                                    tasks={['text']}
                                                />
                                            </div>
                                        )}
                                    </div>
                                </div>

                                <AutomationModelConfig
                                    site={site}
                                    title="Blog Post Generation Models"
                                    config={site.blogPostAutomationModelConfig || site.modelConfig}
                                    onConfigChange={(newConfig) => onSiteUpdate('blogPostAutomationModelConfig', newConfig)}
                                    tasks={['text', 'image']}
                                />

                                <div>
                                    <label className="block text-sm font-medium text-text-primary">Automation Trigger</label>
                                    <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-2 bg-panel-light rounded-lg p-1 w-full sm:max-w-md"><button onClick={() => onSiteUpdate('automationTrigger', 'interval')} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${site.automationTrigger === 'interval' ? 'bg-purple-600 text-white shadow-md' : 'text-text-secondary hover:bg-gray-700/50'}`}><ClockIcon className="h-5 w-5" /> Auto-Pilot</button><button onClick={() => onSiteUpdate('automationTrigger', 'schedule')} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${site.automationTrigger === 'schedule' ? 'bg-purple-600 text-white shadow-md' : 'text-text-secondary hover:bg-gray-700/50'}`}><CalendarDaysIcon className="h-5 w-5" /> Scheduled</button></div>
                                </div>
                                {site.automationTrigger === 'interval' ? (
                                    <div className="space-y-6 p-4 bg-panel rounded-lg border border-border-subtle">
                                        <h3 className="text-lg font-bold text-white">Auto-Pilot Settings</h3>
                                        <div><label htmlFor="autopilot-interval" className="block text-sm font-medium text-text-primary">Generation Interval</label><div className="mt-2 flex items-center gap-2"><input id="autopilot-interval" type="number" min="1" value={site.automationIntervalHours} onChange={(e) => onSiteUpdate('automationIntervalHours', Math.max(1, parseInt(e.target.value, 10) || 1))} className="input-base px-3 py-2 w-24" /><span className="text-text-secondary">hours</span></div></div>
                                    </div>
                                ) : (
                                    <div className="space-y-6 p-4 bg-panel rounded-lg border border-border-subtle">
                                        <h3 className="text-lg font-bold text-white">Scheduled Publishing Settings</h3>
                                        <ScheduleManager schedules={site.recurringSchedules || []} onAdd={(s) => onSiteUpdate('recurringSchedules', [...(site.recurringSchedules || []), { ...s, id: crypto.randomUUID(), isEnabled: true }])} onDelete={(id) => onSiteUpdate('recurringSchedules', site.recurringSchedules.filter(s => s.id !== id))} onToggle={(id, e) => onSiteUpdate('recurringSchedules', site.recurringSchedules.map(s => s.id === id ? { ...s, isEnabled: e } : s))} />
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </details>

            {/* Social Graphics Automation Section */}
            <details className={`content-panel p-0 overflow-hidden ${!planFeatures.socialGraphics ? 'opacity-60' : ''}`} open>
                <summary className="w-full flex items-center justify-between p-6 cursor-pointer" onClick={(e) => !planFeatures.socialGraphics && e.preventDefault()}>
                    <div className='text-left'>
                        <h2 className="text-xl font-bold text-white">Social Graphics Automation</h2>
                        <p className="text-sm text-text-secondary mt-1">Automatically generate one unique image and caption, then publish it to all connected social media accounts.</p>
                    </div>
                    {!planFeatures.socialGraphics && <div className="text-xs font-bold text-yellow-400 bg-yellow-900/50 px-2 py-1 rounded-full">CREATOR+</div>}
                    <ChevronDownIcon className="h-6 w-6 text-text-secondary transition-transform chevron-rotate" />
                </summary>
                {planFeatures.socialGraphics && (
                    <div className="p-6 border-t border-border-subtle animate-fade-in space-y-6">
                        <div className="flex items-center justify-between"><p className="font-semibold text-white">Enable Social Graphics Automation</p><label className="relative inline-flex items-center cursor-pointer"><input type="checkbox" className="sr-only peer" checked={site.isSocialGraphicAutomationEnabled} onChange={e => onSiteUpdate('isSocialGraphicAutomationEnabled', e.target.checked)} /><div className="w-11 h-6 bg-gray-600/50 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div></label></div>
                        {site.isSocialGraphicAutomationEnabled && (
                            <div className="space-y-6">
                                <AutomationModelConfig
                                    site={site}
                                    title="Social Graphic Generation Models"
                                    config={site.socialGraphicAutomationModelConfig || site.modelConfig}
                                    onConfigChange={(newConfig) => onSiteUpdate('socialGraphicAutomationModelConfig', newConfig)}
                                    tasks={['text', 'image']}
                                />
                                <div>
                                    <label className="block text-sm font-medium text-text-primary">Automation Trigger</label>
                                    <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-2 bg-panel-light rounded-lg p-1 w-full sm:max-w-md"><button onClick={() => onSiteUpdate('socialGraphicAutomationTrigger', 'interval')} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${site.socialGraphicAutomationTrigger === 'interval' ? 'bg-purple-600 text-white shadow-md' : 'text-text-secondary hover:bg-gray-700/50'}`}><ClockIcon className="h-5 w-5" /> Auto-Pilot</button><button onClick={() => onSiteUpdate('socialGraphicAutomationTrigger', 'schedule')} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${site.socialGraphicAutomationTrigger === 'schedule' ? 'bg-purple-600 text-white shadow-md' : 'text-text-secondary hover:bg-gray-700/50'}`}><CalendarDaysIcon className="h-5 w-5" /> Scheduled</button></div>
                                </div>
                                {site.socialGraphicAutomationTrigger === 'interval' ? (
                                    <div className="space-y-6 p-4 bg-panel rounded-lg border border-border-subtle">
                                        <h3 className="text-lg font-bold text-white">Auto-Pilot Settings</h3>
                                        <div><label htmlFor="social-graphic-autopilot-interval" className="block text-sm font-medium text-text-primary">Publish Interval</label><div className="mt-2 flex items-center gap-2"><input id="social-graphic-autopilot-interval" type="number" min="1" value={site.socialGraphicAutomationIntervalHours} onChange={(e) => onSiteUpdate('socialGraphicAutomationIntervalHours', Math.max(1, parseInt(e.target.value, 10) || 1))} className="input-base px-3 py-2 w-24" /><span className="text-text-secondary">hours</span></div></div>
                                    </div>
                                ) : (
                                    <ScheduleManager schedules={site.socialGraphicRecurringSchedules || []} onAdd={(s) => onSiteUpdate('socialGraphicRecurringSchedules', [...(site.socialGraphicRecurringSchedules || []), { ...s, id: crypto.randomUUID(), isEnabled: true }])} onDelete={(id) => onSiteUpdate('socialGraphicRecurringSchedules', site.socialGraphicRecurringSchedules.filter(s => s.id !== id))} onToggle={(id, e) => onSiteUpdate('socialGraphicRecurringSchedules', site.socialGraphicRecurringSchedules.map(s => s.id === id ? { ...s, isEnabled: e } : s))} />
                                )}
                            </div>
                        )}
                    </div>
                )}
            </details>

            {/* Social Video Automation Section */}
            <details className={`content-panel p-0 overflow-hidden ${!planFeatures.socialVideo ? 'opacity-60' : ''}`}>
                <summary className="w-full flex items-center justify-between p-6 cursor-pointer" onClick={(e) => !planFeatures.socialVideo && e.preventDefault()}>
                    <div className='text-left flex items-center gap-4'>
                        <div>
                            <h2 className="text-xl font-bold text-white">Social Video Automation</h2>
                            <p className="text-sm text-text-secondary mt-1">Automatically generate short-form videos and publish to social accounts</p>
                        </div>
                    </div>
                    {!planFeatures.socialVideo && <div className="text-xs font-bold text-yellow-400 bg-yellow-900/50 px-2 py-1 rounded-full">PRO+</div>}
                    <ChevronDownIcon className="h-6 w-6 text-text-secondary transition-transform chevron-rotate" />
                </summary>
                {planFeatures.socialVideo && (
                    <div className="p-6 border-t border-border-subtle animate-fade-in space-y-6">
                        <div className="flex items-center justify-between"><p className="font-semibold text-white">Enable Social Video Automation</p><label className="relative inline-flex items-center cursor-pointer"><input type="checkbox" className="sr-only peer" checked={site.isSocialVideoAutomationEnabled} onChange={e => onSiteUpdate('isSocialVideoAutomationEnabled', e.target.checked)} /><div className="w-11 h-6 bg-gray-600/50 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div></label></div>
                        {site.isSocialVideoAutomationEnabled && (<div className="space-y-6">
                            <AutomationModelConfig
                                site={site}
                                title="Social Video Generation Models"
                                config={site.socialVideoAutomationModelConfig || site.modelConfig}
                                onConfigChange={(newConfig) => onSiteUpdate('socialVideoAutomationModelConfig', newConfig)}
                                tasks={['text', 'video']}
                            />
                            <div>
                                <label className="block text-sm font-medium text-text-primary">Automation Trigger</label>
                                <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-2 bg-panel-light rounded-lg p-1 w-full sm:max-w-md"><button onClick={() => onSiteUpdate('socialVideoAutomationTrigger', 'interval')} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${site.socialVideoAutomationTrigger === 'interval' ? 'bg-purple-600 text-white shadow-md' : 'text-text-secondary hover:bg-gray-700/50'}`}><ClockIcon className="h-5 w-5" /> Auto-Pilot</button><button onClick={() => onSiteUpdate('socialVideoAutomationTrigger', 'schedule')} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${site.socialVideoAutomationTrigger === 'schedule' ? 'bg-purple-600 text-white shadow-md' : 'text-text-secondary hover:bg-gray-700/50'}`}><CalendarDaysIcon className="h-5 w-5" /> Scheduled</button></div>
                            </div>
                            {site.socialVideoAutomationTrigger === 'interval' ? (
                                <div className="space-y-6 p-4 bg-panel rounded-lg border border-border-subtle">
                                    <h3 className="text-lg font-bold text-white">Auto-Pilot Settings</h3>
                                    <div><label htmlFor="social-video-autopilot-interval" className="block text-sm font-medium text-text-primary">Publish Interval</label><div className="mt-2 flex items-center gap-2"><input id="social-video-autopilot-interval" type="number" min="1" value={site.socialVideoAutomationIntervalHours} onChange={(e) => onSiteUpdate('socialVideoAutomationIntervalHours', Math.max(1, parseInt(e.target.value, 10) || 1))} className="input-base px-3 py-2 w-24" /><span className="text-text-secondary">hours</span></div></div>
                                </div>
                            ) : (
                                 <ScheduleManager schedules={site.socialVideoRecurringSchedules || []} onAdd={(s) => onSiteUpdate('socialVideoRecurringSchedules', [...(site.socialVideoRecurringSchedules || []), { ...s, id: crypto.randomUUID(), isEnabled: true }])} onDelete={(id) => onSiteUpdate('socialVideoRecurringSchedules', site.socialVideoRecurringSchedules.filter(s => s.id !== id))} onToggle={(id, e) => onSiteUpdate('socialVideoRecurringSchedules', site.socialVideoRecurringSchedules.map(s => s.id === id ? { ...s, isEnabled: e } : s))} />
                            )}
                        </div>)}
                    </div>
                )}
            </details>

            {/* Standalone Email Marketing Automation Section */}
            <details className={`content-panel p-0 overflow-hidden ${!planFeatures.emailMarketing ? 'opacity-60' : ''}`}>
                <summary className="w-full flex items-center justify-between p-6 cursor-pointer" onClick={(e) => !planFeatures.emailMarketing && e.preventDefault()}>
                    <div className='text-left'><h2 className="text-xl font-bold text-white">Standalone Email Marketing</h2><p className="text-sm text-text-secondary mt-1">Automatically generate and send one-off email newsletters.</p></div>
                     {!planFeatures.emailMarketing && <div className="text-xs font-bold text-yellow-400 bg-yellow-900/50 px-2 py-1 rounded-full">PRO+</div>}
                    <ChevronDownIcon className="h-6 w-6 text-text-secondary transition-transform chevron-rotate" />
                </summary>
                {planFeatures.emailMarketing && (
                    <div className="p-6 border-t border-border-subtle animate-fade-in space-y-6">
                        <div className="flex items-center justify-between"><p className="font-semibold text-white">Enable Email Marketing Automation</p><label className="relative inline-flex items-center cursor-pointer"><input type="checkbox" className="sr-only peer" checked={site.isEmailMarketingAutomationEnabled} onChange={e => onSiteUpdate('isEmailMarketingAutomationEnabled', e.target.checked)} /><div className="w-11 h-6 bg-gray-600/50 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div></label></div>
                        {site.isEmailMarketingAutomationEnabled && (<div className="space-y-6">
                            <AutomationModelConfig
                                site={site}
                                title="Email Generation Models"
                                config={site.emailMarketingModelConfig || site.modelConfig}
                                onConfigChange={(newConfig) => onSiteUpdate('emailMarketingModelConfig', newConfig)}
                                tasks={['text']}
                            />
                            <div>
                                <label className="block text-sm font-medium text-text-primary">Automation Trigger</label>
                                <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-2 bg-panel-light rounded-lg p-1 w-full sm:max-w-md"><button onClick={() => onSiteUpdate('emailMarketingAutomationTrigger', 'interval')} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${site.emailMarketingAutomationTrigger === 'interval' ? 'bg-purple-600 text-white shadow-md' : 'text-text-secondary hover:bg-gray-700/50'}`}><ClockIcon className="h-5 w-5" /> Auto-Pilot</button><button onClick={() => onSiteUpdate('emailMarketingAutomationTrigger', 'schedule')} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${site.emailMarketingAutomationTrigger === 'schedule' ? 'bg-purple-600 text-white shadow-md' : 'text-text-secondary hover:bg-gray-700/50'}`}><CalendarDaysIcon className="h-5 w-5" /> Scheduled</button></div>
                            </div>
                            {site.emailMarketingAutomationTrigger === 'interval' ? (
                                <div className="space-y-6 p-4 bg-panel rounded-lg border border-border-subtle">
                                    <h3 className="text-lg font-bold text-white">Auto-Pilot Settings</h3>
                                    <div><label htmlFor="email-autopilot-interval" className="block text-sm font-medium text-text-primary">Send Interval</label><div className="mt-2 flex items-center gap-2"><input id="email-autopilot-interval" type="number" min="1" value={site.emailMarketingAutomationIntervalHours} onChange={(e) => onSiteUpdate('emailMarketingAutomationIntervalHours', Math.max(1, parseInt(e.target.value, 10) || 1))} className="input-base px-3 py-2 w-24" /><span className="text-text-secondary">hours</span></div></div>
                                </div>
                            ) : (
                                 <ScheduleManager schedules={site.emailMarketingRecurringSchedules || []} onAdd={(s) => onSiteUpdate('emailMarketingRecurringSchedules', [...(site.emailMarketingRecurringSchedules || []), { ...s, id: crypto.randomUUID(), isEnabled: true }])} onDelete={(id) => onSiteUpdate('emailMarketingRecurringSchedules', site.emailMarketingRecurringSchedules.filter(s => s.id !== id))} onToggle={(id, e) => onSiteUpdate('emailMarketingRecurringSchedules', site.emailMarketingRecurringSchedules.map(s => s.id === id ? { ...s, isEnabled: e } : s))} />
                            )}
                        </div>)}
                    </div>
                )}
            </details>

            {/* Email Digest Section */}
             <details className={`content-panel p-0 overflow-hidden ${!planFeatures.emailMarketing ? 'opacity-60' : ''}`}>
                <summary className="w-full flex items-center justify-between p-6 cursor-pointer" onClick={(e) => !planFeatures.emailMarketing && e.preventDefault()}>
                    <div className='text-left'><h2 className="text-xl font-bold text-white">Email Digest Automation</h2><p className="text-sm text-text-secondary mt-1">Automatically send a weekly or monthly summary of new posts from an RSS feed.</p></div>
                     {!planFeatures.emailMarketing && <div className="text-xs font-bold text-yellow-400 bg-yellow-900/50 px-2 py-1 rounded-full">PRO+</div>}
                    <ChevronDownIcon className="h-6 w-6 text-text-secondary transition-transform chevron-rotate" />
                </summary>
                {planFeatures.emailMarketing && (
                    <div className="p-6 border-t border-border-subtle animate-fade-in space-y-6">
                        <div className="flex items-center justify-between"><p className="font-semibold text-white">Enable Email Digest Automation</p><label className="relative inline-flex items-center cursor-pointer"><input type="checkbox" className="sr-only peer" checked={site.isDigestAutomationEnabled} onChange={e => onSiteUpdate('isDigestAutomationEnabled', e.target.checked)} /><div className="w-11 h-6 bg-gray-600/50 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div></label></div>
                         {site.isDigestAutomationEnabled && (<div className="space-y-6">
                            <p className="text-xs p-2 rounded-md bg-panel-light border border-border-subtle text-text-secondary">Note: This automation uses your <strong>Master Automation Content Source</strong>. It must be set to 'RSS Feed' for the digest to work.</p>
                            <AutomationModelConfig
                                site={site}
                                title="Digest Generation Models"
                                config={site.digestAutomationModelConfig || site.modelConfig}
                                onConfigChange={(newConfig) => onSiteUpdate('digestAutomationModelConfig', newConfig)}
                                tasks={['text']}
                            />
                            <ScheduleManager schedules={site.digestRecurringSchedules || []} onAdd={(s) => onSiteUpdate('digestRecurringSchedules', [...(site.digestRecurringSchedules || []), { ...s, id: crypto.randomUUID(), isEnabled: true }])} onDelete={(id) => onSiteUpdate('digestRecurringSchedules', site.digestRecurringSchedules.filter(s => s.id !== id))} onToggle={(id, e) => onSiteUpdate('digestRecurringSchedules', site.digestRecurringSchedules.map(s => s.id === id ? { ...s, isEnabled: e } : s))} />
                        </div>)}
                    </div>
                )}
            </details>
        </div>
    );
};