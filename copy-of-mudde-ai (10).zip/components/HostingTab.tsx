import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { Site, HostingStatus, PerformanceRecommendation } from '../types';
import { TenWebIcon, ShieldCheckIcon, CheckCircleIcon, XIcon, LightbulbIcon } from './Icons';
import * as mcpApiService from '../services/mcpApiService';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';


const StatCard: React.FC<{ title: string; value: string | number; status?: 'ok' | 'fail' | 'secure' | 'vulnerable'; children: React.ReactNode; }> = ({ title, value, status, children }) => {
    const statusColor = status === 'ok' || status === 'secure' ? 'text-green-400' : status === 'fail' || status === 'vulnerable' ? 'text-red-400' : 'text-text-primary';
    return (
        <div className="bg-panel p-4 rounded-lg border border-border-subtle flex items-center gap-4">
            <div className="bg-panel-light p-3 rounded-lg">{children}</div>
            <div>
                <p className="text-sm font-medium text-text-secondary">{title}</p>
                <p className={`text-xl font-bold ${statusColor}`}>{value}</p>
            </div>
        </div>
    );
};

const mockPerformanceHistory = () => {
    const data = [];
    let score = 90 + Math.floor(Math.random() * 8);
    for (let i = 6; i >= 0; i--) {
        data.push({
            date: new Date(Date.now() - i * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
            score: score
        });
        score += Math.floor(Math.random() * 5) - 2; // Fluctuate score
        score = Math.max(85, Math.min(99, score)); // Keep it in a realistic range
    }
    // Simulate a recent drop for the recommendation
    data[data.length - 1].score = 86;
    return data;
};


const mockHostingStatus: HostingStatus = {
    isConnected: true,
    provider: '10web',
    siteTitle: 'My Awesome Blog',
    performance: { score: 86, lastChecked: 'Just now' },
    security: { status: 'secure', lastScan: 'Today at 2:15 AM', vulnerabilities: 0 },
    backups: { lastBackup: 'Today at 3:00 AM', status: 'ok' },
    performanceHistory: mockPerformanceHistory(),
    recommendations: [
        {
            id: 'rec1',
            type: 'cache',
            title: 'Performance Drop Detected',
            description: 'Our AI noticed a recent dip in your PageSpeed score. Clearing your site cache often resolves this by serving the latest optimized files.',
            action: 'clear_cache',
            actionLabel: 'Clear Site Cache'
        },
        {
            id: 'rec2',
            type: 'image',
            title: 'Optimize New Images',
            description: 'You have recently uploaded images that have not been optimized. Run the 10Web image optimizer to compress them without quality loss.',
            action: 'optimize_images',
            actionLabel: 'Run Image Optimizer'
        }
    ]
};

export const HostingTab: React.FC<{
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
}> = ({ site, onSiteUpdate }) => {
    const [isConnecting, setIsConnecting] = useState(false);
    const [apiKey, setApiKey] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [actionStates, setActionStates] = useState<Record<string, 'idle' | 'loading' | 'success'>>({});
    const [performanceScore, setPerformanceScore] = useState(site.hosting?.status?.performance.score || 0);
    const chartContainerRef = useRef<HTMLDivElement>(null);
    const [chartSize, setChartSize] = useState({ width: 0, height: 160 });

    useEffect(() => {
        setPerformanceScore(site.hosting?.status?.performance.score || 0);
    }, [site.hosting?.status?.performance.score]);

    useEffect(() => {
        const element = chartContainerRef.current;
        if (!element) return;

        const resizeObserver = new ResizeObserver(entries => {
            if (entries[0]) {
                const { width, height } = entries[0].contentRect;
                setChartSize({ width, height });
            }
        });

        resizeObserver.observe(element);
        return () => resizeObserver.disconnect();
    }, []);

    const handleConnect = async () => {
        setIsConnecting(true);
        // Simulate API call to 10Web
        await new Promise(resolve => setTimeout(resolve, 1500));
        onSiteUpdate('hosting', {
            isConnected: true,
            apiKey: apiKey, // In a real app, don't store this client-side long-term
            status: { ...mockHostingStatus, performance: { ...mockHostingStatus.performance, score: 98 } }
        });
        setIsConnecting(false);
        setIsModalOpen(false);
    };

    const handleActionClick = useCallback(async (recommendation: PerformanceRecommendation) => {
        setActionStates(prev => ({ ...prev, [recommendation.id]: 'loading' }));
        // Simulate API call to trigger action
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // On success, update UI
        setActionStates(prev => ({ ...prev, [recommendation.id]: 'success' }));

        if (recommendation.action === 'clear_cache') {
            // Simulate performance score improving after cache clear
            const newScore = 98;
            setPerformanceScore(newScore);
            
            // Create new history data
            const newHistory = mockPerformanceHistory();
            newHistory[newHistory.length -1].score = newScore;
            
            // Update the site state
            onSiteUpdate('hosting', {
                ...site.hosting,
                status: {
                    ...site.hosting!.status!,
                    performance: { score: newScore, lastChecked: 'Just now' },
                    performanceHistory: newHistory,
                    // Remove the completed recommendation
                    recommendations: site.hosting!.status!.recommendations.filter(r => r.id !== recommendation.id)
                }
            });
        }
        
        setTimeout(() => {
            setActionStates(prev => ({ ...prev, [recommendation.id]: 'idle' }));
        }, 2500);

    }, [site, onSiteUpdate]);

    const isConnected = site.hosting?.isConnected === true;
    const hostingStatus = site.hosting?.status;

    return (
        <div className="max-w-4xl mx-auto space-y-8">
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <div className="flex items-center gap-4">
                    <TenWebIcon className="h-10 w-10 text-white" />
                    <div>
                        <h2 className="text-2xl font-bold text-white">10Web Hosting Integration</h2>
                        <p className="text-text-secondary mt-1">Deploy, manage, and optimize your site with AI-powered hosting.</p>
                    </div>
                </div>
            </div>

            {isConnected && hostingStatus ? (
                <div className="space-y-6 animate-fade-in">
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        <div className="lg:col-span-2 bg-panel/50 p-6 rounded-2xl border border-border">
                             <h3 className="text-xl font-bold text-white">Performance Score</h3>
                             <p className="text-sm text-text-secondary">Google PageSpeed score, updated daily.</p>
                             <div className="flex items-end gap-4 mt-4">
                                <p className={`text-7xl font-extrabold ${performanceScore > 90 ? 'text-green-400' : 'text-yellow-400'}`}>{performanceScore}</p>
                                <p className="text-2xl font-bold text-text-secondary mb-2">/ 100</p>
                             </div>
                             <div ref={chartContainerRef} className="h-40 mt-4">
                                {chartSize.width > 0 && (
                                   <LineChart width={chartSize.width} height={chartSize.height} data={hostingStatus.performanceHistory} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                                       <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                                       <XAxis dataKey="date" stroke="var(--color-text-secondary)" fontSize={12} />
                                       <YAxis domain={[80, 100]} stroke="var(--color-text-secondary)" fontSize={12} />
                                       <Tooltip contentStyle={{ backgroundColor: 'var(--color-panel-light)', border: '1px solid var(--color-border)' }} />
                                       <Line type="monotone" dataKey="score" stroke="var(--color-primary)" strokeWidth={2} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                                   </LineChart>
                                )}
                             </div>
                        </div>
                        <div className="space-y-4">
                           <StatCard title="Security Status" value={hostingStatus.security.status} status={hostingStatus.security.status}>
                                <ShieldCheckIcon className="h-7 w-7 text-purple-400" />
                           </StatCard>
                           {/* Fix: Corrected typo 'failed' to 'fail' to match the type expected by StatCard */}
                           <StatCard title="Last Backup" value={hostingStatus.backups.lastBackup.split(' at ')[0]} status={hostingStatus.backups.status}>
                               <CheckCircleIcon className="h-7 w-7 text-purple-400" />
                           </StatCard>
                            <a href="https://10web.io" target="_blank" rel="noopener noreferrer" className="block w-full text-center btn btn-secondary">
                                Go to 10Web Dashboard
                            </a>
                        </div>
                    </div>

                    <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                        <h3 className="text-xl font-bold text-white flex items-center gap-3">
                            <LightbulbIcon className="h-6 w-6 text-yellow-300"/>
                            AI Performance Recommendations
                        </h3>
                        <div className="mt-4 space-y-4">
                            {hostingStatus.recommendations.length > 0 ? hostingStatus.recommendations.map(rec => {
                                const state = actionStates[rec.id] || 'idle';
                                return (
                                    <div key={rec.id} className="bg-panel p-4 rounded-lg border border-border-subtle flex flex-col sm:flex-row items-start sm:items-center gap-4">
                                        <div className="flex-1">
                                            <p className="font-semibold text-text-primary">{rec.title}</p>
                                            <p className="text-sm text-text-secondary mt-1">{rec.description}</p>
                                        </div>
                                        <button 
                                            onClick={() => handleActionClick(rec)} 
                                            disabled={state !== 'idle'}
                                            className={`btn text-sm w-full sm:w-auto flex-shrink-0 ${state === 'success' ? 'bg-green-600 hover:bg-green-700' : 'btn-primary'}`}
                                        >
                                            {state === 'idle' && rec.actionLabel}
                                            {state === 'loading' && 'Working...'}
                                            {state === 'success' && 'Done!'}
                                        </button>
                                    </div>
                                );
                            }) : (
                                <p className="text-sm text-center text-green-300 bg-green-900/20 py-4 rounded-lg">
                                    <CheckCircleIcon className="h-6 w-6 mx-auto mb-2" />
                                    Your site is fully optimized! No recommendations at this time.
                                </p>
                            )}
                        </div>
                    </div>
                </div>
            ) : (
                 <div className="text-center p-8 bg-panel/50 rounded-2xl border-2 border-dashed border-border animate-fade-in">
                    <TenWebIcon className="mx-auto h-12 w-12 text-white" />
                    <h3 className="mt-4 text-lg font-medium text-white">Connect to 10Web</h3>
                    <p className="mt-1 text-sm text-text-secondary max-w-md mx-auto">Connect your 10Web account to automatically sync your site's performance, security, and backup status.</p>
                    <button onClick={() => setIsModalOpen(true)} className="mt-6 btn btn-primary">Connect 10Web Account</button>
                </div>
            )}
            
             {isModalOpen && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
                    <div className="bg-panel rounded-lg shadow-2xl w-full max-w-md p-6 border border-border animate-modal-pop">
                         <div className="flex justify-between items-center">
                            <h3 className="text-lg font-bold text-white">Connect 10Web</h3>
                            <button onClick={() => setIsModalOpen(false)}><XIcon className="h-6 w-6 text-text-secondary hover:text-white" /></button>
                         </div>
                        <p className="text-sm text-text-secondary mt-2">Enter your 10Web API key to link your account. This is a simulation.</p>
                        <div className="mt-4 space-y-4">
                            <div>
                                <label htmlFor="10web-api-key" className="block text-sm font-medium text-text-primary mb-2">API Key</label>
                                <input id="10web-api-key" type="password" value={apiKey} onChange={e => setApiKey(e.target.value)} className="input-base" placeholder="Enter your 10Web API Key" />
                            </div>
                            <button onClick={handleConnect} disabled={isConnecting || !apiKey} className="w-full btn btn-primary disabled:opacity-50">
                                {isConnecting ? 'Connecting...' : 'Connect'}
                            </button>
                        </div>
                    </div>
                </div>
            )}

        </div>
    );
};