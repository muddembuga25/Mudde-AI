import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { UserCircleIcon, KeyIcon, XIcon, CheckCircleIcon, ExclamationTriangleIcon, PhotoIcon, TrashIcon } from './Icons';
import { PLAN_LIMITS } from '../constants';

interface ProfileModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const getInitials = (name: string = '') => {
    const names = name.split(' ');
    if (names.length > 1) {
        return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
};

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};

export const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose }) => {
    const { currentUser, updateProfile, changePassword } = useAuth();
    const navigate = useNavigate();
    const [activeTab, setActiveTabState] = useState('profile');
    
    const [displayName, setDisplayName] = useState('');
    const [email, setEmail] = useState('');
    const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
    
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmNewPassword, setConfirmNewPassword] = useState('');

    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        if (currentUser) {
            setDisplayName(currentUser.displayName || '');
            setEmail(currentUser.email || '');
            setAvatarPreview(currentUser.avatarUrl || null);
        }
        if (!isOpen) {
            setError(null);
            setSuccess(null);
            setIsLoading(false);
            setCurrentPassword('');
            setNewPassword('');
            setConfirmNewPassword('');
        }
    }, [currentUser, isOpen]);
    
    const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            try {
                const base64 = await fileToBase64(e.target.files[0]);
                setAvatarPreview(base64);
            } catch (err) {
                setError("Failed to load image.");
            }
        }
    };

    const handleProfileUpdate = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setSuccess(null);
        setIsLoading(true);
        try {
            await updateProfile({ displayName, email, avatarUrl: avatarPreview || '' });
            setSuccess("Profile updated successfully!");
        } catch (e: any) {
            setError(e.message || "Failed to update profile.");
        } finally {
            setIsLoading(false);
        }
    };
    
    const handlePasswordChange = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setSuccess(null);
        if (newPassword !== confirmNewPassword) {
            setError("New passwords do not match.");
            return;
        }
        if (newPassword.length < 6) {
            setError("New password must be at least 6 characters long.");
            return;
        }
        setIsLoading(true);
        try {
            await changePassword(currentPassword, newPassword);
            setSuccess("Password changed successfully!");
            setCurrentPassword('');
            setNewPassword('');
            setConfirmNewPassword('');
        } catch (e: any) {
            setError(e.message || "Failed to change password.");
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleManageSubscription = () => {
        navigate('/billing');
        onClose();
    };

    if (!isOpen || !currentUser) return null;

    const subscription = currentUser.subscription;
    const planDetails = PLAN_LIMITS[subscription.plan];
    const usagePercentage = Math.min(100, (subscription.postsGeneratedThisMonth / planDetails.posts) * 100);

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-panel rounded-lg shadow-2xl w-full max-w-3xl border border-border animate-modal-pop max-h-[90vh] flex flex-col">
                <header className="p-4 border-b border-border flex items-center justify-between flex-shrink-0">
                    <h2 className="text-xl font-bold text-white">My Account</h2>
                    <button onClick={onClose} className="p-1 rounded-full text-text-secondary hover:bg-panel-light hover:text-white transition-colors">
                        <XIcon className="h-6 w-6" />
                    </button>
                </header>
                <div className="flex-1 overflow-y-auto">
                    <div className="grid grid-cols-1 md:grid-cols-3">
                        {/* Left Column */}
                        <div className="md:col-span-1 p-6 border-b md:border-b-0 md:border-r border-border space-y-6">
                             <div>
                                <h3 className="text-base font-semibold text-white mb-3">Profile Picture</h3>
                                <div className="flex items-center gap-4">
                                    <div className="relative h-20 w-20 rounded-full bg-panel-light flex items-center justify-center text-2xl font-bold text-purple-300 border-2 border-border">
                                        {avatarPreview ? (
                                            <img src={avatarPreview} alt="Avatar Preview" className="h-full w-full rounded-full object-cover" />
                                        ) : (
                                            <span>{getInitials(displayName)}</span>
                                        )}
                                        <label htmlFor="avatar-upload" className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity cursor-pointer">
                                            <PhotoIcon className="h-8 w-8 text-white" />
                                            <input id="avatar-upload" type="file" accept="image/*" className="hidden" onChange={handleAvatarChange} />
                                        </label>
                                    </div>
                                    {avatarPreview && (
                                        <button onClick={() => setAvatarPreview(null)} className="p-2 text-red-400 hover:bg-red-900/50 rounded-full" title="Remove Photo">
                                            <TrashIcon className="h-5 w-5" />
                                        </button>
                                    )}
                                </div>
                            </div>
                            <div>
                                <h3 className="text-base font-semibold text-white mb-3">Subscription</h3>
                                <div className="bg-panel-light p-4 rounded-lg border border-border-subtle space-y-3">
                                    <p className="text-lg font-bold text-purple-300 capitalize">{subscription.plan} Plan</p>
                                    <div className="text-xs text-text-secondary">
                                        <p>{subscription.postsGeneratedThisMonth} / {planDetails.posts} posts used</p>
                                        <div className="w-full bg-gray-700 rounded-full h-1.5 mt-1"><div className="bg-purple-500 h-1.5 rounded-full" style={{ width: `${usagePercentage}%` }}></div></div>
                                    </div>
                                    <button onClick={handleManageSubscription} className="w-full btn btn-secondary text-sm">Manage Subscription</button>
                                </div>
                            </div>
                        </div>
                        {/* Right Column */}
                        <div className="md:col-span-2 p-6">
                             <div className="border-b border-border">
                                <nav className="-mb-px flex space-x-4" aria-label="Tabs">
                                    <button onClick={() => setActiveTabState('profile')} className={`${activeTab === 'profile' ? 'border-purple-500 text-purple-400' : 'border-transparent text-text-secondary hover:text-text-primary'} flex items-center gap-2 whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors`}>
                                        <UserCircleIcon className="h-5 w-5" /> Profile
                                    </button>
                                    <button onClick={() => setActiveTabState('password')} className={`${activeTab === 'password' ? 'border-purple-500 text-purple-400' : 'border-transparent text-text-secondary hover:text-text-primary'} flex items-center gap-2 whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors`}>
                                        <KeyIcon className="h-5 w-5" /> Password
                                    </button>
                                </nav>
                            </div>
                            <div className="pt-6">
                                {activeTab === 'profile' && (
                                    <form onSubmit={handleProfileUpdate} className="space-y-4 animate-fade-in">
                                        <div>
                                            <label className="block text-sm font-medium text-text-primary mb-2">Username</label>
                                            <input type="text" value={currentUser?.username || ''} className="input-base bg-panel-light cursor-not-allowed" readOnly disabled />
                                        </div>
                                        <div>
                                            <label htmlFor="displayName" className="block text-sm font-medium text-text-primary mb-2">Display Name</label>
                                            <input id="displayName" type="text" value={displayName} onChange={(e) => setDisplayName(e.target.value)} className="input-base" required />
                                        </div>
                                        <div>
                                            <label htmlFor="email" className="block text-sm font-medium text-text-primary mb-2">Email Address</label>
                                            <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="input-base" required />
                                        </div>
                                        <button type="submit" className="w-full btn btn-primary mt-4" disabled={isLoading}>
                                            {isLoading ? 'Saving...' : 'Save Changes'}
                                        </button>
                                    </form>
                                )}
                                {activeTab === 'password' && (
                                    <form onSubmit={handlePasswordChange} className="space-y-4 animate-fade-in">
                                        <div>
                                            <label htmlFor="currentPassword" className="block text-sm font-medium text-text-primary mb-2">Current Password</label>
                                            <input id="currentPassword" type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} className="input-base" required />
                                        </div>
                                        <div>
                                            <label htmlFor="newPassword" className="block text-sm font-medium text-text-primary mb-2">New Password</label>
                                            <input id="newPassword" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} className="input-base" required />
                                        </div>
                                        <div>
                                            <label htmlFor="confirmNewPassword" className="block text-sm font-medium text-text-primary mb-2">Confirm New Password</label>
                                            <input id="confirmNewPassword" type="password" value={confirmNewPassword} onChange={(e) => setConfirmNewPassword(e.target.value)} className="input-base" required />
                                        </div>
                                        <button type="submit" className="w-full btn btn-primary mt-4" disabled={isLoading}>
                                            {isLoading ? 'Updating...' : 'Change Password'}
                                        </button>
                                    </form>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
                 <footer className="p-4 border-t border-border flex-shrink-0 min-h-[56px]">
                    {error && (
                        <div className="bg-red-900/30 border border-red-500/50 text-red-300 px-3 py-2 rounded-lg flex items-center gap-3 text-sm animate-fade-in">
                            <ExclamationTriangleIcon className="h-5 w-5 flex-shrink-0" />
                            <span>{error}</span>
                        </div>
                    )}
                     {success && (
                        <div className="bg-green-900/30 border border-green-500/50 text-green-300 px-3 py-2 rounded-lg flex items-center gap-3 text-sm animate-fade-in">
                            <CheckCircleIcon className="h-5 w-5 flex-shrink-0" />
                            <span>{success}</span>
                        </div>
                    )}
                </footer>
            </div>
        </div>
    );
};