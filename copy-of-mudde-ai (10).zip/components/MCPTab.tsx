import React, { useState, useCallback } from 'react';
import type { Site, User, LogEntry, MCPServer, SelfTestResult } from '../types';
import { ServerIcon, TrashIcon, SparklesIcon, XIcon, CommandLineIcon, ShieldCheckIcon } from './Icons';
import * as mcpApiService from '../services/mcpApiService';
import * as selfTestService from '../services/selfTestService';
import { MCPSelfTest } from './MCPSelfTest';
import { DataForSeoMcp } from './DataForSeoMcp';

interface MCPTabProps {
    sites: Site[];
    selectedSite: Site | undefined;
    currentUser: User | null;
    logs: LogEntry[];
    runBacklinksJobNow: (siteId: string) => void;
    isBacklinksJobRunning: boolean;
    mcpServers: MCPServer[];
    activeMCPServerId: string | null;
    onAddServer: (name: string, url: string) => void;
    onDeleteServer: (id: string) => void;
    onConnectServer: (id: string) => void;
    onDisconnectServer: (id: string) => void;
    activeView: 'state' | 'logs' | 'actions' | 'servers' | 'selftest' | 'dataforseo';
    setActiveView: (view: 'state' | 'logs' | 'actions' | 'servers' | 'selftest' | 'dataforseo') => void;
    filteredLogs: LogEntry[] | null;
    testResults: Record<string, SelfTestResult>;
    setTestResults: React.Dispatch<React.SetStateAction<Record<string, SelfTestResult>>>;
}

export const MCPTab: React.FC<MCPTabProps> = ({ 
    sites, selectedSite, currentUser, logs, runBacklinksJobNow, isBacklinksJobRunning,
    mcpServers, activeMCPServerId, onAddServer, onDeleteServer, onConnectServer, onDisconnectServer,
    activeView, setActiveView, filteredLogs, testResults, setTestResults
}) => {
    
    const [wpCliCommand, setWpCliCommand] = useState<string>('');
    const [wpCliOutput, setWpCliOutput] = useState<string>('');
    const [isWpCliRunning, setIsWpCliRunning] = useState<boolean>(false);
    
    const handleCopyState = () => {
        const stateString = JSON.stringify({ sites, selectedSite, currentUser, mcpServers, activeMCPServerId }, null, 2);
        navigator.clipboard.writeText(stateString);
    };

    const handleRunWpCli = async () => {
        if (!selectedSite || !wpCliCommand.trim()) return;
        setIsWpCliRunning(true);
        setWpCliOutput(`$ wp ${wpCliCommand}\n\nRunning command...`);
        try {
            const { output } = await mcpApiService.runWpCliCommand(selectedSite.id, wpCliCommand);
            setWpCliOutput(`$ wp ${wpCliCommand}\n\n${output}`);
        } catch (e: any) {
            setWpCliOutput(`$ wp ${wpCliCommand}\n\nError: ${e.message}`);
        } finally {
            setIsWpCliRunning(false);
        }
    };

    const handleRunTest = useCallback(async (testId: string) => {
        if (!selectedSite) return;

        setTestResults(prev => ({
            ...prev,
            [testId]: { ...prev[testId], status: 'running', message: '' }
        }));

        const test = selfTestService.getTestById(testId);
        const result = await test.test(selectedSite);

        setTestResults(prev => ({
            ...prev,
            [testId]: {
                id: testId,
                status: result.success ? 'pass' : 'fail',
                message: result.message,
            }
        }));
    }, [selectedSite, setTestResults]);

    const handleRunAllTests = useCallback(async () => {
        const allTestIds = Object.values(selfTestService.testCategories).flat();
        for (const testId of allTestIds) {
            await handleRunTest(testId);
        }
    }, [handleRunTest]);

    const LogViewer: React.FC = () => {
        const logsToDisplay = filteredLogs ?? logs;
        const logTypeClasses: Record<LogEntry['type'], string> = {
            INFO: 'border-blue-500/30 text-blue-300',
            SUCCESS: 'border-green-500/30 text-green-300',
            WARN: 'border-yellow-500/30 text-yellow-300',
            ERROR: 'border-red-500/30 text-red-300',
        };
        const logSiteName = (siteId?: string) => siteId ? sites.find(s => s.id === siteId)?.name || siteId.substring(0,8) : 'Global';

        return (
            <div className="space-y-2 font-mono text-xs max-h-[60vh] overflow-y-auto">
                {logsToDisplay.map(log => (
                    <div key={`${log.timestamp}-${log.message}`} className={`p-2 rounded border ${logTypeClasses[log.type]}`}>
                        <div className="flex justify-between items-baseline">
                            <span className="font-bold">{log.type}</span>
                            <span className="text-text-secondary">{new Date(log.timestamp).toLocaleTimeString()}</span>
                        </div>
                        <p className="text-text-primary break-words whitespace-pre-wrap mt-1">
                            <span className="font-bold bg-gray-700 px-1.5 py-0.5 rounded text-gray-300 mr-2">{logSiteName(log.siteId)}</span>
                            {log.message}
                        </p>
                    </div>
                ))}
            </div>
        )
    };

    const ServerManager: React.FC = () => {
        const [newName, setNewName] = useState('');
        const [newUrl, setNewUrl] = useState('');

        const handleAdd = (e: React.FormEvent) => {
            e.preventDefault();
            if (newName.trim() && newUrl.trim()) {
                onAddServer(newName.trim(), newUrl.trim());
                setNewName('');
                setNewUrl('');
            }
        };

        const statusStyles: Record<MCPServer['status'], { dot: string; text: string; }> = {
            connected: { dot: 'bg-green-500', text: 'text-green-400' },
            disconnected: { dot: 'bg-gray-500', text: 'text-gray-400' },
            error: { dot: 'bg-red-500', text: 'text-red-400' },
            connecting: { dot: 'bg-yellow-500 animate-pulse', text: 'text-yellow-400' },
        };

        return (
            <div className="space-y-6">
                <div>
                    <h3 className="text-lg font-bold text-white mb-4">Add New Server</h3>
                    <form onSubmit={handleAdd} className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
                        <div className="sm:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-text-primary mb-2">Server Name</label>
                                <input value={newName} onChange={e => setNewName(e.target.value)} placeholder="e.g., Production Server" className="input-base" required />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-text-primary mb-2">Server URL</label>
                                <input value={newUrl} onChange={e => setNewUrl(e.target.value)} type="url" placeholder="https://mcp.example.com" className="input-base" required />
                            </div>
                        </div>
                        <button type="submit" className="btn btn-primary w-full">Add Server</button>
                    </form>
                </div>
                <div className="pt-6 border-t border-border-subtle">
                     <h3 className="text-lg font-bold text-white mb-4">Server List</h3>
                     <div className="space-y-3">
                        {mcpServers.length === 0 ? (
                            <p className="text-text-secondary text-center py-4">No servers configured.</p>
                        ) : (
                            mcpServers.map(server => (
                                <div key={server.id} className={`p-4 rounded-lg border flex flex-col sm:flex-row items-start sm:items-center gap-4 ${server.id === activeMCPServerId ? 'bg-purple-900/20 border-purple-500/50' : 'bg-panel-light border-border'}`}>
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center gap-3">
                                            <span className={`w-3 h-3 rounded-full flex-shrink-0 ${statusStyles[server.status].dot}`}></span>
                                            <p className="font-semibold text-text-primary truncate">{server.name}</p>
                                        </div>
                                        <p className="text-sm text-text-secondary truncate mt-1 ml-6">{server.url}</p>
                                        {server.statusMessage && <p className={`text-xs mt-1 ml-6 ${statusStyles[server.status].text}`}>{server.statusMessage}</p>}
                                    </div>
                                    <div className="flex items-center gap-2 self-end sm:self-center">
                                        {server.status === 'connected' ? (
                                            <button onClick={() => onDisconnectServer(server.id)} className="btn bg-red-800/60 hover:bg-red-700 text-sm text-white">Disconnect</button>
                                        ) : (
                                            <button onClick={() => onConnectServer(server.id)} className="btn btn-secondary text-sm" disabled={server.status === 'connecting'}>
                                                {server.status === 'connecting' ? 'Connecting...' : 'Connect'}
                                            </button>
                                        )}
                                        <button onClick={() => onDeleteServer(server.id)} className="p-2 text-red-400 hover:text-red-300 transition-colors"><TrashIcon className="h-5 w-5"/></button>
                                    </div>
                                </div>
                            ))
                        )}
                     </div>
                </div>
            </div>
        );
    };
    
    return (
        <div className="w-full max-w-4xl mx-auto space-y-6">
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                    <div>
                        <h2 className="text-2xl font-bold text-white">Master Control Panel (MCP)</h2>
                        <p className="text-text-secondary mt-1">Developer tools for inspecting state and triggering actions.</p>
                    </div>
                    <p className="text-sm text-purple-300 bg-purple-900/30 p-2 rounded-md border border-purple-500/30">Use the global Mudde AI for voice commands.</p>
                </div>
            </div>
            
            <div className="bg-panel/50 rounded-2xl border border-border">
                <div className="border-b border-border">
                    <nav className="-mb-px flex space-x-4 px-6 overflow-x-auto" aria-label="Tabs">
                        <button onClick={() => setActiveView('selftest')} className={`${ activeView === 'selftest' ? 'border-purple-500 text-purple-400' : 'border-transparent text-text-secondary hover:text-text-primary hover:border-gray-500' } flex items-center gap-2 whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors`}>
                           <ShieldCheckIcon className="h-5 w-5" /> Self-Test
                        </button>
                        {selectedSite && selectedSite.apiKeys.dataforseo && (
                             <button onClick={() => setActiveView('dataforseo')} className={`${ activeView === 'dataforseo' ? 'border-purple-500 text-purple-400' : 'border-transparent text-text-secondary hover:text-text-primary hover:border-gray-500' } flex items-center gap-2 whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors`}>
                               <SparklesIcon className="h-5 w-5" /> DataForSEO
                            </button>
                        )}
                        <button onClick={() => setActiveView('state')} className={`${ activeView === 'state' ? 'border-purple-500 text-purple-400' : 'border-transparent text-text-secondary hover:text-text-primary hover:border-gray-500' } whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors`}>
                           State
                        </button>
                        <button onClick={() => setActiveView('logs')} className={`${ activeView === 'logs' ? 'border-purple-500 text-purple-400' : 'border-transparent text-text-secondary hover:text-text-primary hover:border-gray-500' } whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors`}>
                           Logs
                        </button>
                        <button onClick={() => setActiveView('actions')} className={`${ activeView === 'actions' ? 'border-purple-500 text-purple-400' : 'border-transparent text-text-secondary hover:text-text-primary hover:border-gray-500' } whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors`}>
                           Actions
                        </button>
                         <button onClick={() => setActiveView('servers')} className={`${ activeView === 'servers' ? 'border-purple-500 text-purple-400' : 'border-transparent text-text-secondary hover:text-text-primary hover:border-gray-500' } flex items-center gap-2 whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors`}>
                           <ServerIcon className="h-5 w-5" /> Servers
                        </button>
                    </nav>
                </div>
                <div className="p-6">
                    {activeView === 'selftest' && (
                        <MCPSelfTest 
                            testResults={testResults}
                            onRunTest={handleRunTest}
                            onRunAllTests={handleRunAllTests}
                            testCategories={selfTestService.testCategories}
                            getTestName={(id) => selfTestService.getTestById(id).name}
                        />
                    )}
                    {activeView === 'dataforseo' && selectedSite && (
                        <DataForSeoMcp site={selectedSite} />
                    )}
                    {activeView === 'state' && (
                        <div className="animate-fade-in">
                            <div className="flex justify-between items-center mb-4">
                                <h3 className="text-lg font-bold text-white">Application State</h3>
                                <button onClick={handleCopyState} className="btn btn-secondary text-sm">Copy JSON</button>
                            </div>
                            <pre className="bg-panel-light p-4 rounded-lg text-xs text-text-primary max-h-[60vh] overflow-auto border border-border-subtle">
                                <code>
                                    {JSON.stringify({ sites, selectedSite, currentUser }, null, 2)}
                                </code>
                            </pre>
                        </div>
                    )}
                    {activeView === 'logs' && (
                        <div className="animate-fade-in">
                            <h3 className="text-lg font-bold text-white mb-4">Action Log</h3>
                            <LogViewer />
                        </div>
                    )}
                    {activeView === 'actions' && (
                        <div className="animate-fade-in space-y-4">
                             <h3 className="text-lg font-bold text-white">Manual Triggers</h3>
                             <div className="p-4 rounded-lg border border-border-subtle bg-panel-light">
                                 <h4 className="font-semibold text-text-primary">Backlinks</h4>
                                 <div className="mt-2 flex items-center justify-between">
                                     <p className="text-sm text-text-secondary">Run the automated outreach job for the current site.</p>
                                     <button
                                        onClick={() => selectedSite && runBacklinksJobNow(selectedSite.id)}
                                        disabled={!selectedSite || isBacklinksJobRunning}
                                        className="btn btn-primary disabled:opacity-50 disabled:cursor-wait"
                                     >
                                        {isBacklinksJobRunning ? 'Running...' : 'Run Outreach Job'}
                                     </button>
                                 </div>
                             </div>
                             <div className="p-4 rounded-lg border border-border-subtle bg-panel-light">
                                <h4 className="font-semibold text-text-primary flex items-center gap-2">
                                    <CommandLineIcon className="h-5 w-5 text-purple-400" />
                                    WordPress CLI
                                </h4>
                                {selectedSite && selectedSite.wordpressUrl && selectedSite.applicationPassword ? (
                                    <>
                                        <p className="text-sm text-text-secondary mt-2">Run WP-CLI commands directly on your connected WordPress site.</p>
                                        <div className="mt-3 flex items-center gap-2 font-mono">
                                            <span className="text-gray-500">wp</span>
                                            <input
                                                type="text"
                                                value={wpCliCommand}
                                                onChange={e => setWpCliCommand(e.target.value)}
                                                onKeyDown={e => e.key === 'Enter' && !isWpCliRunning && handleRunWpCli()}
                                                placeholder="plugin list --status=active"
                                                className="input-base flex-grow !font-mono text-sm"
                                                disabled={isWpCliRunning}
                                            />
                                            <button
                                                onClick={handleRunWpCli}
                                                disabled={isWpCliRunning || !wpCliCommand.trim()}
                                                className="btn btn-primary disabled:opacity-50"
                                            >
                                                {isWpCliRunning ? 'Running...' : 'Run'}
                                            </button>
                                        </div>
                                        <pre className="mt-3 bg-black/50 p-3 rounded-md text-xs text-gray-300 font-mono h-48 overflow-y-auto border border-border">
                                            <code>
                                                {wpCliOutput || 'Command output will appear here...'}
                                            </code>
                                        </pre>
                                    </>
                                ) : (
                                    <p className="text-sm text-yellow-400 mt-2">
                                        Please configure and verify WordPress credentials in the WordPress tab to use this feature.
                                    </p>
                                )}
                            </div>
                        </div>
                    )}
                    {activeView === 'servers' && (
                        <div className="animate-fade-in">
                            <ServerManager />
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};