import React, { useState, useCallback, useMemo } from 'react';
import type { Site, RssItem } from '../types';
import * as googleSheetsService from '../services/googleSheetsService';
import type { GoogleSheetRow } from '../services/googleSheetsService';
import { GoogleSheetsIcon, ExclamationTriangleIcon } from './Icons';

interface GoogleSheetContentTabProps {
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    onGenerateAndScore: (topicToTrack: string, generationSource: 'keyword' | 'rss' | 'video' | 'google_sheet' | 'ai_assistant', sourceDetails: RssItem | string | GoogleSheetRow, site: Site, options?: {sourceId?: string, videoItem?: RssItem}) => Promise<void>;
    setError: (error: string | null) => void;
    isPostLimitReached: boolean;
}

export const GoogleSheetContentTab: React.FC<GoogleSheetContentTabProps> = ({ site, onSiteUpdate, onGenerateAndScore, setError, isPostLimitReached }) => {
    const [sheetData, setSheetData] = useState<GoogleSheetRow[] | null>(null);
    const [isFetchingSheet, setIsFetchingSheet] = useState(false);
    
    const handleFetchSheet = useCallback(async () => {
        if (!site.googleSheetUrl) return;
        setIsFetchingSheet(true);
        setError(null);
        try {
            const data = await googleSheetsService.fetchGoogleSheetData(site);
            setSheetData(data);
        } catch (error: any) {
            setError(error.message || 'Failed to fetch Google Sheet data.');
            setSheetData(null);
        } finally {
            setIsFetchingSheet(false);
        }
    }, [site, setError]);

    const unprocessedSheetRows = useMemo(() => sheetData?.filter(row => !site.googleSheetProcessedRows.includes(row.rowIndex)) || [], [sheetData, site.googleSheetProcessedRows]);

    return (
         <div className="max-w-4xl mx-auto space-y-8">
            {isPostLimitReached && (
                <div className="bg-yellow-900/30 border border-yellow-500/50 text-yellow-300 px-3 py-2.5 rounded-lg flex items-center gap-3 text-sm animate-fade-in">
                    <ExclamationTriangleIcon className="h-5 w-5 flex-shrink-0" />
                    <span>You have reached your monthly post generation limit for your current plan.</span>
                </div>
            )}
            <div className="content-panel space-y-4">
                <div className="flex items-center gap-2">
                    <input type="url" value={site.googleSheetUrl} onChange={(e) => onSiteUpdate('googleSheetUrl', e.target.value)} placeholder="Enter public Google Sheet URL" className="input-base flex-grow" />
                    <button onClick={handleFetchSheet} disabled={isFetchingSheet || !site.googleSheetUrl || !site.apiKeys.google} className="btn btn-primary disabled:opacity-50">
                        {isFetchingSheet ? 'Fetching...' : 'Fetch Sheet'}
                    </button>
                </div>
                {!site.apiKeys.google && <p className="text-xs text-yellow-400 mt-2">A Google API Key is required to fetch sheet data. Please add one in the API Keys tab.</p>}
                <div className="space-y-2 pt-4 border-t border-border-subtle">
                    {isFetchingSheet && <p className="text-text-secondary text-center">Fetching sheet data...</p>}
                    {!isFetchingSheet && unprocessedSheetRows.length === 0 && (
                        <p className="text-text-secondary text-center py-4">
                            {sheetData ? 'All rows from this sheet have been processed.' : 'Fetch a sheet to see available rows.'}
                        </p>
                    )}
                    {unprocessedSheetRows.map((row) => (
                        <div key={row.rowIndex} className="flex items-center justify-between p-3 rounded-md bg-panel gap-4">
                            <div className="min-w-0">
                                <p className="text-sm font-medium text-text-primary truncate" title={row.topic}>{row.topic}</p>
                                <p className="text-xs text-text-secondary">Row {row.rowIndex + 1}</p>
                            </div>
                            <button onClick={() => onGenerateAndScore(row.topic, 'google_sheet', row, site)} disabled={isPostLimitReached} className="btn btn-primary text-xs px-3 py-1.5 flex-shrink-0 disabled:opacity-40 disabled:cursor-not-allowed">
                                Generate
                            </button>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};