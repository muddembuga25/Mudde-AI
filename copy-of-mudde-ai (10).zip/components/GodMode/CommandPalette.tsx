import React, { useState, useEffect, useRef } from 'react';

interface CommandPaletteProps {
    isOpen: boolean;
    setIsOpen: (isOpen: boolean) => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({ isOpen, setIsOpen }) => {
    const [inputValue, setInputValue] = useState('');
    const inputRef = useRef<HTMLInputElement>(null);
    const [feedback, setFeedback] = useState<string | null>(null);

    useEffect(() => {
        if (isOpen) {
            inputRef.current?.focus();
            setInputValue('');
            setFeedback(null);
        }
    }, [isOpen]);

    const handleCommand = () => {
        // This is a simulation. A real implementation would involve complex NLP and state management calls.
        const command = inputValue.toLowerCase();
        setFeedback(`Simulating execution for: "${command}"... This is a UI demonstration.`);
        
        // Example command parsing
        if (command.startsWith("generate post for")) {
            // ... logic to parse site and topic, then call mcpApiService.runManualGenerationPipeline
        } else if (command.startsWith("pause all")) {
            // ... logic to call a global pause function
        }

        setTimeout(() => {
            setIsOpen(false);
        }, 2500);
    };

    if (!isOpen) {
        return null;
    }

    return (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-24" onClick={() => setIsOpen(false)}>
            <div 
                className="w-full max-w-2xl bg-panel rounded-xl shadow-2xl border border-border-subtle"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="relative">
                    <input
                        ref={inputRef}
                        type="text"
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleCommand()}
                        placeholder="e.g., generate post for 'My Blog' about the future of AI..."
                        className="w-full bg-transparent p-4 text-lg text-text-primary placeholder:text-text-placeholder focus:outline-none"
                    />
                </div>
                <div className="p-4 border-t border-border-subtle text-sm text-text-secondary">
                    {feedback ? (
                         <p className="text-yellow-300">{feedback}</p>
                    ) : (
                         <p>Start typing a command. Press Enter to execute.</p>
                    )}
                </div>
            </div>
        </div>
    );
};