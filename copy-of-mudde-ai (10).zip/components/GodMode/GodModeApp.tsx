import React, { useState, useEffect, useCallback } from 'react';
import { Routes, Route, NavLink as RouterNavLink } from 'react-router-dom';
import { useGodMode } from '../../contexts/GodModeContext';
import { GodModeDashboard } from './GodModeDashboard';
import { AutomationControllerTab } from './AutomationControllerTab';
import { StrategyEngineTab } from './StrategyEngineTab';
import { CommandPalette } from './CommandPalette';
import { 
    BoltIcon, ChartBarIcon, CpuChipIcon, BeakerIcon, ArrowLeftOnRectangleIcon 
} from '../Icons';

const navItems = [
    { id: 'dashboard', label: 'Global Dashboard', icon: ChartBarIcon, path: '/' },
    { id: 'automation', label: 'Automation Controller', icon: CpuChipIcon, path: '/automation' },
    { id: 'strategy', label: 'Strategy Engine', icon: BeakerIcon, path: '/strategy' },
];

export const GodModeApp: React.FC = () => {
    const { toggleGodMode } = useGodMode();
    const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if ((event.metaKey || event.ctrlKey) && event.key === 'k') {
                event.preventDefault();
                setIsCommandPaletteOpen(p => !p);
            }
             if ((event.metaKey || event.ctrlKey) && event.key === 'g') {
                event.preventDefault();
                toggleGodMode();
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [toggleGodMode]);

    const NavLink: React.FC<{ item: typeof navItems[0] }> = ({ item }) => (
        <RouterNavLink
            to={item.path}
            end={item.path === '/'}
            className={({ isActive }) =>
                `flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition-colors ${
                isActive ? 'bg-yellow-400/10 text-yellow-300' : 'text-gray-400 hover:bg-gray-700/50 hover:text-white'
                }`
            }
        >
            <item.icon className="h-5 w-5" />
            <span>{item.label}</span>
        </RouterNavLink>
    );

    return (
        <div className="h-full flex bg-gray-950 text-text-primary">
            <aside className="w-64 flex-shrink-0 flex flex-col bg-gray-900 border-r border-yellow-500/20">
                <div className="p-4 border-b border-yellow-500/20 text-center">
                    <h1 className="text-xl font-bold text-yellow-300 flex items-center justify-center gap-2">
                        <BoltIcon /> GOD MODE
                    </h1>
                </div>
                <nav className="flex-1 p-3 space-y-1">
                    {navItems.map(item => <NavLink key={item.id} item={item} />)}
                </nav>
                 <div className="p-4 border-t border-yellow-500/20">
                    <button
                        onClick={toggleGodMode}
                        className="w-full btn bg-yellow-600/20 text-yellow-300 hover:bg-yellow-600/40 border border-yellow-500/30"
                    >
                        <ArrowLeftOnRectangleIcon className="h-5 w-5"/>
                        <span>Exit God Mode</span>
                    </button>
                </div>
            </aside>
            <main className="flex-1 overflow-y-auto p-8">
                <Routes>
                    <Route path="/" element={<GodModeDashboard />} />
                    <Route path="/automation" element={<AutomationControllerTab />} />
                    <Route path="/strategy" element={<StrategyEngineTab />} />
                </Routes>
            </main>
            <CommandPalette isOpen={isCommandPaletteOpen} setIsOpen={setIsCommandPaletteOpen} />
        </div>
    );
};