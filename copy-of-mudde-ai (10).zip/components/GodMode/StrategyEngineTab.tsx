import React, { useState, useCallback, useMemo } from 'react';
import { useSitesContext } from '../../contexts/SitesContext';
import * as mcpApiService from '../../services/mcpApiService';
import type { StrategicBrief } from '../../types';
import { SparklesIcon } from '../Icons';

export const StrategyEngineTab: React.FC = () => {
    const { sites } = useSitesContext();
    const [topic, setTopic] = useState('');
    const [promptA, setPromptA] = useState('Generate a standard, informative strategic brief.');
    const [promptB, setPromptB] = useState('Generate a strategic brief with a strong focus on a controversial or contrarian content angle.');
    const [resultA, setResultA] = useState<StrategicBrief | null>(null);
    const [resultB, setResultB] = useState<StrategicBrief | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    
    const [costSimPosts, setCostSimPosts] = useState(50);
    const [costSimModel, setCostSimModel] = useState('gemini-2.5-flash');

    const handleRunAbTest = useCallback(async () => {
        if (!topic.trim() || !sites.length) return;
        setIsLoading(true);
        setResultA(null);
        setResultB(null);
        
        // Use the first site's config for the test
        const siteForTest = sites[0];

        try {
            const [resA, resB] = await Promise.all([
                mcpApiService.generateStrategicBrief(siteForTest.id, 'keyword', topic, { customPrompt: promptA }),
                mcpApiService.generateStrategicBrief(siteForTest.id, 'keyword', topic, { customPrompt: promptB })
            ]);
            setResultA(resA.brief);
            setResultB(resB.brief);
        } catch (e) {
            console.error("A/B Test Failed", e);
        } finally {
            setIsLoading(false);
        }

    }, [topic, promptA, promptB, sites]);

    const estimatedCost = useMemo(() => {
        const costs: Record<string, number> = {
            'gemini-2.5-flash': 0.0015,
            'gpt-4o': 0.012
        };
        const costPerPost = costs[costSimModel] || 0.002;
        return (costPerPost * costSimPosts).toFixed(2);
    }, [costSimPosts, costSimModel]);

    return (
        <div className="space-y-8 animate-fade-in">
            <h1 className="text-3xl font-bold text-white">Strategy Engine</h1>

            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-xl font-bold text-white">Prompt A/B Testing</h2>
                <p className="text-sm text-text-secondary mt-1">Test two different prompts or instructions for generating a strategic brief on the same topic to see which performs better.</p>
                <div className="mt-4 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-text-primary mb-2">Topic</label>
                        <input value={topic} onChange={e => setTopic(e.target.value)} placeholder="e.g., The future of AI in marketing" className="input-base"/>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-text-primary mb-2">Prompt A</label>
                            <textarea value={promptA} onChange={e => setPromptA(e.target.value)} className="input-base" rows={4}></textarea>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-text-primary mb-2">Prompt B</label>
                            <textarea value={promptB} onChange={e => setPromptB(e.target.value)} className="input-base" rows={4}></textarea>
                        </div>
                    </div>
                    <button onClick={handleRunAbTest} disabled={isLoading || !topic.trim()} className="btn btn-primary disabled:opacity-50">
                        {isLoading ? 'Running Test...' : 'Run A/B Test'}
                    </button>
                    {(resultA || resultB) && (
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <pre className="bg-panel p-4 rounded-lg text-xs max-h-96 overflow-auto border border-border-subtle"><code>{JSON.stringify(resultA, null, 2)}</code></pre>
                            <pre className="bg-panel p-4 rounded-lg text-xs max-h-96 overflow-auto border border-border-subtle"><code>{JSON.stringify(resultB, null, 2)}</code></pre>
                        </div>
                    )}
                </div>
            </div>

            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                 <h2 className="text-xl font-bold text-white">API Cost Simulator</h2>
                 <p className="text-sm text-text-secondary mt-1">Estimate the cost of a large content generation job before running it.</p>
                 <div className="mt-4 flex flex-col sm:flex-row items-end gap-4">
                     <div>
                        <label className="block text-sm font-medium text-text-primary mb-2">Number of Posts</label>
                        <input type="number" value={costSimPosts} onChange={e => setCostSimPosts(Number(e.target.value))} className="input-base" />
                     </div>
                     <div>
                        <label className="block text-sm font-medium text-text-primary mb-2">Model</label>
                        <select value={costSimModel} onChange={e => setCostSimModel(e.target.value)} className="input-base">
                            <option value="gemini-2.5-flash">Google Gemini 2.5 Flash</option>
                            <option value="gpt-4o">OpenAI GPT-4o</option>
                        </select>
                     </div>
                     <div className="flex-1 text-center sm:text-left">
                        <p className="text-sm text-text-secondary">Estimated Cost</p>
                        <p className="text-3xl font-bold text-green-400">${estimatedCost}</p>
                     </div>
                 </div>
            </div>
        </div>
    );
};
