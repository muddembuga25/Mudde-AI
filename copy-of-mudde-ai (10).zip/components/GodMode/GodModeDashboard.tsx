import React, { useMemo } from 'react';
import { useSitesContext } from '../../contexts/SitesContext';
import { ApiSpendDashboard } from '../ApiSpendDashboard';
import { DocumentTextIcon, RssIcon, VideoCameraIcon, GoogleSheetsIcon } from '../Icons';

export const GodModeDashboard: React.FC = () => {
    const { sites, handleResetAllSitesSpend } = useSitesContext();

    const { allDrafts, allLogs } = useMemo(() => {
        const drafts = sites.flatMap(site => site.drafts.map(draft => ({ ...draft, siteName: site.name })))
            .sort((a, b) => b.date - a.date);
        
        // In a real app, logs would be fetched from a central server. Here we simulate by merging.
        const logs: any[] = []; // We assume logs are handled globally for simplicity in this view

        return { allDrafts: drafts, allLogs: logs };
    }, [sites]);
    
    const sourceTypeInfo: Record<string, { icon: React.FC<any>, label: string, color: string }> = {
        keyword: { icon: DocumentTextIcon, label: 'Keyword', color: 'text-blue-400' },
        rss: { icon: RssIcon, label: 'RSS', color: 'text-orange-400' },
        video: { icon: VideoCameraIcon, label: 'Video', color: 'text-red-400' },
        google_sheet: { icon: GoogleSheetsIcon, label: 'Google Sheet', color: 'text-green-400' },
    };

    return (
        <div className="space-y-8 animate-fade-in">
            <h1 className="text-3xl font-bold text-white">Global Dashboard</h1>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Unified Content Pipeline */}
                <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                    <h2 className="text-xl font-bold text-white">Unified Content Pipeline</h2>
                    <p className="text-sm text-text-secondary mt-1">All generated drafts across all workflows, ready for review.</p>
                    <div className="mt-4 space-y-3 max-h-96 overflow-y-auto pr-2 -mr-2">
                        {allDrafts.length === 0 ? (
                            <p className="text-center py-8 text-text-secondary">No drafts pending review.</p>
                        ) : allDrafts.map(draft => {
                            const info = sourceTypeInfo[draft.sourceDetails.type];
                            const Icon = info.icon;
                            return (
                                <div key={draft.id} className="bg-panel p-3 rounded-lg border border-border-subtle">
                                    <p className="font-semibold text-text-primary truncate">{draft.blogPost.title}</p>
                                    <div className="flex items-center justify-between mt-1 text-xs">
                                        <span className="font-bold text-purple-300">{draft.siteName}</span>
                                        <span className={`flex items-center gap-1.5 ${info.color}`}>
                                            <Icon className="h-4 w-4" /> {info.label}
                                        </span>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                </div>

                {/* Global API Spend */}
                <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                     <ApiSpendDashboard sites={sites} onResetAllSitesSpend={handleResetAllSitesSpend} />
                </div>
            </div>
        </div>
    );
};