

import React, { useMemo } from 'react';
import { AppStatus } from '../types';
import type { Site } from '../types';
import { AutomationProcessVisualizer, AutomationStep } from './AutomationProcessVisualizer';
import { ClockIcon, DocumentTextIcon, SparklesIcon, PenIcon, PhotoIcon, ShieldCheckIcon, WordPressIcon, ShareIcon, CheckCircleIcon, XIcon, SpinnerIcon } from './Icons';

interface AutomationState {
  status: AppStatus;
  statusMessage: string;
  topic: string | null;
  siteId: string;
}

interface GlobalAutomationTrackerProps {
  automationStates: Record<string, AutomationState>;
  sites: Site[];
  onClose: (siteId: string) => void;
}

const automationSteps: AutomationStep[] = [
    { title: 'Triggered', icon: ClockIcon },
    { title: 'Source', icon: DocumentTextIcon },
    { title: 'Strategy', icon: SparklesIcon },
    { title: 'Writing', icon: PenIcon },
    { title: 'Image', icon: PhotoIcon },
    { title: 'SEO', icon: ShieldCheckIcon },
    { title: 'Publish', icon: WordPressIcon },
    { title: 'Social', icon: ShareIcon },
    { title: 'Complete', icon: CheckCircleIcon },
];

const TrackerInstance: React.FC<{ job: AutomationState; siteName: string; onClose: () => void; }> = ({ job, siteName, onClose }) => {
    const { currentStepIndex, isComplete, isError } = useMemo(() => {
        const statusToStepMap: Partial<Record<AppStatus, number>> = {
            [AppStatus.AUTOMATION_TRIGGERED]: 0,
            [AppStatus.FETCHING_SOURCE]: 1,
            [AppStatus.GENERATING_STRATEGY]: 2,
            [AppStatus.AWAITING_STRATEGY_SELECTION]: 2,
            [AppStatus.GENERATING_ARTICLE]: 3,
            [AppStatus.GENERATING_IMAGE]: 4,
            [AppStatus.OPTIMIZING_ARTICLE]: 5,
            [AppStatus.READY_TO_PUBLISH]: 5,
            [AppStatus.PUBLISHING]: 6,
            [AppStatus.GENERATING_SOCIAL_POSTS]: 7,
            [AppStatus.PUBLISHED]: 8,
        };
        
        return {
            currentStepIndex: statusToStepMap[job.status] ?? -1,
            isComplete: job.status === AppStatus.PUBLISHED,
            isError: job.status === AppStatus.ERROR,
        };
    }, [job.status]);
    
    let statusIndicator;
    if (isError) {
        statusIndicator = <XIcon className="h-8 w-8 text-red-400 flex-shrink-0" />;
    } else if (isComplete) {
        statusIndicator = <CheckCircleIcon className="h-8 w-8 text-green-400 flex-shrink-0" />;
    } else {
        statusIndicator = <SpinnerIcon className="h-8 w-8 text-purple-400 animate-spin flex-shrink-0" />;
    }

    return (
        <div className="bg-panel/90 backdrop-blur-sm p-4 border-b border-border animate-fade-in-up">
            <div className="max-w-7xl mx-auto">
                <div className="flex justify-between items-start gap-4">
                    <div className="flex items-center gap-4 min-w-0">
                        {statusIndicator}
                        <div className="min-w-0">
                            <p className="font-bold text-white truncate">Automation for "{siteName}"</p>
                            <p className="text-sm text-text-secondary truncate">Topic: "{job.topic || '...'}"</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-1 rounded-full text-text-secondary hover:bg-panel-light hover:text-white transition-colors flex-shrink-0">
                        <XIcon className="h-6 w-6" />
                    </button>
                </div>
                <div className="mt-4">
                    <AutomationProcessVisualizer
                        steps={automationSteps}
                        currentStepIndex={currentStepIndex}
                        isComplete={isComplete}
                        isError={isError}
                        errorMessage={job.statusMessage}
                        layout="horizontal"
                    />
                </div>
                {job.statusMessage && !isError && (
                    <div className="text-center mt-3 text-purple-300 font-semibold">{job.statusMessage}</div>
                )}
            </div>
        </div>
    );
};


export const GlobalAutomationTracker: React.FC<GlobalAutomationTrackerProps> = ({ automationStates, sites, onClose }) => {
    // Fix: Changed Object.values to Object.keys().map() for better type inference, resolving errors where 'job.status' could not be accessed.
    const runningJobs: AutomationState[] = Object.keys(automationStates)
        .map(key => automationStates[key])
        .filter(job => job.status !== AppStatus.IDLE);

    if (runningJobs.length === 0) {
        return null;
    }

    return (
        <div className="fixed bottom-0 left-0 right-0 z-30 max-h-[50vh] overflow-y-auto">
            {runningJobs.map((job: AutomationState) => {
                const site = sites.find(s => s.id === job.siteId);
                return (
                    <TrackerInstance
                        key={job.siteId}
                        job={job}
                        siteName={site?.name || 'Unknown Site'}
                        onClose={() => onClose(job.siteId)}
                    />
                );
            })}
        </div>
    );
};