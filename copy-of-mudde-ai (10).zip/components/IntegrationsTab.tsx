import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import type { Site, ApiKeys } from '../types';
import * as mcpApiService from '../services/mcpApiService';
import { WordPressIcon, GoogleIcon, MailchimpIcon, CheckCircleIcon, ExclamationTriangleIcon, XCircleIcon, ArrowPathIcon, ChartBarIcon } from './Icons';

interface IntegrationsTabProps {
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
}

type VerificationStatus = 'idle' | 'verifying' | 'success' | 'error';
interface VerificationResult {
    status: VerificationStatus;
    message?: string;
}

const IntegrationCard: React.FC<{
    title: string;
    description: string;
    icon: React.FC<any>;
    statusText: string;
    statusColor: 'green' | 'yellow' | 'red' | 'gray';
    onVerify: () => void;
    isLoading: boolean;
    result: VerificationResult | null;
    settingsPath: string;
}> = ({ title, description, icon: Icon, statusText, statusColor, onVerify, isLoading, result, settingsPath }) => {
    const navigate = useNavigate();
    
    const colorClasses = {
        green: 'bg-green-500',
        yellow: 'bg-yellow-500',
        red: 'bg-red-500',
        gray: 'bg-gray-500',
    };

    return (
        <div className="bg-panel p-6 rounded-lg border border-border-subtle flex flex-col gap-4">
            <div className="flex items-center gap-4">
                <Icon className="h-8 w-8 text-text-secondary" />
                <div>
                    <h3 className="text-xl font-bold text-white">{title}</h3>
                    <div className="flex items-center gap-2 mt-1">
                        <div className={`w-2.5 h-2.5 rounded-full ${colorClasses[statusColor]}`}></div>
                        <span className="text-sm font-medium text-text-secondary">{statusText}</span>
                    </div>
                </div>
            </div>
            <p className="text-sm text-text-secondary flex-grow">{description}</p>
            {result && (
                <div className={`flex items-center gap-3 text-sm p-3 rounded-lg border animate-fade-in ${result.status === 'success' ? 'bg-green-900/20 border-green-500/30 text-green-300' : 'bg-red-900/20 border-red-500/30 text-red-300'}`}>
                    {result.status === 'success' ? <CheckCircleIcon className="h-5 w-5"/> : <XCircleIcon className="h-5 w-5"/>}
                    <span>{result.message}</span>
                </div>
            )}
            <div className="flex items-center gap-3">
                <button onClick={onVerify} disabled={isLoading} className="btn btn-secondary text-sm flex-grow">
                    {isLoading ? 'Verifying...' : 'Test Connection'}
                </button>
                <button onClick={() => navigate(settingsPath)} className="btn btn-secondary text-sm">Settings</button>
            </div>
        </div>
    );
};

export const IntegrationsTab: React.FC<IntegrationsTabProps> = ({ site, onSiteUpdate }) => {
    const [verificationStates, setVerificationStates] = useState<Record<string, { loading: boolean; result: VerificationResult | null }>>({});
    const navigate = useNavigate();

    const handleVerify = useCallback(async (key: string, verifyFn: () => Promise<{ success: boolean; message: string }>) => {
        setVerificationStates(prev => ({ ...prev, [key]: { loading: true, result: null } }));
        try {
            const res = await verifyFn();
            setVerificationStates(prev => ({
                ...prev,
                [key]: {
                    loading: false,
                    result: {
                        status: res.success ? 'success' : 'error',
                        message: res.message,
                    },
                },
            }));
        } catch (e: any) {
            setVerificationStates(prev => ({
                ...prev,
                [key]: {
                    loading: false,
                    result: { status: 'error', message: e.message },
                },
            }));
        }
    }, []);

    const wpStatus = (site.wordpressUrl && site.wordpressUsername && site.applicationPassword) ? 'configured' : 'missing';
    const driveStatus = site.googleDrive?.isConnected ? 'connected' : 'disconnected';
    const analyticsStatus = site.googleAnalytics?.isConnected ? 'connected' : 'disconnected';
    const mailchimpStatus = site.mailchimp?.isConnected ? 'connected' : 'disconnected';
    
    return (
        <div className="max-w-4xl mx-auto space-y-8">
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-2xl font-bold text-white">Integrations Status</h2>
                <p className="text-text-secondary mt-1">Check the status of all your connections to ensure the application is ready to automate.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <IntegrationCard
                    title="WordPress"
                    description="The core connection for publishing your generated blog posts directly to your website."
                    icon={WordPressIcon}
                    statusText={wpStatus === 'configured' ? 'Credentials Added' : 'Configuration Missing'}
                    statusColor={wpStatus === 'configured' ? 'yellow' : 'red'}
                    onVerify={() => handleVerify('wp', () => mcpApiService.verifyWordPressConnection(site.id))}
                    isLoading={verificationStates.wp?.loading}
                    result={verificationStates.wp?.result}
                    settingsPath="/settings/wordpress"
                />
                <IntegrationCard
                    title="Google Drive"
                    description="Used as a reference source for the AI to provide context from your documents and files."
                    icon={GoogleIcon}
                    statusText={driveStatus === 'connected' ? 'Connected' : 'Not Connected'}
                    statusColor={driveStatus === 'connected' ? 'green' : 'gray'}
                    onVerify={() => handleVerify('gdrive', () => mcpApiService.verifyGoogleConnection(site.id, 'drive'))}
                    isLoading={verificationStates.gdrive?.loading}
                    result={verificationStates.gdrive?.result}
                    settingsPath="/settings/references"
                />
                <IntegrationCard
                    title="Google Analytics"
                    description="Provides performance data for your published posts to generate AI-powered SEO insights."
                    icon={ChartBarIcon}
                    statusText={analyticsStatus === 'connected' ? 'Connected' : 'Not Connected'}
                    statusColor={analyticsStatus === 'connected' ? 'green' : 'gray'}
                    onVerify={() => handleVerify('ganalytics', () => mcpApiService.verifyGoogleConnection(site.id, 'analytics'))}
                    isLoading={verificationStates.ganalytics?.loading}
                    result={verificationStates.ganalytics?.result}
                    settingsPath="/analytics"
                />
                <IntegrationCard
                    title="Mailchimp"
                    description="Enables automated email marketing campaigns to be sent to your audience after a new post is published."
                    icon={MailchimpIcon}
                    statusText={mailchimpStatus === 'connected' ? 'Connected' : 'Not Connected'}
                    statusColor={mailchimpStatus === 'connected' ? 'green' : 'gray'}
                    // Fix: Property 'verifyMailchimpConnection' does not exist on type 'typeof import("file:///services/mcpApiService")'.
                    onVerify={() => handleVerify('mailchimp', () => mcpApiService.verifyMailchimpConnection(site.id))}
                    isLoading={verificationStates.mailchimp?.loading}
                    result={verificationStates.mailchimp?.result}
                    settingsPath="/automation"
                />
            </div>

            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-xl font-bold text-white">API Key Status</h2>
                <p className="text-sm text-text-secondary mt-1">Verify that your AI provider API keys are valid and can connect to their respective services.</p>
                <div className="mt-4 space-y-2">
                    {Object.entries(site.apiKeys || {}).filter(([_, value]) => value).map(([key, value]) => {
                        const apiKeyName = key as keyof ApiKeys;
                        const isLoading = verificationStates[apiKeyName]?.loading;
                        const result = verificationStates[apiKeyName]?.result;
                        return (
                            <div key={apiKeyName} className="bg-panel p-3 rounded-lg flex items-center justify-between gap-3 border border-border-subtle">
                                <span className="font-semibold text-text-primary capitalize">{apiKeyName.replace(/([A-Z])/g, ' $1')}</span>
                                <div className="flex items-center gap-3">
                                    {result && (
                                        <span className={`text-xs font-medium flex items-center gap-1.5 ${result.status === 'success' ? 'text-green-400' : 'text-red-400'}`}>
                                            {result.status === 'success' ? <CheckCircleIcon className="h-4 w-4" /> : <XCircleIcon className="h-4 w-4" />}
                                            {result.status}
                                        </span>
                                    )}
                                    <button onClick={() => handleVerify(apiKeyName, () => mcpApiService.verifyApiKey(site.id, apiKeyName, value as string))} disabled={isLoading} className="btn btn-secondary text-xs p-2">
                                        {isLoading ? <ArrowPathIcon className="h-4 w-4 animate-spin" /> : <ArrowPathIcon className="h-4 w-4" />}
                                    </button>
                                </div>
                            </div>
                        );
                    })}
                     {Object.values(site.apiKeys || {}).every(v => !v) && (
                        <p className="text-center text-sm text-text-secondary py-4">No API keys have been added. <button onClick={() => navigate('/settings/keys')} className="font-semibold text-purple-400 hover:underline">Add Keys</button></p>
                     )}
                </div>
            </div>
        </div>
    );
};