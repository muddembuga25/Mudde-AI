import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import type { WebsitePlan } from '../types';
import { SparklesIcon, CheckCircleIcon, ServerIcon } from './Icons';
import { useSitesContext } from '../contexts/SitesContext';
import * as mcpApiService from '../services/mcpApiService';

const StepIndicator: React.FC<{ currentStep: number }> = ({ currentStep }) => {
    const steps = ['Idea', 'Plan', 'Build', 'Launch'];
    return (
        <nav aria-label="Progress">
            <ol role="list" className="flex items-center">
                {steps.map((step, stepIdx) => (
                    <li key={step} className={`relative ${stepIdx !== steps.length - 1 ? 'flex-1' : ''}`}>
                        <>
                            {stepIdx < currentStep ? (
                                <div className="absolute inset-0 flex items-center" aria-hidden="true">
                                    <div className="h-0.5 w-full bg-purple-600" />
                                </div>
                            ) : (
                                <div className="absolute inset-0 flex items-center" aria-hidden="true">
                                    <div className="h-0.5 w-full bg-border" />
                                </div>
                            )}
                            <div className={`relative flex h-8 w-8 items-center justify-center rounded-full ${stepIdx < currentStep ? 'bg-purple-600' : stepIdx === currentStep ? 'border-2 border-purple-500 bg-panel' : 'border-2 border-border bg-panel'}`}>
                                {stepIdx < currentStep ? (
                                    <CheckCircleIcon className="h-5 w-5 text-white" />
                                ) : (
                                    <span className={`h-2.5 w-2.5 rounded-full ${stepIdx === currentStep ? 'bg-purple-500' : 'bg-border'}`} />
                                )}
                            </div>
                             <p className={`mt-2 text-xs font-semibold ${stepIdx <= currentStep ? 'text-purple-300' : 'text-text-secondary'}`}>{step}</p>
                        </>
                    </li>
                ))}
            </ol>
        </nav>
    );
};


export const WebsiteCreatorTab: React.FC = () => {
    const { sites, setSites, setSelectedSiteId } = useSitesContext();
    const navigate = useNavigate();

    const [step, setStep] = useState(1);
    const [idea, setIdea] = useState('');
    const [websitePlan, setWebsitePlan] = useState<WebsitePlan | null>(null);
    const [creationLog, setCreationLog] = useState<string[]>([]);
    const [finalSiteDetails, setFinalSiteDetails] = useState<{ siteUrl: string, adminUrl: string, adminUser: string, adminPass: string } | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleAnalyzeIdea = useCallback(async () => {
        if (!idea.trim()) return;
        setIsLoading(true);
        setError(null);
        try {
            // If no sites exist, pass a temporary ID. The service layer will handle creating a transient site for the API call.
            const siteIdForApiKeys = sites[0]?.id || "temp-site-id";
            const { plan } = await mcpApiService.generateWebsitePlan(siteIdForApiKeys, idea);
            setWebsitePlan(plan);
            setStep(2);
        } catch (e: any) {
            setError(e.message || "Failed to analyze the idea. Please try again.");
        } finally {
            setIsLoading(false);
        }
    }, [idea, sites]);

    const handleCreateWebsite = useCallback(async () => {
        if (!websitePlan) return;
        setIsLoading(true);
        setError(null);
        setStep(3);
        const logUpdater = (message: string) => setCreationLog(prev => [...prev, message]);

        try {
            const { newSite, ...details } = await mcpApiService.create10WebSite(websitePlan, logUpdater);
            setSites(prev => [...prev, newSite]);
            setSelectedSiteId(newSite.id);
            setFinalSiteDetails(details);
            setStep(4);
        } catch (e: any) {
            setError(e.message || "Failed to create the website.");
        } finally {
            setIsLoading(false);
        }
    }, [websitePlan, setSites, setSelectedSiteId]);

    const renderStep = () => {
        switch (step) {
            case 1:
                return (
                    <div className="text-center">
                        <h3 className="text-3xl font-extrabold text-white">Start with an Idea</h3>
                        <p className="mt-2 text-lg text-text-secondary">Describe your dream website, and let AI build the foundation.</p>
                        <textarea value={idea} onChange={e => setIdea(e.target.value)} placeholder="e.g., An online store selling handmade ceramic coffee mugs. The vibe should be minimalist, earthy, and warm..." className="input-base text-base mt-6 w-full max-w-2xl mx-auto" rows={5}></textarea>
                        <button onClick={handleAnalyzeIdea} disabled={isLoading || !idea.trim()} className="btn btn-primary text-lg py-3 px-6 mt-6 disabled:opacity-50">
                            {isLoading ? 'Analyzing...' : 'Generate Plan'}
                        </button>
                    </div>
                );
            case 2:
                return (
                    <div>
                        <h3 className="text-2xl font-bold text-white text-center">AI-Generated Plan</h3>
                        <p className="text-text-secondary mt-1 text-center">Review and refine the AI's suggestions before building your site.</p>
                        <div className="mt-6 space-y-4">
                            {/* Editable fields would be added here */}
                            <pre className="bg-panel p-4 rounded-lg text-xs max-h-96 overflow-auto border border-border-subtle"><code>{JSON.stringify(websitePlan, null, 2)}</code></pre>
                        </div>
                        <div className="mt-6 flex justify-center gap-4">
                            <button onClick={() => setStep(1)} className="btn btn-secondary">Back</button>
                            <button onClick={handleCreateWebsite} disabled={isLoading} className="btn btn-primary">Create Website</button>
                        </div>
                    </div>
                );
            case 3:
                 return (
                    <div className="text-center">
                        <h3 className="text-2xl font-bold text-white">Your Website is Being Built!</h3>
                        <p className="text-text-secondary mt-1">This may take a few minutes. Please don't close this tab.</p>
                        <div className="mt-6 bg-panel p-4 rounded-lg border border-border-subtle text-left font-mono text-sm text-text-secondary h-64 overflow-y-auto">
                            {creationLog.map((line, i) => <p key={i} className="animate-fade-in">&gt; {line}</p>)}
                            <div className="w-2 h-4 bg-purple-400 animate-pulse ml-2"></div>
                        </div>
                    </div>
                );
            case 4:
                return (
                     <div className="text-center">
                        <CheckCircleIcon className="h-16 w-16 text-green-400 mx-auto" />
                        <h3 className="text-3xl font-extrabold text-white mt-4">Website Created Successfully!</h3>
                        <p className="text-lg text-text-secondary mt-1">Your new site is live and ready to manage.</p>
                        <div className="mt-6 bg-panel p-6 rounded-lg border border-border-subtle max-w-lg mx-auto space-y-3 text-left">
                            <p><strong className="text-text-primary">Site URL:</strong> <a href={finalSiteDetails?.siteUrl} target="_blank" className="text-purple-400 hover:underline">{finalSiteDetails?.siteUrl}</a></p>
                            <p><strong className="text-text-primary">Admin URL:</strong> <a href={finalSiteDetails?.adminUrl} target="_blank" className="text-purple-400 hover:underline">{finalSiteDetails?.adminUrl}</a></p>
                            <p><strong className="text-text-primary">Username:</strong> {finalSiteDetails?.adminUser}</p>
                            <p><strong className="text-text-primary">Password:</strong> {finalSiteDetails?.adminPass}</p>
                        </div>
                        <div className="mt-6 flex justify-center gap-4">
                           <button onClick={() => navigate('/')} className="btn btn-primary">Manage Site in Dashboard</button>
                        </div>
                    </div>
                );
        }
    };

    return (
        <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
             <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-2xl font-bold text-white flex items-center gap-3"><SparklesIcon className="h-6 w-6" /> AI Website Builder</h2>
                <p className="text-text-secondary mt-1">Go from idea to a live, AI-generated WordPress site in minutes, powered by 10Web.</p>
            </div>
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <div className="mb-8">
                    <StepIndicator currentStep={step-1} />
                </div>
                <div className="min-h-[300px] flex items-center justify-center">
                     {renderStep()}
                </div>
                 {error && <p className="text-red-400 text-center mt-4">{error}</p>}
            </div>
        </div>
    );
};