import React, { useState, useEffect, useCallback } from 'react';
import type { Site, WordPressAuthor, WordPressCategory } from '../types';
import * as mcpApiService from '../services/mcpApiService';
import { WordPressIcon, CheckCircleIcon, ExclamationTriangleIcon, ArrowPathIcon } from './Icons';

interface WordPressTabProps {
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    onMultipleSiteUpdates: (updates: Partial<Site>) => void;
    setError: (error: string | null) => void;
}

export const WordPressTab: React.FC<WordPressTabProps> = ({ site, onSiteUpdate, onMultipleSiteUpdates, setError }) => {
    const [isVerifying, setIsVerifying] = useState(false);
    const [isFetchingData, setIsFetchingData] = useState(false);
    const [verificationStatus, setVerificationStatus] = useState<{ success: boolean; message: string } | null>(null);

    const handleVerifyConnection = useCallback(async () => {
        setIsVerifying(true);
        setError(null);
        setVerificationStatus(null);
        try {
            const result = await mcpApiService.verifyWordPressConnection(site.id);
            setVerificationStatus(result);
            if (result.success && result.siteTitle) {
                onSiteUpdate('name', result.siteTitle);
            }
        } catch (error: any) {
            setError(error.message);
            setVerificationStatus({ success: false, message: error.message });
        } finally {
            setIsVerifying(false);
        }
    }, [site.id, setError, onSiteUpdate]);

    const handleFetchData = useCallback(async () => {
        setIsFetchingData(true);
        setError(null);
        try {
            const { authors } = await mcpApiService.fetchWordPressAuthors(site.id);
            // Fix: Property 'categories' does not exist on type 'void'.
            const { categories } = await mcpApiService.fetchWordPressCategories(site.id);
            onMultipleSiteUpdates({
                availableAuthors: authors,
                availableCategories: categories,
            });
        } catch (error: any) {
            setError(error.message);
        } finally {
            setIsFetchingData(false);
        }
    }, [site.id, setError, onMultipleSiteUpdates]);

    const isConfigured = site.wordpressUrl && site.wordpressUsername && site.applicationPassword;

    return (
        <div className="max-w-4xl mx-auto space-y-8">
            <div className="content-panel">
                <h3 className="text-xl font-bold text-white">Connection Details</h3>
                <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label htmlFor="wp-url" className="block text-sm font-medium text-text-primary mb-2">WordPress URL</label>
                        <input id="wp-url" type="url" value={site.wordpressUrl} onChange={(e) => onSiteUpdate('wordpressUrl', e.target.value)} placeholder="https://example.com" className="input-base" />
                    </div>
                    <div>
                        <label htmlFor="wp-user" className="block text-sm font-medium text-text-primary mb-2">WordPress Username</label>
                        <input id="wp-user" type="text" value={site.wordpressUsername} onChange={(e) => onSiteUpdate('wordpressUsername', e.target.value)} placeholder="Your admin username" className="input-base" />
                    </div>
                    <div className="md:col-span-2">
                        <label htmlFor="wp-pass" className="block text-sm font-medium text-text-primary mb-2">Application Password</label>
                        <input id="wp-pass" type="password" value={site.applicationPassword} onChange={(e) => onSiteUpdate('applicationPassword', e.target.value)} placeholder="Generate this in your WP User Profile" className="input-base" />
                        <p className="text-xs text-text-secondary mt-2">
                            To get an Application Password, go to Users &gt; Your Profile in your WordPress admin dashboard, and find the "Application Passwords" section.
                        </p>
                    </div>
                </div>
                <div className="mt-6 pt-6 border-t border-border-subtle">
                    <button onClick={handleVerifyConnection} disabled={!isConfigured || isVerifying} className="btn btn-primary w-full sm:w-auto disabled:opacity-50">
                        {isVerifying ? 'Verifying...' : 'Verify Connection'}
                    </button>
                    {verificationStatus && (
                        <div className={`mt-4 flex items-start gap-3 p-3 rounded-lg border text-sm ${verificationStatus.success ? 'bg-green-900/20 border-green-500/30 text-green-300' : 'bg-red-900/20 border-red-500/30 text-red-300'}`}>
                            {verificationStatus.success ? <CheckCircleIcon className="h-5 w-5 flex-shrink-0" /> : <ExclamationTriangleIcon className="h-5 w-5 flex-shrink-0" />}
                            <p>{verificationStatus.message}</p>
                        </div>
                    )}
                </div>
            </div>

            <div className={`content-panel ${!verificationStatus?.success ? 'opacity-50 pointer-events-none' : ''}`}>
                <h3 className="text-xl font-bold text-white">Site Data</h3>
                <p className="text-sm text-text-secondary mt-1">Fetch authors and categories to use for publishing.</p>
                <div className="mt-6">
                    <button onClick={handleFetchData} disabled={!verificationStatus?.success || isFetchingData} className="btn btn-secondary flex items-center gap-2">
                        <ArrowPathIcon className={`h-5 w-5 ${isFetchingData ? 'animate-spin' : ''}`} />
                        {isFetchingData ? 'Fetching Data...' : 'Fetch Authors & Categories'}
                    </button>
                    <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label htmlFor="wp-author" className="block text-sm font-medium text-text-primary mb-2">Default Author</label>
                            <select id="wp-author" value={site.authorId || ''} onChange={(e) => onSiteUpdate('authorId', e.target.value ? parseInt(e.target.value, 10) : undefined)} className="input-base">
                                <option value="">Select an author...</option>
                                {(site.availableAuthors || []).map(author => <option key={author.id} value={author.id}>{author.name}</option>)}
                            </select>
                             {site.availableAuthors?.length === 0 && <p className="text-xs text-text-secondary mt-2">No authors fetched yet, or none found.</p>}
                        </div>
                        <div>
                             <h4 className="text-sm font-medium text-text-primary mb-2">Available Categories</h4>
                            {(site.availableCategories || []).length > 0 ? (
                                <div className="flex flex-wrap gap-2">
                                    {site.availableCategories.map(cat => <span key={cat.id} className="bg-gray-700/50 text-text-secondary text-xs font-medium px-2 py-1 rounded-full">{cat.name}</span>)}
                                </div>
                            ) : <p className="text-xs text-text-secondary">No categories fetched yet.</p>}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};