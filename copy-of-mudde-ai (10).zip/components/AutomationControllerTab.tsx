import React from 'react';
import type { Site } from '../../types';
import { useSitesContext } from '../../contexts/SitesContext';
import { PenIcon, PhotoIcon, VideoCameraIcon, MailIcon, StopIcon } from '../Icons';

const KillSwitch: React.FC<{
    title: string;
    description: string;
    icon: React.FC<any>;
    onPause: () => void;
}> = ({ title, description, icon: Icon, onPause }) => (
    <div className="bg-panel p-4 rounded-lg border border-border-subtle flex items-center justify-between gap-4">
        <div className="flex items-center gap-4">
            <div className="bg-red-900/40 p-3 rounded-lg"><Icon className="h-6 w-6 text-red-300" /></div>
            <div>
                <h4 className="font-semibold text-white">{title}</h4>
                <p className="text-sm text-text-secondary">{description}</p>
            </div>
        </div>
        <button onClick={onPause} className="btn bg-red-600 hover:bg-red-700 text-white flex-shrink-0 flex items-center gap-2">
            <StopIcon className="h-5 w-5" /> Pause All
        </button>
    </div>
);


export const AutomationControllerTab: React.FC = () => {
    const { sites, setSites } = useSitesContext();
    
    const pauseAllOfType = (type: 'blog' | 'social_graphic' | 'social_video' | 'email') => {
        if (!window.confirm(`Are you sure you want to pause ALL ${type} automations across ${sites.length} sites?`)) {
            return;
        }

        let keyToUpdate: keyof Site;
        switch(type) {
            case 'blog': keyToUpdate = 'isAutomationEnabled'; break;
            case 'social_graphic': keyToUpdate = 'isSocialGraphicAutomationEnabled'; break;
            case 'social_video': keyToUpdate = 'isSocialVideoAutomationEnabled'; break;
            case 'email': keyToUpdate = 'isEmailMarketingAutomationEnabled'; break;
        }
        
        setSites(prevSites => prevSites.map(site => ({ ...site, [keyToUpdate]: false })));
    };

    return (
        <div className="space-y-8 animate-fade-in">
            <h1 className="text-3xl font-bold text-white">Global Automation Controller</h1>
            
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-xl font-bold text-white text-red-400">Global Kill Switches</h2>
                <p className="text-sm text-text-secondary mt-1">These actions immediately pause all running and scheduled automations of a specific type across every site in your portfolio. This is useful for emergency stops or system-wide maintenance.</p>
                <div className="mt-4 space-y-3">
                    <KillSwitch 
                        title="Pause All Blog Post Automations" 
                        description="Stops all new article generation jobs." 
                        icon={PenIcon}
                        onPause={() => pauseAllOfType('blog')}
                    />
                    <KillSwitch 
                        title="Pause All Social Graphic Automations" 
                        description="Stops all new social graphic and caption generation jobs." 
                        icon={PhotoIcon}
                        onPause={() => pauseAllOfType('social_graphic')}
                    />
                    <KillSwitch 
                        title="Pause All Social Video Automations" 
                        description="Stops all new social video generation jobs." 
                        icon={VideoCameraIcon}
                        onPause={() => pauseAllOfType('social_video')}
                    />
                    <KillSwitch 
                        title="Pause All Email Marketing Automations" 
                        description="Stops all new email campaign and digest generation jobs." 
                        icon={MailIcon}
                        onPause={() => pauseAllOfType('email')}
                    />
                </div>
            </div>
        </div>
    );
};
