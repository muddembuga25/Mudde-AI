import React from 'react';
import type { Draft } from '../types';
import { PenIcon, TrashIcon, DocumentTextIcon, RssIcon, VideoCameraIcon, GoogleSheetsIcon } from './Icons';

interface DraftsTabProps {
    drafts: Draft[];
    onReview: (draftId: string) => void;
    onDiscard: (draftId: string) => void;
}

export const DraftsTab: React.FC<DraftsTabProps> = ({ drafts, onReview, onDiscard }) => {
    const sortedDrafts = [...drafts].sort((a, b) => b.date - a.date);
    
    const sourceTypeInfo: Record<string, { icon: React.FC<any>, label: string, color: string }> = {
        keyword: { icon: DocumentTextIcon, label: 'Keyword', color: 'text-blue-400' },
        rss: { icon: RssIcon, label: 'RSS', color: 'text-orange-400' },
        video: { icon: VideoCameraIcon, label: 'Video', color: 'text-red-400' },
        google_sheet: { icon: GoogleSheetsIcon, label: 'Google Sheet', color: 'text-green-400' },
    };

    return (
        <div className="max-w-4xl mx-auto">
            {sortedDrafts.length === 0 ? (
                <div className="text-center py-16 bg-panel/50 rounded-2xl border-2 border-dashed border-border">
                    {/* Fix: Removed invalid title prop */}
                    <PenIcon className="mx-auto h-12 w-12 text-text-secondary" />
                    <h3 className="mt-4 text-lg font-medium text-white">No Drafts Yet</h3>
                    <p className="mt-1 text-sm text-text-secondary">
                        Disable "Publish Automatically" in the Automation tab to have generated posts appear here for review.
                    </p>
                </div>
            ) : (
                <div className="space-y-4 max-h-[70vh] overflow-y-auto -mr-2 pr-2">
                    {sortedDrafts.map((draft, index) => {
                        const info = sourceTypeInfo[draft.sourceDetails.type];
                        const Icon = info.icon;
                        
                        return (
                            <div key={draft.id} className="bg-panel p-4 rounded-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border border-border-subtle animate-fade-in-up" style={{ animationDelay: `${index * 60}ms`, opacity: 0, animationFillMode: 'forwards' }}>
                                <div className='flex-1 min-w-0'>
                                    <p className="font-semibold text-text-primary truncate" title={draft.blogPost.title}>
                                        {draft.blogPost.title}
                                    </p>
                                    <div className="flex items-center flex-wrap gap-x-4 gap-y-1 mt-1.5 text-sm text-text-secondary">
                                        <span>Generated: {new Date(draft.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                                        <span className="flex items-center gap-1.5">
                                            <Icon className={`h-4 w-4 ${info.color}`} /> 
                                            Source: <span className="font-medium text-text-primary truncate" title={draft.sourceTopic}>{draft.sourceTopic}</span>
                                        </span>
                                    </div>
                                </div>
                                <div className="flex items-center gap-3 w-full sm:w-auto flex-shrink-0">
                                    {/* Fix: Moved title prop from TrashIcon to the parent button */}
                                    <button onClick={() => onDiscard(draft.id)} title="Discard Draft" className="w-1/2 sm:w-auto btn bg-red-900/40 hover:bg-red-800/60 text-red-300">
                                        <TrashIcon className="h-5 w-5" />
                                    </button>
                                    <button onClick={() => onReview(draft.id)} className="w-1/2 sm:w-auto btn btn-primary flex items-center justify-center gap-2">
                                        Review & Publish
                                    </button>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
};