import React from 'react';
import { UsersIcon } from './Icons';

export const ClientsTab: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto space-y-8">
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-2xl font-bold text-white">Client Management</h2>
                <p className="text-text-secondary mt-1">This feature is available for Agency plans. Manage your client sites from a central dashboard.</p>
            </div>
            <div className="text-center p-8 bg-panel/50 rounded-2xl border-2 border-dashed border-border">
                 <UsersIcon className="mx-auto h-12 w-12 text-text-secondary" />
                <h3 className="mt-4 text-lg font-medium text-white">Coming Soon</h3>
                <p className="mt-1 text-sm text-text-secondary">A dedicated space to manage all your client projects and configurations.</p>
            </div>
        </div>
    );
};
