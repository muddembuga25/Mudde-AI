import React from 'react';

export const LogoIcon: React.FC = () => (
  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 2L2 7V17L12 22L22 17V7L12 2Z" stroke="#8B5CF6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M2 7L12 12L22 7" stroke="#8B5CF6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M12 12V22" stroke="#8B5CF6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export const GoogleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" {...props}>
    <path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"/>
    <path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"/>
    <path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.222,0-9.519-3.356-11.024-7.923l-6.522,5.025C9.505,39.556,16.227,44,24,44z"/>
    <path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.574l6.19,5.238C39.904,36.218,44,30.668,44,24C44,22.659,43.862,21.35,43.611,20.083z"/>
  </svg>
);

export const ExclamationTriangleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
  </svg>
);
export const UserIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
  </svg>
);
export const MailIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />
  </svg>
);
export const KeyIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 5.25a3 3 0 013 3m3 0a6 6 0 01-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 1121.75 8.25z" />
  </svg>
);
export const ArrowLeftOnRectangleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15m3 0l3-3m0 0l-3-3m3 3H9" />
  </svg>
);
export const PlusIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
  </svg>
);
export const ChevronDownIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
  </svg>
);
export const Bars3Icon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
  </svg>
);
export const XIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
  </svg>
);
export const DocumentTextIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
  </svg>
);
export const RssIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12.75 19.5v-.75a7.5 7.5 0 00-7.5-7.5H4.5m0-6.75h.75c7.87 0 14.25 6.38 14.25 14.25v.75M6 18.75a.75.75 0 100-1.5.75.75 0 000 1.5z" />
  </svg>
);
export const VideoCameraIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 10.5l4.72-4.72a.75.75 0 011.28.53v11.38a.75.75 0 01-1.28.53l-4.72-4.72M4.5 18.75h9a2.25 2.25 0 002.25-2.25v-9a2.25 2.25 0 00-2.25-2.25h-9A2.25 2.25 0 002.25 7.5v9A2.25 2.25 0 004.5 18.75z" />
  </svg>
);
export const TrashIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.134-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.067-2.09 1.02-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
  </svg>
);
export const LightbulbIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 001.5-11.25H10.5a6.01 6.01 0 001.5 11.25v.213" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a.75.75 0 110-1.5.75.75 0 010 1.5zm0 0A3.375 3.375 0 0015.375 15h-6.75A3.375 3.375 0 0012 18.75z" />
  </svg>
);
export const LinkIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.19 8.688a4.5 4.5 0 011.242 7.244l-4.5 4.5a4.5 4.5 0 01-6.364-6.364l1.757-1.757m13.35-.622l1.757-1.757a4.5 4.5 0 00-6.364-6.364l-4.5 4.5a4.5 4.5 0 001.242 7.244" />
  </svg>
);
export const WordPressIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path d="M10 0C4.477 0 0 4.477 0 10c0 5.523 4.477 10 10 10s10-4.477 10-10C20 4.477 15.523 0 10 0zM7.135 14.39c-.112.01-.22-.008-.322-.053l-2.4-1.09c-.21-.095-.21-.24 0-.334l2.4-1.09c.21-.095.378-.027.321.187l-.692 2.19c-.057.215.027.378.187.321l.107-.045zm3.033.433c-.14.075-.285.03-.432-.112L5.209 7.02c-.147-.14-.182-.285-.112-.432l.433-.9c.07-.147.215-.182.355-.112L13.57 9.89c.14.07.182.215.112.355l-.433.9c-.07.147-.215.182-.355.112L7.135 7.828l3.62 6.376.107-.06zm3.92-1.773c.16-.057.24-.22.187-.378l-.68-2.19c-.056-.16.028-.322.187-.322l.108.045c.11.05.218.01.32-.05L17.1 9.01c.21-.1.21-.248 0-.342l-2.4-1.09c-.21-.1-.378-.028-.322.187l.68 2.19c.057.16-.028.322-.187.322l-.108-.045z"/>
  </svg>
);
export const ChartBarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" />
  </svg>
);
export const SparklesIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.898 20.572L16.5 21.75l-.398-1.178a3.375 3.375 0 00-2.3-2.3L12.75 18l1.178-.398a3.375 3.375 0 002.3-2.3L16.5 14.25l.398 1.178a3.375 3.375 0 002.3 2.3l1.178.398-1.178.398a3.375 3.375 0 00-2.3 2.3z" />
  </svg>
);
export const CheckCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);
export const XCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);
export const UserCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
);
export const PhotoIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
    </svg>
);
export const ArrowUpTrayIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" />
    </svg>
);
export const GoogleDriveIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 448 512" fill="currentColor" {...props}><path d="M439.2 240l-143.2-143.2c-12.5-12.5-32.8-12.5-45.3 0l-143.2 143.2c-12.5 12.5-12.5 32.8 0 45.3l71.6 71.6c12.5 12.5 32.8 12.5 45.3 0l47.7-47.7 47.7 47.7c12.5 12.5 32.8 12.5 45.3 0l71.6-71.6c12.5-12.5 12.5-32.8 0-45.3zM224 416L80.8 272.8 224 129.6l143.2 143.2L224 416z"/></svg>
);
export const ClockIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);
export const ArchiveBoxIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10 11.25h4M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z" />
    </svg>
);
export const CalendarDaysIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0h18M-4.5 12h27" />
    </svg>
);
export const ArrowPathIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0011.667 0l3.181-3.183m-3.181-4.991v4.99" />
  </svg>
);
export const ServerIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 14.25h13.5m-13.5 0a3 3 0 01-3-3V7.5a3 3 0 013-3h13.5a3 3 0 013 3v3.75a3 3 0 01-3 3m-13.5 0v-3.75a3 3 0 013-3h13.5a3 3 0 013 3v3.75m-16.5 3.75h16.5a3 3 0 003-3V7.5a3 3 0 00-3-3H5.25a3 3 0 00-3 3v3.75a3 3 0 003 3z" />
    </svg>
);
export const CommandLineIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 7.5l3 2.25-3 2.25m4.5 0h3m-9 8.25h13.5A2.25 2.25 0 0021 18V6a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 6v12a2.25 2.25 0 002.25 2.25z" />
    </svg>
);
export const ShieldCheckIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.57-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.286zm0 13.036h.008v.008H12v-.008z" />
    </svg>
);
export const PenIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125" />
    </svg>
);
export const ShareIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M7.217 10.907a2.25 2.25 0 100 2.186m0-2.186c.195.025.39.044.586.06.334.032.664.09.986.162l.245.064m-1.817 0l1.817-2.186m12.552 2.186a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0m-2.186 0c.032.334.09.664.162.986l.064.245m0 0l2.186 1.817m-2.186-1.817a2.25 2.25 0 10-2.186-1.817 2.25 2.25 0 002.186 1.817z" />
  </svg>
);
export const SpinnerIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" {...props}>
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);
export const PaperAirplaneIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" />
    </svg>
);
export const ChatBubbleLeftRightIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193l-3.72.338c-.337.03-.664.062-.996.096a18.29 18.29 0 01-3.413-.263m-4.518 0a18.26 18.26 0 00-3.72.338c-1.133-.093-1.98-1.057-1.98-2.192v-4.286c0-.97.616-1.813 1.5-2.097m4.518 0a18.285 18.285 0 01-3.413-.263m4.518 0c.332.034.661.066.996.096m4.518 0c-.332.034-.661.066-.996.096" />
    </svg>
);
export const MicrophoneIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 006-6v-1.5m-6 7.5a6 6 0 01-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 01-3-3V4.5a3 3 0 016 0v8.25a3 3 0 01-3 3z" />
    </svg>
);
export const StopCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 9.563C9 9.252 9.252 9 9.563 9h4.874c.311 0 .563.252.563.563v4.874c0 .311-.252.563-.563.563H9.563C9.252 15 9 14.748 9 14.437V9.563z" />
    </svg>
);
export const GoogleSheetsIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M12.5 3H18C18.5523 3 19 3.44772 19 4V9.5" stroke="#34A853" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M5 21H16C16.5523 21 17 20.5523 17 20V4C17 3.44772 16.5523 3 16 3H8C7.44772 3 7 3.44772 7 4V20C7 20.5523 7.44772 21 8 21H12" stroke="#34A853" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 16H8" stroke="#34A853" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 12H8" stroke="#34A853" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 8H8" stroke="#34A853" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);
export const MailchimpIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}><path d="M17.382 10.364c-2.427-2.18-4.59-4.823-4.855-8.87a.765.765 0 00-.76-.694h-.01a.755.755 0 00-.75.765c-.06 2.5-1.076 4.7-2.583 6.45-2.062 2.4-5.632 3.6-7.534 3.782a.75.75 0 00-.63.75v.01c0 .414.336.75.75.75 2.126.24 5.215 1.44 7.218 3.722 1.5 1.74 2.525 3.96 2.584 6.45a.75.75 0 00.75.75h.01c.414 0 .75-.336.75-.75.24-4.047 2.37-6.69 4.856-8.871 2.37-2.12 5.05-3.06 7.275-3.3v-.01a.75.75 0 00-.75-.75c-2.226-.18-4.906.78-7.276 2.9" fill="#FFE01B"/></svg>
);
export const InfoIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" />
  </svg>
);
export const HomeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12l8.954-8.955a.75.75 0 011.06 0l8.955 8.955a.75.75 0 01-1.06 1.06L12 4.06 3.31 13.06a.75.75 0 01-1.06-1.06z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h7.5" />
  </svg>
);
export const HostingIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 17.25v-.228a4.5 4.5 0 00-.12-1.03l-2.268-9.64a3.375 3.375 0 00-3.285-2.602H7.923a3.375 3.375 0 00-3.285 2.602l-2.268 9.64a4.5 4.5 0 00-.12 1.03v.228m19.5 0a3 3 0 01-3 3H5.25a3 3 0 01-3-3m19.5 0a3 3 0 00-3-3H5.25a3 3 0 00-3 3m16.5 0h.008v.008h-.008v-.008zm-3 0h.008v.008h-.008v-.008z" />
  </svg>
);
export const TenWebIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}><path d="M14.4 2.4H9.6L7.2 14.4l4.8 7.2 4.8-7.2-2.4-12z" fill="#000"/><path d="M9.6 2.4H4.8l2.4 12 2.4-2.4-2.4-9.6zM14.4 2.4h4.8l-2.4 12-2.4-2.4 2.4-9.6z" fill="#000"/></svg>
);
export const UsersIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.53-2.475M15 19.128v-3.375c0-1.621-1.328-2.926-2.95-2.926s-2.95 1.305-2.95 2.926v3.375M15 19.128c0-1.621-1.328-2.926-2.95-2.926s-2.95 1.305-2.95 2.926v3.375m0 0a3.004 3.004 0 009.75 0m-9.75 0a9.37 9.37 0 015.625-1.543 9.37 9.37 0 015.625 1.543m-11.25 0a3.004 3.004 0 005.625 0m-5.625 0a3.004 3.004 0 015.625 0m-5.625 0L6 16.128v4.02A9.355 9.355 0 0012 21.75a9.355 9.355 0 006-1.602v-4.02M9 9.75a3 3 0 116 0 3 3 0 01-6 0z" />
    </svg>
);
// Fix: Add missing social media icons
export const WhatsAppIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg fill="currentColor" viewBox="0 0 24 24" {...props}>
        <path d="M16.75,13.96C17,14.26 17.21,14.5 17.38,14.81C17.55,15.12 17.6,15.3 17.56,15.54C17.51,15.79 17.42,16.13 17.18,16.5C16.94,16.88 16.54,17.14 16.1,17.31C15.66,17.48 15.19,17.54 14.65,17.38C14.1,17.22 13.11,16.91 11.75,15.96C10.03,14.76 8.76,13.04 8.5,12.7C8.24,12.36 7.94,11.96 7.94,11.5C7.94,11.04 8.1,10.71 8.31,10.5C8.53,10.29 8.78,10.18 9,10.18H9.3C9.5,10.18 9.7,10.23 9.89,10.41C10.09,10.59 10.23,10.85 10.3,11.05C10.38,11.25 10.44,11.45 10.46,11.64C10.49,11.83 10.49,12 10.43,12.15C10.37,12.31 10.26,12.45 10.1,12.61C9.94,12.77 9.79,12.92 9.68,13.03C9.56,13.14 9.47,13.25 9.4,13.34C9.3,13.43 9.25,13.5 9.25,13.54C9.25,13.58 9.27,13.62 9.29,13.67C9.31,13.72 9.35,13.78 9.4,13.84C9.77,14.41 10.4,15.04 11,15.35C11.19,15.46 11.36,15.55 11.5,15.63C11.64,15.7 11.75,15.75 11.85,15.75C11.95,15.75 12.05,15.73 12.14,15.68C12.23,15.63 12.33,15.54 12.45,15.42C12.57,15.3 12.68,15.19 12.77,15.1C12.86,15.01 12.95,14.93 13.03,14.86C13.11,14.79 13.18,14.73 13.23,14.7C13.28,14.67 13.32,14.65 13.34,14.65C13.36,14.65 13.38,14.65 13.4,14.65C13.43,14.65 13.45,14.65 13.48,14.66C13.51,14.67 13.53,14.68 13.56,14.68C13.73,14.71 14.04,14.83 14.5,15.05C14.96,15.27 15.2,15.39 15.3,15.44C15.41,15.49 15.5,15.56 15.58,15.66C15.66,15.76 15.72,15.85 15.75,15.94C15.8,16.05 15.81,16.15 15.81,16.24C15.81,16.33 15.79,16.42 15.75,16.5C15.5,16.95 15.04,17.3 14.53,17.49C14.02,17.68 13.5,17.75 13,17.75C12.5,17.75 12.03,17.68 11.59,17.54C11.15,17.4 10.42,17.15 9.4,16.58C8.38,16.01 7.49,15.3 6.74,14.45C5.99,13.6 5.42,12.68 5.04,11.68C4.66,10.68 4.5,9.7 4.56,8.75C4.63,7.8 4.93,6.96 5.48,6.23C6.03,5.5 6.7,5.04 7.5,4.82C8.3,4.6 9.1,4.6 9.89,4.83C10.68,5.06 11.36,5.48 11.9,6.11C12.44,6.74 12.82,7.46 13.03,8.25C13.24,9.04 13.24,9.82 13.04,10.59C12.84,11.36 12.44,12.08 11.88,12.75C11.69,12.98 11.48,13.19 11.25,13.39C11.02,13.59 10.8,13.75 10.61,13.88C10.5,13.97 10.41,14.05 10.35,14.12C10.29,14.19 10.23,14.27 10.19,14.34C10.15,14.41 10.1,14.48 10.05,14.56C10,14.64 9.95,14.73 9.9,14.81C9.75,15.05 9.61,15.29 9.5,15.5C9.39,15.71 9.28,15.91 9.19,16.1C9.1,16.29 9.03,16.48 8.99,16.66C8.95,16.84 8.93,17.02 8.94,17.19C8.95,17.36 9,17.53 9.08,17.69C9.16,17.85 9.28,18 9.42,18.13C9.56,18.26 9.72,18.36 9.89,18.44C10.06,18.52 10.24,18.56 10.43,18.58C10.62,18.6 10.8,18.6 10.99,18.56C11.18,18.52 11.36,18.45 11.54,18.34C11.72,18.23 11.89,18.11 12.04,17.95C12.19,17.79 12.33,17.61 12.45,17.42C12.57,17.23 12.68,17.02 12.75,16.81C12.82,16.6 12.88,16.38 12.91,16.15C12.94,15.92 12.95,15.68 12.91,15.45C12.87,15.22 12.8,14.97 12.7,14.7C12.6,14.43 12.45,14.13 12.25,13.8C12.05,13.47 11.83,13.14 11.6,12.81C11.37,12.48 11.12,12.14 10.88,11.81C10.64,11.48 10.4,11.15 10.19,10.81C9.98,10.47 9.8,10.14 9.68,9.81C9.56,9.48 9.47,9.15 9.43,8.81C9.39,8.47 9.38,8.14 9.43,7.81C9.48,7.48 9.56,7.15 9.68,6.81C9.8,6.48 9.98,6.15 10.19,5.81C10.4,5.47 10.64,5.14 10.88,4.81C11.12,4.48 11.37,4.15 11.6,3.81C11.83,3.48 12.05,3.14 12.25,2.81C12.45,2.48 12.6,2.18 12.7,1.9C12.8,1.63 12.87,1.38 12.91,1.15C12.95,0.92 12.94,0.68 12.91,0.45C12.88,0.22 12.82,0 12.75,-0.2C12.68,-0.4 12.57,-0.61 12.45,-0.8C12.33,-0.99 12.19,-1.17 12.04,-1.33C11.89,-1.49 11.72,-1.61 11.54,-1.72C11.36,-1.83 11.18,-1.9 10.99,-1.94C10.8,-1.98 10.62,-2 10.43,-1.98C10.24,-1.96 10.06,-1.92 9.89,-1.84C9.72,-1.76 9.56,-1.66 9.42,-1.53C9.28,-1.4 9.16,-1.18 9.08,-1.01C9,-0.85 8.95,-0.68 8.94,-0.51C8.93,-0.34 8.95,-0.16 8.99,0.02C9.03,0.2 9.1,0.39 9.19,0.58C9.28,0.77 9.39,0.97 9.5,1.18C9.61,1.39 9.75,1.63 9.9,1.87C10.05,2.11 10.15,2.28 10.19,2.35C10.23,2.42 10.29,2.5 10.35,2.57C10.41,2.64 10.5,2.72 10.61,2.81C10.72,2.9 10.81,2.98 10.88,3.03C11.12,3.19 11.37,3.31 11.6,3.44C11.83,3.57 12.05,3.68 12.25,3.8C12.45,3.92 12.6,4 12.7,4.05C12.8,4.1 12.87,4.13 12.91,4.15C12.95,4.17 12.94,4.18 12.91,4.2C12.88,4.22 12.82,4.25 12.75,4.31C12.68,4.37 12.57,4.45 12.45,4.54C12.33,4.63 12.19,4.73 12.04,4.85C11.89,4.97 11.72,5.11 11.54,5.25C11.36,5.39 11.18,5.55 10.99,5.72C10.8,5.89 10.62,6.08 10.43,6.29C10.24,6.5 10.06,6.72 9.89,6.96C9.72,7.2 9.56,7.45 9.42,7.72C9.28,7.99 9.16,8.27 9.08,8.56C9,8.85 8.95,9.15 8.94,9.45C8.93,9.75 8.95,10.05 8.99,10.34C9.03,10.63 9.1,10.92 9.19,11.2C9.28,11.48 9.39,11.76 9.5,12.04C9.61,12.32 9.75,12.58 9.9,12.84C10.05,13.1 10.23,13.34 10.43,13.56C10.63,13.78 10.8,13.97 10.88,14.06C11.12,14.33 11.37,14.54 11.6,14.7C11.83,14.86 12.05,14.98 12.25,15.08C12.45,15.18 12.6,15.25 12.7,15.3C12.8,15.35 12.87,15.38 12.91,15.4C12.95,15.42 12.94,15.43 12.91,15.45C12.88,15.47 12.82,15.5 12.75,15.56C12.5,15.75 12.25,15.88 12,15.96C11.75,16.04 11.5,16.08 11.25,16.08C11,16.08 10.75,16.04 10.5,15.96C10.25,15.88 10,15.75 9.75,15.56C9.5,15.37 9.25,15.13 9,14.84C8.75,14.55 8.5,14.23 8.25,13.88C8,13.53 7.75,13.18 7.53,12.81C7.31,12.44 7.12,12.08 6.95,11.7C6.78,11.32 6.65,10.95 6.56,10.59C6.47,10.23 6.42,9.88 6.42,9.53C6.42,9.18 6.47,8.83 6.56,8.47C6.65,8.11 6.78,7.74 6.95,7.36C7.12,6.98 7.31,6.62 7.53,6.25C7.75,5.88 8,5.53 8.25,5.18C8.5,4.83 8.75,4.52 9,4.22C9.25,3.92 9.5,3.64 9.75,3.38C10,3.12 10.25,2.88 10.5,2.66C10.75,2.44 11,2.25 11.25,2.08C11.5,1.91 11.75,1.78 12,1.68C12.25,1.58 12.5,1.5 12.75,1.46C13,1.42 13.25,1.41 13.5,1.44C13.75,1.47 14,1.54 14.25,1.66C14.5,1.78 14.75,1.94 15,2.13C15.25,2.32 15.5,2.56 15.75,2.84C16,3.12 16.25,3.43 16.5,3.78C16.75,4.13 17,4.48 17.18,4.86C17.36,5.24 17.51,5.61 17.62,5.99C17.73,6.37 17.8,6.75 17.8,7.14C17.8,7.53 17.73,7.91 17.62,8.29C17.51,8.67 17.36,9.04 17.18,9.41C17,9.78 16.75,10.13 16.5,10.46C16.25,10.79 16,11.11 15.75,11.41C15.5,11.71 15.25,12 15,12.26C14.75,12.52 14.5,12.75 14.25,12.96C14,13.17 13.75,13.35 13.5,13.49C13.25,13.63 13,13.75 12.75,13.84C12.5,13.93 12.25,14 12,14C11.75,14 11.5,13.96 11.25,13.88C11,13.8 10.75,13.7 10.5,13.56C10.25,13.42 10,13.25 9.75,13.04C9.5,12.83 9.25,12.59 9,12.31C8.75,12.03 8.5,11.72 8.25,11.38C8,11.04 7.75,10.69 7.53,10.33C7.31,9.97 7.12,9.61 6.95,9.25C6.78,8.89 6.65,8.54 6.56,8.19C6.47,7.84 6.42,7.5 6.42,7.15C6.42,6.8 6.47,6.46 6.56,6.11C6.65,5.76 6.78,5.4 6.95,5.04C7.12,4.68 7.31,4.32 7.53,3.96C7.75,3.6 8,3.25 8.25,2.92C8.5,2.59 8.75,2.28 9,2C9.25,1.72 9.5,1.47 9.75,1.25C10,1.03 10.25,0.83 10.5,0.66C10.75,0.49 11,0.35 11.25,0.25C11.5,0.15 11.75,0.08 12,0.04C12.25,0 12.5,0 12.75,0.04C13,0.08 13.25,0.15 13.5,0.25C13.75,0.35 14,0.49 14.25,0.66C14.5,0.83 14.75,1.03 15,1.25C15.25,1.47 15.5,1.72 15.75,2C16,2.28 16.25,2.59 16.5,2.92C16.75,3.25 17,3.6 17.18,3.96C17.36,4.32 17.51,4.68 17.62,5.04C17.73,5.4 17.8,5.76 17.8,6.11C17.8,6.46 17.73,6.81 17.62,7.15C17.51,7.49 17.36,7.84 17.18,8.19C17,8.54 16.75,8.89 16.5,9.22C16.25,9.55 16,9.86 15.75,10.15C15.5,10.44 15.25,10.71 15,10.96C14.75,11.21 14.5,11.44 14.25,11.64C14,11.84 13.75,12.02 13.5,12.18C13.25,12.34 13,12.47 12.75,12.58C12.5,12.69 12.25,12.75 12,12.75C11.75,12.75 11.5,12.69 11.25,12.58C11,12.47 10.75,12.34 10.5,12.18C10.25,12.02 10,11.84 9.75,11.64C9.5,11.44 9.25,11.21 9,10.96C8.75,10.71 8.5,10.44 8.25,10.15C8,9.86 7.75,9.55 7.53,9.22C7.31,8.89 7.12,8.54 6.95,8.19C6.78,7.84 6.65,7.49 6.56,7.15C6.47,6.8 6.42,6.46 6.42,6.11C12,6.11 12.12,10.84 12.12,10.84C12.12,10.84 16.75,13.96 16.75,13.96Z" />
    </svg>
);
export const TelegramIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg fill="currentColor" viewBox="0 0 24 24" {...props}>
        <path d="M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M9.5,16.5L8,11.5L14.5,8.5L11,15L9.5,16.5M10.5,11.5L12,13L14,10.5L10.5,11.5Z" />
    </svg>
);
export const XIconSocial: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg fill="currentColor" viewBox="0 0 24 24" {...props}>
        <path d="M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 7.184L18.901 1.153zm-1.8 20.35h2.94L7.025 2.373H3.949l13.152 19.13z"/>
    </svg>
);
export const FacebookIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg fill="currentColor" viewBox="0 0 24 24" {...props}>
        <path d="M12 2.04C6.5 2.04 2 6.53 2 12.06c0 5.52 4.5 10.02 10 10.02c5.52 0 10-4.5 10-10.02C22 6.53 17.52 2.04 12 2.04zM16.5 12.06h-2.25v6.98h-2.5v-6.98H9.75V9.81h2V8.31c0-1.7 1.1-2.75 2.91-2.75c.52 0 1.05.04 1.59.08v2.24h-1.32c-.84 0-1 .4-1 .98v1.18h2.34l-.3 2.25z"/>
    </svg>
);
export const LinkedInIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg fill="currentColor" viewBox="0 0 24 24" {...props}>
        <path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-11 5v10H5V8h3m-1.5-2.25A1.75 1.75 0 0 0 4.75 7.5a1.75 1.75 0 0 0 3.5 0A1.75 1.75 0 0 0 6.5 5.75M18 18h-3v-4.75c0-1.4-1.12-2.5-2.5-2.5S10 11.85 10 13.25V18h-3V8h3v1.31C10.9 8.5 11.83 8 13.5 8c2.48 0 4.5 2.02 4.5 4.5V18z"/>
    </svg>
);
export const InstagramIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg fill="currentColor" viewBox="0 0 24 24" {...props}>
        <path d="M7.8,2H16.2C19.4,2 22,4.6 22,7.8V16.2A5.8,5.8 0 0,1 16.2,22H7.8C4.6,22 2,19.4 2,16.2V7.8A5.8,5.8 0 0,1 7.8,2M7.6,4A3.6,3.6 0 0,0 4,7.6V16.4C4,18.39 5.61,20 7.6,20H16.4A3.6,3.6 0 0,0 20,16.4V7.6C20,5.61 18.39,4 16.4,4H7.6M17.25,5.5A1.25,1.25 0 0,1 18.5,6.75A1.25,1.25 0 0,1 17.25,8A1.25,1.25 0 0,1 16,6.75A1.25,1.25 0 0,1 17.25,5.5M12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9Z"/>
    </svg>
);
export const PinterestIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg fill="currentColor" viewBox="0 0 24 24" {...props}>
        <path d="M12 2C6.48 2 2 6.48 2 12c0 4.25 2.76 7.85 6.5 9.25-.05-.33-.1-1.2.03-1.7l1.7-7.2s-.42-.85-.42-2.1c0-1.98 1.15-3.45 2.6-3.45 1.22 0 1.8.92 1.8 2.03 0 1.23-.78 3.08-1.2 4.78-.34 1.42.72 2.58 2.15 2.58 2.55 0 4.5-2.7 4.5-6.62 0-3.48-2.5-5.95-6.15-5.95-4.18 0-6.8 3.15-6.8 6.2 0 1.25.48 2.6.98 3.38.12.2.14.42.1.63-.05.2-.18.75-.23.95-.08.3-.3.4-.6.25-1.93-1-3.1-3.88-3.1-6.2 0-5.22 3.8-9.75 10.4-9.75 5.48 0 9.85 3.9 9.85 9.32 0 5.45-3.42 9.78-8.2 9.78-1.62 0-3.15-.85-3.68-1.82l-1.05 4.1-.38 1.48c-.54 2.1-2.08 4.7-3.2 6.1Z"/>
    </svg>
);
export const YouTubeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg fill="currentColor" viewBox="0 0 24 24" {...props}>
        <path d="M10,15L15.19,12L10,9V15M21.56,7.17C21.69,7.64 21.78,8.27 21.84,9.07C21.91,9.87 21.94,10.56 21.94,11.16L22,12C22,14.19 21.84,15.8 21.56,16.83C21.31,17.73 20.73,18.31 19.83,18.56C19.36,18.69 18.73,18.78 17.93,18.84C17.13,18.91 16.44,18.94 15.84,18.94L15,19C12.81,19 11.2,18.84 10.17,18.56C9.27,18.31 8.69,17.73 8.44,16.83C8.31,16.36 8.22,15.73 8.16,14.93C8.09,14.13 8.06,13.44 8.06,12.84L8,12C8,9.81 8.16,8.2 8.44,7.17C8.69,6.27 9.27,5.69 10.17,5.44C10.64,5.31 11.27,5.22 12.07,5.16C12.87,5.09 13.56,5.06 14.16,5.06L15,5C17.19,5 18.8,5.16 19.83,5.44C20.73,5.69 21.31,6.27 21.56,7.17Z"/>
    </svg>
);
export const TikTokIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg fill="currentColor" viewBox="0 0 24 24" {...props}>
        <path d="M16.6 5.82s.51.5 0 0c-1.4 1.4-1.4 1.4-1.4 1.4v7.48c0 2.2-1.8 4-4 4s-4-1.8-4-4 1.8-4 4-4c.4 0 .8.07 1.15.2v-2.3C13.2 6.2 12.63 6 12 6c-3.3 0-6 2.7-6 6s2.7 6 6 6 6-2.7 6-6V9.82s0-1.4 0-1.4c1.4-1.4 1.4-1.4 1.4-1.4s-.5-.51 0 0z"/>
    </svg>
);
export const SnapchatIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg fill="currentColor" viewBox="0 0 24 24" {...props}>
        <path d="M9.4,5.15C9.8,5.15 10.15,5.5 10.15,5.9C10.15,6.3 9.8,6.65 9.4,6.65C9,6.65 8.65,6.3 8.65,5.9C8.65,5.5 9,5.15 9.4,5.15M14.6,5.15C15,5.15 15.35,5.5 15.35,5.9C15.35,6.3 15,6.65 14.6,6.65C14.2,6.65 13.85,6.3 13.85,5.9C13.85,5.5 14.2,5.15 14.6,5.15M11.25,10.35C10.5,10.35 10,10.65 10,11.15C10,11.5 10.1,12.05 10.3,12.6C10.35,12.75 10.4,12.9 10.45,13C10.5,13.1 10.5,13.15 10.5,13.2C10.55,13.25 10.55,13.25 10.55,13.3C10.55,13.3 10.55,13.3 10.55,13.3C10.6,13.4 10.6,13.4 10.6,13.45C10.6,13.45 10.6,13.45 10.6,13.45C10.65,13.55 10.7,13.6 10.7,13.65C10.75,13.7 10.75,13.7 10.75,13.7C10.8,13.8 10.85,13.85 10.9,13.9C10.9,13.9 10.95,13.95 10.95,13.95C11.1,14.15 11.2,14.25 11.25,14.3C11.3,14.25 11.4,14.15 11.55,13.95C11.55,13.95 11.6,13.9 11.6,13.9C11.65,13.85 11.7,13.8 11.75,13.7C11.75,13.7 11.75,13.7 11.8,13.65C11.8,13.6 11.85,13.55 11.9,13.45C11.9,13.45 11.9,13.45 11.9,13.45C11.9,13.4 11.95,13.4 11.95,13.3C11.95,13.3 11.95,13.3 11.95,13.3C12,13.25 12,13.25 12.05,13.2C12.05,13.15 12.05,13.1 12.05,13C12.1,12.9 12.15,12.75 12.2,12.6C12.4,12.05 12.5,11.5 12.5,11.15C12.5,10.65 12,10.35 11.25,10.35M12,2C6.5,2 2,6.5 2,12C2,15.25 3.75,18.05 6.2,19.75C6.35,19.9 6.5,20 6.65,20C6.9,20 7.15,19.9 7.3,19.7C7.65,19.4 7.7,18.9 7.4,18.55C7.2,18.25 7.05,17.9 6.95,17.5C7.55,17.9 8.25,18.25 9,18.45C9.55,18.6 10.1,18.75 10.7,18.85C10.7,18.85 10.7,18.85 10.7,18.85C10.85,18.9 11,18.9 11.1,18.9C11.2,18.9 11.25,18.9 11.35,18.85C11.35,18.85 11.35,18.85 11.35,18.85C11.95,18.75 12.45,18.6 13,18.45C13.75,18.25 14.45,17.9 15.05,17.5C14.95,17.9 14.8,18.25 14.6,18.55C14.3,18.9 14.35,19.4 14.7,19.7C14.85,19.9 15.1,20 15.35,20C15.5,20 15.65,19.9 15.8,19.75C18.25,18.05 20,15.25 20,12C20,6.5 16.5,2 12,2Z"/>
    </svg>
);
export const MicrophoneMutedIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 006-6v-1.5m-6 7.5a6 6 0 01-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 01-3-3V4.5a3 3 0 016 0v8.25a3 3 0 01-3 3z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 3l18 18" />
    </svg>
);
export const EndCallIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" {...props}>
      <path d="M12 2c-5.52 0-10 4.48-10 10s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm3.62 14.16c-.2.2-.46.31-.72.31-.24 0-.46-.09-.64-.26l-1.95-1.95c-.4-.4-.4-1.04 0-1.44l1.24-1.24c-1.35-.41-2.79-.99-4.1-1.72l-1.88 1.88c-.35.35-.82.55-1.31.55-.26 0-.52-.05-.77-.16-1.12-.48-1.83-1.61-1.7-2.82.13-1.23.9-2.28 2.05-2.66.4-.13.83-.06 1.22.15l2.42 1.3c.46.26.68.81.54 1.33-.06.23-.2.43-.38.57l-1.03.8c1.16.63 2.22 1.14 3.2 1.5l.8-1.03c.14-.18.34-.32.57-.38.52-.14 1.07.08 1.33.54l1.3 2.42c.38.71.19 1.62-.43 2.05z" />
    </svg>
);
export const QuestionMarkIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9.879 7.519c1.171-1.025 3.071-1.025 4.242 0 1.172 1.025 1.172 2.687 0 3.712-.203.179-.43.326-.67.442-.745.361-1.45.999-1.45 1.827v.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);
export const WaveformIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path d="M3 10V14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><animate attributeName="d" values="M3 10V14; M3 8V16; M3 10V14" dur="0.8s" repeatCount="indefinite" /></path>
      <path d="M8 8V16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><animate attributeName="d" values="M8 8V16; M8 12V12; M8 8V16" dur="0.8s" repeatCount="indefinite" /></path>
      <path d="M13 6V18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><animate attributeName="d" values="M13 6V18; M13 10V14; M13 6V18" dur="0.8s" repeatCount="indefinite" /></path>
      <path d="M18 9V15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><animate attributeName="d" values="M18 9V15; M18 6V18; M18 9V15" dur="0.8s" repeatCount="indefinite" /></path>
      <path d="M21 10V14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><animate attributeName="d" values="M21 10V14; M21 8V16; M21 10V14" dur="0.8s" repeatCount="indefinite" /></path>
    </svg>
);
export const BoltIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" />
    </svg>
);
export const CpuChipIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 7.5l-2.25-1.313M21 7.5v2.25m0-2.25l-2.25 1.313M3 7.5l2.25-1.313M3 7.5v2.25m0-2.25l2.25 1.313M3 16.5l2.25 1.313M3 16.5v-2.25m0 2.25l2.25-1.313m18-2.25v-2.25m0 2.25l-2.25-1.313m-13.5 0L3 16.5m13.5 0l2.25 1.313M18.75 16.5l-2.25-1.313m-13.5 0l-2.25-1.313M12 21v-2.25m0 2.25l-2.25-1.313M12 21l2.25-1.313M12 3v2.25m0-2.25l-2.25 1.313M12 3l2.25 1.313M9 12l-2.25 1.313M9 12l2.25 1.313M9 12v-2.25m2.25 4.5l-2.25 1.313m-2.25-4.5l2.25 1.313M15 12l2.25 1.313M15 12l-2.25 1.313M15 12v-2.25m-2.25 4.5l2.25 1.313M9.75 14.25l1.5-1.5m1.5 1.5l1.5-1.5M9.75 14.25v1.5m1.5-1.5v1.5m1.5-1.5v1.5m-3-6.75l1.5 1.5m1.5-1.5l1.5 1.5m-3-3v3m3-3v3m0-3h-3m3 0h3m-6 3h3m3 0h3" />
  </svg>
);
export const BeakerIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 3.104v5.625a2.25 2.25 0 01-2.25 2.25H4.5a2.25 2.25 0 01-2.25-2.25V3.104m6 1.425a2.25 2.25 0 01-2.25 2.25H4.5a2.25 2.25 0 01-2.25-2.25m11.25 0v5.625a2.25 2.25 0 01-2.25 2.25H9.75a2.25 2.25 0 01-2.25-2.25V4.529m11.25 0a2.25 2.25 0 01-2.25 2.25H9.75a2.25 2.25 0 01-2.25-2.25M15 21h-6a2.25 2.25 0 01-2.25-2.25V15h10.5v3.75A2.25 2.25 0 0115 21z" />
    </svg>
);
export const StopIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 7.5A2.25 2.25 0 017.5 5.25h9a2.25 2.25 0 012.25 2.25v9a2.25 2.25 0 01-2.25 2.25h-9a2.25 2.25 0 01-2.25-2.25v-9z" />
    </svg>
);
