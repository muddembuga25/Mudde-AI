import React, { useMemo, useState, useRef, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell } from 'recharts';
import type { Site, ApiKeys } from '../types';
import { ExclamationTriangleIcon, TrashIcon, WordPressIcon, ChevronDownIcon } from './Icons';

interface ApiSpendDashboardProps {
  sites: Site[];
  onResetAllSitesSpend: () => void;
}

// Fix: Add missing 'tenweb' property to match ApiKeys type
const providerDisplayNames: Record<keyof ApiKeys, string> = {
  google: 'Google',
  googleClientId: 'Google Client ID',
  openAI: 'OpenAI',
  openRouter: 'OpenRouter',
  anthropic: 'Anthropic',
  xai: 'X.AI Grok',
  replicate: 'Replicate',
  dataforseo: 'DataForSEO',
  freepik: 'Freepik',
  falai: 'Fal.ai',
  perplexity: 'Perplexity AI',
  mailgun: 'Mailgun',
  sendgrid: 'SendGrid',
  tenweb: '10Web',
};

const COLORS = ['#a855f7', '#82ca9d', '#ffc658', '#ff8042', '#00C49F', '#FFBB28', '#0088FE'];

export const ApiSpendDashboard: React.FC<ApiSpendDashboardProps> = ({ sites, onResetAllSitesSpend }) => {
    const [isResetModalOpen, setIsResetModalOpen] = useState(false);
    const [expandedSites, setExpandedSites] = useState<Record<string, boolean>>({});
    const chartContainerRef = useRef<HTMLDivElement>(null);
    const [chartSize, setChartSize] = useState({ width: 0, height: 300 });

    useEffect(() => {
        const element = chartContainerRef.current;
        if (!element) return;

        const resizeObserver = new ResizeObserver(entries => {
            if (entries[0]) {
                const { width, height } = entries[0].contentRect;
                setChartSize({ width, height });
            }
        });

        resizeObserver.observe(element);
        return () => resizeObserver.disconnect();
    }, []);

    const toggleSiteExpansion = (siteId: string) => {
        setExpandedSites(prev => ({ ...prev, [siteId]: !prev[siteId] }));
    };

    const { totalSpend, spendData, perSiteSpend } = useMemo(() => {
        // Per-site calculation with provider breakdown
        const siteSpends = sites.map(site => {
            const providerSpend: Partial<Record<keyof ApiKeys, number>> = {};
            let siteTotal = 0;
            if (site.apiUsage) {
                for (const key in site.apiUsage) {
                    const providerKey = key as keyof ApiKeys;
                    const spend = site.apiUsage[providerKey] || 0;
                    if (spend > 0) {
                        providerSpend[providerKey] = spend;
                    }
                    siteTotal += spend;
                }
            }
            return {
                id: site.id,
                name: site.name,
                totalSpend: siteTotal,
                providerSpend,
            };
        }).sort((a, b) => b.totalSpend - a.totalSpend);

        // Aggregated provider calculation (for the chart)
        const aggregatedUsage: Partial<Record<keyof ApiKeys, number>> = {};
        for (const site of sites) {
            if (site.apiUsage) {
                for (const key in site.apiUsage) {
                    const providerKey = key as keyof ApiKeys;
                    aggregatedUsage[providerKey] = (aggregatedUsage[providerKey] || 0) + (site.apiUsage[providerKey] || 0);
                }
            }
        }
        
        const providerData = (Object.keys(providerDisplayNames) as Array<keyof ApiKeys>)
            .map((key) => ({
                name: providerDisplayNames[key],
                spend: aggregatedUsage[key] || 0,
            }))
            .filter(item => item.spend > 0)
            .sort((a, b) => b.spend - a.spend);
        
        const overallTotal = siteSpends.reduce((sum, site) => sum + site.totalSpend, 0);

        return { totalSpend: overallTotal, spendData: providerData, perSiteSpend: siteSpends };
    }, [sites]);

    const handleResetAllSpend = () => {
        onResetAllSitesSpend();
        setIsResetModalOpen(false);
    };

    return (
        <div className="space-y-8 max-w-4xl mx-auto">
             <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-2xl font-bold text-white">API Spend Overview</h2>
                <p className="text-text-secondary mt-1">An estimate of your API costs. Prices are based on public data and may not be exact.</p>
            </div>

            <div className="bg-gradient-to-br from-purple-600/20 to-blue-600/20 p-8 rounded-2xl border border-border flex flex-col items-center justify-center">
                <p className="text-text-secondary text-sm font-medium uppercase tracking-wider">Total Estimated Spend (All Workflows)</p>
                <p className="text-5xl font-extrabold text-white mt-2 animate-count-up">${totalSpend.toFixed(5)}</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                    <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-3">
                        <WordPressIcon className="h-5 w-5 text-purple-400" />
                        Spend by Workflow
                    </h3>
                    <div className="space-y-2 max-h-96 overflow-y-auto -mr-2 pr-2">
                        {perSiteSpend.length > 0 ? perSiteSpend.map((site) => {
                            const isExpanded = !!expandedSites[site.id];
                            const providerSpends = Object.entries(site.providerSpend);

                            return (
                                <div key={site.id} className="bg-panel rounded-lg border border-border-subtle overflow-hidden">
                                    <button
                                        className="flex justify-between items-center w-full p-4 text-left disabled:cursor-default"
                                        onClick={() => providerSpends.length > 0 && toggleSiteExpansion(site.id)}
                                        disabled={providerSpends.length === 0}
                                        aria-expanded={isExpanded}
                                    >
                                        <span className="font-medium text-text-primary">{site.name}</span>
                                        <div className="flex items-center gap-4">
                                            <span className="font-semibold text-white">${site.totalSpend.toFixed(5)}</span>
                                            {providerSpends.length > 0 && (
                                                <ChevronDownIcon className={`h-5 w-5 text-text-secondary transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} />
                                            )}
                                        </div>
                                    </button>
                                    {isExpanded && providerSpends.length > 0 && (
                                        <div className="border-t border-border-subtle mx-4 mb-4 pt-3 animate-fade-in">
                                            <ul className="space-y-2">
                                                {providerSpends.map(([provider, spend]) => (
                                                    <li key={provider} className="flex justify-between items-center text-sm">
                                                        <span className="text-text-secondary">{providerDisplayNames[provider as keyof ApiKeys]}</span>
                                                        <span className="font-mono text-text-primary">${(spend as number).toFixed(5)}</span>
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    )}
                                </div>
                            );
                        }) : (
                            <p className="text-center text-text-secondary py-4">No spend data recorded.</p>
                        )}
                    </div>
                </div>

                <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                    <h3 className="text-xl font-bold text-white mb-6">Spend by Provider</h3>
                    {spendData.length > 0 ? (
                        <div ref={chartContainerRef} style={{ width: '100%', height: 300 }}>
                            {chartSize.width > 0 && (
                                <BarChart width={chartSize.width} height={chartSize.height} data={spendData} margin={{ top: 5, right: 5, left: -15, bottom: 5 }} layout="vertical">
                                    <CartesianGrid strokeDasharray="2 2" stroke="var(--color-border-subtle)" />
                                    <XAxis type="number" stroke="var(--color-text-secondary)" tick={{ fill: 'var(--color-text-secondary)', fontSize: 12 }} tickFormatter={(value) => `$${Number(value).toFixed(4)}`} />
                                    <YAxis type="category" dataKey="name" stroke="var(--color-text-secondary)" width={80} tick={{ fill: 'var(--color-text-secondary)', fontSize: 12 }} />
                                    <Tooltip
                                        cursor={{ fill: 'rgba(168, 85, 247, 0.1)'}}
                                        contentStyle={{ backgroundColor: 'var(--color-panel-light)', border: '1px solid var(--color-border)', color: 'var(--color-text-primary)', borderRadius: '0.5rem' }}
                                        formatter={(value: number) => [`$${value.toFixed(5)}`, 'Spend']}
                                    />
                                    <Bar dataKey="spend" name="Spend (USD)" barSize={20}>
                                        {spendData.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                        ))}
                                    </Bar>
                                </BarChart>
                            )}
                        </div>
                    ) : (
                        <p className="text-center text-text-secondary py-8">No API usage has been recorded yet.</p>
                    )}
                </div>
            </div>

            <div className="mt-8 pt-8 border-t border-red-500/30">
                <h2 className="text-xl font-bold text-red-400">Danger Zone</h2>
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mt-4 gap-4">
                    <div className="flex-grow">
                        <p className="text-sm text-text-secondary"> Reset all spend counters for all of your workflows to zero. This action cannot be undone.</p>
                    </div>
                    <button onClick={() => setIsResetModalOpen(true)} className="w-full sm:w-auto flex-shrink-0 btn bg-red-600 hover:bg-red-700 text-white font-bold text-sm">
                        <TrashIcon className="h-4 w-4 mr-2" />
                        Reset All Spend Data
                    </button>
                </div>
            </div>
          
            {isResetModalOpen && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
                    <div className="bg-panel rounded-lg shadow-2xl w-full max-w-md p-6 border border-red-500/50 animate-modal-pop">
                        <div className="flex items-start gap-4">
                            <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-900/50 sm:mx-0 sm:h-10 sm:w-10"> <ExclamationTriangleIcon className="h-6 w-6 text-red-400" /> </div>
                            <div className="mt-0 text-left flex-1">
                                <h3 className="text-lg leading-6 font-bold text-white">Reset All Spend Data?</h3>
                                <div className="mt-2"> <p className="text-sm text-text-secondary"> Are you sure you want to reset all API spend counters? This action cannot be undone. </p> </div>
                            </div>
                        </div>
                        <div className="mt-5 sm:mt-4 sm:flex sm:flex-row-reverse gap-3">
                            <button type="button" className="w-full btn bg-red-600 hover:bg-red-700 text-white sm:w-auto" onClick={handleResetAllSpend}> Reset Data </button>
                            <button type="button" className="mt-3 w-full btn btn-secondary sm:mt-0 sm:w-auto" onClick={() => setIsResetModalOpen(false)}> Cancel </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};