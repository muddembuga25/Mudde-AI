import React, { useState, useCallback } from 'react';
import type { Site, ApiKeys } from '../types';
import { AiProvider } from '../types';
import * as mcpApiService from '../services/mcpApiService';
import { ApiSpendDashboard } from './ApiSpendDashboard';
import { ArrowPathIcon, CheckCircleIcon, ExclamationTriangleIcon } from './Icons';
import { providerDisplayNames as baseProviderDisplayNames } from '../constants';
import { useAuth } from '../hooks/useAuth';

// --- APIKeysPanel moved here ---
interface APIKeysPanelProps {
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    setError: (error: string | null) => void;
}

const providerDisplayNames: Record<AiProvider, string> = baseProviderDisplayNames;

const ApiKeysPanel: React.FC<APIKeysPanelProps> = ({ site, onSiteUpdate, setError }) => {
    const { currentUser } = useAuth();
    const [verificationStatus, setVerificationStatus] = useState<Record<string, 'idle' | 'verifying' | 'success' | 'error'>>({});

    const handleApiKeyUpdate = (provider: keyof ApiKeys, value: string) => {
        onSiteUpdate('apiKeys', { ...site.apiKeys, [provider]: value });
    };

    const handleResetApiUsage = (provider: keyof ApiKeys) => {
        onSiteUpdate('apiUsage', { ...(site.apiUsage || {}), [provider]: 0 });
    };
    
    const handleVerifyKey = useCallback(async (provider: keyof ApiKeys) => {
        if (!site.apiKeys[provider]) return;

        setVerificationStatus(prev => ({ ...prev, [provider]: 'verifying' }));
        setError(null);
        try {
            const result = await mcpApiService.verifyApiKey(site.id, provider, site.apiKeys[provider]!);
            
            if (result.success) {
                setVerificationStatus(prev => ({ ...prev, [provider]: 'success' }));
                setTimeout(() => setVerificationStatus(prev => ({ ...prev, [provider]: 'idle' })), 2500);
                
                const providerToEnumMap: Record<string, AiProvider | undefined> = {
                    google: AiProvider.GOOGLE,
                    openAI: AiProvider.OPENAI,
                    openRouter: AiProvider.OPENROUTER,
                    anthropic: AiProvider.ANTHROPIC,
                    xai: AiProvider.XAI,
                    perplexity: AiProvider.PERPLEXITY,
                    replicate: AiProvider.REPLICATE,
                    freepik: AiProvider.FREEPIK,
                    falai: AiProvider.FALAI
                };
                const providerEnum = providerToEnumMap[provider];

                if (providerEnum) {
                     const { updatedSite } = await mcpApiService.fetchAvailableModels(site.id, providerEnum, site.apiKeys[provider]!);
                     onSiteUpdate('fetchedModels', updatedSite.fetchedModels);
                }
            } else {
                throw new Error(result.message);
            }
        } catch (error: any) {
            setError(`Verification failed for ${providerDisplayNames[provider as AiProvider] || provider}: ${error.message}`);
            setVerificationStatus(prev => ({ ...prev, [provider]: 'error' }));
            setTimeout(() => setVerificationStatus(prev => ({ ...prev, [provider]: 'idle' })), 4000);
        }
    }, [site.id, site.apiKeys, onSiteUpdate, setError]);
    
    const apiKeyGroups: Record<string, Array<keyof ApiKeys>> = {
        'Core AI Providers': ['google', 'openAI', 'openRouter', 'anthropic', 'xai', 'perplexity'],
        'Specialized AI Providers': ['replicate', 'freepik', 'falai'],
        'SEO & Data Providers': ['dataforseo'],
        'Email & Integration Providers': ['mailgun', 'sendgrid', 'tenweb'],
        'Google Services (OAuth)': ['googleClientId'],
    };

    const generationProviders: Partial<Record<keyof ApiKeys, AiProvider>> = {
        google: AiProvider.GOOGLE,
        openAI: AiProvider.OPENAI,
        openRouter: AiProvider.OPENROUTER,
        anthropic: AiProvider.ANTHROPIC,
        xai: AiProvider.XAI,
        perplexity: AiProvider.PERPLEXITY,
        replicate: AiProvider.REPLICATE,
        freepik: AiProvider.FREEPIK,
        falai: AiProvider.FALAI,
    };
    
    return (
        <div className="bg-panel/50 p-6 rounded-2xl border border-border">
            <h2 className="text-xl font-bold text-white">API Keys</h2>
            <p className="text-sm text-text-secondary mt-1">Enter your API keys to enable content generation. If no Google key is provided, a default development key will be used.</p>
            <div className="mt-6 space-y-8">
                {Object.entries(apiKeyGroups).map(([groupName, keysInGroup]) => (
                    <div key={groupName}>
                        <h3 className="text-lg font-semibold text-purple-300 mb-4 border-b border-border-subtle pb-2">{groupName}</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-6">
                            {keysInGroup.map(key => {
                                const nameMap: Record<keyof ApiKeys, string> = { google: 'Google', googleClientId: 'Google Client ID', openAI: 'OpenAI', anthropic: 'Anthropic', openRouter: 'OpenRouter', xai: 'X.AI (Grok)', perplexity: 'Perplexity AI', replicate: 'Replicate', dataforseo: 'DataForSEO', freepik: 'Freepik', falai: 'Fal.ai', mailgun: 'Mailgun', sendgrid: 'SendGrid', tenweb: '10Web' };
                                const placeholderMap: Record<keyof ApiKeys, string> = { google: 'Enter your Google API Key (Optional)', googleClientId: 'Enter your Google OAuth Client ID', openAI: 'sk-...', anthropic: 'sk-ant-...', openRouter: 'sk-or-...', xai: 'Enter your X.AI API Key', perplexity: 'pplx-...', replicate: 'r8_...', dataforseo: 'login:password or token', freepik: 'Enter your Freepik API Key', falai: 'Enter your Fal.ai Key ID:Key Secret', mailgun: 'key-...', sendgrid: 'SG....', tenweb: 'Enter your 10Web API Key' };
                                const providerKey = key as keyof ApiKeys;
                                const providerEnum = generationProviders[providerKey];
                                const currentStatus = verificationStatus[providerKey] || 'idle';
                                
                                return (
                                    <div key={providerKey}>
                                        <div className="flex items-center justify-between gap-2 mb-2">
                                            <label htmlFor={`${providerKey}-key`} className="block text-sm font-medium text-text-primary">{nameMap[providerKey]}</label>
                                            { providerKey !== 'googleClientId' && (
                                            <div className="flex items-center gap-2 text-xs text-text-secondary">
                                                Est. Spend: ${site.apiUsage?.[providerKey]?.toFixed(5) || '0.00000'}
                                                <button onClick={() => handleResetApiUsage(providerKey)} title="Reset spend counter" className="text-gray-500 hover:text-white transition-colors">
                                                    <ArrowPathIcon className="h-4 w-4" />
                                                </button>
                                            </div>
                                            )}
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <input id={`${providerKey}-key`} type="password" value={site.apiKeys[providerKey] || ''} onChange={e => handleApiKeyUpdate(providerKey, e.target.value)} placeholder={placeholderMap[providerKey]} className="input-base px-4 py-2 flex-grow" />
                                            {providerEnum && (
                                            <button onClick={() => handleVerifyKey(providerKey)} disabled={!site.apiKeys[providerKey] || currentStatus === 'verifying'} className="btn btn-secondary p-2 flex-shrink-0 disabled:opacity-50 disabled:cursor-not-allowed" title="Verify Key">
                                                {currentStatus === 'verifying' && <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>}
                                                {currentStatus === 'success' && <CheckCircleIcon className="h-5 w-5 text-green-400" />}
                                                {currentStatus === 'error' && <ExclamationTriangleIcon className="h-5 w-5 text-red-400" />}
                                                {currentStatus === 'idle' && <ArrowPathIcon className="h-5 w-5" />}
                                            </button>
                                            )}
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

// --- Main component for the new tab ---
interface APIKeysTabProps {
    sites: Site[];
    selectedSite: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    onResetAllSitesSpend: () => void;
    setError: (error: string | null) => void;
}

export const APIKeysTab: React.FC<APIKeysTabProps> = ({ sites, selectedSite, onSiteUpdate, onResetAllSitesSpend, setError }) => {
    return (
        <div className="space-y-8">
            <ApiKeysPanel site={selectedSite} onSiteUpdate={onSiteUpdate} setError={setError} />
            <ApiSpendDashboard sites={sites} onResetAllSitesSpend={onResetAllSitesSpend} />
        </div>
    );
};
