import React, { createContext, useContext, useState, PropsWithChildren, useCallback } from 'react';

interface GodModeContextType {
  isGodModeActive: boolean;
  toggleGodMode: () => void;
}

const GodModeContext = createContext<GodModeContextType | null>(null);

export const GodModeProvider = ({ children }: PropsWithChildren) => {
  const [isGodModeActive, setIsGodModeActive] = useState(false);

  const toggleGodMode = useCallback(() => {
    setIsGodModeActive(prev => !prev);
  }, []);

  const value = { isGodModeActive, toggleGodMode };

  return (
    <GodModeContext.Provider value={value}>
      {children}
    </GodModeContext.Provider>
  );
};

export const useGodMode = () => {
  const context = useContext(GodModeContext);
  if (!context) {
    throw new Error('useGodMode must be used within a GodModeProvider');
  }
  return context;
};