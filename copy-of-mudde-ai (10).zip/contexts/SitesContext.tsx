
import React, { createContext, useContext, useState, useEffect, useCallback, useRef, PropsWithChildren } from 'react';
import type { Site, ApiKeys, SocialMediaSettings, ModelConfig, User, GeminiModelConfig } from '../types';
import { AiProvider } from '../types';
import { AVAILABLE_MODELS, PLAN_LIMITS } from '../constants';
import * as mcpApiService from '../services/mcpApiService';
import { useAuth } from './AuthContext';

const defaultApiKeys: ApiKeys = { google: '', googleClientId: '', openAI: '', anthropic: '', openRouter: '', xai: '', replicate: '', dataforseo: '', freepik: '', falai: '', perplexity: '', mailgun: '', sendgrid: '', tenweb: '' };
const defaultModelConfig: ModelConfig = {
  textProvider: AiProvider.GOOGLE, textModel: AVAILABLE_MODELS[AiProvider.GOOGLE].text[0],
  imageProvider: AiProvider.GOOGLE, imageModel: AVAILABLE_MODELS[AiProvider.GOOGLE].image[0],
  videoProvider: AiProvider.GOOGLE, videoModel: AVAILABLE_MODELS[AiProvider.GOOGLE].video?.[0] || '',
  geminiConfig: { temperature: 0.7, topK: 40, topP: 0.95 },
};
const defaultSocialSettings: SocialMediaSettings = { twitter: [], facebook: [], linkedin: [], instagram: [], pinterest: [], whatsapp: [], youtube: [], tiktok: [], telegram: [], snapchat: [] };
const defaultApiUsage: Partial<Record<keyof ApiKeys, number>> = { google: 0, openAI: 0, anthropic: 0, openRouter: 0, xai: 0, replicate: 0, dataforseo: 0, freepik: 0, falai: 0, perplexity: 0, mailgun: 0, sendgrid: 0, tenweb: 0 };

interface SitesContextType {
    sites: Site[];
    setSites: React.Dispatch<React.SetStateAction<Site[]>>;
    selectedSite: Site | undefined;
    selectedSiteId: string | null;
    setSelectedSiteId: (id: string | null) => void;
    isSaved: boolean;
    isSaving: boolean;
    isLoading: boolean;
    handleSiteUpdate: (field: keyof Site, value: any) => void;
    handleMultipleSiteUpdates: (updates: Partial<Site>) => void;
    handleAddNewSite: () => void;
    handleDeleteSite: (siteIdToDelete: string) => void;
    handleResetAllSitesSpend: () => void;
}

const SitesContext = createContext<SitesContextType | null>(null);

export const SitesProvider = ({ children }: PropsWithChildren) => {
    const { currentUser } = useAuth();
    const [sites, setSites] = useState<Site[]>([]);
    const [selectedSiteId, setSelectedSiteId] = useState<string | null>(null);
    const [isSaved, setIsSaved] = useState<boolean>(true);
    const [isSaving, setIsSaving] = useState<boolean>(false);
    const [isLoading, setIsLoading] = useState(true);
    const debounceTimeoutRef = useRef<number | null>(null);
    const isInitialLoad = useRef(true);

    useEffect(() => {
        if (!currentUser) {
            setSites([]);
            setSelectedSiteId(null);
            setIsLoading(false);
            isInitialLoad.current = true;
            return;
        }

        const loadSites = async () => {
            setIsLoading(true);
            try {
                const finalSites = await mcpApiService.getSitesForUser(currentUser.username);
                setSites(finalSites);
        
                if (finalSites.length > 0) {
                    const lastSelectedId = localStorage.getItem(`ai-seo-blog-writer-last-selected-${currentUser.username}`);
                    const lastSiteExists = finalSites.some(s => s.id === lastSelectedId);
                    if (lastSelectedId && lastSiteExists) {
                        setSelectedSiteId(lastSelectedId);
                    } else {
                        setSelectedSiteId(finalSites[0].id);
                    }
                } else {
                    setSelectedSiteId(null);
                }
            } catch (error: any) { 
                console.warn("Could not load sites from MCP service:", error);
                setSites([]);
                setSelectedSiteId(null);
            } finally {
                setIsLoading(false);
                setTimeout(() => { isInitialLoad.current = false; }, 500);
            }
        };
        loadSites();
    }, [currentUser]);

    // Debounced automatic saving
    useEffect(() => {
        if (isLoading || isInitialLoad.current) return;
        
        if (debounceTimeoutRef.current) clearTimeout(debounceTimeoutRef.current);

        setIsSaving(true);
        setIsSaved(false);

        debounceTimeoutRef.current = window.setTimeout(async () => {
            if (currentUser) {
                try {
                    await mcpApiService.updateSitesForUser(currentUser.username, sites);
                    setIsSaved(true);
                } catch (e) {
                    console.error("Failed to save sites to server:", e);
                    setIsSaved(false);
                } finally {
                    setIsSaving(false);
                }
            }
        }, 1000);

        return () => { if (debounceTimeoutRef.current) clearTimeout(debounceTimeoutRef.current); };
    }, [sites, currentUser, isLoading]);

    useEffect(() => {
        if (selectedSiteId && currentUser) {
            localStorage.setItem(`ai-seo-blog-writer-last-selected-${currentUser.username}`, selectedSiteId);
        }
    }, [selectedSiteId, currentUser]);
    
    const handleSiteUpdate = useCallback((field: keyof Site, value: any) => {
        if (!selectedSiteId) return;
        setSites(prevSites =>
            prevSites.map(site =>
                site.id === selectedSiteId ? { ...site, [field]: value } : site
            )
        );
    }, [selectedSiteId]);
    
    const handleMultipleSiteUpdates = useCallback((updates: Partial<Site>) => {
        if (!selectedSiteId) return;
        setSites(prevSites =>
            prevSites.map(site =>
                site.id === selectedSiteId ? { ...site, ...updates } : site
            )
        );
    }, [selectedSiteId]);

    const handleAddNewSite = useCallback(() => {
        if (!currentUser) return;

        const planLimits = PLAN_LIMITS[currentUser.subscription.plan];
        if (sites.length >= planLimits.sites) {
            alert(`You have reached your workflow limit of ${planLimits.sites} for the ${currentUser.subscription.plan} plan. Please upgrade to add more workflows.`);
            return;
        }

        const workflowNumbers = sites
            .map(site => {
                const match = site.name.match(/^Workflow (\d+)$/);
                return match ? parseInt(match[1], 10) : 0;
            })
            .filter(num => num > 0);
        
        const nextNumber = workflowNumbers.length > 0 ? Math.max(...workflowNumbers) + 1 : 1;

        const newSite: Site = {
            id: crypto.randomUUID(), name: `Workflow ${nextNumber}`, wordpressUrl: '', wordpressUsername: '', applicationPassword: '',
            brandGuideline: '', brandLogo: '', brandColors: [], brandFonts: [], promoLink1: '', promoLink2: '', nicheTargeting: '',
            keywordList: '', videoSources: [], references: [], characterLibrary: [], authorName: '', authorId: undefined,
            availableAuthors: [], availableCategories: [], history: [], isAutomationEnabled: true, automationTrigger: 'interval',
            automationIntervalHours: 24, recurringSchedules: [], isAutoPublishEnabled: false, drafts: [],
            isDraftNotificationEnabled: false, draftNotificationMethods: [], draftNotificationEmail: '',
            masterAutomationSource: 'keyword', intervalGenerationSource: 'keyword', scheduleGenerationSource: 'keyword',
            rssFeedUrl: '', processedRssGuids: [], googleSheetUrl: '', googleSheetProcessedRows: [],
            isLocalSeoEnabled: false, localSeoBusinessName: '', localSeoServiceArea: '', localSeoPhoneNumber: '',
            socialMediaSettings: { ...defaultSocialSettings }, seoDataProvider: 'google_search', modelConfig: defaultModelConfig,
            apiKeys: { ...defaultApiKeys }, apiUsage: { ...defaultApiUsage }, fetchedModels: {},
            dataforseoSeedKeywords: '', dataforseoTargetLocation: 'us', dataforseoTargetLanguage: 'en',
            dataforseoKeywordDifficultyMin: 0, dataforseoKeywordDifficultyMax: 30, dataforseoSearchVolumeMin: 500,
            dataforseoSearchVolumeMax: 10000, isSocialGraphicAutomationEnabled: true, socialGraphicAutomationTrigger: 'interval',
            socialGraphicAutomationIntervalHours: 48, socialGraphicRecurringSchedules: [], socialGraphicGenerationSource: 'keyword',
            isSocialVideoAutomationEnabled: true, socialVideoAutomationTrigger: 'interval', socialVideoAutomationIntervalHours: 72,
            socialVideoRecurringSchedules: [], socialVideoGenerationSource: 'keyword', googleDrive: { isConnected: false, userEmail: '' },
            googleAnalytics: { isConnected: false, userEmail: '' }, isBacklinksAutomationEnabled: false, backlinksCompetitors: '',
            backlinksOwnDomain: '', backlinksEmailProvider: 'mailgun', backlinksFromName: '', backlinksFromEmail: '',
            backlinksEmailSubject: 'Regarding your article', backlinksEmailBody: 'Hi,\n\nI was just reading your article and really enjoyed it.\n\n[Personalization]\n\nI thought your readers might also find this resource useful. Let me know if you\'d be interested in taking a look.\n\nThanks,\n[Your Name]',
            backlinksHistory: [], backlinksIntervalHours: 168, commentingProspects: [], isSocialCommentingEnabled: false,
            socialCommentingKeywords: 'AI in marketing\n#SEOtips\ndigital strategy', socialCommentingGuideline: 'Write a positive and insightful comment. Ask a question to encourage a reply. Do not include links or self-promotion.',
            socialCommentingProspects: [], monitoredBacklinks: [], isBacklinkMonitoringEnabled: false, isEmailFollowUpEnabled: true,
            isSocialFollowUpEnabled: true, emailMarketingSettings: { fromName: '', fromEmail: '', targetList: '' },
            emailMarketingModelConfig: defaultModelConfig, isEmailMarketingAutomationEnabled: false, emailMarketingAutomationTrigger: 'interval',
            emailMarketingAutomationIntervalHours: 168, emailMarketingRecurringSchedules: [], isDigestAutomationEnabled: false,
            digestRecurringSchedules: [], processedDigestGuids: [], digestAutomationModelConfig: defaultModelConfig,
            mailchimp: { isConnected: false, apiKey: '', serverPrefix: '', status: 'disconnected' }, automationLock: null,
        };
        
        setSites(prev => [...prev, newSite]);
        setSelectedSiteId(newSite.id);
    }, [currentUser, sites]);

    const handleDeleteSite = useCallback((siteIdToDelete: string) => {
        const sitesAfterDeletion = sites.filter(s => s.id !== siteIdToDelete);
        setSites(sitesAfterDeletion);
        
        if (selectedSiteId === siteIdToDelete) {
            setSelectedSiteId(sitesAfterDeletion.length > 0 ? sitesAfterDeletion[0].id : null);
        }
    }, [sites, selectedSiteId]);

    const handleResetAllSitesSpend = useCallback(() => {
        setSites(prevSites => 
            prevSites.map(site => {
                const resetUsage: Partial<Record<keyof ApiKeys, number>> = {};
                for (const key in site.apiKeys) {
                    resetUsage[key as keyof ApiKeys] = 0;
                }
                return { ...site, apiUsage: resetUsage };
            })
        );
    }, []);

    const selectedSite = sites.find(s => s.id === selectedSiteId);

    const value: SitesContextType = {
        sites,
        setSites,
        selectedSite,
        selectedSiteId,
        setSelectedSiteId,
        isSaved,
        isSaving,
        isLoading,
        handleSiteUpdate,
        handleMultipleSiteUpdates,
        handleAddNewSite,
        handleDeleteSite,
        handleResetAllSitesSpend,
    };

    return <SitesContext.Provider value={value}>{children}</SitesContext.Provider>;
};

export const useSitesContext = () => {
    const context = useContext(SitesContext);
    if (!context) {
        throw new Error('useSitesContext must be used within a SitesProvider');
    }
    return context;
};