import { AppStatus, AiProvider, SubscriptionPlan, UserSubscription } from '../types';
import type { StoredUser, User, Site, ApiKeys, RssItem, Draft, PostHistoryItem, SocialMediaPost, EmailMarketingCampaign, BacklinksHistoryItem, MonitoredBacklink, CommentingProspect, SocialCommentingProspect, StrategicBrief, PostPerformanceData, AnalyticsInsight, SocialMediaAccount, WhatsAppAccount, TelegramAccount, MailchimpAccount, SeoChecklist, BlogPost, SocialMediaSettings, WebsitePlan, ModelConfig, ReferenceItem } from '../types';
import * as aiServiceInternal from './aiServiceInternal';
import { aiProviderToApiKey } from './aiServiceInternal';
import * as wordpressService from './wordpressService';
import * as socialMediaService from './socialMediaService';
import * as googleApiService from './googleApiService';
import * as oauthService from './oauthService';
import * as dataforseoService from './dataforseoService';
import { sendDraftNotification } from './notificationService';
import { fetchAndParseRssFeed } from './rssService';
import { fetchGoogleSheetData } from './googleSheetsService';
import type { GoogleSheetRow } from './googleSheetsService';
import type { SocialPlatform } from './oauthService';
import { calculateSeoScore } from './seoService';
import { AVAILABLE_MODELS } from '../constants';


const FAKE_LATENCY = 400; // ms

// --- Mock Database (localStorage) - Internal to this service ---
const getUsersDB = (): StoredUser[] => JSON.parse(localStorage.getItem('mcp-users') || '[]');
const setUsersDB = (users: StoredUser[]) => localStorage.setItem('mcp-users', JSON.stringify(users));
const getSitesDB = (): Site[] => JSON.parse(localStorage.getItem('mcp-sites') || '[]');
const setSitesDB = (sites: Site[]) => localStorage.setItem('mcp-sites', JSON.stringify(sites));

// --- Auth Helpers (Internal to this service) ---
async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

const createDefaultSubscription = (plan: SubscriptionPlan = SubscriptionPlan.FREE): UserSubscription => {
    const credits = { socialGraphics: 0, socialVideo: 0 };
    if (plan === SubscriptionPlan.FREE) {
        credits.socialGraphics = 1;
    }
    if (plan === SubscriptionPlan.CREATOR) {
        credits.socialVideo = 1;
    }
    return {
        plan,
        postsGeneratedThisMonth: 0,
        renewalDate: Date.now() + 30 * 24 * 60 * 60 * 1000,
        featureCredits: credits,
        commentingActionsThisMonth: 0,
    };
};

const JWT_SECRET = 'this-is-a-super-secret-key-for-local-dev-only';
const createToken = (username: string) => `header.${btoa(JSON.stringify({ username, exp: Date.now() + 86400000 }))}.${JWT_SECRET}`;
const decodeToken = (token: string): { username: string; exp: number } | null => {
    try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        if (token.split('.')[2] !== JWT_SECRET) return null;
        return payload;
    } catch {
        return null;
    }
};

// --- Default objects for site creation ---
const defaultApiKeys: ApiKeys = { google: '', googleClientId: '', openAI: '', anthropic: '', openRouter: '', xai: '', replicate: '', dataforseo: '', freepik: '', falai: '', perplexity: '', mailgun: '', sendgrid: '', tenweb: '' };
const defaultModelConfig: ModelConfig = {
  textProvider: AiProvider.GOOGLE, textModel: AVAILABLE_MODELS[AiProvider.GOOGLE].text[0],
  imageProvider: AiProvider.GOOGLE, imageModel: AVAILABLE_MODELS[AiProvider.GOOGLE].image[0],
  videoProvider: AiProvider.GOOGLE, videoModel: AVAILABLE_MODELS[AiProvider.GOOGLE].video?.[0] || '',
  geminiConfig: { temperature: 0.7, topK: 40, topP: 0.95 },
};
const defaultSocialSettings: SocialMediaSettings = { twitter: [], facebook: [], linkedin: [], instagram: [], pinterest: [], whatsapp: [], youtube: [], tiktok: [], telegram: [], snapchat: [] };
const defaultApiUsage: Partial<Record<keyof ApiKeys, number>> = { google: 0, openAI: 0, anthropic: 0, openRouter: 0, xai: 0, replicate: 0, dataforseo: 0, freepik: 0, falai: 0, perplexity: 0, mailgun: 0, sendgrid: 0, tenweb: 0 };

// --- Helper Functions ---
const getSiteForTask = async (siteId: string): Promise<Site> => {
    await new Promise(resolve => setTimeout(resolve, FAKE_LATENCY / 4));
    const site = getSitesDB().find(s => s.id === siteId);
    if (!site) throw new Error(`Site with ID ${siteId} not found for task.`);
    return JSON.parse(JSON.stringify(site)); // Return a copy to prevent mutation issues
};

const updateSiteInDB = (updatedSite: Site): Site => {
    const sites = getSitesDB();
    const index = sites.findIndex(s => s.id === updatedSite.id);
    if (index !== -1) {
        sites[index] = updatedSite;
        setSitesDB(sites);
    }
    return updatedSite;
};

const logApiUsage = (site: Site, provider: keyof ApiKeys, cost: number): Site => {
    if (!provider || cost === 0) return site;
    const currentCost = site.apiUsage?.[provider] || 0;
    const newApiUsage = { ...(site.apiUsage || {}), [provider]: currentCost + cost };
    return { ...site, apiUsage: newApiUsage };
};

const _publishSocialMediaPosts = async (site: Site, posts: Record<string, SocialMediaPost>): Promise<any[]> => {
    const publishingLog: any[] = [];
    const enabledPlatforms = (Object.keys(site.socialMediaSettings) as (keyof typeof site.socialMediaSettings)[]);

    for (const platform of enabledPlatforms) {
        const platformKey = platform as oauthService.SocialPlatform;
        if (posts[platformKey]) {
            const enabledAccounts = (site.socialMediaSettings[platformKey] as SocialMediaAccount[] || [])
                .filter(acc => acc.isConnected && acc.isAutomationEnabled);

            for (const account of enabledAccounts) {
                try {
                    const result = await socialMediaService.postToSocialMedia(platformKey, account, posts[platformKey]);
                    if (result.success) {
                        publishingLog.push({ platform, accountName: account.name, status: 'success' });
                    } else {
                        publishingLog.push({ platform, accountName: account.name, status: 'failed', message: result.message });
                    }
                } catch (e: any) {
                    publishingLog.push({ platform, accountName: account.name, status: 'failed', message: e.message });
                }
            }
        }
    }
    console.log('[MCP Service] Social Publishing Log:', publishingLog);
    return publishingLog;
};

type ProgressCallback = (update: { status: AppStatus; message: string; topic?: string; cost?: { provider: keyof ApiKeys; amount: number; }}) => void;
const noOpProgress: ProgressCallback = () => {};

// --- Authentication ---
export async function login(username: string, password: string) {
    await new Promise(resolve => setTimeout(resolve, FAKE_LATENCY));
    const users = getUsersDB();
    const passwordHash = await hashPassword(password);
    const user = users.find(u => u.username === username && u.passwordHash === passwordHash);
    if (!user) {
        throw new Error("Invalid username or password.");
    }
    const { passwordHash: _, ...userToReturn } = user;
    return { user: userToReturn, token: createToken(username) };
}

export async function signup(details: Omit<StoredUser, 'passwordHash' | 'subscription' | 'avatarUrl'> & { password: string}) {
    await new Promise(resolve => setTimeout(resolve, FAKE_LATENCY));
    const { username, password, displayName, email } = details;

    const users = getUsersDB();
    if (users.some(u => u.username === username)) {
        throw new Error("Username already exists.");
    }
    const passwordHash = await hashPassword(password);
    const newUserRecord: StoredUser = { 
        username, 
        displayName, 
        email, 
        passwordHash, 
        subscription: createDefaultSubscription(), 
        avatarUrl: '' 
    };
    
    users.push(newUserRecord);
    setUsersDB(users);

    const { passwordHash: _, ...userToReturn } = newUserRecord;
    return { user: userToReturn, token: createToken(newUserRecord.username) };
}


export async function validateToken(token: string): Promise<User | null> {
    await new Promise(resolve => setTimeout(resolve, FAKE_LATENCY / 2));
    const payload = decodeToken(token);
    if (!payload || payload.exp < Date.now()) {
        return null;
    }
    const user = getUsersDB().find(u => u.username === payload.username);
    if (!user) return null;
    const { passwordHash, ...userToReturn } = user;
    return userToReturn;
}

// --- Site Data Management ---
export async function getSitesForUser(username: string): Promise<Site[]> {
    await new Promise(resolve => setTimeout(resolve, FAKE_LATENCY));
    // In a real app, this would filter sites by username/owner.
    // For the simulation, we return all sites.
    return getSitesDB();
}

export async function updateSitesForUser(username: string, sites: Site[]): Promise<void> {
    await new Promise(resolve => setTimeout(resolve, FAKE_LATENCY / 2));
    // Again, a real app would have security checks here.
    setSitesDB(sites);
}

// --- AI Service Wrappers ---
export async function generateStrategicBrief(siteId: string, sourceType: 'keyword' | 'rss' | 'video' | 'google_sheet', sourceDetails: any, options?: any) {
    let site = await getSiteForTask(siteId);
    let result;
    if (sourceType === 'keyword') {
        result = await aiServiceInternal.generateStrategicBriefFromKeyword(sourceDetails, site);
    } else if (sourceType === 'rss') {
        result = await aiServiceInternal.generateStrategicBriefFromRssItem(sourceDetails, site);
    } else if (sourceType === 'video') {
        result = await aiServiceInternal.generateStrategicBriefFromVideoUrl(sourceDetails, site, options);
    } else if (sourceType === 'google_sheet') {
        result = await aiServiceInternal.generateStrategicBriefFromGoogleSheetRow(sourceDetails, site);
    } else {
        throw new Error("Invalid source type for strategy generation.");
    }
    site = logApiUsage(site, result.cost.provider, result.cost.amount);
    return { brief: result.brief, updatedSite: updateSiteInDB(site) };
}

export async function fleshOutBrief(siteId: string, partialBrief: Partial<StrategicBrief>) {
    let site = await getSiteForTask(siteId);
    const { brief, cost } = await aiServiceInternal.fleshOutBrief(partialBrief, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { brief, updatedSite: updateSiteInDB(site) };
}

export async function generateArticle(siteId: string, brief: StrategicBrief) {
    let site = await getSiteForTask(siteId);
    const { postData, cost } = await aiServiceInternal.generateArticleFromBrief(brief, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { postData, updatedSite: updateSiteInDB(site) };
}

export async function optimizeArticle(siteId: string, rawHtmlContent: string, brief: StrategicBrief) {
    let site = await getSiteForTask(siteId);
    const { finalHtmlContent, cost } = await aiServiceInternal.optimizeAndFinalizeArticle(rawHtmlContent, brief, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { finalHtmlContent, updatedSite: updateSiteInDB(site) };
}

export async function generateImage(siteId: string, prompt: string) {
    let site = await getSiteForTask(siteId);
    const { base64Image, cost } = await aiServiceInternal.generateFeaturedImage(prompt, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { base64Image, updatedSite: updateSiteInDB(site) };
}

export async function regenerateArticleSection(siteId: string, brief: StrategicBrief, heading: string, sectionHtml: string) {
    let site = await getSiteForTask(siteId);
    const { regeneratedHtml, cost } = await aiServiceInternal.regenerateArticleSection(site, brief, heading, sectionHtml);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { regeneratedHtml, updatedSite: updateSiteInDB(site) };
}

export async function generateSocialGraphicAndCaption(siteId: string, prompt: string, aspectRatio: '16:9' | '1:1' | '9:16', platformDescription: string, modelConfigOverride?: Partial<Site['modelConfig']>, characterId?: string) {
    let site = await getSiteForTask(siteId);
    if (modelConfigOverride) site.modelConfig = { ...site.modelConfig, ...modelConfigOverride };
    const { generationResult, totalCost } = await aiServiceInternal.generateSocialGraphicAndCaption(site, prompt, aspectRatio, platformDescription, modelConfigOverride, characterId);
    site = logApiUsage(site, totalCost.provider, totalCost.amount);
    return { generationResult, updatedSite: updateSiteInDB(site) };
}

export async function publishSocialGraphic(siteId: string, generationResult: { imageUrl: string; caption: string; }) {
    let site = await getSiteForTask(siteId);
    await aiServiceInternal.publishSocialGraphic(site, generationResult);
    return { updatedSite: updateSiteInDB(site) };
}

export async function generateSocialGraphicPrompt(siteId: string) {
    let site = await getSiteForTask(siteId);
    const { prompt, cost } = await aiServiceInternal.generateSocialGraphicPrompt(site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { prompt, updatedSite: updateSiteInDB(site) };
}

export async function brainstormContentIdeas(siteId: string, theme: string, contentType: 'blog_post' | 'social_graphic' | 'email_campaign') {
    let site = await getSiteForTask(siteId);
    const { ideas, cost } = await aiServiceInternal.brainstormContentIdeas(site, theme, contentType);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { ideas, updatedSite: updateSiteInDB(site) };
}

export async function generateBrandGuidelineFromUrl(siteId: string, url: string) {
    let site = await getSiteForTask(siteId);
    const { guideline, cost } = await aiServiceInternal.generateBrandGuidelineFromUrl(url, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    site.brandGuideline = guideline;
    return { updatedSite: updateSiteInDB(site) };
}

export async function suggestKeywords(siteId: string, existingKeywords: string) {
    let site = await getSiteForTask(siteId);
    const { suggestions, cost } = await aiServiceInternal.suggestKeywords(existingKeywords, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { suggestions, updatedSite: updateSiteInDB(site) };
}

export async function suggestKeywordsFromUrl(siteId: string, url: string, existingKeywords: string) {
    let site = await getSiteForTask(siteId);
    const { suggestions, cost } = await aiServiceInternal.suggestKeywordsFromUrl(url, existingKeywords, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { suggestions, updatedSite: updateSiteInDB(site) };
}

export async function findCommentingProspects(topic: string, siteId: string) {
    let site = await getSiteForTask(siteId);
    const { prospects, cost } = await aiServiceInternal.findCommentingProspects(topic, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { prospects, updatedSite: updateSiteInDB(site) };
}

export async function generateBlogComment(siteId: string, prospectUrl: string, ownPostTopic: string) {
    let site = await getSiteForTask(siteId);
    const { comment, cost } = await aiServiceInternal.generateBlogComment(prospectUrl, ownPostTopic, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { comment, updatedSite: updateSiteInDB(site) };
}

export async function checkBacklinkStatus(siteId: string, link: MonitoredBacklink) {
    let site = await getSiteForTask(siteId);
    const { status, anchorText } = await aiServiceInternal.checkBacklinkStatus(site, link);
    const updatedLinks = site.monitoredBacklinks.map(l => l.id === link.id ? { ...l, status, anchorText, lastChecked: Date.now() } : l);
    site.monitoredBacklinks = updatedLinks;
    return { updatedSite: updateSiteInDB(site) };
}

export async function generateManualEmailCampaign(siteId: string, topic: string) {
    let site = await getSiteForTask(siteId);
    const { campaign, cost } = await aiServiceInternal.generateStandaloneEmailCampaign(site, topic);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { campaign, updatedSite: updateSiteInDB(site) };
}

export async function sendAndRecordEmailCampaign(siteId: string, campaign: EmailMarketingCampaign) {
    let site = await getSiteForTask(siteId);
    await aiServiceInternal.sendMailchimpCampaign(site, campaign);
    const newHistoryItem: PostHistoryItem = { id: crypto.randomUUID(), topic: campaign.subject, url: '#', date: Date.now(), type: 'Email Marketing', emailCampaign: campaign };
    site.history = [newHistoryItem, ...site.history];
    return { updatedSite: updateSiteInDB(site) };
}

export async function verifyApiKey(siteId: string, provider: keyof ApiKeys, apiKey: string) {
    return aiServiceInternal.verifyApiKey(provider, apiKey);
}

export async function fetchAvailableModels(siteId: string, provider: AiProvider, apiKey: string) {
    let site = await getSiteForTask(siteId);
    const models = await aiServiceInternal.fetchAvailableModels(provider, apiKey);
    site.fetchedModels = { ...(site.fetchedModels || {}), [provider]: models };
    return { updatedSite: updateSiteInDB(site) };
}

export async function verifyDataForSeoConnection(siteId: string) {
    const site = await getSiteForTask(siteId);
    return dataforseoService.verifyConnection(site);
}

export async function runRawDataForSeoQuery(siteId: string, endpoint: string, payload: any) {
    const site = await getSiteForTask(siteId);
    const result = await dataforseoService.runRawDataForSeoQuery(site, endpoint, payload);
    return { result };
}

export async function findBestKeyword(siteId: string, seedKeyword: string) {
    let site = await getSiteForTask(siteId);
    const { bestKeyword, cost } = await aiServiceInternal.findBestKeyword(seedKeyword, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { bestKeyword, updatedSite: updateSiteInDB(site) };
}

export async function findSocialMediaProspects(siteId: string) {
    let site = await getSiteForTask(siteId);
    const { prospects, cost } = await aiServiceInternal.findSocialMediaProspects(site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { prospects, updatedSite: updateSiteInDB(site) };
}

export async function generateSocialMediaComment(siteId: string, prospect: SocialCommentingProspect, sourcePost: PostHistoryItem) {
    let site = await getSiteForTask(siteId);
    const { comment, cost } = await aiServiceInternal.generateSocialMediaComment(site, prospect, sourcePost);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { comment, updatedSite: updateSiteInDB(site) };
}

export async function postSocialMediaComment(siteId: string, prospect: SocialCommentingProspect) {
    let site = await getSiteForTask(siteId);
    const account = (site.socialMediaSettings[prospect.platform as keyof SocialMediaSettings] as SocialMediaAccount[]).find(acc => acc.id === prospect.postingAccountId);
    if (!account) throw new Error("Account not found for posting.");
    if (!prospect.generatedComment) throw new Error("Comment text is empty.");
    await socialMediaService.postCommentToSocialMedia(prospect.platform as SocialPlatform, account, prospect.prospectPostUrl, prospect.generatedComment);
    const updatedProspects = site.socialCommentingProspects.map(p => p.id === prospect.id ? { ...p, status: 'posted' as const } : p);
    site.socialCommentingProspects = updatedProspects;
    return { updatedSite: updateSiteInDB(site) };
}

export async function runWpCliCommand(siteId: string, command: string) {
    const site = await getSiteForTask(siteId);
    const output = await wordpressService.runWpCliCommand({ url: site.wordpressUrl, username: site.wordpressUsername, password: site.applicationPassword }, command);
    return { output };
}

export async function generateAnalyticsInsights(siteId: string, postData: PostPerformanceData) {
    let site = await getSiteForTask(siteId);
    const { insights, cost } = await aiServiceInternal.generateAnalyticsInsights(site, postData);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { insights, updatedSite: updateSiteInDB(site) };
}

export async function connectMailchimp(siteId: string, apiKey: string, serverPrefix: string) {
    let site = await getSiteForTask(siteId);
    try {
        const { availableAudiences } = await aiServiceInternal.verifyMailchimpConnection(apiKey, serverPrefix);
        site.mailchimp = { isConnected: true, apiKey, serverPrefix, status: 'connected', statusMessage: `Successfully connected. Found ${availableAudiences.length} audience(s).`, availableAudiences };
    } catch (e: any) {
        site.mailchimp = { isConnected: false, apiKey, serverPrefix, status: 'error', statusMessage: e.message };
    }
    return { updatedSite: updateSiteInDB(site) };
}

export async function disconnectMailchimp(siteId: string) {
    let site = await getSiteForTask(siteId);
    site.mailchimp = { isConnected: false, apiKey: '', serverPrefix: '', status: 'disconnected', statusMessage: '', availableAudiences: [], defaultAudienceId: '' };
    return { updatedSite: updateSiteInDB(site) };
}

export async function generateSocialVideoAndCaption(siteId: string, prompt: string, characterId?: string) {
    let site = await getSiteForTask(siteId);
    const { generationResult, totalCost } = await aiServiceInternal.generateSocialVideoAndCaption(site, prompt, characterId);
    site = logApiUsage(site, totalCost.provider, totalCost.amount);
    return { generationResult, updatedSite: updateSiteInDB(site) };
}

export async function fetchPerformanceData(siteId: string) {
    const site = await getSiteForTask(siteId);
    const performanceData = await googleApiService.fetchCombinedPerformanceData(site);
    return { performanceData };
}

// --- WordPress Wrappers ---
export async function verifyWordPressConnection(siteId: string) {
    const site = await getSiteForTask(siteId);
    return wordpressService.verifyWordPressConnection({ url: site.wordpressUrl, username: site.wordpressUsername, password: site.applicationPassword });
}

export async function fetchWordPressAuthors(siteId: string) {
    const site = await getSiteForTask(siteId);
    const authors = await wordpressService.fetchAuthors({ url: site.wordpressUrl, username: site.wordpressUsername, password: site.applicationPassword });
    return { authors };
}

export async function fetchWordPressCategories(siteId: string) {
    const site = await getSiteForTask(siteId);
    const categories = await wordpressService.fetchCategories({ url: site.wordpressUrl, username: site.wordpressUsername, password: site.applicationPassword });
    return { categories };
}

// --- OAuth ---
export async function exchangeCodeForToken(siteId: string, platform: SocialPlatform, accountId: string, code: string) {
    let site = await getSiteForTask(siteId);
    const account = (site.socialMediaSettings[platform as keyof SocialMediaSettings] as SocialMediaAccount[]).find(a => a.id === accountId);
    if (!account || !account.clientId || !account.clientSecret) throw new Error("Account configuration is missing client ID or secret.");
    const { accessToken } = await oauthService.exchangeCodeForToken(platform, code, account.clientId, account.clientSecret);
    const { success, message } = await oauthService.verifyConnection(platform, accessToken);
    
    const updatedAccounts = (site.socialMediaSettings[platform as keyof SocialMediaSettings] as SocialMediaAccount[]).map(a => 
        a.id === accountId ? { ...a, accessToken, isConnected: success, status: success ? 'connected' : 'needs_reauth', statusMessage: message } : a
    );
    site.socialMediaSettings = { ...site.socialMediaSettings, [platform]: updatedAccounts };
    return { updatedSite: updateSiteInDB(site) };
}

// --- Automation Pipelines ---
const getNextAutomationSource = async (site: Site, jobType: 'blog' | 'social_graphic' | 'social_video' | 'email_marketing' | 'email_digest'): Promise<{ sourceType: 'keyword' | 'rss' | 'video' | 'google_sheet', sourceDetails: any, updatedSite: Site, topic: string } | null> => {
    const source = site.masterAutomationSource;
    if (source === 'keyword') {
        const keywords = site.keywordList.split('\n').filter(k => k.trim() && !k.trim().startsWith('[DONE]'));
        if (keywords.length === 0) return null;
        const topic = keywords[0];
        site.keywordList = site.keywordList.replace(topic, `[DONE] ${topic}`);
        return { sourceType: 'keyword', sourceDetails: topic, updatedSite: site, topic };
    }
    if (source === 'rss') {
        const { items } = await fetchAndParseRssFeed(site.rssFeedUrl);
        const unprocessed = items.filter(item => !site.processedRssGuids.includes(item.guid));
        if (unprocessed.length === 0) return null;
        const item = unprocessed[0];
        site.processedRssGuids.push(item.guid);
        return { sourceType: 'rss', sourceDetails: item, updatedSite: site, topic: item.title };
    }
    return null;
}

export async function runManualGenerationPipeline(siteId: string, sourceType: any, sourceDetails: any, options: any, progressCallback: ProgressCallback) {
    let site = await getSiteForTask(siteId);
    
    progressCallback({ status: AppStatus.GENERATING_STRATEGY, message: 'Generating strategic brief...' });
    const { brief, updatedSite: siteAfterBrief } = await generateStrategicBrief(siteId, sourceType, sourceDetails, options);
    site = siteAfterBrief;

    progressCallback({ status: AppStatus.GENERATING_ARTICLE, message: 'Generating article from brief...' });
    const { postData, updatedSite: siteAfterArticle } = await generateArticle(siteId, brief);
    site = siteAfterArticle;

    progressCallback({ status: AppStatus.GENERATING_IMAGE, message: 'Generating featured image...' });
    const { base64Image, updatedSite: siteAfterImage } = await generateImage(siteId, postData.imagePrompt);
    site = siteAfterImage;
    const blogPostWithImage: BlogPost = { ...postData, imageUrl: base64Image };

    progressCallback({ status: AppStatus.OPTIMIZING_ARTICLE, message: 'Optimizing article for SEO...' });
    const { finalHtmlContent, updatedSite: siteAfterOptimize } = await optimizeArticle(siteId, blogPostWithImage.content, brief);
    site = siteAfterOptimize;
    const finalBlogPost: BlogPost = { ...blogPostWithImage, content: finalHtmlContent };

    const score = calculateSeoScore(finalBlogPost, brief);
    const draft: Draft = { id: crypto.randomUUID(), date: Date.now(), sourceTopic: brief.topic, sourceDetails: { type: sourceType, value: sourceDetails }, blogPost: finalBlogPost, brief: brief };

    return { draft, score, updatedSite: site };
}

export async function publishPostAndFollowUps(siteId: string, draft: Draft, editedPost: BlogPost) {
    let site = await getSiteForTask(siteId);
    const postUrl = await wordpressService.publishPost({ url: site.wordpressUrl, username: site.wordpressUsername, password: site.applicationPassword }, editedPost, draft.brief.focusKeyword, site.authorId);
    let publishingLog: any[] = [];
    let finalHistoryItem: PostHistoryItem = { id: draft.id, topic: editedPost.title, url: postUrl, date: Date.now(), type: 'Keyword' };

    if (site.isSocialFollowUpEnabled) {
        const { posts: socialPosts, cost } = await aiServiceInternal.generateSocialMediaPosts(editedPost, postUrl, site);
        site = logApiUsage(site, cost.provider, cost.amount);
        publishingLog = await _publishSocialMediaPosts(site, socialPosts);
        finalHistoryItem.socialMediaPosts = socialPosts;
    }
    if (site.isEmailFollowUpEnabled && site.mailchimp?.isConnected) {
        const { campaign, cost } = await aiServiceInternal.generateEmailCampaignFromPost(editedPost, postUrl, site);
        site = logApiUsage(site, cost.provider, cost.amount);
        await aiServiceInternal.sendMailchimpCampaign(site, campaign);
        finalHistoryItem.emailCampaign = campaign;
    }
    
    site.history = [finalHistoryItem, ...site.history];
    site.drafts = site.drafts.filter(d => d.id !== draft.id);
    return { postUrl, publishingLog, updatedSite: updateSiteInDB(site) };
}

export async function runBlogPostAutomation(siteId: string, recurringScheduleId: string | null, progressCallback: ProgressCallback = noOpProgress) {
    let site = await getSiteForTask(siteId);
    progressCallback({ status: AppStatus.FETCHING_SOURCE, message: 'Finding next topic...' });
    const source = await getNextAutomationSource(site, 'blog');
    if (!source) throw new Error("No available topics from the master automation source.");
    site = source.updatedSite;
    progressCallback({ status: AppStatus.FETCHING_SOURCE, message: `Found topic: "${source.topic}"`, topic: source.topic });
    const { draft, score } = await runManualGenerationPipeline(siteId, source.sourceType, source.sourceDetails, {}, progressCallback);
    site = await getSiteForTask(siteId);
    if (site.isAutoPublishEnabled) {
        progressCallback({ status: AppStatus.PUBLISHING, message: 'Publishing post to WordPress...' });
        const { updatedSite } = await publishPostAndFollowUps(siteId, draft, draft.blogPost);
        site = updatedSite;
    } else {
        site.drafts = [draft, ...site.drafts];
        await sendDraftNotification(site, draft);
    }
    return updateSiteInDB(site);
}

export async function runSocialGraphicAutomation(siteId: string, recurringScheduleId: string | null, progressCallback: ProgressCallback = noOpProgress) {
    let site = await getSiteForTask(siteId);
    progressCallback({ status: AppStatus.FETCHING_SOURCE, message: 'Finding next topic...' });
    const source = await getNextAutomationSource(site, 'social_graphic');
    if (!source) throw new Error("No available topics for social graphic.");
    site = source.updatedSite;
    progressCallback({ status: AppStatus.FETCHING_SOURCE, message: `Found topic: "${source.topic}"`, topic: source.topic });
    progressCallback({ status: AppStatus.GENERATING_IMAGE, message: 'Generating social graphic...' });
    const { generationResult, updatedSite } = await generateSocialGraphicAndCaption(siteId, source.topic, '1:1', 'social media');
    site = updatedSite;
    progressCallback({ status: AppStatus.PUBLISHING, message: 'Publishing to social media...' });
    await aiServiceInternal.publishSocialGraphic(site, { imageUrl: generationResult.base64Image, caption: generationResult.caption });
    const newHistoryItem: PostHistoryItem = { id: crypto.randomUUID(), topic: `Social Graphic: "${source.topic.substring(0, 50)}..."`, url: '#', date: Date.now(), type: 'Social Graphic', socialGraphics: { custom: { imageUrl: generationResult.base64Image, caption: generationResult.caption } } };
    site.history = [newHistoryItem, ...site.history];
    return updateSiteInDB(site);
}

export async function runSocialVideoAutomation(siteId: string, recurringScheduleId: string | null, progressCallback: ProgressCallback = noOpProgress) {
    let site = await getSiteForTask(siteId);
    progressCallback({ status: AppStatus.FETCHING_SOURCE, message: 'Finding topic for video...' });
    const source = await getNextAutomationSource(site, 'social_video');
    if (!source) throw new Error("No available topics for social video.");
    site = source.updatedSite;
    progressCallback({ status: AppStatus.FETCHING_SOURCE, message: `Found topic: "${source.topic}"`, topic: source.topic });
    
    progressCallback({ status: AppStatus.GENERATING_ARTICLE, message: 'Generating video script & caption...' }); // Re-using status for text gen
    const { generationResult, updatedSite } = await generateSocialVideoAndCaption(site.id, source.topic);
    site = updatedSite;

    progressCallback({ status: AppStatus.PUBLISHING, message: 'Publishing video to accounts...' });
    const socialPosts: Record<string, SocialMediaPost> = {
        youtube: { content: generationResult.caption, hashtags: [] },
        tiktok: { content: generationResult.caption, hashtags: [] }
    };
    await _publishSocialMediaPosts(site, socialPosts);

    const newHistoryItem: PostHistoryItem = { id: crypto.randomUUID(), topic: `Social Video: "${source.topic.substring(0, 50)}..."`, url: '#', date: Date.now(), type: 'Social Video', socialVideos: { custom: { videoUrl: generationResult.videoUrl, caption: generationResult.caption } } };
    site.history = [newHistoryItem, ...site.history];
    return updateSiteInDB(site);
}

export async function runEmailMarketingAutomation(siteId: string, recurringScheduleId: string | null, progressCallback: ProgressCallback = noOpProgress) {
    let site = await getSiteForTask(siteId);
    progressCallback({ status: AppStatus.FETCHING_SOURCE, message: 'Finding topic for email...' });
    const source = await getNextAutomationSource(site, 'email_marketing');
    if (!source) throw new Error("No available topics for email marketing.");
    site = source.updatedSite;
    progressCallback({ status: AppStatus.FETCHING_SOURCE, message: `Found topic: "${source.topic}"`, topic: source.topic });

    progressCallback({ status: AppStatus.GENERATING_ARTICLE, message: 'Generating email campaign...' });
    const { campaign, updatedSite } = await generateManualEmailCampaign(site.id, source.topic);
    site = updatedSite;

    progressCallback({ status: AppStatus.PUBLISHING, message: 'Sending email campaign...' });
    await aiServiceInternal.sendMailchimpCampaign(site, campaign);

    const newHistoryItem: PostHistoryItem = { id: crypto.randomUUID(), topic: campaign.subject, url: '#', date: Date.now(), type: 'Email Marketing', emailCampaign: campaign };
    site.history = [newHistoryItem, ...site.history];
    return updateSiteInDB(site);
}

export async function runDigestAutomation(siteId: string, recurringScheduleId: string | null, progressCallback: ProgressCallback = noOpProgress) {
    let site = await getSiteForTask(siteId);
    if (site.masterAutomationSource !== 'rss' || !site.rssFeedUrl) {
        throw new Error("Email Digest requires Master Source to be 'RSS Feed'.");
    }

    progressCallback({ status: AppStatus.FETCHING_SOURCE, message: 'Fetching new RSS items...' });
    const { items } = await fetchAndParseRssFeed(site.rssFeedUrl);
    const unprocessed = items.filter(item => !(site.processedDigestGuids || []).includes(item.guid));
    if (unprocessed.length === 0) {
        throw new Error("No new items in RSS feed to create a digest.");
    }
    progressCallback({ status: AppStatus.FETCHING_SOURCE, message: `Found ${unprocessed.length} new items.` });

    progressCallback({ status: AppStatus.GENERATING_ARTICLE, message: 'Generating digest email...' });
    const { campaign, cost } = await aiServiceInternal.generateRssDigestEmail(site, unprocessed);
    site = logApiUsage(site, cost.provider, cost.amount);

    progressCallback({ status: AppStatus.PUBLISHING, message: 'Sending digest...' });
    await aiServiceInternal.sendMailchimpCampaign(site, campaign);
    
    const newGuids = unprocessed.map(item => item.guid);
    site.processedDigestGuids = [...(site.processedDigestGuids || []), ...newGuids];
    const newHistoryItem: PostHistoryItem = { id: crypto.randomUUID(), topic: campaign.subject, url: '#', date: Date.now(), type: 'Email Digest', emailCampaign: campaign };
    site.history = [newHistoryItem, ...site.history];
    return updateSiteInDB(site);
}

// --- Website Creator ---
export async function generateWebsitePlan(siteId: string, idea: string) {
    let site: Site;
    const allSites = getSitesDB();
    const siteExists = allSites.some(s => s.id === siteId);

    if (!siteExists) {
        site = { id: 'transient', name: 'Transient Site', modelConfig: defaultModelConfig, apiKeys: defaultApiKeys } as Site;
    } else {
        site = await getSiteForTask(siteId);
    }
    return aiServiceInternal.generateWebsitePlan(idea, site);
}

export async function create10WebSite(plan: WebsitePlan, logCallback: (message: string) => void) {
    const { newSite, ...details } = await aiServiceInternal.create10WebSite(plan, logCallback);
    const sites = getSitesDB();
    sites.push(newSite);
    setSitesDB(sites);
    return { newSite, ...details };
}

// --- Self-Test & Integration Functions ---
export async function testWpAuthorPermissions(siteId: string) {
    const site = await getSiteForTask(siteId);
    await wordpressService.testAuthorPermissions({
        url: site.wordpressUrl,
        username: site.wordpressUsername,
        password: site.applicationPassword,
    });
}
export async function testWpCategoryPermissions(siteId: string) {
    const site = await getSiteForTask(siteId);
    await wordpressService.testCategoryPermissions({
        url: site.wordpressUrl,
        username: site.wordpressUsername,
        password: site.applicationPassword,
    });
}
export async function testWpMediaPermissions(siteId: string) {
    const site = await getSiteForTask(siteId);
    await wordpressService.testMediaPermissions({
        url: site.wordpressUrl,
        username: site.wordpressUsername,
        password: site.applicationPassword,
    });
}
export async function testWpPostPermissions(siteId: string) {
    const site = await getSiteForTask(siteId);
    await wordpressService.testPostPermissions({
        url: site.wordpressUrl,
        username: site.wordpressUsername,
        password: site.applicationPassword,
    });
}
export async function verifyGoogleConnection(siteId: string, service: 'drive' | 'analytics') {
    await new Promise(resolve => setTimeout(resolve, FAKE_LATENCY / 2));
    const site = await getSiteForTask(siteId);
    if (service === 'drive' && site.googleDrive?.isConnected) {
        return { success: true, message: `Connected to Google Drive as ${site.googleDrive.userEmail}.` };
    }
    if (service === 'analytics' && site.googleAnalytics?.isConnected) {
        return { success: true, message: `Connected to Google Analytics as ${site.googleAnalytics.userEmail}.` };
    }
    return { success: false, message: "Integration is not connected." };
}
export async function verifyMailchimpConnection(siteId: string): Promise<{ success: boolean; message: string; }> {
    const site = await getSiteForTask(siteId);
    if (!site.mailchimp?.apiKey || !site.mailchimp.serverPrefix) {
        return { success: false, message: "Credentials missing." };
    }
    try {
        const { availableAudiences } = await aiServiceInternal.verifyMailchimpConnection(site.mailchimp.apiKey, site.mailchimp.serverPrefix);
        return { success: true, message: `Connection successful. Found ${availableAudiences.length} audience(s).` };
    } catch (e: any) {
        return { success: false, message: e.message };
    }
}

export async function verifySocialConnection(siteId: string, platform: SocialPlatform, accountId: string) {
    let site = await getSiteForTask(siteId);
    const account = (site.socialMediaSettings[platform as keyof SocialMediaSettings] as SocialMediaAccount[]).find(a => a.id === accountId);
    if (!account || !account.accessToken) throw new Error("Account or access token not found for verification.");
    
    const { success, message } = await oauthService.verifyConnection(platform, account.accessToken);
    
    const updatedAccounts = (site.socialMediaSettings[platform as keyof SocialMediaSettings] as SocialMediaAccount[]).map(a => 
        a.id === accountId ? { ...a, status: success ? 'connected' : 'needs_reauth' as const, statusMessage: message } : a
    );
    site.socialMediaSettings = { ...site.socialMediaSettings, [platform]: updatedAccounts };
    return { updatedSite: updateSiteInDB(site) };
}

export async function verifyCredentialedSocialConnection(siteId: string, platform: 'whatsapp' | 'telegram', accountId: string) {
    let site = await getSiteForTask(siteId);
    const account = (site.socialMediaSettings[platform] as (WhatsAppAccount | TelegramAccount)[]).find(a => a.id === accountId);
    if (!account) throw new Error("Account not found for verification.");

    const { success, message } = await oauthService.verifyCredentialBasedConnection(platform, account);
    
    const updatedAccounts = (site.socialMediaSettings[platform] as (WhatsAppAccount | TelegramAccount)[]).map(a => 
        a.id === accountId ? { ...a, isConnected: success, status: success ? 'connected' : 'disconnected' as const, statusMessage: message } : a
    );
    site.socialMediaSettings = { ...site.socialMediaSettings, [platform]: updatedAccounts };
    return { updatedSite: updateSiteInDB(site) };
}

export async function connectGoogleDrive(siteId: string, userEmail: string) {
    let site = await getSiteForTask(siteId);
    site.googleDrive = { isConnected: true, userEmail };
    return { updatedSite: updateSiteInDB(site) };
}

export async function disconnectGoogleDrive(siteId: string) {
    let site = await getSiteForTask(siteId);
    site.googleDrive = { isConnected: false, userEmail: '' };
    return { updatedSite: updateSiteInDB(site) };
}

export async function addDriveFileReference(siteId: string, file: { id: string, name: string, mimeType: string }) {
    let site = await getSiteForTask(siteId);
    const newRef: ReferenceItem = {
        id: file.id,
        type: 'file',
        value: `drive://${file.id}`,
        name: `[Drive] ${file.name}`,
        mimeType: file.mimeType,
    };
    site.references = [...site.references, newRef];
    return { updatedSite: updateSiteInDB(site) };
}

export async function connectGoogleAnalytics(siteId: string, userEmail: string) {
    let site = await getSiteForTask(siteId);
    site.googleAnalytics = { isConnected: true, userEmail };
    return { updatedSite: updateSiteInDB(site) };
}

export async function disconnectGoogleAnalytics(siteId: string) {
    let site = await getSiteForTask(siteId);
    site.googleAnalytics = { isConnected: false, userEmail: '' };
    return { updatedSite: updateSiteInDB(site) };
}
