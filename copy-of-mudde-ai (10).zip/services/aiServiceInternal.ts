// This file contains the core AI logic that was previously in aiService.ts.
// It is now called by the mcpApiService, which acts as a secure wrapper.

import type { Site, ApiKeys, RssItem, BlogPost, SocialMediaPost, EmailMarketingCampaign, StrategicBrief, CommentingProspect, MonitoredBacklink, AnalyticsInsight, PostPerformanceData, SocialMediaSettings, SocialMediaAccount, MailchimpAccount, SocialCommentingProspect, PostHistoryItem, SeoChecklist, WebsitePlan, ModelConfig } from '../types';
import { AiProvider } from '../types';
import { GoogleGenAI, Type } from "@google/genai";
import * as socialMediaService from './socialMediaService';
import * as dataforseoService from './dataforseoService';
import type { SocialPlatform } from './oauthService';
import { AVAILABLE_MODELS } from '../constants';
import { checkReadability } from './seoService';
import type { GoogleSheetRow } from './googleSheetsService';

const defaultApiKeys: ApiKeys = { google: '', googleClientId: '', openAI: '', anthropic: '', openRouter: '', xai: '', replicate: '', dataforseo: '', freepik: '', falai: '', perplexity: '', mailgun: '', sendgrid: '', tenweb: '' };
const defaultModelConfig: ModelConfig = {
  textProvider: AiProvider.GOOGLE, textModel: AVAILABLE_MODELS[AiProvider.GOOGLE].text[0],
  imageProvider: AiProvider.GOOGLE, imageModel: AVAILABLE_MODELS[AiProvider.GOOGLE].image[0],
  videoProvider: AiProvider.GOOGLE, videoModel: AVAILABLE_MODELS[AiProvider.GOOGLE].video?.[0] || '',
  geminiConfig: { temperature: 0.7, topK: 40, topP: 0.95 },
};
const defaultSocialSettings: SocialMediaSettings = { twitter: [], facebook: [], linkedin: [], instagram: [], pinterest: [], whatsapp: [], youtube: [], tiktok: [], telegram: [], snapchat: [] };
const defaultApiUsage: Partial<Record<keyof ApiKeys, number>> = { google: 0, openAI: 0, anthropic: 0, openRouter: 0, xai: 0, replicate: 0, dataforseo: 0, freepik: 0, falai: 0, perplexity: 0, mailgun: 0, sendgrid: 0, tenweb: 0 };


export const aiProviderToApiKey = (provider: AiProvider): keyof ApiKeys => {
    switch (provider) {
        case AiProvider.GOOGLE: return 'google';
        case AiProvider.OPENAI: return 'openAI';
        case AiProvider.OPENROUTER: return 'openRouter';
        case AiProvider.ANTHROPIC: return 'anthropic';
        case AiProvider.XAI: return 'xai';
        case AiProvider.REPLICATE: return 'replicate';
        case AiProvider.FREEPIK: return 'freepik';
        case AiProvider.FALAI: return 'falai';
        case AiProvider.PERPLEXITY: return 'perplexity';
        default: return 'google';
    }
};

const getAiClient = (site: Site, provider: AiProvider) => {
    let apiKey: string | undefined;

    if (provider === AiProvider.GOOGLE) {
        apiKey = process.env.API_KEY;
    } else {
        apiKey = site.apiKeys[aiProviderToApiKey(provider)];
    }

    if (!apiKey) {
        throw new Error(`${provider} API key not found. Please add it in the API Keys tab.`);
    }
    return new GoogleGenAI({ apiKey });
};

const mockCost = (site: Site, providerOverride?: keyof ApiKeys, amount: number = 0.001) => ({
    provider: providerOverride || aiProviderToApiKey(site.modelConfig.textProvider),
    amount
});

const buildLocalSeoPromptPart = (site: Site): string => {
    if (!site.isLocalSeoEnabled || !site.localSeoServiceArea) return '';
    let localPrompt = `\n**Local SEO Targeting is ENABLED.** The content MUST be tailored for **${site.localSeoServiceArea}**.`;
    if (site.localSeoBusinessName) localPrompt += ` Mention the business "${site.localSeoBusinessName}".`;
    if (site.localSeoPhoneNumber) localPrompt += ` Include the phone number ${site.localSeoPhoneNumber}.`;
    return localPrompt;
};

// --- MOCKED AI LOGIC ---

export const generateStrategicBriefFromRssItem = async (item: RssItem, site: Site) => generateStrategicBriefFromKeyword(item.title, site);
export const generateStrategicBriefFromVideoUrl = async (videoUrl: string, site: Site, options: any) => generateStrategicBriefFromKeyword(options?.videoItem?.title || `Content based on video: ${videoUrl}`, site);
export const generateStrategicBriefFromGoogleSheetRow = async (row: GoogleSheetRow, site: Site) => generateStrategicBriefFromKeyword(row.topic, site);

export const fleshOutBrief = async (partialBrief: Partial<StrategicBrief>, site: Site): Promise<{ brief: StrategicBrief; cost: { provider: keyof ApiKeys; amount: number } }> => {
    console.warn("aiServiceInternal.fleshOutBrief is a stub.");
    const fullBrief: StrategicBrief = { topic: 'Placeholder Topic', focusKeyword: 'placeholder', keywordCluster: [], targetAudience: 'General Audience', contentAngle: 'Informational', entities: [], competitorUrls: [], internalLinks: [], seoTitle: 'Placeholder SEO Title', metaDescription: 'Placeholder meta description.', slug: 'placeholder-slug', imagePrompt: 'placeholder image prompt', imageAltText: 'placeholder image alt text', categories: ['General'], tags: ['general'], faq: [], wordCount: 800, brandGuideline: '', authorName: '', authorBio: '', ...partialBrief };
    return { brief: fullBrief, cost: mockCost(site) };
};

export const generateArticleFromBrief = async (brief: StrategicBrief, site: Site): Promise<{ postData: Omit<BlogPost, 'imageUrl'>; cost: { provider: keyof ApiKeys; amount: number } }> => {
    const ai = getAiClient(site, site.modelConfig.textProvider);
    const localSeoPrompt = buildLocalSeoPromptPart(site);

    const prompt = `
        Generate a full, well-researched, and SEO-optimized blog post based on this strategic brief.
        The output must be a single block of clean HTML content.

        **Strategic Brief:**
        - **Topic:** ${brief.topic}
        - **Focus Keyword:** ${brief.focusKeyword}
        - **Target Audience:** ${brief.targetAudience}
        - **Content Angle/Format:** ${brief.contentAngle}
        - **Keywords to Include:** ${brief.keywordCluster.join(', ')}
        - **Brand Guideline/Tone of Voice:** ${brief.brandGuideline}
        - **Author Name:** ${brief.authorName}
        ${localSeoPrompt}

        **HTML Structure Requirements:**
        - The entire output MUST be valid HTML. Do not include markdown or plain text.
        - Start with an engaging <h2> introduction section.
        - Use multiple <h2> and <h3> tags for a clear, logical structure.
        - Naturally incorporate the focus keyword and keyword cluster throughout the content, headings, and paragraphs.
        - Include at least one unordered list \`<ul>\` and one ordered list \`<ol>\`.
        - Use \`<strong>\` and \`<em>\` tags for emphasis.
        - If the brief includes an FAQ, create a dedicated "Frequently Asked Questions" section with <h2> and use <h3> for each question.
        - Create a final "About the Author" section using <h3>.
    `;

    const response = await ai.models.generateContent({
        model: site.modelConfig.textModel,
        contents: prompt,
    });
    
    const content = response.text;

    const postData = {
        title: brief.seoTitle,
        content: content,
        seoTitle: brief.seoTitle,
        metaDescription: brief.metaDescription,
        slug: brief.slug,
        excerpt: brief.metaDescription,
        categories: brief.categories,
        tags: brief.tags,
        imagePrompt: brief.imagePrompt,
        imageAltText: brief.imageAltText,
        focusKeyword: brief.focusKeyword,
    };
    
    return { postData, cost: mockCost(site, 'google', 0.002) };
};

export const optimizeAndFinalizeArticle = async (rawHtmlContent: string, brief: StrategicBrief, site: Site): Promise<{ finalHtmlContent: string; cost: { provider: keyof ApiKeys; amount: number } }> => {
    console.warn("aiServiceInternal.optimizeAndFinalizeArticle is a stub.");
    return { finalHtmlContent: rawHtmlContent + '<!-- optimized -->', cost: mockCost(site) };
};

export const generateFeaturedImage = async (prompt: string, site: Site): Promise<{ base64Image: string; cost: { provider: keyof ApiKeys; amount: number } }> => {
    const provider = site.modelConfig.imageProvider;

    if (provider !== AiProvider.GOOGLE) {
        console.warn(`Image generation for ${provider} is not implemented. Using a mock image.`);
        const mockBase64Image = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAyAAAAHgCAIAAAC6q52XAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADTSURBVHja7cEBDQAAAMKg9U9tB20gIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgA8A7wAB2GArbAAAAABJRU5ErkJggg==";
        return { base64Image: mockBase64Image, cost: mockCost(site, aiProviderToApiKey(provider), 0) };
    }
    
    const ai = getAiClient(site, AiProvider.GOOGLE);
    const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/jpeg',
          aspectRatio: '16:9'
        },
    });

    const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
    const imageUrl = `data:image/jpeg;base64,${base64ImageBytes}`;
    
    return { base64Image: imageUrl, cost: mockCost(site, 'google', 0.04) };
};

export const regenerateArticleSection = async (site: Site, brief: StrategicBrief, heading: string, sectionHtml: string): Promise<{ regeneratedHtml: string; cost: { provider: keyof ApiKeys; amount: number } }> => {
    const ai = getAiClient(site, AiProvider.GOOGLE);
    const localSeoPrompt = buildLocalSeoPromptPart(site);
    const prompt = `Rewrite the following blog post section.\nHeading: ${heading}\nBrief: ${brief.topic}\n${localSeoPrompt}\nStart with <h2>${heading}</h2>.`;
    const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
    return { regeneratedHtml: `<h2>${heading}</h2><p>${response.text}</p>`, cost: mockCost(site, 'google', 0.0005) };
};

export const generateSocialGraphicAndCaption = async (site: Site, prompt: string, aspectRatio: '16:9' | '1:1' | '9:16', platformDescription: string, modelConfigOverride?: Partial<Site['modelConfig']>, characterId?: string): Promise<{ generationResult: { base64Image: string; caption: string; }; totalCost: { provider: keyof ApiKeys; amount: number } }> => {
    console.warn("aiServiceInternal.generateSocialGraphicAndCaption is a stub.");
    const base64Image = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAIAAABt+uBvAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABYSURBVO3BAQEAAAACIP1/2ko4KACw5wADAAAAAADg8wADAAAAAADg8wADAAAAAADg8wADAAAAAADg8wADAAAAAADg8wADAAAAAADg8wADAAAAAADg8wADAAAAAACwbwYVAAE8V39UAAAAAElFTkSuQmCC";
    const generationResult = { base64Image, caption: `A great caption about ${prompt} for ${platformDescription}. #tags` };
    return { generationResult, totalCost: mockCost(site, aiProviderToApiKey(site.modelConfig.imageProvider), 0.041) };
};

export const publishSocialGraphic = async (site: Site, generationResult: { imageUrl: string; caption: string; }): Promise<void> => {
    console.warn("aiServiceInternal.publishSocialGraphic is a stub.");
    return Promise.resolve();
};

export const generateSocialGraphicPrompt = async (site: Site): Promise<{ prompt: string; cost: { provider: keyof ApiKeys; amount: number } }> => {
    console.warn("aiServiceInternal.generateSocialGraphicPrompt is a stub.");
    return { prompt: 'A stunning, abstract representation of AI and creativity, vibrant colors.', cost: mockCost(site) };
};

export const brainstormContentIdeas = async (site: Site, theme: string, contentType: 'blog_post' | 'social_graphic' | 'email_campaign'): Promise<{ ideas: string[]; cost: { provider: keyof ApiKeys; amount: number } }> => {
    console.warn("aiServiceInternal.brainstormContentIdeas is a stub.");
    const ideas = [`Idea 1 for ${theme}`, `Idea 2 for ${theme}`, `Idea 3 for ${theme}`];
    return { ideas, cost: mockCost(site) };
};

export const generateBrandGuidelineFromUrl = async (url: string, site: Site): Promise<{ guideline: string; cost: { provider: keyof ApiKeys; amount: number } }> => {
    console.warn("aiServiceInternal.generateBrandGuidelineFromUrl is a stub.");
    return { guideline: `Generated brand guideline based on ${url}. Tone: professional. Audience: tech-savvy.`, cost: mockCost(site) };
};

export const suggestKeywords = async (existingKeywords: string, site: Site): Promise<{ suggestions: string[]; cost: { provider: keyof ApiKeys; amount: number } }> => {
    console.warn("aiServiceInternal.suggestKeywords is a stub.");
    const suggestions = ['suggested keyword 1', 'suggested keyword 2'];
    return { suggestions, cost: mockCost(site) };
};

export const suggestKeywordsFromUrl = async (url: string, existingKeywords: string, site: Site): Promise<{ suggestions: string[]; cost: { provider: keyof ApiKeys; amount: number } }> => {
    console.warn("aiServiceInternal.suggestKeywordsFromUrl is a stub.");
    const suggestions = [`keyword from ${url} 1`, `keyword from ${url} 2`];
    return { suggestions, cost: mockCost(site) };
};

export const findCommentingProspects = async (topic: string, site: Site): Promise<{ prospects: { url: string; title: string; description: string; }[]; cost: { provider: keyof ApiKeys; amount: number } }> => {
    console.warn("aiServiceInternal.findCommentingProspects is a stub.");
    const prospects = [{ url: 'https://example.com/blog/1', title: `Blog about ${topic}`, description: 'A great post on a relevant topic.' }];
    return { prospects, cost: mockCost(site) };
};

export const generateBlogComment = async (prospectUrl: string, ownPostTopic: string, site: Site): Promise<{ comment: string; cost: { provider: keyof ApiKeys; amount: number } }> => {
    console.warn("aiServiceInternal.generateBlogComment is a stub.");
    return { comment: `Great post! This reminds me of ${ownPostTopic}.`, cost: mockCost(site) };
};

export const checkBacklinkStatus = async (site: Site, link: MonitoredBacklink): Promise<{ status: MonitoredBacklink['status']; anchorText: string | null; }> => {
    console.warn("aiServiceInternal.checkBacklinkStatus is a stub.");
    return { status: 'active', anchorText: 'example link' };
};

export const generateStandaloneEmailCampaign = async (site: Site, topic: string): Promise<{ campaign: EmailMarketingCampaign; cost: { provider: keyof ApiKeys; amount: number } }> => {
    console.log(`[aiServiceInternal] Simulating email campaign generation for topic: "${topic}"`);
    const modelConfig = site.emailMarketingModelConfig || site.modelConfig;
    const ai = getAiClient(site, modelConfig.textProvider);
    const prompt = `Generate a compelling email newsletter about "${topic}". The output should be a JSON object with two keys: "subject" and "body". The body must be clean, well-formatted HTML, including headings, paragraphs, and lists.`;
    const response = await ai.models.generateContent({ model: modelConfig.textModel, contents: prompt, config: { responseMimeType: "application/json", responseSchema: { type: Type.OBJECT, properties: { subject: { type: Type.STRING }, body: { type: Type.STRING } } } } });
    const campaign = JSON.parse(response.text.trim());
    return { campaign, cost: mockCost(site, aiProviderToApiKey(modelConfig.textProvider), 0.002) };
};

export async function sendMailchimpCampaign(site: Site, campaign: EmailMarketingCampaign): Promise<void> {
    console.log(`[aiServiceInternal] SIMULATING sending Mailchimp campaign "${campaign.subject}" for site "${site.name}".`);
    await new Promise(resolve => setTimeout(resolve, 1000));
    if (!site.mailchimp?.isConnected || !site.mailchimp.defaultAudienceId) {
        throw new Error("Mailchimp is not connected or no default audience is selected.");
    }
    return Promise.resolve();
}

export async function findBestKeyword(seedKeyword: string, site: Site): Promise<{ bestKeyword: string; cost: { provider: keyof ApiKeys; amount: number } }> { console.warn("aiServiceInternal.findBestKeyword is a stub."); return { bestKeyword: `best long-tail for ${seedKeyword}`, cost: mockCost(site) }; }
export async function findSocialMediaProspects(site: Site): Promise<{ prospects: any[]; cost: { provider: keyof ApiKeys; amount: number } }> { console.warn("aiServiceInternal.findSocialMediaProspects is a stub."); return { prospects: [], cost: mockCost(site) }; }
export async function generateSocialMediaComment(site: Site, prospect: SocialCommentingProspect, sourcePost: PostHistoryItem): Promise<{ comment: string; cost: { provider: keyof ApiKeys; amount: number } }> { console.warn("aiServiceInternal.generateSocialMediaComment is a stub."); return { comment: "Great social media comment!", cost: mockCost(site) }; }
export async function generateAnalyticsInsights(site: Site, postData: PostPerformanceData): Promise<{ insights: AnalyticsInsight; cost: { provider: keyof ApiKeys; amount: number } }> { console.warn("aiServiceInternal.generateAnalyticsInsights is a stub."); const insights = { insights: ['Your CTR is above average.'], recommendations: [{ text: 'Update the title to be more engaging.', pro: false }] }; return { insights, cost: mockCost(site) }; }
export async function verifyMailchimpConnection(apiKey: string, serverPrefix: string): Promise<{ availableAudiences: { id: string, name: string }[] }> { console.warn("aiServiceInternal.verifyMailchimpConnection is a stub."); if (!apiKey.includes('-' + serverPrefix)) { throw new Error("API Key does not match server prefix (simulation)."); } return { availableAudiences: [{ id: '123', name: 'Test Audience' }] }; }

export async function generateSocialVideoAndCaption(site: Site, prompt: string, characterId?: string): Promise<{ generationResult: { videoUrl: string, caption: string }; totalCost: { provider: keyof ApiKeys; amount: number } }> {
    console.log(`[aiServiceInternal] Simulating video and caption generation for prompt: "${prompt}"`);
    const modelConfig = site.socialVideoAutomationModelConfig || site.modelConfig;
    const ai = getAiClient(site, modelConfig.textProvider);
    const captionPrompt = `Generate a short, engaging social media caption for a video about "${prompt}". Include 3-5 relevant hashtags.`;
    const response = await ai.models.generateContent({ model: modelConfig.textModel, contents: captionPrompt });
    const caption = response.text;
    const generationResult = {
        videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
        caption: caption
    };
    return { generationResult, totalCost: mockCost(site, aiProviderToApiKey(modelConfig.videoProvider || AiProvider.GOOGLE), 0.1) };
}

export async function generateSocialMediaPosts(post: BlogPost, postUrl: string, site: Site): Promise<{ posts: Record<string, SocialMediaPost>; cost: { provider: keyof ApiKeys; amount: number } }> { console.warn("aiServiceInternal.generateSocialMediaPosts is a stub."); const posts = { twitter: { content: `Check out our new post: ${post.title}! ${postUrl}`, hashtags: ['#blog', '#newpost'] }, facebook: { content: `We just published a new article: "${post.title}". Read it here: ${postUrl}`, hashtags: [] } }; return { posts, cost: mockCost(site) }; }
export async function generateEmailCampaignFromPost(post: BlogPost, postUrl: string, site: Site): Promise<{ campaign: EmailMarketingCampaign; cost: { provider: keyof ApiKeys; amount: number } }> { console.warn("aiServiceInternal.generateEmailCampaignFromPost is a stub."); const campaign = { subject: `New Post: ${post.title}`, body: `<p>Read our new post: <a href="${postUrl}">${post.title}</a></p>` }; return { campaign, cost: mockCost(site) }; }

// Fix: Removed the problematic publishSocialVideo function. Publishing logic is now in mcpApiService.ts.

export async function generateRssDigestEmail(site: Site, items: RssItem[]): Promise<{ campaign: EmailMarketingCampaign; cost: { provider: keyof ApiKeys; amount: number } }> {
    console.log(`[aiServiceInternal] Simulating RSS digest generation for ${items.length} items.`);
    const modelConfig = site.digestAutomationModelConfig || site.modelConfig;
    const ai = getAiClient(site, modelConfig.textProvider);
    const itemsMarkdown = items.map(item => `- **[${item.title}](${item.link})**: ${item.contentSnippet}`).join('\n');
    const prompt = `Generate a friendly, engaging weekly digest email summarizing the following new blog posts. The output should be a JSON object with "subject" and "body" (clean HTML). Include a brief intro and outro. Here are the posts:\n${itemsMarkdown}`;
    const response = await ai.models.generateContent({ model: modelConfig.textModel, contents: prompt, config: { responseMimeType: "application/json", responseSchema: { type: Type.OBJECT, properties: { subject: { type: Type.STRING }, body: { type: Type.STRING } } } } });
    const campaign = JSON.parse(response.text.trim());
    return { campaign, cost: mockCost(site, aiProviderToApiKey(modelConfig.textProvider), 0.003) };
}

export async function fetchPublishedPosts(site: Site) { console.warn("aiServiceInternal.fetchPublishedPosts is a stub."); return []; }
export async function verifyApiKey(provider: keyof ApiKeys, apiKey: string): Promise<{ success: boolean; message: string; }> { if (!apiKey) return { success: false, message: "API key is empty." }; if (apiKey.includes('invalid')) return { success: false, message: "The provided API key is invalid." }; return { success: true, message: "API Key appears valid (simulation)." }; }
export async function fetchAvailableModels(provider: AiProvider, apiKey: string) { await new Promise(resolve => setTimeout(resolve, 300)); return AVAILABLE_MODELS[provider as keyof typeof AVAILABLE_MODELS] || { text: [], image: [], video: [] }; }

export const generateStrategicBriefFromKeyword = async (topic: string, site: Site) => {
    // This is a simplified mock. A real implementation would be more complex.
    console.warn("aiServiceInternal.generateStrategicBriefFromKeyword is a stub.");
    const slug = topic.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    const brief: StrategicBrief = {
        topic, focusKeyword: topic, keywordCluster: [`${topic} benefits`, `best ${topic} practices`], targetAudience: 'Beginners', contentAngle: 'Informational Guide', entities: ['Core Concept 1'], competitorUrls: ['https://example.com/blog/topic'], internalLinks: [], seoTitle: `The Ultimate Guide to ${topic}`, metaDescription: `Learn everything about ${topic}.`, slug, imagePrompt: `A photorealistic image of ${topic}`, imageAltText: `A close-up of ${topic}`, categories: ['General'], tags: [topic.toLowerCase()], faq: [{ question: `What is ${topic}?`, answer: `${topic} is...` }], wordCount: 800, brandGuideline: site.brandGuideline, promoLink1: site.promoLink1, promoLink2: site.promoLink2, nicheTargeting: site.nicheTargeting, authorName: site.authorName, authorBio: '',
    };
    return { brief, cost: mockCost(site) };
};

export async function generateWebsitePlan(idea: string, site: Site): Promise<{ plan: WebsitePlan; cost: { provider: keyof ApiKeys; amount: number } }> {
    console.warn("aiServiceInternal.generateWebsitePlan is a stub.");
    const plan = {
        nameSuggestions: ['Creative Site', 'Idea Factory'],
        taglineSuggestions: ['Your ideas, realized.', 'Building the future.'],
        corePages: ['Home', 'About', 'Contact'],
        colorPalette: [{ hex: '#FFFFFF', name: 'White' }],
        typography: { heading: 'Inter', body: 'Roboto' },
        businessType: 'Blog',
        keywords: ['keyword1', 'keyword2'],
    };
    return { plan, cost: mockCost(site, 'google', 0.002) };
};

export async function create10WebSite(plan: WebsitePlan, logCallback: (message: string) => void): Promise<{ newSite: Site, siteUrl: string, adminUrl: string, adminUser: string, adminPass: string }> {
    logCallback("Initiating 10Web site creation...");
    await new Promise(r => setTimeout(r, 1000));
    logCallback("Provisioning server...");
    await new Promise(r => setTimeout(r, 2000));
    logCallback("Installing WordPress...");
    await new Promise(r => setTimeout(r, 1500));
    logCallback("Verifying new WordPress installation...");

    const newSiteId = crypto.randomUUID();
    const siteUrl = `https://${newSiteId.substring(0,8)}.10web.site`;
    const adminPass = `pass_${crypto.randomUUID().substring(0,8)}`;
    
    // Fulfilling the user's hint: The site name is derived from the plan's name suggestions, which acts as the "website title".
    const siteTitle = plan.nameSuggestions[0] || "New AI Website";
    logCallback(`Successfully connected to "${siteTitle}"`);

    // Create a new, complete site object from scratch.
    const newSite: Site = {
        id: newSiteId,
        name: siteTitle,
        wordpressUrl: siteUrl,
        wordpressUsername: 'admin',
        applicationPassword: adminPass,
        brandGuideline: `This website is for a ${plan.businessType} focused on ${plan.keywords.join(', ')}. The brand should feel [describe desired feeling, e.g., modern, rustic, professional]. The tone of voice is [describe tone, e.g., friendly, authoritative, witty].`,
        brandLogo: '',
        brandColors: plan.colorPalette.map(c => c.hex),
        brandFonts: [plan.typography.heading, plan.typography.body],
        promoLink1: '',
        promoLink2: '',
        nicheTargeting: plan.businessType,
        keywordList: plan.keywords.join('\n'),
        videoSources: [],
        references: [],
        characterLibrary: [],
        authorName: 'Admin',
        authorId: 1, // Assume default admin user ID is 1
        availableAuthors: [{ id: 1, name: 'admin', bio: '' }],
        availableCategories: [{ id: 1, name: 'Uncategorized' }],
        history: [],
        isAutomationEnabled: false, // Default to off for new sites
        automationTrigger: 'interval',
        automationIntervalHours: 24,
        recurringSchedules: [],
        isAutoPublishEnabled: false,
        drafts: [],
        isDraftNotificationEnabled: false,
        draftNotificationMethods: [],
        draftNotificationEmail: '',
        masterAutomationSource: 'keyword',
        intervalGenerationSource: 'keyword',
        scheduleGenerationSource: 'keyword',
        rssFeedUrl: '',
        processedRssGuids: [],
        googleSheetUrl: '',
        googleSheetProcessedRows: [],
        isLocalSeoEnabled: false,
        localSeoBusinessName: '',
        localSeoServiceArea: '',
        localSeoPhoneNumber: '',
        socialMediaSettings: defaultSocialSettings,
        seoDataProvider: 'google_search',
        modelConfig: defaultModelConfig,
        apiKeys: defaultApiKeys, // Start with empty keys, user must fill them in.
        apiUsage: defaultApiUsage,
        fetchedModels: {},
        dataforseoSeedKeywords: '', dataforseoTargetLocation: 'us', dataforseoTargetLanguage: 'en',
        dataforseoKeywordDifficultyMin: 0, dataforseoKeywordDifficultyMax: 30,
        dataforseoSearchVolumeMin: 500, dataforseoSearchVolumeMax: 10000,
        isSocialGraphicAutomationEnabled: false, socialGraphicAutomationTrigger: 'interval',
        socialGraphicAutomationIntervalHours: 48, socialGraphicRecurringSchedules: [],
        socialGraphicGenerationSource: 'keyword',
        isSocialVideoAutomationEnabled: false, socialVideoAutomationTrigger: 'interval',
        socialVideoAutomationIntervalHours: 72, socialVideoRecurringSchedules: [],
        socialVideoGenerationSource: 'keyword',
        googleDrive: { isConnected: false, userEmail: '' },
        googleAnalytics: { isConnected: false, userEmail: '' },
        isBacklinksAutomationEnabled: false,
        backlinksCompetitors: '',
        backlinksOwnDomain: siteUrl,
        backlinksEmailProvider: 'mailgun',
        backlinksFromName: siteTitle,
        backlinksFromEmail: '',
        backlinksEmailSubject: 'Regarding your article',
        backlinksEmailBody: 'Hi,\n\nI was just reading your article and really enjoyed it.\n\n[Personalization]\n\nI thought your readers might also find this resource useful. Let me know if you\'d be interested in taking a look.\n\nThanks,\n[Your Name]',
        backlinksHistory: [],
        backlinksIntervalHours: 168,
        commentingProspects: [],
        isSocialCommentingEnabled: false,
        socialCommentingKeywords: 'AI in marketing\n#SEOtips\ndigital strategy',
        socialCommentingGuideline: 'Write a positive and insightful comment. Ask a question to encourage a reply. Do not include links or self-promotion.',
        socialCommentingProspects: [],
        monitoredBacklinks: [],
        isBacklinkMonitoringEnabled: false,
        isEmailFollowUpEnabled: false,
        isSocialFollowUpEnabled: false,
        emailMarketingSettings: {
            fromName: siteTitle,
            fromEmail: '',
            targetList: '',
        },
        emailMarketingModelConfig: defaultModelConfig,
        isEmailMarketingAutomationEnabled: false,
        emailMarketingAutomationTrigger: 'interval',
        emailMarketingAutomationIntervalHours: 168,
        emailMarketingRecurringSchedules: [],
        isDigestAutomationEnabled: false,
        digestRecurringSchedules: [],
        processedDigestGuids: [],
        digestAutomationModelConfig: defaultModelConfig,
        mailchimp: { isConnected: false, apiKey: '', serverPrefix: '', status: 'disconnected' },
        automationLock: null,
        hosting: {
            isConnected: true,
            status: {
                isConnected: true,
                provider: '10web',
                siteTitle: siteTitle,
                performance: { score: 98, lastChecked: 'Just now' },
                security: { status: 'secure', lastScan: 'Just now', vulnerabilities: 0 },
                backups: { lastBackup: 'Just now', status: 'ok' },
                performanceHistory: [],
                recommendations: []
            }
        }
    };

    return {
        newSite,
        siteUrl: newSite.wordpressUrl,
        adminUrl: `${newSite.wordpressUrl}/wp-admin`,
        adminUser: newSite.wordpressUsername,
        adminPass: newSite.applicationPassword
    };
}