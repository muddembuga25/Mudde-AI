// services/selfTestService.ts
import type { Site } from '../types';
import * as mcpApiService from './mcpApiService';

// This service runs non-destructive tests on the application's features.

export type TestFunction = (site: Site) => Promise<{ success: boolean; message: string }>;

const runTest = async (testFn: () => Promise<any>): Promise<{ success: boolean; message: string }> => {
    try {
        // The test function might return the result object directly
        const result = await testFn();
        if (typeof result === 'object' && result !== null && 'success' in result && 'message' in result) {
            return result;
        }
        return { success: true, message: 'Test passed successfully.' };
    } catch (e: any) {
        return { success: false, message: e.message || 'An unknown error occurred.' };
    }
};

const allTests: { [key: string]: { name: string; test: TestFunction } } = {
    // --- Content Generation ---
    'gen_keyword': {
        name: 'Generate from Keyword',
        test: (site) => runTest(() => mcpApiService.generateStrategicBrief(site.id, 'keyword', 'test keyword'))
    },
    'gen_social_graphic': {
        name: 'Generate Social Graphic',
        test: (site) => runTest(() => mcpApiService.generateSocialGraphicAndCaption(site.id, 'test prompt', '1:1', 'test platform'))
    },
    // --- Automations ---
    'auto_blog': {
        name: 'Blog Post Automation',
        // Fix: Property 'runBlogPostAutomation' does not exist on type 'typeof import("file:///services/mcpApiService")'.
        test: (site) => runTest(() => mcpApiService.runBlogPostAutomation(site.id, null))
    },
    'auto_social_graphic': {
        name: 'Social Graphic Automation',
        // Fix: Property 'runSocialGraphicAutomation' does not exist on type 'typeof import("file:///services/mcpApiService")'.
        test: (site) => runTest(() => mcpApiService.runSocialGraphicAutomation(site.id, null))
    },
    'auto_email_marketing': {
        name: 'Email Marketing Automation',
        // Fix: Property 'runEmailMarketingAutomation' does not exist on type 'typeof import("file:///services/mcpApiService")'.
        test: (site) => runTest(() => mcpApiService.runEmailMarketingAutomation(site.id, null))
    },
    'auto_email_digest': {
        name: 'Email Digest Automation',
        // Fix: Property 'runDigestAutomation' does not exist on type 'typeof import("file:///services/mcpApiService")'.
        test: (site) => runTest(() => mcpApiService.runDigestAutomation(site.id, null))
    },
    // --- WordPress Integration Health ---
    'wp_connect': {
        name: 'REST API Connection',
        test: (site) => {
             if (!site.wordpressUrl || !site.wordpressUsername || !site.applicationPassword) {
                return Promise.resolve({ success: false, message: 'WP credentials not configured.' });
            }
            return runTest(() => mcpApiService.verifyWordPressConnection(site.id));
        }
    },
    'wp_authors': {
        name: 'Author Permissions',
        // Fix: Property 'testWpAuthorPermissions' does not exist on type 'typeof import("file:///services/mcpApiService")'.
        test: (site) => runTest(() => mcpApiService.testWpAuthorPermissions(site.id))
    },
    'wp_categories': {
        name: 'Category Permissions',
        // Fix: Property 'testWpCategoryPermissions' does not exist on type 'typeof import("file:///services/mcpApiService")'.
        test: (site) => runTest(() => mcpApiService.testWpCategoryPermissions(site.id))
    },
    'wp_media': {
        name: 'Media Upload & Delete',
        // Fix: Property 'testWpMediaPermissions' does not exist on type 'typeof import("file:///services/mcpApiService")'.
        test: (site) => runTest(() => mcpApiService.testWpMediaPermissions(site.id))
    },
    'wp_posts': {
        name: 'Post Create & Delete',
        // Fix: Property 'testWpPostPermissions' does not exist on type 'typeof import("file:///services/mcpApiService")'.
        test: (site) => runTest(() => mcpApiService.testWpPostPermissions(site.id))
    },
    // --- Other Integrations ---
    'int_mailchimp': {
        name: 'Mailchimp Connection',
        test: async (site) => {
             if (!site.mailchimp?.apiKey || !site.mailchimp?.serverPrefix) {
                return { success: false, message: 'Mailchimp credentials not configured.' };
            }
            // Fix: Property 'verifyMailchimpConnection' does not exist on type 'typeof import("file:///services/mcpApiService")'.
            const result = await mcpApiService.verifyMailchimpConnection(site.id);
            return { success: result.success, message: result.message };
        }
    },
    'int_google_drive': {
        name: 'Google Drive Connection',
        test: async (site) => {
            if (!site.googleDrive?.isConnected) return { success: true, message: 'Integration not enabled, skipping test.'};
            // Fix: Property 'verifyGoogleConnection' does not exist on type 'typeof import("file:///services/mcpApiService")'.
            const result = await mcpApiService.verifyGoogleConnection(site.id, 'drive');
            return { success: result.success, message: result.message };
        }
    },
    // --- Authority Building ---
    'auth_blog_comment_prospects': {
        name: 'Find Blog Comment Prospects',
        test: (site) => runTest(() => mcpApiService.findCommentingProspects('test topic', site.id))
    },
    'auth_social_comment_prospects': {
        name: 'Find Social Comment Prospects',
        test: (site) => runTest(() => mcpApiService.findSocialMediaProspects(site.id))
    },
    'auth_backlink_check': {
        name: 'Check Backlink Status',
        test: (site) => runTest(() => mcpApiService.checkBacklinkStatus(site.id, {
            id: 'test', url: 'https://example.com', targetUrl: site.backlinksOwnDomain || 'https://example.com/target',
            status: 'pending', anchorText: '', dateFound: 0, lastChecked: 0, domainAuthority: 0
        }))
    },
};

export const testCategories = {
    'Content Generation': ['gen_keyword', 'gen_social_graphic'],
    'Automations': ['auto_blog', 'auto_social_graphic', 'auto_email_marketing', 'auto_email_digest'],
    'WordPress Integration Health': ['wp_connect', 'wp_authors', 'wp_categories', 'wp_media', 'wp_posts'],
    'Other Integrations': ['int_mailchimp', 'int_google_drive'],
    'Authority Building': ['auth_blog_comment_prospects', 'auth_social_comment_prospects', 'auth_backlink_check']
};

export const getTestById = (id: string): { name: string; test: TestFunction } => {
    return allTests[id];
};