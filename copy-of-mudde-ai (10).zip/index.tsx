import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { AuthProvider } from './contexts/AuthContext';
import { SitesProvider } from './contexts/SitesContext';
import { GodModeProvider } from './contexts/GodModeContext';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <AuthProvider>
      <BrowserRouter>
        <SitesProvider>
          <GodModeProvider>
            <App />
          </GodModeProvider>
        </SitesProvider>
      </BrowserRouter>
    </AuthProvider>
  </React.StrictMode>
);