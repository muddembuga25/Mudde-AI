import React from 'react';
import { useAuth } from './contexts/AuthContext';
import { AuthScreen } from './components/AuthScreen';
import { MainApp } from './MainApp';
import { GodModeApp } from './components/GodMode/GodModeApp';
import { LogoIcon } from './components/Icons';
import { useGodMode } from './contexts/GodModeContext';

const App: React.FC = () => {
  const { currentUser, isLoading } = useAuth();
  const { isGodModeActive } = useGodMode();

  if (isLoading) {
    return (
      <div className="h-full flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
            <div className="relative h-20 w-20">
              <div className="absolute inset-0 bg-indigo-500/30 rounded-full animate-ping"></div>
              <div className="relative bg-panel p-4 rounded-full border border-border">
                <LogoIcon />
              </div>
            </div>
            <p className="text-text-secondary animate-pulse">Connecting to MCP Server...</p>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return <AuthScreen />;
  }
  
  if (isGodModeActive) {
      return <GodModeApp />;
  }

  return <MainApp />;
};

export default App;