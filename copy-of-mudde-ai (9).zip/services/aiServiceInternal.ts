// This file contains the core AI logic that was previously in aiService.ts.
// It is now called by the mcpApiService, which acts as a secure wrapper.

import type { Site, ApiKeys, RssItem, BlogPost, SocialMediaPost, EmailMarketingCampaign, StrategicBrief, CommentingProspect, MonitoredBacklink, AnalyticsInsight, PostPerformanceData, SocialMediaSettings, SocialMediaAccount, MailchimpAccount, SocialCommentingProspect, PostHistoryItem, SeoChecklist } from '../types';
import { AiProvider } from '../types';
import { GoogleGenAI, Type } from "@google/genai";
import * as socialMediaService from './socialMediaService';
import * as dataforseoService from './dataforseoService';
import type { SocialPlatform } from './oauthService';
import { AVAILABLE_MODELS } from '../constants';
import { checkReadability } from './seoService';

export const aiProviderToApiKey = (provider: AiProvider): keyof ApiKeys => {
    switch (provider) {
        case AiProvider.GOOGLE: return 'google';
        case AiProvider.OPENAI: return 'openAI';
        case AiProvider.OPENROUTER: return 'openRouter';
        case AiProvider.ANTHROPIC: return 'anthropic';
        case AiProvider.XAI: return 'xai';
        case AiProvider.REPLICATE: return 'replicate';
        case AiProvider.FREEPIK: return 'freepik';
        case AiProvider.FALAI: return 'falai';
        case AiProvider.PERPLEXITY: return 'perplexity';
        default: return 'google';
    }
};

const getAiClient = (site: Site, provider: AiProvider) => {
    let apiKey: string | undefined;

    if (provider === AiProvider.GOOGLE) {
        // If the user has entered a specific Google key for the site, use it.
        // Otherwise, fall back to the pre-configured environment key for development.
        apiKey = site.apiKeys.google || process.env.API_KEY;
    } else {
        // For all other providers, use the key specified for the site.
        apiKey = site.apiKeys[aiProviderToApiKey(provider)];
    }

    if (!apiKey) {
        throw new Error(`${provider} API key not found. Please add it in the API Keys tab.`);
    }

    // Currently only supports GoogleGenAI, but could be extended
    return new GoogleGenAI({ apiKey });
};


// --- Cost Simulation ---
const mockCost = (site: Site, providerOverride?: keyof ApiKeys, amount: number = 0.001) => ({
    provider: providerOverride || aiProviderToApiKey(site.modelConfig.textProvider),
    amount
});


// --- Exported Functions ---

export const fetchPublishedPosts = async (site: Site) => {
    console.warn("aiServiceInternal.fetchPublishedPosts is a stub.");
    return [];
};

export const verifyApiKey = async (provider: keyof ApiKeys, apiKey: string): Promise<{ success: boolean; message: string; }> => {
    if (!apiKey) return { success: false, message: "API key is empty." };
    if (provider === 'google') {
        try {
            const ai = new GoogleGenAI({ apiKey });
            await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: 'test' });
            return { success: true, message: "API Key is valid and connected to Google AI." };
        } catch (e: any) {
            return { success: false, message: e.message || "Invalid Google API Key." };
        }
    }
    // Simulate for others
    if (apiKey.includes('invalid')) return { success: false, message: "The provided API key is invalid." };
    return { success: true, message: "API Key appears valid (simulation)." };
};

export const fetchAvailableModels = async (provider: AiProvider, apiKey: string) => {
    console.warn(`Simulating fetchAvailableModels for ${provider}. Returning defaults.`);
    // In a real app, this would make an API call to the provider using the apiKey.
    // For this simulation, we'll just return the static list from constants.
    // We add a small fake latency.
    await new Promise(resolve => setTimeout(resolve, 300));
    return AVAILABLE_MODELS[provider as keyof typeof AVAILABLE_MODELS] || { text: [], image: [], video: [] };
};

const buildLocalSeoPromptPart = (site: Site): string => {
    if (!site.isLocalSeoEnabled || !site.localSeoServiceArea) {
        return '';
    }

    let localPrompt = `
        **Local SEO Targeting is ENABLED.**
        The content MUST be tailored for the following local context:
        - **Location/Service Area:** ${site.localSeoServiceArea}
    `;

    if (site.localSeoBusinessName) {
        localPrompt += `\n- **Business Name:** ${site.localSeoBusinessName}`;
    }
    if (site.localSeoPhoneNumber) {
        localPrompt += `\n- **Business Phone Number:** ${site.localSeoPhoneNumber}`;
    }

    localPrompt += `
        Incorporate local elements naturally. Mention local landmarks, neighborhoods, or events if relevant. The tone should appeal to a local audience.
        If a business name and phone number are provided, ensure they are included in a call-to-action or contact information section.
        The generated FAQs should be relevant to local search intent (e.g., "Where can I find... in [City]").
    `;

    return localPrompt.trim();
};

const _getGoogleAnalysis = async (topic: string, site: Site) => {
    const ai = getAiClient(site, AiProvider.GOOGLE);
    const nichePrompt = site.nicheTargeting ? ` within the niche of "${site.nicheTargeting}"` : '';
    const locationPrompt = site.isLocalSeoEnabled && site.localSeoServiceArea ? ` for the location "${site.localSeoServiceArea}"` : '';
    
    // First call: Get a grounded summary and competitor URLs from grounding metadata.
    const groundedResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Provide a detailed SEO analysis and summary of the top search results for the keyword "${topic}"${locationPrompt}${nichePrompt}. Include common themes, user intent, and frequently asked questions. Critically, analyze the dominant content format of the top-ranking pages (e.g., "Listicle", "How-To Guide", "Comparison Review", "News Article", "Informational Guide").`,
        config: {
            tools: [{ googleSearch: {} }],
        }
    });

    const chunks = groundedResponse.candidates?.[0]?.groundingMetadata?.groundingChunks;
    const competitorUrls = chunks?.map(chunk => (chunk as any).web.uri).filter(Boolean) || [];
    
    // Second call: Extract structured data (FAQ, Entities, contentAngle) from the grounded text.
    const extractionPrompt = `
        From the following text, extract four things:
        1.  A list of frequently asked questions with concise answers.
        2.  A list of 5-7 key semantically related keywords and entities (people, concepts, products) that are essential for demonstrating topical authority on the main subject. This should be a mix of broad concepts and specific long-tail terms. Call this "keywordCluster".
        3.  A separate, broader list of general entities.
        4.  The dominant content format or angle (e.g., "Listicle", "How-To Guide", "Comparison Review").

        Return the result as a single, clean JSON object with four keys: "faq", "keywordCluster", "entities", and "contentAngle".
        Do not include any other text, markdown formatting, or explanations. Just the raw JSON object.

        Text to analyze:
        ---
        ${groundedResponse.text}
        ---
    `;

    const extractionResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: extractionPrompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    faq: { 
                        type: Type.ARRAY, 
                        items: { 
                            type: Type.OBJECT, 
                            properties: { 
                                question: { type: Type.STRING }, 
                                answer: { type: Type.STRING } 
                            },
                            required: ["question", "answer"]
                        } 
                    },
                    keywordCluster: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING }
                    },
                    entities: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING }
                    },
                    contentAngle: {
                        type: Type.STRING,
                        description: "The dominant content format of the top search results."
                    }
                },
                required: ["faq", "keywordCluster", "entities", "contentAngle"]
            }
        }
    });

    const extractedData = JSON.parse(extractionResponse.text);

    return {
        competitorUrls: competitorUrls.slice(0, 5), // Limit to top 5 competitors
        faq: extractedData.faq || [],
        keywordCluster: extractedData.keywordCluster || [],
        entities: extractedData.entities || [],
        contentAngle: extractedData.contentAngle || 'Informational Guide'
    };
};

const _getDataForSeoAnalysis = async (topic: string, site: Site) => {
    console.log(`[DataForSEO] Using live API to get SERP and keyword data for: "${topic}".`);
    return await dataforseoService.getAdvancedSeoAnalysis(topic, site);
};

const _getLLMAnalysis = async (
    topic: string,
    site: Site,
    analysisProvider: AiProvider,
    dataForSeoData?: any // Data from _getDataForSeoAnalysis
): Promise<{ analysisData: any; cost: { provider: keyof ApiKeys; amount: number } }> => {

    const ai = getAiClient(site, analysisProvider);
    // Determine model to use based on provider
    let model: string;
    switch (analysisProvider) {
        case AiProvider.OPENAI: model = 'gpt-4o'; break;
        case AiProvider.XAI: model = 'grok-1'; break;
        case AiProvider.PERPLEXITY: model = 'llama-3-sonar-large-32k-online'; break;
        case AiProvider.OPENROUTER: model = site.modelConfig.textModel; break;
        default: model = 'gemini-2.5-flash';
    }
    
    let contextPrompt = '';
    if (dataForSeoData) {
        contextPrompt = `You have been provided with the following rich SEO data from the DataForSEO API. Use this as your primary source of truth for the analysis. Data: ${JSON.stringify(dataForSeoData)}`;
    } else {
        contextPrompt = `You will be using your internal knowledge to perform the analysis.`;
    }

    const nichePrompt = site.nicheTargeting ? ` within the niche of "${site.nicheTargeting}"` : '';
    const locationPrompt = site.isLocalSeoEnabled && site.localSeoServiceArea ? ` for the location "${site.localSeoServiceArea}"` : '';

    const prompt = `
        You are an SEO expert. Analyze the topic "${topic}"${locationPrompt}${nichePrompt}.
        ${contextPrompt}
        Based on your analysis, provide a list of likely competitor URLs, a list of frequently asked questions with concise answers, a keyword cluster of 5-7 related terms, a list of key related entities, and the most common content format (e.g., "Listicle", "How-To Guide").
        
        Return the result as a single, clean JSON object with keys: "competitorUrls", "faq", "keywordCluster", "entities", "contentAngle".
    `;

    const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    competitorUrls: { type: Type.ARRAY, items: { type: Type.STRING } },
                    faq: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { question: { type: Type.STRING }, answer: { type: Type.STRING } }, required: ["question", "answer"] } },
                    keywordCluster: { type: Type.ARRAY, items: { type: Type.STRING } },
                    entities: { type: Type.ARRAY, items: { type: Type.STRING } },
                    contentAngle: { type: Type.STRING }
                },
                required: ["competitorUrls", "faq", "keywordCluster", "entities", "contentAngle"]
            }
        }
    });

    const analysisData = JSON.parse(response.text);
    const cost = mockCost(site, aiProviderToApiKey(analysisProvider), dataForSeoData ? 0.002 : 0.001);

    return { analysisData, cost };
};

export const generateStrategicBriefFromKeyword = async (topic: string, site: Site) => {
    let analysisData;
    let cost = mockCost(site);
    
    const provider = site.seoDataProvider;

    if (provider === 'google_search') {
        analysisData = await _getGoogleAnalysis(topic, site);
        cost = { provider: 'google', amount: 0.001 };
    } else if (provider.startsWith('dataforseo_')) {
        if (!site.apiKeys.dataforseo) throw new Error("DataForSEO API key is required for this provider.");
        const dataForSeoData = await _getDataForSeoAnalysis(topic, site);
        cost = { provider: 'dataforseo', amount: 0.05 };
        
        const analysisProviderMap: Record<string, AiProvider> = {
            'dataforseo_gemini': AiProvider.GOOGLE,
            'dataforseo_openai': AiProvider.OPENAI,
            'dataforseo_xai': AiProvider.XAI,
            'dataforseo_perplexity': AiProvider.PERPLEXITY,
        };
        const llmProvider = analysisProviderMap[provider];
        
        const llmResult = await _getLLMAnalysis(topic, site, llmProvider, dataForSeoData);
        analysisData = llmResult.analysisData;
        // This is a bit tricky for cost. We log the DataForSEO cost, and the LLM analysis cost will be logged separately.
        // For simplicity, let's just create a combined cost object to return for now.
        const llmCost = mockCost(site, aiProviderToApiKey(llmProvider), 0.002);
        // This won't be logged yet, just used internally. The final cost is logged by the caller.
    } else if (provider.startsWith('standalone_')) {
        const analysisProviderMap: Record<string, AiProvider> = {
            'standalone_gemini': AiProvider.GOOGLE,
            'standalone_openai': AiProvider.OPENAI,
            'standalone_xai': AiProvider.XAI,
            'standalone_perplexity': AiProvider.PERPLEXITY,
            'standalone_openrouter': AiProvider.OPENROUTER,
        };
        const llmProvider = analysisProviderMap[provider];
        const llmResult = await _getLLMAnalysis(topic, site, llmProvider);
        analysisData = llmResult.analysisData;
        cost = llmResult.cost;
    } else {
        // Fallback to default
        analysisData = await _getGoogleAnalysis(topic, site);
        cost = { provider: 'google', amount: 0.001 };
    }

    const localSeoInstructions = buildLocalSeoPromptPart(site);
    
    let finalBrandGuideline = (site.brandGuideline || '') + '\n' + localSeoInstructions;
    if (!site.nicheTargeting && site.wordpressUrl) {
        const websiteContext = `The content should be suitable for a website with this URL: ${site.wordpressUrl}. The AI should infer the website's niche from its content.`;
        finalBrandGuideline = finalBrandGuideline ? `${finalBrandGuideline}\n${websiteContext}` : websiteContext;
    }

    const publishedPosts = site.history
        .filter(p => p.url && p.url !== '#')
        .map(p => ({ title: p.topic, link: p.url }));

    const ai = getAiClient(site, site.modelConfig.textProvider);

    const briefEnhancementPrompt = `
      You are an SEO strategist creating a content brief. Based on the provided analysis and site context, generate the final components for the brief.
      
      Topic: "${topic}"
      
      Available published posts on the site:
      ${publishedPosts.length > 0 ? JSON.stringify(publishedPosts) : "None"}

      Author Name: "${site.authorName}"
      Author Bio from WordPress: "${site.availableAuthors?.find(a => a.id === site.authorId)?.bio || 'Not available.'}"

      **Your Tasks:**
      1.  **Internal Links:** From the list of available posts, select up to 3 that are most semantically relevant to the topic.
      2.  **Author Bio:** Based on the author's name, existing bio, and the current topic, write a concise, one-paragraph expert bio (around 30-50 words) that establishes their authority on this subject. If no bio is available, create a plausible one.
      3.  **SEO Title:** Create a compelling, SEO-optimized title for the article, between 50 and 60 characters long.
      4.  **Meta Description:** Write an engaging meta description (between 120 and 155 characters) that includes the focus keyword.

      Return a single, clean JSON object with the keys: "internalLinks", "authorBio", "seoTitle", "metaDescription".
      "internalLinks" should be an array of objects with "title" and "link" properties.
    `;

    const enhancementResponse = await ai.models.generateContent({
        model: site.modelConfig.textModel,
        contents: briefEnhancementPrompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    internalLinks: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { title: { type: Type.STRING }, link: { type: Type.STRING } } } },
                    authorBio: { type: Type.STRING },
                    seoTitle: { type: Type.STRING },
                    metaDescription: { type: Type.STRING }
                },
                required: ["internalLinks", "authorBio", "seoTitle", "metaDescription"]
            }
        }
    });

    const enhancedData = JSON.parse(enhancementResponse.text);

    const brief: StrategicBrief = {
      topic,
      focusKeyword: topic,
      keywordCluster: analysisData.keywordCluster || [],
      targetAudience: 'General Audience',
      contentAngle: analysisData.contentAngle || 'Informative and engaging',
      entities: analysisData.entities || [],
      competitorUrls: analysisData.competitorUrls,
      internalLinks: enhancedData.internalLinks || [],
      seoTitle: enhancedData.seoTitle,
      metaDescription: enhancedData.metaDescription,
      slug: topic.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-'),
      imagePrompt: `A high-quality, photorealistic image related to ${topic}, suitable for a blog post header. The style should match a website with this brand guideline: "${site.brandGuideline}"`,
      imageAltText: `An illustrative image for an article about ${topic}`,
      categories: ['General'],
      tags: [topic.toLowerCase(), ...analysisData.entities.slice(0, 4).map((e: string) => e.toLowerCase())],
      faq: analysisData.faq,
      wordCount: 1200,
      brandGuideline: finalBrandGuideline.trim(),
      brandLogo: site.brandLogo,
      brandColors: site.brandColors,
      brandFonts: site.brandFonts,
      promoLink1: site.promoLink1,
      promoLink2: site.promoLink2,
      authorName: site.authorName,
      authorBio: enhancedData.authorBio,
      nicheTargeting: site.nicheTargeting,
    };
    
    return { brief, cost };
};

export const generateStrategicBriefFromRssItem = async (item: RssItem, site: Site) => {
     return generateStrategicBriefFromKeyword(item.title, site);
}
export const generateStrategicBriefFromVideoUrl = async (url: string, site: Site, options?: any) => {
     return generateStrategicBriefFromKeyword(`Summary of Video: ${url}`, site);
}
export const generateStrategicBriefFromGoogleSheetRow = async (row: any, site: Site) => {
     return generateStrategicBriefFromKeyword(row.topic, site);
}

export const fleshOutBrief = async (partialBrief: Partial<StrategicBrief>, site: Site): Promise<{ brief: StrategicBrief; cost: { provider: keyof ApiKeys; amount: number; }; }> => {
    if (!partialBrief.topic) {
        throw new Error("Topic is required to flesh out a brief.");
    }

    // Reuse the full generation logic to ensure all fields are populated.
    const { brief: fullBrief, cost } = await generateStrategicBriefFromKeyword(partialBrief.topic, site);

    // Then, merge the user-provided specifics over the generated base.
    const finalBrief: StrategicBrief = {
        ...fullBrief,
        ...partialBrief,
    };
    
    return { brief: finalBrief, cost };
};

export const generateArticleFromBrief = async (brief: StrategicBrief, site: Site) => {
    const ai = getAiClient(site, site.modelConfig.textProvider);
    const nicheInstruction = brief.nicheTargeting ? `\n- The content should be specifically tailored for this niche: "${brief.nicheTargeting}".` : '';
    
    let brandingInstructions = `- Adhere to the brand guideline: "${brief.brandGuideline}"`;
    if (brief.brandColors && brief.brandColors.length > 0) {
        brandingInstructions += `\n- Use brand colors for styling inspiration if describing visual elements: ${brief.brandColors.join(', ')}.`;
    }

    const eeatInstructions = `
    **E-E-A-T (Experience, Expertise, Authoritativeness, Trustworthiness) REQUIREMENTS:** This is the most important part of the task. You MUST follow these instructions precisely.
    - **Author Persona:** Write the entire article from the first-person perspective of an expert named "${brief.authorName}". This author's bio is: "${brief.authorBio}". The tone and content must reflect this persona's deep expertise.
    - **Demonstrate Experience:** Use first-person phrases (e.g., "I've found that...", "In my experience...", "My recommendation is...") to demonstrate hands-on experience. This is not optional.
    - **Build Trust:** Find and cite 1-2 high-authority, non-competing external sources (e.g., from research institutions, universities, or reputable industry publications) to back up key claims.
    - **Content Angle:** The content format MUST be a "${brief.contentAngle}". Structure the article headings and flow accordingly. If it's a "Listicle", use numbered headings. If it's a "How-To Guide", use clear, sequential steps. This is a strict requirement.
    - **Author Bio Section:** The article MUST end with an H3 section titled "About the Author", followed by a paragraph containing the author's bio provided in this brief. This must be the very last element in the HTML.
    `;

    const prompt = `
    You are an expert SEO content writer and subject matter expert. Your task is to generate a 100% SEO-optimized, comprehensive, and engaging blog post based on the provided strategic brief. The output must be a single block of clean HTML content, ready for publishing.

    **MANDATORY STRUCTURE & UX REQUIREMENTS:**
    1.  **Key Takeaways:** Immediately after the first H2 heading, include a "Key Takeaways" section. This should be a styled \`div\` containing a \`ul\` with 3-4 concise bullet points summarizing the article's most important information.
    2.  **Table of Contents:** After the "Key Takeaways" section, include a "Table of Contents". This should be an \`h3\` titled "Table of Contents" followed by a \`ul\` where each \`li\` contains an \`a\` tag linking to an H2 heading's ID. The H2 tags must have corresponding IDs (e.g., \`<h2 id="section-1">Section 1</h2>\` and \`<li><a href="#section-1">Section 1</a></li>\`).

    **MANDATORY READABILITY & STYLE GUIDE:** This is a non-negotiable requirement.
    - **Paragraph Length:** NO paragraph may exceed 150 words. Break complex ideas into multiple short paragraphs.
    - **Sentence Length:** Keep sentences short and direct. The average sentence length MUST be under 20 words.
    - **Active Voice:** Use the active voice almost exclusively.

    ${eeatInstructions}

    **CRITICAL SEO REQUIREMENTS:**
    1.  **Keyword Usage:** The focus keyword "${brief.focusKeyword}" MUST be included in the first paragraph, at least one H2 heading, and naturally throughout the content (~1-1.5% density).
    2.  **Topical Authority:** The article's structure and headings should be based on the provided Keyword Cluster. Cover these topics to build authority: ${brief.keywordCluster.join(', ')}.
    3.  **Linking:**
        - **Internal Links:** You MUST contextually embed the following internal links within relevant sentences in the article body. DO NOT just list them. Links: ${JSON.stringify(brief.internalLinks)}.
        - **External Links:** Find and cite 1-2 authoritative, non-competing external sources to back up claims, using your search tool.
        - **Promotional Links:** If provided, naturally integrate these links: Promo Link 1: ${brief.promoLink1 || 'N/A'}, Promo Link 2: ${brief.promoLink2 || 'N/A'}.
    4.  **FAQ Section:** If a FAQ is provided, create a final H2 section titled "Frequently Asked Questions" and include all questions and answers. This section must appear *before* the "About the Author" section.
    5.  **Schema Markup:** Include a complete JSON-LD schema inside a \`<script type="application/ld+json">\` tag at the very end. The schema MUST be a single object with \`@context: "https://schema.org"\` and \`@graph\` containing multiple entities:
        - A \`BlogPosting\` entity for the article.
        - A \`Person\` entity for the author ("${brief.authorName}"), including their bio in the \`description\` and a placeholder for social profiles (\`sameAs\`).
        - An \`Organization\` entity for the website.
        - If the content angle is a "How-To Guide", include a \`HowTo\` schema.
        - A \`FAQPage\` schema containing all the questions and answers from the brief.
        - Use "[FEATURED_IMAGE_URL]" as a placeholder for all image URLs.

    **Strategic Brief (for context):**
    ${JSON.stringify(brief, null, 2)}

    Now, generate the complete, clean HTML for the blog post. Your response must be ONLY the raw HTML content. Do not wrap the output in \`\`\`html, \`\`\`, \`<html>\`, or \`<body>\` tags. The response should start directly with the first heading tag (e.g., \`<h2>\`).
    `;
    
    const response = await ai.models.generateContent({ 
        model: site.modelConfig.textModel, 
        contents: prompt,
        config: {
            tools: [{ googleSearch: {} }],
        }
    });
    
    let content = response.text.trim();
    if (content.startsWith('```html')) {
        content = content.substring(7).trim();
    }
    if (content.endsWith('```')) {
        content = content.substring(0, content.length - 3).trim();
    }

    const postData: Omit<BlogPost, 'imageUrl'> = {
        title: brief.seoTitle,
        content: content,
        seoTitle: brief.seoTitle,
        metaDescription: brief.metaDescription,
        slug: brief.slug,
        excerpt: brief.metaDescription,
        categories: brief.categories,
        tags: brief.tags,
        imagePrompt: brief.imagePrompt,
        imageAltText: brief.imageAltText,
        focusKeyword: brief.focusKeyword,
    };
    return { postData, cost: mockCost(site, undefined, 0.002) };
};

// Helper function for the SEO Auditor Agent
async function runSeoAuditorAgent(html: string, brief: StrategicBrief, site: Site): Promise<{ seoReport: Record<string, { passed: boolean; notes: string }>; cost: { provider: keyof ApiKeys; amount: number } }> {
    const ai = getAiClient(site, AiProvider.GOOGLE); // Use Google for analysis
    
    const prompt = `
        You are a meticulous SEO auditing tool. Your task is to audit a draft HTML article against its strategic brief.
        Your goal is to identify specific, actionable ways to improve the article to better match the SERP data and user intent outlined in the brief.
        Your output MUST be a valid JSON object. Do not include any other text or markdown.
        The JSON object should have keys corresponding to the checks below. For each key, the value should be an object with two properties: "passed" (boolean) and "notes" (a string explaining the reason if it failed, or "OK" if it passed). The notes must be concise and actionable feedback for a rewrite agent.

        **Strategic Brief for Analysis:**
        - Focus Keyword: "${brief.focusKeyword}"
        - Content Angle: "${brief.contentAngle}"
        - Keyword Cluster (must be covered): ${JSON.stringify(brief.keywordCluster)}
        - Entities (should be mentioned): ${JSON.stringify(brief.entities)}
        - FAQ Section (must include all questions): ${JSON.stringify(brief.faq.map(f => f.question))}

        **HTML Content to Analyze:**
        \`\`\`html
        ${html}
        \`\`\`

        **Perform these checks:**
        1. "contentAngleAlignment": Does the article's structure, tone, and format match the required "${brief.contentAngle}"? If not, what specific changes are needed (e.g., "Add a product comparison table," "Structure as a step-by-step guide")?
        2. "keywordClusterCoverage": Does the article content adequately cover all topics from the keyword cluster? List any missing keywords/topics.
        3. "entityCoverage": Are the key entities mentioned naturally in the text? List any important missing entities.
        4. "faqImplementation": Is there an H2 section for "Frequently Asked Questions" that includes all the required questions from the brief?
        5. "semanticDepth": Does the article's semantic depth and structure reflect what's needed to rank for "${brief.focusKeyword}" based on the brief? Suggest any missing sub-topics or sections that top competitors might cover.
        6. "eeatAndReadability": Does the article maintain the author's voice, use first-person experience ("I've found", "in my experience"), and have good readability (short sentences/paragraphs)? This is a general quality check.
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    contentAngleAlignment: { type: Type.OBJECT, properties: { passed: { type: Type.BOOLEAN }, notes: { type: Type.STRING } } },
                    keywordClusterCoverage: { type: Type.OBJECT, properties: { passed: { type: Type.BOOLEAN }, notes: { type: Type.STRING } } },
                    entityCoverage: { type: Type.OBJECT, properties: { passed: { type: Type.BOOLEAN }, notes: { type: Type.STRING } } },
                    faqImplementation: { type: Type.OBJECT, properties: { passed: { type: Type.BOOLEAN }, notes: { type: Type.STRING } } },
                    semanticDepth: { type: Type.OBJECT, properties: { passed: { type: Type.BOOLEAN }, notes: { type: Type.STRING } } },
                    eeatAndReadability: { type: Type.OBJECT, properties: { passed: { type: Type.BOOLEAN }, notes: { type: Type.STRING } } }
                }
            }
        }
    });

    const seoReport = JSON.parse(response.text);
    return { seoReport, cost: mockCost(site, 'google', 0.0005) };
}

// Helper function for the Rewrite Agent
async function runRewriteAgent(html: string, brief: StrategicBrief, failedChecks: string[], site: Site): Promise<{ rewrittenHtml: string; cost: { provider: keyof ApiKeys; amount: number } }> {
    const ai = getAiClient(site, site.modelConfig.textProvider);

    const prompt = `
        You are a surgical SEO copy editor. Your task is to revise the provided HTML blog post to fix specific issues identified by an SEO audit.
        You must perform **surgical edits**. This means you should change as little as possible while still addressing the feedback. Do not rewrite the entire article. Focus on adding, removing, or rephrasing sentences or small sections to meet the requirements.

        **Strategic Brief for Context:**
        ${JSON.stringify({
            topic: brief.topic,
            focusKeyword: brief.focusKeyword,
            authorName: brief.authorName,
            brandGuideline: brief.brandGuideline,
            internalLinks: brief.internalLinks
        }, null, 2)}
        
        **ISSUES TO FIX (MUST ADDRESS ALL):**
        - ${failedChecks.join('\n- ')}

        **Original HTML Draft:**
        \`\`\`html
        ${html}
        \`\`\`

        Return only the revised, complete, and clean HTML content. Your response must be ONLY the raw HTML content. Do not wrap the output in \`\`\`html, \`\`\`, \`<html>\`, or \`<body>\` tags. The response should start directly with the first heading tag (e.g., \`<h2>\`). Do not add any commentary or explanations. Your edits must be precise and directly fix the listed issues.
    `;

    const response = await ai.models.generateContent({
        model: site.modelConfig.textModel,
        contents: prompt,
    });

    return { rewrittenHtml: response.text, cost: mockCost(site, aiProviderToApiKey(site.modelConfig.textProvider), 0.0015) };
}


export const optimizeAndFinalizeArticle = async (html: string, brief: StrategicBrief, site: Site) => {
    let currentHtml = html;
    let attempts = 0;
    const maxAttempts = 3;
    let totalCostAmount = 0;
    const costProvider = aiProviderToApiKey(site.modelConfig.textProvider);

    while (attempts < maxAttempts) {
        attempts++;

        // --- Agent 1: The SEO Auditor ---
        const { seoReport, cost: auditCost } = await runSeoAuditorAgent(currentHtml, brief, site);
        totalCostAmount += auditCost.amount;

        const failedChecks = Object.entries(seoReport)
            .filter(([_, value]) => (value as { passed: boolean }).passed === false)
            .map(([key, value]) => `${key}: ${(value as { notes: string }).notes}`);

        if (failedChecks.length === 0) {
            console.log(`[Optimizer] All SEO checks passed on attempt ${attempts}. Finalizing.`);
            break; // All good, exit loop
        }

        console.warn(`[Optimizer] Attempt ${attempts} failed ${failedChecks.length} checks:`, failedChecks);

        // --- Agent 2: The E-E-A-T & Readability Editor ---
        const { rewrittenHtml, cost: rewriteCost } = await runRewriteAgent(currentHtml, brief, failedChecks, site);
        totalCostAmount += rewriteCost.amount;
        currentHtml = rewrittenHtml;
    }

    if (attempts >= maxAttempts) {
        console.error(`[Optimizer] Failed to pass all checks after ${maxAttempts} attempts. Using last generated version.`);
    }

    // Defensive cleanup to ensure no markdown fences or stray html tags are left.
    let finalHtmlContent = currentHtml.trim();
    if (finalHtmlContent.startsWith('```html')) {
        finalHtmlContent = finalHtmlContent.substring(7).trim();
    }
    if (finalHtmlContent.endsWith('```')) {
        finalHtmlContent = finalHtmlContent.substring(0, finalHtmlContent.length - 3).trim();
    }

    return { finalHtmlContent, cost: { provider: costProvider, amount: totalCostAmount } };
};

export const generateFeaturedImage = async (prompt: string, site: Site) => {
    const ai = getAiClient(site, site.modelConfig.imageProvider);
    
    let enhancedPrompt = prompt;
    if (site.brandColors && site.brandColors.length > 0) {
        enhancedPrompt += ` The image should prominently feature the brand colors: ${site.brandColors.join(', ')}.`;
    }
    if (site.brandFonts && site.brandFonts.length > 0) {
        enhancedPrompt += ` If any text is present, it should evoke the style of these fonts: ${site.brandFonts.join(', ')}.`;
    }

    const response = await ai.models.generateImages({
        model: site.modelConfig.imageModel,
        prompt: enhancedPrompt,
        config: { numberOfImages: 1, outputMimeType: 'image/jpeg' }
    });
    const base64Image = response.generatedImages[0].image.imageBytes;
    return { base64Image, cost: mockCost(site, aiProviderToApiKey(site.modelConfig.imageProvider), 0.02) };
};

export const generateSocialMediaPosts = async (post: BlogPost, url: string, site: Site) => {
    const ai = getAiClient(site, site.modelConfig.textProvider);
    const prompt = `
      Create social media posts to promote a new blog article.
      Article Title: "${post.title}"
      Article URL: ${url}
      Article Excerpt: "${post.excerpt}"
      
      Generate posts for Twitter, Facebook, and LinkedIn.
      - Twitter: Keep it short, engaging, and include 2-3 relevant hashtags.
      - Facebook: Write a slightly longer, more descriptive post.
      - LinkedIn: Write a professional post, perhaps posing a question to spark discussion.
    `;
    const response = await ai.models.generateContent({
        model: site.modelConfig.textModel,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    twitter: { type: Type.OBJECT, properties: { content: { type: Type.STRING }, hashtags: { type: Type.ARRAY, items: { type: Type.STRING } } } },
                    facebook: { type: Type.OBJECT, properties: { content: { type: Type.STRING }, hashtags: { type: Type.ARRAY, items: { type: Type.STRING } } } },
                    linkedin: { type: Type.OBJECT, properties: { content: { type: Type.STRING }, hashtags: { type: Type.ARRAY, items: { type: Type.STRING } } } }
                }
            }
        }
    });
    const posts = JSON.parse(response.text) as Record<string, SocialMediaPost>;
    return { posts, cost: mockCost(site, undefined, 0.001) };
};

export const generateEmailCampaignFromPost = async (post: BlogPost, url: string, site: Site): Promise<{ campaign: EmailMarketingCampaign; cost: { provider: keyof ApiKeys; amount: number; }; }> => {
    const ai = getAiClient(site, site.emailMarketingModelConfig?.textProvider || site.modelConfig.textProvider);
    const model = site.emailMarketingModelConfig?.textModel || site.modelConfig.textModel;
    const prompt = `
        You are an expert email marketer. Write a promotional email for a new blog post.
        The brand guideline is: "${site.brandGuideline || 'friendly and informative'}".
        The blog post is: Title: ${post.title}, URL: ${url}, Excerpt: ${post.excerpt}.
        Generate a compelling subject line and an HTML body. The HTML should be simple and clean.
    `;

    const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    subject: { type: Type.STRING, description: "The subject line." },
                    body: { type: Type.STRING, description: "The HTML email body." }
                },
                required: ["subject", "body"]
            }
        }
    });
    
    const campaign = JSON.parse(response.text) as EmailMarketingCampaign;
    return { campaign, cost: mockCost(site, undefined, 0.0005) };
};

export const generateStandaloneEmailCampaign = async (site: Site, topic: string): Promise<{ campaign: EmailMarketingCampaign; cost: { provider: keyof ApiKeys; amount: number; }; }> => {
    const ai = getAiClient(site, site.emailMarketingModelConfig?.textProvider || site.modelConfig.textProvider);
    const model = site.emailMarketingModelConfig?.textModel || site.modelConfig.textModel;
    const prompt = `
        You are an expert email marketer. Write a promotional email newsletter about the topic: "${topic}".
        The brand guideline is: "${site.brandGuideline || 'friendly and informative'}".
        The niche is: "${site.nicheTargeting || 'general audience'}".
        Generate a compelling subject line and an HTML body. The HTML should be simple, clean, and engaging for a newsletter format.
        If the site has promotional links (Promo Link 1: ${site.promoLink1}, Promo Link 2: ${site.promoLink2}), try to incorporate one naturally.
    `;

    const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    subject: { type: Type.STRING, description: "The subject line." },
                    body: { type: Type.STRING, description: "The HTML email body." }
                },
                required: ["subject", "body"]
            }
        }
    });
    
    const campaign = JSON.parse(response.text) as EmailMarketingCampaign;
    return { campaign, cost: mockCost(site, aiProviderToApiKey(site.emailMarketingModelConfig?.textProvider || site.modelConfig.textProvider), 0.0005) };
};

export const generateRssDigestEmail = async (site: Site, newItems: RssItem[]): Promise<{ campaign: EmailMarketingCampaign; cost: { provider: keyof ApiKeys; amount: number; }; }> => {
    const ai = getAiClient(site, site.digestAutomationModelConfig?.textProvider || site.modelConfig.textProvider);
    const model = site.digestAutomationModelConfig?.textModel || site.modelConfig.textModel;

    const itemsJson = JSON.stringify(newItems.map(item => ({ title: item.title, link: item.link, snippet: item.contentSnippet })));

    const prompt = `
        You are an expert email marketer creating a weekly roundup newsletter.
        The brand guideline is: "${site.brandGuideline || 'friendly and informative'}".
        The niche is: "${site.nicheTargeting || 'general audience'}".

        Here are the new blog posts from the past week:
        ${itemsJson}

        Your task is to generate a complete email digest. This includes:
        1.  A compelling, catchy subject line for the weekly digest (e.g., "This Week in [Niche]: Your Weekly Roundup").
        2.  A clean HTML body for the email. The body must contain:
            - A friendly introduction.
            - For each article provided, create a short, engaging summary (2-3 sentences).
            - Each summary must be followed by a clear call-to-action link to the original article.
            - A brief, friendly closing paragraph.

        Return the result as a single JSON object with "subject" and "body" keys.
    `;

    const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    subject: { type: Type.STRING, description: "The subject line for the digest email." },
                    body: { type: Type.STRING, description: "The full HTML body of the digest email." }
                },
                required: ["subject", "body"]
            }
        }
    });

    const campaign = JSON.parse(response.text) as EmailMarketingCampaign;
    return { campaign, cost: mockCost(site, aiProviderToApiKey(site.digestAutomationModelConfig?.textProvider || site.modelConfig.textProvider), 0.001) };
};


export const generateAnalyticsInsights = async (site: Site, postData: PostPerformanceData): Promise<{ insights: AnalyticsInsight; cost: { provider: keyof ApiKeys; amount: number; } }> => {
    const ai = getAiClient(site, AiProvider.GOOGLE); // Insights should use Google for consistency
    const prompt = `Analyze SEO data for a blog post:
      Title: "${postData.title}"
      Keyword: "${postData.focusKeyword}"
      Data: Clicks: ${postData.searchConsole.clicks}, Impressions: ${postData.searchConsole.impressions}, CTR: ${(postData.searchConsole.ctr * 100).toFixed(2)}%, Position: ${postData.searchConsole.position.toFixed(1)}
      Provide key insights and actionable recommendations.`;
    
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    insights: { type: Type.ARRAY, items: { type: Type.STRING } },
                    recommendations: { type: Type.ARRAY, items: { type: Type.STRING } }
                },
                required: ["insights", "recommendations"]
            }
        }
    });

    const insights = JSON.parse(response.text) as AnalyticsInsight;
    return { insights, cost: mockCost(site, 'google', 0.0003) };
};

export const findBestKeywordWithDataForSeo = async (site: Site): Promise<string | null> => {
    console.log(`[DataForSEO Simulation] Finding best keyword...`);
    // In a real app, this would be a complex chain of API calls. We simulate it with one Gemini call.
    const ai = getAiClient(site, AiProvider.GOOGLE);
    const usedTopics = site.history.map(h => h.topic).join(', ');
    const prompt = `
      You are an SEO expert. Based on the seed keywords "${site.dataforseoSeedKeywords}", find one new, high-potential keyword.
      It should have a search volume between ${site.dataforseoSearchVolumeMin}-${site.dataforseoSearchVolumeMax} and a keyword difficulty between ${site.dataforseoKeywordDifficultyMin}-${site.dataforseoKeywordDifficultyMax}.
      Do not suggest any of these already used topics: ${usedTopics}.
      Return only the single best keyword phrase and nothing else.
    `;
    const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
    return response.text.trim();
};

export const findBacklinkProspects = async (site: Site) => { throw new Error("Not Implemented"); };
export const generateOutreachEmail = async (site: Site, prospectUrl: string) => { throw new Error("Not Implemented"); };
export const sendEmail = async (site: Site, to: string, subject: string, body: string) => { console.log(`Simulating email send to ${to}`); };

const _simulateFetch = (url: string, site: Site) => `<html><body><a href="${site.backlinksOwnDomain}/some-article">anchor text</a></body></html>`;

export const checkBacklinkStatus = async (site: Site, link: MonitoredBacklink): Promise<Pick<MonitoredBacklink, 'status' | 'anchorText'>> => {
    console.log(`[Backlink Check] Simulating check for ${link.url}`);
    await new Promise(resolve => setTimeout(resolve, 1000));
    const simulatedHtml = _simulateFetch(link.url, site);
    const linkRegex = new RegExp(`<a\\s+.*?href=["'](${link.targetUrl})["'].*?>(.*?)</a>`, 'i');
    const match = simulatedHtml.match(linkRegex);
    return match ? { status: 'active', anchorText: match[2].trim() } : { status: 'inactive', anchorText: null };
};

export const publishSocialGraphic = async (site: Site, generationResult: { imageUrl: string; caption: string; }) => {
    const allEnabledAccounts: { platform: SocialPlatform, account: SocialMediaAccount }[] = [];
    const socialPlatforms: (keyof Omit<SocialMediaSettings, 'whatsapp' | 'telegram'>)[] = ['twitter', 'facebook', 'linkedin', 'instagram', 'pinterest'];
    
    for (const platform of socialPlatforms) {
        (site.socialMediaSettings[platform] as SocialMediaAccount[])?.forEach(acc => {
            if (acc.isConnected && acc.isAutomationEnabled) {
                allEnabledAccounts.push({ platform, account: acc });
            }
        });
    }

    if (allEnabledAccounts.length === 0) return;

    for (const { platform, account } of allEnabledAccounts) {
        await socialMediaService.postToSocialMedia(platform, account, { content: generationResult.caption, hashtags: [] });
    }
};

export const generateSocialGraphicPrompt = async (site: Site) => {
    const ai = getAiClient(site, site.modelConfig.textProvider);
    const prompt = `Generate a creative, inspiring, one-sentence prompt for an AI image generator. The topic should be related to the overall themes of a site focused on: ${site.keywordList.split('\n')[0] || 'digital marketing'}.`;
    const response = await ai.models.generateContent({ model: site.modelConfig.textModel, contents: prompt });
    return { prompt: response.text.trim(), cost: mockCost(site) };
};

export const generateSocialVideoAndCaption = async (site: Site, prompt: string, characterId?: string): Promise<{ generationResult: { videoUrl: string, caption: string }, totalCost: { provider: keyof ApiKeys, amount: number } }> => {
    let finalPrompt = prompt;
    const character = site.characterLibrary?.find(c => c.id === characterId);
    if (character) {
        finalPrompt = `A short video featuring a character with this description: "${character.visualReferenceText}". The character's personality is: "${character.personality}". The scene is: ${prompt}.`;
    }
    console.log(`[AI Internal] Simulating video generation for prompt: "${finalPrompt}"`);
    await new Promise(resolve => setTimeout(resolve, 3000)); // Simulate longer generation time for video
    
    const ai = getAiClient(site, site.socialVideoAutomationModelConfig?.textProvider || site.modelConfig.textProvider);
    const model = site.socialVideoAutomationModelConfig?.textModel || site.modelConfig.textModel;

    const captionPrompt = `Write a short, engaging social media caption for a video about "${prompt}". Include 2-3 relevant hashtags.`;
    const captionResponse = await ai.models.generateContent({ model, contents: captionPrompt });
    
    const generationResult = {
        videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4', // Mock video URL
        caption: captionResponse.text.trim()
    };
    
    return { generationResult, totalCost: mockCost(site, aiProviderToApiKey(site.modelConfig.videoProvider || AiProvider.GOOGLE), 0.15) };
};

export const publishSocialVideo = async (site: Site, generationResult: { videoUrl: string; caption: string; }) => {
    // Similar to publishSocialGraphic, but might target different platforms (TikTok, YouTube Shorts)
    const allEnabledAccounts: { platform: SocialPlatform, account: SocialMediaAccount }[] = [];
    // For simulation, let's assume we can post to these. Real implementation would be more specific.
    const socialPlatforms: (keyof Omit<SocialMediaSettings, 'whatsapp' | 'telegram'>)[] = ['tiktok', 'youtube', 'instagram'];
    
    for (const platform of socialPlatforms) {
        (site.socialMediaSettings[platform] as SocialMediaAccount[])?.forEach(acc => {
            if (acc.isConnected && acc.isAutomationEnabled) {
                allEnabledAccounts.push({ platform, account: acc });
            }
        });
    }

    if (allEnabledAccounts.length === 0) {
        console.log("[AI Internal] No enabled social accounts found for video publishing.");
        return;
    }

    console.log(`[AI Internal] Publishing video to ${allEnabledAccounts.length} accounts.`);
    for (const { platform, account } of allEnabledAccounts) {
        // socialMediaService.postToSocialMedia doesn't support video, so this is just a simulation.
        console.log(`[AI Internal] SIMULATING post of video to ${platform} account "${account.name}".`);
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
};

export const brainstormContentIdeas = async (
    site: Site,
    theme: string,
    contentType: 'blog_post' | 'social_graphic' | 'email_campaign'
): Promise<{ ideas: string[]; cost: { provider: keyof ApiKeys; amount: number } }> => {
    const ai = getAiClient(site, site.modelConfig.textProvider);
    const nicheContext = site.nicheTargeting ? `The site's niche is: "${site.nicheTargeting}". The ideas should be highly relevant to this niche.` : 'The site is about general digital marketing.';

    if (contentType === 'blog_post') {
        const localSeoInstructions = buildLocalSeoPromptPart(site);
        const prompt = `
            You are an expert SEO and content strategist. Your task is to brainstorm high-potential, long-tail blog post keywords based on a seed theme.
            Use your search tool to analyze the current search landscape for the theme.
            Identify user intent, common questions, and related "People Also Ask" queries.
            Based on this research, suggest 5 specific, engaging, and SEO-optimized long-tail keywords that have a high probability of ranking.

            **Seed Theme:** "${theme}"
            **Niche Context:** ${site.nicheTargeting || 'General digital marketing.'}
            ${localSeoInstructions}

            Return only a numbered list of the 5 suggested keywords. Do not include explanations or any other text.
        `;
        
        const googleAI = getAiClient(site, AiProvider.GOOGLE);

        const response = await googleAI.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                tools: [{ googleSearch: {} }],
            }
        });

        const ideas = response.text.split('\n').map(idea => idea.replace(/^\d+\.\s*/, '').trim()).filter(Boolean);
        return { ideas, cost: mockCost(site, 'google', 0.001) };

    } else if (contentType === 'email_campaign') {
        const prompt = `
            You are an expert email marketer. Brainstorm 5 engaging and creative topics for an email newsletter based on the theme "${theme}".
            ${nicheContext}
            Return only a numbered list of the ideas. The ideas should be concise and suitable for email subject lines.
        `;

        const response = await ai.models.generateContent({
            model: site.modelConfig.textModel,
            contents: prompt,
        });

        const ideas = response.text.split('\n').map(idea => idea.replace(/^\d+\.\s*/, '').trim()).filter(Boolean);
        return { ideas, cost: mockCost(site, aiProviderToApiKey(site.modelConfig.textProvider), 0.0005) };
    } else { // social_graphic
        const prompt = `
            You are an expert content strategist. Brainstorm 5 engaging and creative prompts for social media images based on the theme "${theme}".
            ${nicheContext}
            Return only a numbered list of the ideas.
        `;

        const response = await ai.models.generateContent({
            model: site.modelConfig.textModel,
            contents: prompt,
        });

        const ideas = response.text.split('\n').map(idea => idea.replace(/^\d+\.\s*/, '').trim()).filter(Boolean);
        return { ideas, cost: mockCost(site, aiProviderToApiKey(site.modelConfig.textProvider), 0.0005) };
    }
};

export const findBestKeyword = async (
    seedKeyword: string, 
    site: Site
): Promise<{ bestKeyword: string, cost: { provider: keyof ApiKeys, amount: number } }> => {
    
    // If DataForSEO is configured, use it for a data-driven decision.
    if (site.seoDataProvider.startsWith('dataforseo_') && site.apiKeys.dataforseo) {
        console.log(`[DataForSEO Simulation] Finding best keyword based on seed: "${seedKeyword}"`);
        // In a real app, this would be a complex chain of API calls. We simulate it with one Gemini call.
        const ai = getAiClient(site, AiProvider.GOOGLE); // Use Google to interpret and decide
        const usedTopics = site.history.map(h => h.topic).join(', ');
        const prompt = `
          You are an SEO expert using DataForSEO. Your task is to find the single best keyword to target based on a seed keyword.
          
          **Seed Keyword:** "${seedKeyword}"
          **Research Parameters:**
          - Target Location: ${site.dataforseoTargetLocation}
          - Target Language: ${site.dataforseoTargetLanguage}
          - Search Volume: ${site.dataforseoSearchVolumeMin} - ${site.dataforseoSearchVolumeMax}
          - Keyword Difficulty: ${site.dataforseoKeywordDifficultyMin} - ${site.dataforseoKeywordDifficultyMax}

          **Instructions:**
          1. Use the seed keyword to generate a list of related long-tail keywords.
          2. Imagine you are querying DataForSEO's API for each of these keywords to get their metrics.
          3. Select the single best keyword that fits the parameters and has the highest commercial intent and ranking potential.
          4. Do not suggest any of these already used topics: ${usedTopics}.
          5. Return ONLY the single best keyword phrase. No explanations, no formatting, just the keyword.
        `;
        const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
        return { bestKeyword: response.text.trim(), cost: mockCost(site, 'dataforseo', 0.05) };
    }

    // Default to Google Search grounding for other providers
    const ai = getAiClient(site, AiProvider.GOOGLE);
    const localSeoInstructions = buildLocalSeoPromptPart(site);
    const nicheContext = site.nicheTargeting ? `The site's niche is: "${site.nicheTargeting}".` : '';

    const prompt = `
        You are an expert SEO strategist. Your goal is to refine a given topic into a high-intent, long-tail keyword that is ideal for a new blog post.
        Use your search tool to analyze the search landscape for the original topic. Look for "People Also Ask", related queries, and forum discussions to understand user intent.

        **Original Topic:** "${seedKeyword}"
        **Niche Context:** ${nicheContext}
        ${localSeoInstructions}

        Based on your research, determine the single best, most specific long-tail keyword to target for a blog post. It should be a phrase a user would actually type into a search engine.

        Return ONLY the refined keyword. Nothing else.
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            tools: [{ googleSearch: {} }],
        }
    });

    return { bestKeyword: response.text.trim(), cost: mockCost(site, 'google', 0.001) };
};


export const generateSocialGraphicAndCaption = async (site: Site, prompt: string, aspectRatio: any, platform: string, overrides?: any, characterId?: string) => {
    const imageProvider = overrides?.imageProvider || site.modelConfig.imageProvider;
    const imageModel = overrides?.imageModel || site.modelConfig.imageModel;

    let enhancedPrompt = prompt;
    const character = site.characterLibrary?.find(c => c.id === characterId);
    if (character) {
        enhancedPrompt = `A character with this description: "${character.visualReferenceText}". The character's personality is: "${character.personality}". The scene is: ${prompt}.`;
    }

    const imageAi = getAiClient(site, imageProvider);
    const imageResponse = await imageAi.models.generateImages({
        model: imageModel,
        prompt: enhancedPrompt,
        config: { numberOfImages: 1, outputMimeType: 'image/jpeg', aspectRatio }
    });
    const base64Image = imageResponse.generatedImages[0].image.imageBytes;

    const textAi = getAiClient(site, site.modelConfig.textProvider);
    const captionPrompt = `Write a short, engaging social media caption for this image, suitable for a ${platform}. The original prompt was "${prompt}". Include 2-3 relevant hashtags.`;
    const captionResponse = await textAi.models.generateContent({
        model: site.modelConfig.textModel,
        contents: { parts: [{ inlineData: { mimeType: 'image/jpeg', data: base64Image } }, { text: captionPrompt }] }
    });

    const result = { base64Image, caption: captionResponse.text };
    return { generationResult: result, totalCost: mockCost(site, undefined, 0.021) };
};

export const suggestKeywords = async (existingKeywords: string, site: Site) => {
    const ai = getAiClient(site, site.modelConfig.textProvider);
    const prompt = `You are an SEO expert. Given the following list of keywords, suggest 5 new, related long-tail keywords. Do not repeat any from the existing list.\n\nExisting Keywords:\n${existingKeywords}`;
    const response = await ai.models.generateContent({ model: site.modelConfig.textModel, contents: prompt });
    const suggestions = response.text.split('\n').map(k => k.replace(/^- \d+\.\s*/, '').trim()).filter(Boolean);
    return { suggestions, cost: mockCost(site) };
};

export const suggestKeywordsFromUrl = async (url: string, existing: string, site: Site) => {
    const ai = getAiClient(site, AiProvider.GOOGLE);
    const prompt = `As an SEO expert, analyze the content at the URL provided. Based on the main topics, suggest 10 new, related keywords. Avoid keywords already in this list: ${existing}.`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `${prompt}\n\nURL: ${url}`,
        config: { tools: [{ googleSearch: {} }] }
    });
    const suggestions = response.text.split('\n').map(k => k.replace(/^- \d+\.\s*/, '').trim()).filter(Boolean);
    return { suggestions, cost: mockCost(site, 'google') };
};

export const generateBrandGuidelineFromUrl = async (url: string, site: Site) => {
    const ai = getAiClient(site, AiProvider.GOOGLE);
    const prompt = `Analyze the writing style, tone of voice, and common topics at the provided URL. Synthesize a concise brand guideline document based on your analysis. The guideline should be a few paragraphs.`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `${prompt}\n\nURL: ${url}`,
        config: { tools: [{ googleSearch: {} }] }
    });
    return { guideline: response.text, cost: mockCost(site, 'google') };
};

export const findCommentingProspects = async (topic: string, site: Site): Promise<{ prospects: { url: string; title: string; description: string; }[]; cost: { provider: keyof ApiKeys; amount: number; }; }> => {
    const ai = getAiClient(site, AiProvider.GOOGLE);
    const prompt = `Find 5 recent blog posts about "${topic}" that are likely to have comments enabled. For each, provide its URL, title, and a brief description.`;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            tools: [{ googleSearch: {} }],
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.ARRAY, items: {
                    type: Type.OBJECT, properties: {
                        url: { type: Type.STRING }, title: { type: Type.STRING }, description: { type: Type.STRING },
                    }, required: ["url", "title", "description"],
                },
            },
        },
    });
    return { prospects: JSON.parse(response.text.trim()), cost: mockCost(site, 'google', 0.001) };
};

export const generateBlogComment = async (prospectUrl: string, ownPostTopic: string, site: Site): Promise<{ comment: string; cost: { provider: keyof ApiKeys; amount: number; }; }> => {
    const ai = getAiClient(site, AiProvider.GOOGLE);
    const prompt = `Read the content of the article at the provided URL. Then, write a short, insightful, and friendly blog comment about it. The comment should add value. My own related article is about "${ownPostTopic}", so keep that context in mind, but DO NOT mention my article or link to it. Adhere to this brand guideline: "${site.brandGuideline || 'friendly and informative'}"`;
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `${prompt}\n\nURL: ${prospectUrl}`,
        config: { tools: [{ googleSearch: {} }] }
    });
    
    return { comment: response.text, cost: mockCost(site, 'google') };
};

export const findSocialMediaProspects = async (site: Site): Promise<{ prospects: { platform: string; url: string; author: string; content: string; }[]; cost: { provider: keyof ApiKeys; amount: number; }; }> => {
    const ai = getAiClient(site, AiProvider.GOOGLE);
    const prompt = `Find 5 recent, popular posts across various social media platforms (like X/Twitter, LinkedIn, Facebook, Instagram, Pinterest, TikTok) that are relevant to these keywords/hashtags: "${site.socialCommentingKeywords}". For each post, provide its platform, a plausible URL, the author's name, and the post's content.`;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            tools: [{ googleSearch: {} }],
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.ARRAY, items: {
                    type: Type.OBJECT, properties: {
                        platform: { type: Type.STRING },
                        url: { type: Type.STRING },
                        author: { type: Type.STRING },
                        content: { type: Type.STRING },
                    }, required: ["platform", "url", "author", "content"],
                },
            },
        },
    });
    return { prospects: JSON.parse(response.text.trim()), cost: mockCost(site, 'google', 0.001) };
};

export const generateSocialMediaComment = async (site: Site, prospect: SocialCommentingProspect, sourcePost: PostHistoryItem): Promise<{ comment: string; cost: { provider: keyof ApiKeys; amount: number; }; }> => {
    const ai = getAiClient(site, site.modelConfig.textProvider);
    const prompt = `
        You are an expert social media marketer. Your goal is to write a valuable comment on a social media post to build authority and engagement.
        
        **Your Commenting Guideline:** ${site.socialCommentingGuideline}
        
        **Context from one of your own blog posts:**
        - Title: "${sourcePost.topic}"
        - URL: ${sourcePost.url} (Do NOT mention or link to this URL in the comment)

        **The Social Media post you are commenting on:**
        - Author: ${prospect.prospectPostAuthor}
        - Content: "${prospect.prospectPostContent}"

        Based on all this information, write a short, high-quality comment. Return only the text of the comment.
    `;
    
    const response = await ai.models.generateContent({ model: site.modelConfig.textModel, contents: prompt });
    
    return { comment: response.text.trim(), cost: mockCost(site) };
};


// --- Mailchimp Integration ---
export const verifyMailchimpConnection = async (apiKey: string, serverPrefix: string): Promise<{ availableAudiences: { id: string, name: string }[] }> => {
    // In a real app, this would call \`https://<serverPrefix>.api.mailchimp.com/3.0/\`
    await new Promise(resolve => setTimeout(resolve, 800));
    if (!apiKey.trim() || !serverPrefix.trim()) {
        throw new Error("API Key and Server Prefix are required.");
    }
    if (apiKey.toLowerCase().includes('invalid')) {
        throw new Error("The provided API Key is invalid.");
    }
    // Simulate fetching audiences
    return {
        availableAudiences: [
            { id: 'aud123', name: 'Newsletter Subscribers' },
            { id: 'aud456', name: 'Customer List' },
            { id: 'aud789', name: 'Blog Followers' },
        ]
    };
};

export const sendMailchimpCampaign = async (site: Site, campaign: EmailMarketingCampaign): Promise<void> => {
    const mailchimpConfig = site.mailchimp;
    if (!mailchimpConfig || !mailchimpConfig.isConnected || !mailchimpConfig.defaultAudienceId) {
        console.warn("[Mailchimp] Cannot send campaign: Not connected or no default audience selected.");
        return;
    }
    
    console.log(`[Mailchimp Service] SIMULATING sending campaign:
    - Subject: "${campaign.subject}"
    - To Audience: "${mailchimpConfig.availableAudiences?.find(a => a.id === mailchimpConfig.defaultAudienceId)?.name || mailchimpConfig.defaultAudienceId}"
    - From: ${site.emailMarketingSettings?.fromName} <${site.emailMarketingSettings?.fromEmail}>
    `);
    
    // In a real app, this would involve multiple API calls to create a campaign, set its content, and send it.
    await new Promise(resolve => setTimeout(resolve, 1500));
    console.log("[Mailchimp Service] Campaign sent successfully (simulation).");
};

export const regenerateArticleSection = async (site: Site, brief: StrategicBrief, heading: string, sectionHtml: string): Promise<{ regeneratedHtml: string; cost: { provider: keyof ApiKeys; amount: number } }> => {
    const ai = getAiClient(site, site.modelConfig.textProvider);
    const prompt = `
        You are an expert content writer. Your task is to rewrite a specific section of a blog post to improve its quality, clarity, and engagement, while maintaining the original topic and adhering to the overall brief.

        **Overall Article Topic:** "${brief.topic}"
        **Section Heading to Rewrite:** "${heading}"
        **Original HTML of the section to be rewritten:**
        \`\`\`html
        ${sectionHtml}
        \`\`\`

        **Instructions:**
        1.  Rewrite the content under the provided heading.
        2.  The new content MUST adhere to the same readability standards: short sentences (avg < 20 words) and concise paragraphs ( < 150 words).
        3.  Maintain the first-person perspective of the author, "${brief.authorName}".
        4.  Ensure the tone is consistent with the brand guideline: "${brief.brandGuideline}".
        5.  The output must be only the new, clean HTML for this section, starting with the same \`<h2>\` or \`<h3>\` tag. Do not include any other text, explanations, or markdown.
    `;

    const response = await ai.models.generateContent({
        model: site.modelConfig.textModel,
        contents: prompt,
    });

    return { regeneratedHtml: response.text.trim(), cost: mockCost(site, undefined, 0.0005) };
};