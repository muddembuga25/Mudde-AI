import type { WhatsAppAccount, TelegramAccount } from '../types';

const getRedirectUri = () => {
    // Return the base URL of the application for the OAuth redirect.
    return window.location.origin + window.location.pathname;
};

const OAUTH_CONFIGS = {
    twitter: {
        authUrl: 'https://twitter.com/i/oauth2/authorize',
        tokenUrl: 'https://api.twitter.com/2/oauth2/token',
        scopes: ['tweet.read', 'tweet.write', 'users.read', 'offline.access'].join(' '),
        verifyUrl: 'https://api.twitter.com/2/users/me',
    },
    facebook: {
        authUrl: 'https://www.facebook.com/v20.0/dialog/oauth',
        tokenUrl: 'https://graph.facebook.com/v20.0/oauth/access_token',
        scopes: ['email', 'pages_manage_posts', 'publish_to_groups'].join(','),
        verifyUrl: 'https://graph.facebook.com/me',
    },
    linkedin: {
        authUrl: 'https://www.linkedin.com/oauth/v2/authorization',
        tokenUrl: 'https://www.linkedin.com/oauth/v2/accessToken',
        scopes: ['profile', 'email', 'w_member_social', 'w_organization_social'].join(' '),
        verifyUrl: 'https://api.linkedin.com/v2/userinfo',
    },
    youtube: {
        authUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
        tokenUrl: 'https://oauth2.googleapis.com/token',
        scopes: ['https://www.googleapis.com/auth/youtube.upload', 'https://www.googleapis.com/auth/youtube.readonly'].join(' '),
        verifyUrl: 'https://www.googleapis.com/oauth2/v3/userinfo'
    },
    tiktok: {
        authUrl: 'https://www.tiktok.com/v2/auth/authorize',
        tokenUrl: 'https://open.tiktokapis.com/v2/oauth/token/',
        scopes: ['video.upload', 'user.info.basic'].join(','),
        verifyUrl: 'https://open.tiktokapis.com/v2/user/info/'
    },
    snapchat: {
        authUrl: 'https://accounts.snapchat.com/login/oauth2/authorize',
        tokenUrl: 'https://accounts.snapchat.com/login/oauth2/access_token',
        scopes: ['snapchat-marketing-api'].join(' '),
        verifyUrl: 'https://adsapi.snapchat.com/v1/me'
    },
    instagram: {
        authUrl: 'https://api.instagram.com/oauth/authorize',
        tokenUrl: 'https://api.instagram.com/oauth/access_token',
        scopes: ['user_profile', 'user_media'].join(','), // Basic scopes for demo
        verifyUrl: 'https://graph.instagram.com/me'
    },
    pinterest: {
        authUrl: 'https://www.pinterest.com/oauth/',
        tokenUrl: 'https://api.pinterest.com/v5/oauth/token',
        scopes: ['pins:read', 'pins:write', 'boards:read', 'boards:write'].join(','),
        verifyUrl: 'https://api.pinterest.com/v5/user_account'
    },
    whatsapp: {
        authUrl: '',
        tokenUrl: '',
        scopes: '',
        verifyUrl: 'https://graph.facebook.com/v20.0/me/phone_numbers' // Placeholder
    },
    telegram: {
        authUrl: '',
        tokenUrl: '',
        scopes: '',
        verifyUrl: 'https://api.telegram.org/bot{token}/getMe' // Placeholder, requires token in URL
    },
};

export type SocialPlatform = keyof typeof OAUTH_CONFIGS;

export const redirectToAuth = (platform: SocialPlatform, clientId: string, siteId: string, accountId: string) => {
    const config = OAUTH_CONFIGS[platform];
    if (!config || !config.authUrl) {
        alert(`OAuth is not configured for ${platform} in this demo app.`);
        console.error(`OAuth not configured for platform: ${platform}`);
        return;
    }

    const state = crypto.randomUUID();
    // Store necessary info to handle the callback, now including accountId
    localStorage.setItem('oauth_state', JSON.stringify({ state, platform, siteId, accountId }));

    const redirectUri = getRedirectUri();
    
    const params = new URLSearchParams({
        response_type: 'code',
        client_id: clientId,
        redirect_uri: redirectUri,
        scope: config.scopes,
        state: state,
    });
    
    // Twitter requires a PKCE challenge
    if (platform === 'twitter') {
        const codeVerifier = crypto.randomUUID() + crypto.randomUUID();
        localStorage.setItem('oauth_pkce_verifier', codeVerifier);
        
        const createChallenge = async () => {
            const encoder = new TextEncoder();
            const data = encoder.encode(codeVerifier);
            const digest = await crypto.subtle.digest('SHA-256', data);
            const base64url = btoa(String.fromCharCode(...new Uint8Array(digest)))
                .replace(/=/g, '')
                .replace(/\+/g, '-')
                .replace(/\//g, '_');

            params.append('code_challenge', base64url);
            params.append('code_challenge_method', 'S256');
            
            window.top.location.href = `${config.authUrl}?${params.toString()}`;
        };
        
        createChallenge();
        return;
    }
    
    // TikTok requires a specific parameter name
    if (platform === 'tiktok') {
        params.set('client_key', clientId);
        params.delete('client_id');
    }

    // Google/YouTube specific parameter
    if (platform === 'youtube') {
        params.append('access_type', 'offline');
        params.append('prompt', 'consent');
    }


    window.top.location.href = `${config.authUrl}?${params.toString()}`;
};


export const exchangeCodeForToken = async (
    platform: SocialPlatform,
    code: string,
    clientId: string,
    clientSecret: string
): Promise<{ accessToken: string }> => {
    const { tokenUrl } = OAUTH_CONFIGS[platform];
    const redirectUri = getRedirectUri();
    
    const body = new URLSearchParams({
        grant_type: 'authorization_code',
        code: code,
        redirect_uri: redirectUri,
        client_id: clientId,
        client_secret: clientSecret,
    });
    
    if (platform === 'twitter') {
        const pkceVerifier = localStorage.getItem('oauth_pkce_verifier');
        if (pkceVerifier) {
            body.append('code_verifier', pkceVerifier);
        }
    }

    if (platform === 'tiktok') {
        body.set('client_key', clientId);
        body.delete('client_id');
    }

    if (platform === 'pinterest') {
        // Pinterest uses Basic Auth for token exchange
        const headers = {
            'Authorization': `Basic ${btoa(`${clientId}:${clientSecret}`)}`,
            'Content-Type': 'application/x-www-form-urlencoded'
        };
        console.log(`
        --- [OAuth Token Exchange Simulation] ---
        This is a frontend-only application. To protect the Client Secret, a real application
        would send the authorization code to a secure backend. The backend would then make
        the following POST request to the provider's token endpoint.
        
        ENDPOINT: POST ${tokenUrl}
        HEADERS: ${JSON.stringify(headers)}
        BODY: ${body.toString()}
        -----------------------------------------
        `);

    } else {
         console.log(`
            --- [OAuth Token Exchange Simulation] ---
            This is a frontend-only application. To protect the Client Secret, a real application
            would send the authorization code to a secure backend. The backend would then make
            the following POST request to the provider's token endpoint.
            
            ENDPOINT: POST ${tokenUrl}
            HEADERS: { 'Content-Type': 'application/x-www-form-urlencoded' }
            BODY: ${body.toString()}
            -----------------------------------------
        `);
    }
    
    // Simulate network delay for a more realistic user experience
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // In a real app, you would fetch(tokenUrl, { method: 'POST', body }) on your backend,
    // parse the response, and return the real access token.
    // Here, we return a simulated token for demonstration purposes.
    const simulatedToken = `genuine_token_for_${platform}_${crypto.randomUUID()}`;
    
    localStorage.removeItem('oauth_pkce_verifier');
    
    return { accessToken: simulatedToken };
};


export const handleOAuthCallback = (): { platform: string; siteId: string; accountId: string; code: string } | null => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    const state = params.get('state');
    
    if (!code || !state) {
        return null;
    }

    const storedStateJSON = localStorage.getItem('oauth_state');
    if (!storedStateJSON) {
        return null;
    }

    try {
        const storedState = JSON.parse(storedStateJSON);
        if (storedState.state !== state) {
            console.error("OAuth state mismatch. Possible CSRF attack.");
            return null;
        }

        window.history.replaceState({}, document.title, window.location.pathname);
        
        return {
            platform: storedState.platform,
            siteId: storedState.siteId,
            accountId: storedState.accountId,
            code: code,
        };
    } catch (e) {
        console.error("Error parsing stored OAuth state.", e);
        return null;
    } finally {
        localStorage.removeItem('oauth_state');
    }
};

export const verifyConnection = async (
    platform: SocialPlatform,
    accessToken: string
): Promise<{ success: boolean; message: string; }> => {
    const config = OAUTH_CONFIGS[platform];
    if (!config || !config.verifyUrl) {
        return { success: false, message: 'Verification not supported for this platform.' };
    }
    
    console.log(`
        --- [Connection Verification Simulation] ---
        Simulating a check to verify the API token is still valid. In a real application,
        this would make a GET request to an endpoint like '${config.verifyUrl}'.
        
        This simulation has a chance to fail to demonstrate how the app handles
        expired tokens or revoked permissions.
        -------------------------------------------
    `);

    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Randomly fail about 20% of the time to simulate an expired token
    if (Math.random() < 0.2) {
        return { 
            success: false, 
            message: 'The API token seems to be invalid or has expired. Please reconnect the account.' 
        };
    }

    return { success: true, message: 'Connection verified successfully.' };
};

export const verifyCredentialBasedConnection = async (
    platform: 'whatsapp' | 'telegram',
    account: WhatsAppAccount | TelegramAccount
): Promise<{ success: boolean; message: string; }> => {
    
    console.log(`
        --- [Credential Verification Simulation] ---
        Verifying credentials for ${platform} account "${account.name}".
        In a real app, this would make a request to the respective API endpoint.
        - WhatsApp: ${OAUTH_CONFIGS.whatsapp.verifyUrl} with accessToken and phoneNumberId.
        - Telegram: ${OAUTH_CONFIGS.telegram.verifyUrl.replace('{token}', (account as TelegramAccount).botToken || '')}
        -------------------------------------------
    `);
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Simulate validation
    if (platform === 'whatsapp') {
        const waAccount = account as WhatsAppAccount;
        if (!waAccount.accessToken || !waAccount.phoneNumberId || !waAccount.destination) {
            return { success: false, message: 'Missing required WhatsApp credentials.' };
        }
    }
    if (platform === 'telegram') {
        const tgAccount = account as TelegramAccount;
        if (!tgAccount.botToken || !tgAccount.chatId) {
            return { success: false, message: 'Missing required Telegram credentials.' };
        }
    }
    
    // Randomly fail about 20% of the time to simulate invalid credentials
    if (Math.random() < 0.2) {
        return { 
            success: false, 
            message: `The provided credentials for ${platform} appear to be invalid.` 
        };
    }

    return { success: true, message: 'Connection verified successfully.' };
};