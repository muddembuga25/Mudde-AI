// This service now acts as a "thin client" that communicates with the mcpApiService.
// It abstracts the client-server communication from the UI components.

import type { Site, RssItem, BlogPost, SocialMediaPost, ApiKeys, ModelConfig, StrategicBrief, CommentingProspect, EmailMarketingCampaign, MonitoredBacklink } from '../types';
import * as mcpApiService from './mcpApiService';
import type { GoogleSheetRow } from './googleSheetsService';

// The UI will only import from this file.

export const generateStrategyProposals = (sourceType: 'keyword' | 'rss' | 'video' | 'google_sheet', sourceDetails: any, siteId: string, options?: any) => {
    return mcpApiService.generateStrategicBrief(siteId, sourceType, sourceDetails, options);
};

export const fleshOutBrief = (siteId: string, partialBrief: Partial<StrategicBrief>) => {
    return mcpApiService.fleshOutBrief(siteId, partialBrief);
};

export const generateArticleFromBrief = (brief: StrategicBrief, siteId: string) => {
    return mcpApiService.generateArticle(siteId, brief);
};

export const humanizeAndFinalizeArticle = (rawHtmlContent: string, brief: StrategicBrief, siteId: string) => {
    return mcpApiService.optimizeArticle(siteId, rawHtmlContent, brief);
};

export const generateFeaturedImage = (prompt: string, siteId: string) => {
    return mcpApiService.generateImage(siteId, prompt);
};

// --- Combined & Other Functions ---

export const generateSocialGraphicAndCaption = (
    siteId: string,
    prompt: string,
    aspectRatio: '16:9' | '1:1' | '9:16',
    platformDescription: string,
    modelConfigOverride?: Partial<ModelConfig>
) => {
    return mcpApiService.generateSocialGraphicAndCaption(siteId, prompt, aspectRatio, platformDescription, modelConfigOverride);
};

export const generateSocialGraphicPrompt = (siteId: string) => {
    return mcpApiService.generateSocialGraphicPrompt(siteId);
};

export const brainstormContentIdeas = (siteId: string, theme: string, contentType: 'blog_post' | 'social_graphic' | 'email_campaign') => {
    return mcpApiService.brainstormContentIdeas(siteId, theme, contentType);
};

export const generateBrandGuidelineFromUrl = (url: string, siteId: string) => {
    return mcpApiService.generateBrandGuidelineFromUrl(siteId, url);
};

export const suggestKeywords = (existingKeywords: string, siteId: string) => {
    return mcpApiService.suggestKeywords(siteId, existingKeywords);
};

export const suggestKeywordsFromUrl = (url: string, existingKeywords: string, siteId: string) => {
    return mcpApiService.suggestKeywordsFromUrl(siteId, url, existingKeywords);
};

export const findCommentingProspects = (topic: string, siteId: string) => {
    return mcpApiService.findCommentingProspects(siteId, topic);
};

export const generateBlogComment = (prospectUrl: string, ownPostTopic: string, siteId: string) => {
    return mcpApiService.generateBlogComment(siteId, prospectUrl, ownPostTopic);
};

export const checkBacklinkStatus = (siteId: string, link: MonitoredBacklink) => {
    return mcpApiService.checkBacklinkStatus(siteId, link);
};

export const generateManualEmailCampaign = (siteId: string, topic: string) => {
    return mcpApiService.generateManualEmailCampaign(siteId, topic);
};

export const sendAndRecordEmailCampaign = (siteId: string, campaign: EmailMarketingCampaign) => {
    return mcpApiService.sendAndRecordEmailCampaign(siteId, campaign);
};