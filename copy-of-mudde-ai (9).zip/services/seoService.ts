
import type { BlogPost, SeoChecklist, SeoScoreResult, StrategicBrief } from '../types';

// Helper to get word count from HTML content
export const getWordCount = (html: string): number => {
    const text = html.replace(/<[^>]*>/g, ' '); // Strip HTML tags
    return text.trim().split(/\s+/).filter(Boolean).length;
};

// Helper to count occurrences of a keyword (case-insensitive)
const countKeywordOccurrences = (text: string, keyword: string): number => {
    const regex = new RegExp(keyword.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'), 'gi');
    const matches = text.match(regex);
    return matches ? matches.length : 0;
};

// New helper for readability check
export const checkReadability = (html: string): boolean => {
    // Strip all HTML tags and normalize whitespace for analysis
    const plainText = html.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
    if (!plainText) return false;

    // 1. Average sentence length check.
    // A sentence is a string of characters ending with a period, exclamation mark, or question mark.
    const sentences = plainText.match(/[^.!?]+[.!?]+/g) || [];
    if (sentences.length > 0) {
        const totalWords = plainText.split(/\s+/).filter(Boolean).length;
        const avgSentenceLength = totalWords / sentences.length;
        // Fails if sentences are too long on average, which harms readability.
        if (avgSentenceLength > 25) {
            console.warn(`Readability check failed: Average sentence length is ${avgSentenceLength.toFixed(1)} (target < 25)`);
            return false;
        }
    }

    // 2. Long paragraphs check.
    // Split content by closing paragraph tags to isolate paragraph blocks.
    const paragraphs = html.split(/<\/p>/i);
    for (const p of paragraphs) {
        const paragraphWordCount = getWordCount(p);
        // Fails if any single paragraph is excessively long.
        if (paragraphWordCount > 150) {
            console.warn(`Readability check failed: A paragraph has ${paragraphWordCount} words (target < 150)`);
            return false;
        }
    }

    return true;
};


export const calculateSeoScore = (post: BlogPost, brief: StrategicBrief): SeoScoreResult => {
    const checks: SeoChecklist = {
        titleLength: false,
        metaDescriptionLength: false,
        keywordInTitle: false,
        keywordInMetaDescription: false,
        keywordInSlug: false,
        keywordInContent: false,
        keywordInHeadings: false,
        sufficientInternalLinks: false,
        sufficientExternalLinks: false,
        imageAltText: false,
        contentLength: false,
        faqSection: false,
        schemaMarkupValid: false,
        readability: false,
        authorMentioned: false,
        firstPersonExperience: false,
        aboutTheAuthorSection: false,
    };

    let score = 0;
    const lowerCaseKeyword = brief.focusKeyword.toLowerCase();
    const plainTextContent = post.content.replace(/<[^>]*>/g, ' ').toLowerCase();

    // === On-Page Basics (30 points) ===
    if (post.seoTitle.length >= 50 && post.seoTitle.length <= 60) { checks.titleLength = true; score += 5; }
    if (post.metaDescription.length >= 120 && post.metaDescription.length <= 155) { checks.metaDescriptionLength = true; score += 5; }
    if (post.seoTitle.toLowerCase().includes(lowerCaseKeyword)) { checks.keywordInTitle = true; score += 10; }
    if (post.metaDescription.toLowerCase().includes(lowerCaseKeyword)) { checks.keywordInMetaDescription = true; score += 5; }
    if (post.slug.toLowerCase().includes(lowerCaseKeyword.replace(/\s+/g, '-'))) { checks.keywordInSlug = true; score += 5; }

    // === Content Quality (40 points) ===
    const wordCount = getWordCount(post.content);
    if (wordCount > 300) { checks.contentLength = true; score += 5; }

    const keywordCount = countKeywordOccurrences(post.content, brief.focusKeyword);
    const density = wordCount > 0 ? (keywordCount / wordCount) * 100 : 0;
    if (density >= 0.5 && density <= 1.5) { checks.keywordInContent = true; score += 5; }

    const headingRegex = /<h[23][^>]*>(.*?)<\/h[23]>/gi;
    let headingMatch;
    let keywordFoundInHeading = false;
    while ((headingMatch = headingRegex.exec(post.content)) !== null) {
        if (headingMatch[1].toLowerCase().includes(lowerCaseKeyword)) { keywordFoundInHeading = true; break; }
    }
    if (keywordFoundInHeading) { checks.keywordInHeadings = true; score += 10; }

    if (checkReadability(post.content)) { checks.readability = true; score += 5; }
    if (post.imageAltText && post.imageAltText.toLowerCase().includes(lowerCaseKeyword)) { checks.imageAltText = true; score += 5; }
    if (post.content.toLowerCase().includes('<h2>frequently asked questions</h2>')) { checks.faqSection = true; score += 5; }

    // === Authority & Trust (E-E-A-T) (30 points) ===
    const linkRegex = /<a\s+.*?href=["'](.*?)["']/g;
    let match;
    let internalLinkCount = 0;
    let externalLinkCount = 0;
    let siteHostname = '';
    
    // Use the one from the brief, which is more reliable
    const siteUrl = brief.brandGuideline?.match(/website.*?URL:\s*(https?:\/\/\S+)/)?.[1] || '';
    if (siteUrl) {
        try { siteHostname = new URL(siteUrl).hostname.replace(/^www\./, ''); } catch (e) { /* ignore */ }
    }
    while ((match = linkRegex.exec(post.content)) !== null) {
        try {
            const href = match[1];
            if (!href || href.startsWith('#')) continue;
            if (href.startsWith('http')) {
                const linkHostname = new URL(href).hostname.replace(/^www\./, '');
                if (siteHostname && linkHostname === siteHostname) internalLinkCount++;
                else externalLinkCount++;
            } else {
                internalLinkCount++;
            }
        } catch(e) {/* ignore invalid urls */}
    }
    if (internalLinkCount >= 2) { checks.sufficientInternalLinks = true; score += 5; }
    if (externalLinkCount >= 2) { checks.sufficientExternalLinks = true; score += 5; }

    if (brief.authorName && plainTextContent.includes(brief.authorName.toLowerCase())) { checks.authorMentioned = true; score += 5; }
    if (post.content.toLowerCase().includes('<h3>about the author</h3>')) { checks.aboutTheAuthorSection = true; score += 5; }
    
    const firstPersonRegex = /\b(i've|i'm|i am|i think|in my experience|i have found|my personal take)\b/i;
    if (firstPersonRegex.test(plainTextContent)) { checks.firstPersonExperience = true; score += 5; }

    const schemaRegex = /<script type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/gi;
    const schemaMatch = schemaRegex.exec(post.content);
    if (schemaMatch && schemaMatch[1]) {
        try {
            const schemaJson = JSON.parse(schemaMatch[1]);
            // Check for BlogPosting and also check if there's an FAQPage, which is a sign of advanced schema.
            const mainEntity = schemaJson['@graph'] ? schemaJson['@graph'].find((e: any) => e['@type'] === 'BlogPosting') : schemaJson;
            const hasFaqSchema = schemaJson['@graph'] ? schemaJson['@graph'].some((e: any) => e['@type'] === 'FAQPage') : mainEntity?.mainEntity?.['@type'] === 'FAQPage';
            
            if (mainEntity && mainEntity['@type'] === 'BlogPosting' && hasFaqSchema) {
                checks.schemaMarkupValid = true;
                score += 5;
            } else if (mainEntity && mainEntity['@type'] === 'BlogPosting') {
                // Give partial credit for basic schema
                checks.schemaMarkupValid = true;
                score += 2;
            }

        } catch (e) { /* invalid JSON, do nothing */ }
    }

    return { score: Math.min(100, score), checklist: checks };
};