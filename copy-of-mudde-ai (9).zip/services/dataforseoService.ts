// services/dataforseoService.ts
import type { Site, StrategicBrief } from '../types';
import { GoogleGenAI, Type } from "@google/genai";

interface DataForSeoResult {
    competitorUrls: string[];
    faq: { question: string; answer: string; }[];
    keywordCluster: string[];
    entities: string[];
    contentAngle: string;
}

const getAuthHeaders = (site: Site): Headers => {
    const credentials = site.apiKeys.dataforseo;
    if (!credentials) {
        throw new Error("DataForSEO API credentials are not configured for this site.");
    }
    const headers = new Headers();
    headers.append('Authorization', 'Basic ' + btoa(credentials));
    headers.append('Content-Type', 'application/json');
    return headers;
};

// This function now uses Gemini to simulate the aggregation and analysis of multiple DataForSEO APIs,
// providing a much more comprehensive and powerful SEO analysis.
export const getAdvancedSeoAnalysis = async (topic: string, site: Site): Promise<DataForSeoResult> => {
    console.log(`[DataForSEO Simulation] Running comprehensive analysis for: "${topic}" using Gemini to simulate DataForSEO API aggregation.`);

    const ai = new GoogleGenAI({ apiKey: site.apiKeys.google || process.env.API_KEY });

    // The Gemini prompt acts as our "MCP" for DataForSEO, aggregating and synthesizing data from various simulated endpoints.
    const prompt = `
        You are an AI simulating the aggregated output of multiple DataForSEO APIs to create a comprehensive SEO brief.
        Your task is to act as if you have already queried the following DataForSEO endpoints for the keyword "${topic}" and are now synthesizing the results.

        **1. SERP Analysis:**
        - You've analyzed the top 10 Google results.
        - You've extracted the "People Also Ask" and "Related Searches" sections.

        **2. Competitor On-Page Analysis:**
        - You've fetched the on-page content for the top 3 ranking pages, focusing on their H1, H2, and H3 structure and main content themes.

        **3. Keyword Research:**
        - You've used "Related Keywords" and "Keyword Suggestions" to find semantically related terms.
        - You've filtered these based on typical user search volume (${site.dataforseoSearchVolumeMin}-${site.dataforseoSearchVolumeMax}) and keyword difficulty (${site.dataforseoKeywordDifficultyMin}-${site.dataforseoKeywordDifficultyMax}) parameters for a competitive but achievable blog post.

        **Your Synthesis Task:**
        Based on your simulated, comprehensive DataForSEO analysis, generate a single JSON object containing the following keys:

        - "competitorUrls": An array of 5 plausible competitor URLs.
        - "faq": An array of 4 objects, each with a "question" (from "People Also Ask") and a concise "answer".
        - "keywordCluster": An array of 7 highly relevant, long-tail keywords and semantic terms that a new article must cover to be competitive.
        - "entities": An array of 5 key entities (people, places, products, concepts) related to the topic.
        - "contentAngle": A string describing the dominant content format of the top-ranking pages (e.g., "Listicle with Product Reviews", "Comprehensive How-To Guide", "Ultimate Guide with Case Studies", "News and Analysis").

        **Constraint:** The output must be ONLY the raw JSON object, without any markdown formatting or explanatory text.
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    competitorUrls: { type: Type.ARRAY, items: { type: Type.STRING } },
                    faq: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                question: { type: Type.STRING },
                                answer: { type: Type.STRING }
                            },
                            required: ["question", "answer"]
                        }
                    },
                    keywordCluster: { type: Type.ARRAY, items: { type: Type.STRING } },
                    entities: { type: Type.ARRAY, items: { type: Type.STRING } },
                    contentAngle: { type: Type.STRING }
                },
                required: ["competitorUrls", "faq", "keywordCluster", "entities", "contentAngle"]
            }
        }
    });

    return JSON.parse(response.text.trim());
};


export const verifyConnection = async (site: Site): Promise<{ success: boolean; message: string; }> => {
    const headers = getAuthHeaders(site);
    try {
        const response = await fetch('https://api.dataforseo.com/v3/user', { headers });
        const data = await response.json();

        if (response.ok && data.status_code === 20000) {
            const balance = data.tasks[0].result[0].money.balance;
            return { success: true, message: `Connection successful. Account balance: $${balance.toFixed(2)}.` };
        } else {
            return { success: false, message: data.status_message || 'Authentication failed.' };
        }
    } catch (e: any) {
        return { success: false, message: e.message || 'A network error occurred.' };
    }
};

export const runRawDataForSeoQuery = async (site: Site, endpoint: string, payload: any): Promise<any> => {
    console.log(`[DataForSEO Simulation] Running raw query for endpoint "${endpoint}" with payload:`, payload);
    const ai = new GoogleGenAI({ apiKey: site.apiKeys.google || process.env.API_KEY });

    const prompt = `
        You are an AI simulating the response of a single DataForSEO API endpoint.
        Your task is to generate a plausible JSON response that matches the structure and data types of a real DataForSEO API call.
        
        **API Endpoint:** \`${endpoint}\`
        **Request Payload:**
        \`\`\`json
        ${JSON.stringify(payload, null, 2)}
        \`\`\`

        Based on the endpoint and payload, generate a realistic JSON response. The response should be a single JSON object.
        For example, if the endpoint is for SERP analysis, the response should contain a list of organic results with titles, URLs, descriptions, etc.
        If it's for keyword suggestions, provide a list of related keywords with metrics like search volume and competition.

        **Constraint:** The output must be ONLY the raw JSON object, without any markdown formatting or explanatory text.
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
        }
    });
    
    let jsonString = response.text.trim();
    if (jsonString.startsWith('```json')) {
        jsonString = jsonString.substring(7, jsonString.length - 3).trim();
    }

    try {
        return JSON.parse(jsonString);
    } catch (e) {
        console.error("Failed to parse simulated DataForSEO JSON response:", e);
        return { error: "Failed to parse JSON response from AI model.", raw_response: jsonString };
    }
};
