import type { BlogPost, Site } from '../types';

export interface WordPressCredentials {
  url: string;
  username: string;
  password: string;
}

export interface PublishedPost {
  title: string;
  link: string;
}

export interface WordPressAuthor {
  id: number;
  name: string;
  bio: string;
}

export interface WordPressCategory {
  id: number;
  name: string;
}

export interface WordPressConnectionResult {
    success: boolean;
    message: string;
    siteTitle?: string;
}


// Helper to convert data URL to Blob
async function dataUrlToBlob(dataUrl: string): Promise<Blob> {
  const res = await fetch(dataUrl);
  return await res.blob();
}

// Helper to get or create a term (category or tag) and return its ID
const getOrCreateTerm = async (
  apiUrl: string,
  headers: Headers,
  endpoint: 'categories' | 'tags',
  name: string
): Promise<number> => {
  // Search for existing term
  const searchResponse = await fetch(`${apiUrl}/wp/v2/${endpoint}?search=${encodeURIComponent(name)}`);
  if (!searchResponse.ok) throw new Error(`Failed to search for ${endpoint}: ${name}`);
  const existingTerms = await searchResponse.json();
  const exactMatch = existingTerms.find((term: { name: string }) => term.name.toLowerCase() === name.toLowerCase());

  if (exactMatch) {
    return exactMatch.id;
  }

  // If not found, create it
  const createHeaders = new Headers(headers);
  createHeaders.append('Content-Type', 'application/json');
  const createResponse = await fetch(`${apiUrl}/wp/v2/${endpoint}`, {
    method: 'POST',
    headers: createHeaders,
    body: JSON.stringify({ name }),
  });

  if (!createResponse.ok) {
     const errorData = await createResponse.json().catch(() => ({ message: `Failed to create term '${name}'.`}));
     throw new Error(`Term creation failed for '${name}': ${errorData.message}`);
  }
  const newTerm = await createResponse.json();
  return newTerm.id;
};

export const fetchPublishedPosts = async (credentials: WordPressCredentials): Promise<PublishedPost[]> => {
  const { url, username, password } = credentials;
  // Don't proceed if URL is missing, to avoid errors.
  if (!url.trim() || !username.trim() || !password.trim()) {
    return [];
  }
  
  const cleanedUrl = url.replace(/\/+$/, '');
  const apiUrl = `${cleanedUrl}/wp-json/wp/v2/posts?status=publish&per_page=100&_fields=id,title,link`;

  const authHeaders = new Headers();
  authHeaders.append('Authorization', 'Basic ' + btoa(`${username}:${password}`));

  try {
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: authHeaders,
    });

    if (!response.ok) {
      // Don't throw an error, just log it and return empty so the main process doesn't fail.
      console.warn(`Could not fetch published posts from WordPress. Status: ${response.status}`);
      return [];
    }
    
    const postsData = await response.json();
    
    if (Array.isArray(postsData)) {
        return postsData.map((post: any) => ({
            title: post.title.rendered,
            link: post.link,
        }));
    }
    return [];

  } catch (error) {
    console.warn("Error fetching published posts from WordPress:", error);
    return []; // Return empty array on any failure
  }
};

export const fetchAuthors = async (credentials: WordPressCredentials): Promise<WordPressAuthor[]> => {
  const { url, username, password } = credentials;
  if (!url.trim() || !username.trim() || !password.trim()) {
    return [];
  }

  const cleanedUrl = url.replace(/\/+$/, '');
  // Fetch users with roles that can typically publish content
  const apiUrl = `${cleanedUrl}/wp-json/wp/v2/users?roles=administrator,editor,author&per_page=100&_fields=id,name,description`;

  const authHeaders = new Headers();
  authHeaders.append('Authorization', 'Basic ' + btoa(`${username}:${password}`));

  try {
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: authHeaders,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ message: 'Could not fetch authors. Check permissions.' }));
      // This could fail if the user doesn't have permission to list users, which is common.
      // We throw an error so the UI can handle it gracefully.
      throw new Error(`Failed to fetch authors: ${errorData.message || `Status ${response.status}`}`);
    }

    const authorsData = await response.json();
    if (Array.isArray(authorsData)) {
      return authorsData.map((author: any) => ({
        id: author.id,
        name: author.name,
        bio: author.description || '',
      }));
    }
    return [];
  } catch (error) {
    console.error("Error fetching authors from WordPress:", error);
    if (error instanceof Error) {
        throw error;
    }
    throw new Error("An unknown error occurred while fetching authors.");
  }
};

export const fetchCategories = async (credentials: WordPressCredentials): Promise<WordPressCategory[]> => {
    const { url, username, password } = credentials;
    if (!url.trim() || !username.trim() || !password.trim()) {
        return [];
    }
    const cleanedUrl = url.replace(/\/+$/, '');
    const apiUrl = `${cleanedUrl}/wp/v2/categories?per_page=100&_fields=id,name&orderby=count&order=desc`;
    const authHeaders = new Headers();
    authHeaders.append('Authorization', 'Basic ' + btoa(`${username}:${password}`));

    try {
        const response = await fetch(apiUrl, { method: 'GET', headers: authHeaders });
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({ message: 'Could not fetch categories.' }));
            throw new Error(`Failed to fetch categories: ${errorData.message || `Status ${response.status}`}`);
        }
        const categoriesData = await response.json();
        if (Array.isArray(categoriesData)) {
            return categoriesData.map((cat: any) => ({ id: cat.id, name: cat.name }));
        }
        return [];
    } catch (error) {
        console.error("Error fetching categories from WordPress:", error);
        if (error instanceof Error) throw error;
        throw new Error("An unknown error occurred while fetching categories.");
    }
};

export const verifyWordPressConnection = async (credentials: WordPressCredentials): Promise<WordPressConnectionResult> => {
    const { url, username, password } = credentials;
    if (!url.trim() || !username.trim() || !password.trim()) {
        return { success: false, message: "URL, Username, and Application Password are required." };
    }
    const cleanedUrl = url.replace(/\/+$/, '');
    const apiUrl = `${cleanedUrl}/wp-json/`;

    const authHeaders = new Headers();
    authHeaders.append('Authorization', 'Basic ' + btoa(`${username}:${password}`));

    try {
        const response = await fetch(apiUrl, {
            method: 'GET',
            headers: authHeaders,
        });

        if (!response.ok) {
            if (response.status === 401) {
                return { success: false, message: 'Authentication failed. Please double-check your WordPress Username and Application Password.' };
            }
            if (response.status === 404) {
                 return { success: false, message: 'Connection failed (404 Not Found). Ensure the WordPress URL is correct and REST API is enabled (check Settings > Permalinks).' };
            }
            const errorData = await response.json().catch(() => ({ message: `Connection failed with status ${response.status}. Your server or a security plugin might be blocking the request.` }));
            return { success: false, message: errorData.message };
        }

        const data = await response.json();
        const siteTitle = data.name || 'Unknown Site Title';

        return { success: true, message: `Successfully connected to "${siteTitle}"!`, siteTitle };
    } catch (error) {
        if (error instanceof TypeError && error.message.includes('fetch')) {
            return { success: false, message: "A network error occurred. This is often due to a CORS policy on your WordPress site. Please ensure your site allows requests from this origin. You can use a WordPress plugin to enable CORS (Cross-Origin Resource Sharing)." };
        }
        if (error instanceof Error) {
            return { success: false, message: error.message };
        }
        return { success: false, message: "An unknown error occurred while trying to connect." };
    }
};


export const publishPost = async (credentials: WordPressCredentials, post: BlogPost, keyword: string, authorId?: number): Promise<string> => {
  const { url, username, password } = credentials;
  const cleanedUrl = url.replace(/\/+$/, ''); // Remove trailing slash
  const apiUrl = `${cleanedUrl}/wp-json`;

  const authHeaders = new Headers();
  authHeaders.append('Authorization', 'Basic ' + btoa(`${username}:${password}`));

  try {
    // 1. Upload Image
    const imageBlob = await dataUrlToBlob(post.imageUrl);
    const mediaHeaders = new Headers(authHeaders);
    const filename = `${post.slug}-featured-image.jpg`;
    mediaHeaders.append('Content-Disposition', `attachment; filename="${filename}"`);
    mediaHeaders.append('Content-Type', 'image/jpeg');

    const mediaResponse = await fetch(`${apiUrl}/wp/v2/media`, {
      method: 'POST',
      headers: mediaHeaders,
      body: imageBlob,
    });

    if (!mediaResponse.ok) {
      const errorData = await mediaResponse.json().catch(() => ({ message: 'Check WordPress URL and permissions for media upload.' }));
      throw new Error(`Media Upload Failed: ${errorData.message}`);
    }
    const mediaData = await mediaResponse.json();
    const featuredMediaId = mediaData.id;
    const featuredMediaUrl = mediaData.source_url;

    // 1.1 Update Image Metadata (Alt Text)
    const updateMediaHeaders = new Headers(authHeaders);
    updateMediaHeaders.append('Content-Type', 'application/json');
    await fetch(`${apiUrl}/wp/v2/media/${featuredMediaId}`, {
        method: 'POST',
        headers: updateMediaHeaders,
        body: JSON.stringify({
            alt_text: post.imageAltText,
            title: post.title, // Also set the image title for good measure
        }),
    });


    // 2. Get or Create Categories and Tags
    const categoryIds = await Promise.all(
      post.categories.map(name => getOrCreateTerm(apiUrl, authHeaders, 'categories', name))
    );
    const tagIds = await Promise.all(
      post.tags.map(name => getOrCreateTerm(apiUrl, authHeaders, 'tags', name))
    );

    // 3. Create Post with all metadata
    const postHeaders = new Headers(authHeaders);
    postHeaders.append('Content-Type', 'application/json');

    // Replace the placeholder image URL in the schema markup
    const finalContent = post.content.replace(/"\[FEATURED_IMAGE_URL\]"/g, `"${featuredMediaUrl}"`);

    const postBodyObject: any = {
      title: post.title,
      content: finalContent,
      status: 'publish',
      slug: post.slug,
      excerpt: post.excerpt,
      featured_media: featuredMediaId,
      categories: categoryIds,
      tags: tagIds,
      meta: {
          // Yoast SEO
          _yoast_wpseo_title: post.seoTitle,
          _yoast_wpseo_metadesc: post.metaDescription,
          _yoast_wpseo_focuskw: keyword,

          // Rank Math
          rank_math_title: post.seoTitle,
          rank_math_description: post.metaDescription,
          rank_math_focus_keyword: keyword,
      }
    };

    if (authorId) {
      postBodyObject.author = authorId;
    }

    const postBody = JSON.stringify(postBodyObject);

    const postResponse = await fetch(`${apiUrl}/wp/v2/posts`, {
      method: 'POST',
      headers: postHeaders,
      body: postBody,
    });

    if (!postResponse.ok) {
      const errorData = await postResponse.json().catch(() => ({ message: 'Check credentials and permissions for creating posts.' }));
      // Provide a more detailed error if possible
      const message = errorData.message || `Post Creation Failed with status ${postResponse.status}`;
      throw new Error(message);
    }

    const newPostData = await postResponse.json();
    return newPostData.link; // Return the URL of the new post
  } catch (error) {
    console.error("Error publishing to WordPress:", error);
    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new Error("A network error occurred. This is often due to a CORS policy on your WordPress site. Please ensure your site allows requests from this origin. You can use a WordPress plugin to enable CORS (Cross-Origin Resource Sharing).");
    }
    if (error instanceof Error) {
        throw new Error(error.message);
    }
    throw new Error("An unknown error occurred while publishing to WordPress.");
  }
};

export const runWpCliCommand = async (credentials: WordPressCredentials, command: string): Promise<string> => {
    const { url } = credentials;
    if (!url.trim()) {
        return "Error: WordPress URL is not configured.";
    }

    // --- SIMULATION ---
    // In a real application, this would make an API call to a secure endpoint on the MCP server,
    // which would then execute the WP-CLI command on the target WordPress server.
    await new Promise(resolve => setTimeout(resolve, 1200));

    const commandClean = command.trim().toLowerCase();

    if (commandClean.startsWith('plugin list')) {
        return `+-------------------------------------+--------+-----------+---------+
| name                                | status | update    | version |
+-------------------------------------+--------+-----------+---------+
| akismet                             | active | none      | 5.3.2   |
| classic-editor                      | active | none      | 1.6.3   |
| elementor                           | active | available | 3.21.5  |
| hello-dolly                         | inactive| none      | 1.7.2   |
| jetpack                             | active | none      | 13.4.1  |
| yoast-seo                           | active | none      | 22.8    |
+-------------------------------------+--------+-----------+---------+
Success: Displayed 6 of 6 plugins.`;
    }

    if (commandClean.startsWith('cache flush')) {
        return `Success: The object cache was flushed.`;
    }
    
    if (commandClean.startsWith('user list')) {
        return `+----+-----------------+--------------+-----------------------+
| ID | user_login      | display_name | user_email            |
+----+-----------------+--------------+-----------------------+
| 1  | admin           | Admin        | admin@example.com     |
| 2  | editor_user     | Editor User  | editor@example.com    |
+----+-----------------+--------------+-----------------------+`;
    }

    return `Error: The command "${command}" is not supported in this simulation or is invalid.
Supported commands for simulation: 'plugin list', 'cache flush', 'user list'.`;
};


// --- SELF-TEST FUNCTIONS ---

export const testAuthorPermissions = async (credentials: WordPressCredentials): Promise<void> => {
    // This function now throws on failure, which is handled by the self-test runner.
    await fetchAuthors(credentials);
};

export const testCategoryPermissions = async (credentials: WordPressCredentials): Promise<void> => {
    await fetchCategories(credentials);
};

export const testMediaPermissions = async (credentials: WordPressCredentials): Promise<void> => {
    const { url, username, password } = credentials;
    const cleanedUrl = url.replace(/\/+$/, '');
    const apiUrl = `${cleanedUrl}/wp-json`;
    const authHeaders = new Headers();
    authHeaders.append('Authorization', 'Basic ' + btoa(`${username}:${password}`));
    let mediaId: number | null = null;

    try {
        const tinyGif = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
        const imageBlob = await dataUrlToBlob(tinyGif);
        const mediaHeaders = new Headers(authHeaders);
        mediaHeaders.append('Content-Disposition', 'attachment; filename="mudde-ai-selftest.gif"');
        mediaHeaders.append('Content-Type', 'image/gif');

        const mediaResponse = await fetch(`${apiUrl}/wp/v2/media`, {
            method: 'POST',
            headers: mediaHeaders,
            body: imageBlob,
        });

        if (!mediaResponse.ok) {
            const errorData = await mediaResponse.json().catch(() => ({}));
            throw new Error(`Media upload failed (Status ${mediaResponse.status}): ${errorData.message || 'Check permissions.'}`);
        }
        const mediaData = await mediaResponse.json();
        mediaId = mediaData.id;

        const deleteResponse = await fetch(`${apiUrl}/wp/v2/media/${mediaId}?force=true`, {
            method: 'DELETE',
            headers: authHeaders,
        });
        if (!deleteResponse.ok) {
            throw new Error(`Media uploaded but could not be deleted (Status ${deleteResponse.status}). Check delete permissions.`);
        }
    } catch (e) {
        if (mediaId) {
             await fetch(`${apiUrl}/wp/v2/media/${mediaId}?force=true`, { method: 'DELETE', headers: authHeaders }).catch(() => {});
        }
        throw e; // Re-throw the error to be caught by the test runner
    }
};

export const testPostPermissions = async (credentials: WordPressCredentials): Promise<void> => {
    const { url, username, password } = credentials;
    const cleanedUrl = url.replace(/\/+$/, '');
    const apiUrl = `${cleanedUrl}/wp-json`;
    const headers = new Headers();
    headers.append('Authorization', 'Basic ' + btoa(`${username}:${password}`));
    headers.append('Content-Type', 'application/json');
    let postId: number | null = null;

    try {
        const postBody = JSON.stringify({
            title: 'Mudde AI Self-Test Post (will be deleted)',
            content: 'This is a temporary post created to test API permissions.',
            status: 'draft',
        });

        const postResponse = await fetch(`${apiUrl}/wp/v2/posts`, {
            method: 'POST',
            headers,
            body: postBody,
        });

        if (!postResponse.ok) {
            const errorData = await postResponse.json().catch(() => ({}));
            throw new Error(`Post creation failed (Status ${postResponse.status}): ${errorData.message || 'Check permissions.'}`);
        }
        const newPostData = await postResponse.json();
        postId = newPostData.id;

        const deleteResponse = await fetch(`${apiUrl}/wp/v2/posts/${postId}?force=true`, {
            method: 'DELETE',
            headers,
        });
        if (!deleteResponse.ok) {
            throw new Error(`Post created but could not be deleted (Status ${deleteResponse.status}). Check delete permissions.`);
        }
    } catch (e) {
         if (postId) {
             await fetch(`${apiUrl}/wp/v2/posts/${postId}?force=true`, { method: 'DELETE', headers }).catch(() => {});
        }
        throw e; // Re-throw the error to be caught by the test runner
    }
};