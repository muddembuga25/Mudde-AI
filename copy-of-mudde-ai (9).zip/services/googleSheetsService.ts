import type { Site } from '../types';

export interface GoogleSheetRow {
    rowIndex: number;
    topic: string;
    data: string[];
}

export const parseSheetUrl = (url: string): { spreadsheetId: string; } | null => {
    // Regex to capture spreadsheet ID from various URL formats
    const match = url.match(/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    if (!match || !match[1]) return null;
    
    // For simplicity, we won't parse the sheet name/gid and will assume the first sheet.
    return { spreadsheetId: match[1] };
};

export const fetchGoogleSheetData = async (site: Site): Promise<GoogleSheetRow[]> => {
    if (!site.googleSheetUrl) {
        throw new Error("Google Sheet URL is not configured.");
    }
    if (!site.apiKeys.google) {
        throw new Error("Google API Key is required to fetch sheet data.");
    }

    const parsed = parseSheetUrl(site.googleSheetUrl);
    if (!parsed) {
        throw new Error("Invalid Google Sheet URL format. Please provide the full URL from your browser.");
    }

    // We assume the data is in the first sheet and covers columns A-Z.
    // A more advanced implementation might allow specifying the sheet name and range.
    const range = 'A:Z';
    const apiUrl = `https://sheets.googleapis.com/v4/spreadsheets/${parsed.spreadsheetId}/values/${range}?key=${site.apiKeys.google}`;

    try {
        const response = await fetch(apiUrl);
        if (!response.ok) {
            const errorData = await response.json();
            const message = errorData.error?.message || `HTTP Error: ${response.status}`;
            throw new Error(`Failed to fetch Google Sheet data. Ensure the Sheet is public ('Anyone with the link can view') and the Google Sheets API is enabled for your API key. Details: ${message}`);
        }
        
        const data = await response.json();
        const values: string[][] = data.values || [];
        
        // Skip header row if it exists and transform data
        const startIndex = values.length > 0 && values[0].some(header => /topic|keyword|title/i.test(header)) ? 1 : 0;
        
        return values.slice(startIndex).map((row, index) => ({
            rowIndex: startIndex + index, // Store original row index for processing tracking
            topic: row[0] || '',
            data: row,
        })).filter(row => row.topic.trim() !== ''); // Filter out empty rows

    } catch (error) {
        console.error("Google Sheets fetch error:", error);
        if (error instanceof Error) throw error;
        throw new Error("An unknown error occurred while fetching from Google Sheets.");
    }
};