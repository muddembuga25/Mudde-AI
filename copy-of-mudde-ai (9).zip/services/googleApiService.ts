// In a real app, this service would handle OAuth and API calls to Google Cloud.
// For this simulation, we will return realistic mock data.

import type { Site, PostPerformanceData } from '../types';

const FAKE_LATENCY = 800;

// Helper to create a stable, pseudo-random number from a string (for consistent mock data)
const pseudoRandom = (seed: string): number => {
    let hash = 0;
    for (let i = 0; i < seed.length; i++) {
        const char = seed.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash |= 0; // Convert to 32bit integer
    }
    return (hash & 0x7fffffff) / 0x7fffffff;
};

export const fetchCombinedPerformanceData = async (site: Site): Promise<PostPerformanceData[]> => {
    if (!site.googleAnalytics?.isConnected) {
        throw new Error("Google Account is not connected for this site.");
    }
    
    await new Promise(resolve => setTimeout(resolve, FAKE_LATENCY));

    // Filter for posts that have a real URL
    const publishedPosts = (site.history || []).filter(p => p.url && p.url !== '#');

    // Generate mock data for each published post
    const performanceData: PostPerformanceData[] = publishedPosts.map(post => {
        const seed = post.id + site.id;
        const impressions = Math.floor(pseudoRandom(seed + 'imp') * 5000) + 100;
        const clicks = Math.floor(impressions * (pseudoRandom(seed + 'ctr') * 0.1));
        const position = Math.round((pseudoRandom(seed + 'pos') * 49) + 1);
        const pageviews = Math.floor(clicks * (1 + pseudoRandom(seed + 'pv') * 0.5));

        return {
            postId: post.id,
            title: post.topic,
            url: post.url,
            focusKeyword: post.topic, // Simplified for mock
            searchConsole: {
                clicks,
                impressions,
                ctr: impressions > 0 ? clicks / impressions : 0,
                position: position,
            },
            analytics: {
                pageviews,
                users: Math.floor(pageviews * (0.8 + pseudoRandom(seed + 'usr') * 0.2)),
                avgTimeOnPage: Math.floor(pseudoRandom(seed + 'time') * 180) + 20,
            },
        };
    });

    return performanceData.sort((a, b) => b.searchConsole.clicks - a.searchConsole.clicks);
};