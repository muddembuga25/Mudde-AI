// This service assumes gapi and google.accounts.oauth2 have been loaded from scripts in index.html

declare global {
  var google: any;
}

const DRIVE_API_DISCOVERY_DOC = 'https://www.googleapis.com/discovery/v1/apis/drive/v3/rest';
const DRIVE_SCOPES = 'https://www.googleapis.com/auth/drive.file';

// --- Client & GAPI Management ---

export const loadGapi = (): Promise<void> => {
    return new Promise((resolve, reject) => {
        if ((window as any).gapi) {
            (window as any).gapi.load('client:picker', {
                callback: resolve,
                onerror: reject,
            });
        } else {
            reject(new Error("gapi script not loaded."));
        }
    });
};

export const initTokenClient = (
    clientId: string,
    onTokenResponse: (tokenResponse: any) => void,
    onError: (error: any) => void,
): any => {
    return google.accounts.oauth2.initTokenClient({
        client_id: clientId,
        scope: DRIVE_SCOPES,
        callback: onTokenResponse,
        error_callback: onError,
    });
};

// --- API Interactions (Authenticated) ---

const findOrCreateFolder = async (folderName: string, accessToken: string): Promise<string> => {
    await (window as any).gapi.client.load(DRIVE_API_DISCOVERY_DOC);
    
    // Search for the folder
    const response = await (window as any).gapi.client.drive.files.list({
        q: `mimeType='application/vnd.google-apps.folder' and name='${folderName}' and trashed=false`,
        fields: 'files(id, name)',
        spaces: 'drive',
        access_token: accessToken,
    });
    
    if (response.result.files && response.result.files.length > 0) {
        return response.result.files[0].id;
    }
    
    // Create the folder if it doesn't exist
    const createResponse = await (window as any).gapi.client.drive.files.create({
        resource: {
            name: folderName,
            mimeType: 'application/vnd.google-apps.folder',
        },
        fields: 'id',
        access_token: accessToken,
    });

    return createResponse.result.id;
};

export const createDocFromHtml = async (title: string, htmlContent: string, accessToken: string): Promise<string> => {
    const FOLDER_NAME = "Mudde AI";
    const boundary = '-------314159265358979323846';
    const delimiter = `\r\n--${boundary}\r\n`;
    const close_delim = `\r\n--${boundary}--`;

    try {
        const folderId = await findOrCreateFolder(FOLDER_NAME, accessToken);
        
        const metadata = {
            name: title,
            mimeType: 'application/vnd.google-apps.document',
            parents: [folderId],
        };

        const multipartRequestBody =
            delimiter +
            'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
            JSON.stringify(metadata) +
            delimiter +
            'Content-Type: text/html; charset=UTF-8\r\n\r\n' +
            htmlContent +
            close_delim;

        const response = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': `multipart/related; boundary=${boundary}`,
            },
            body: multipartRequestBody,
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`Failed to create Google Doc: ${errorData.error.message}`);
        }
        
        const fileData = await response.json();
        return fileData.webViewLink || `https://docs.google.com/document/d/${fileData.id}/edit`;

    } catch (error) {
        console.error("Error creating Google Doc:", error);
        throw error;
    }
};


// --- Google Picker ---

export const createPicker = (
    apiKey: string,
    accessToken: string,
    onPick: (docs: any[]) => void,
    onCancel: () => void,
): void => {
    const view = new google.picker.View(google.picker.ViewId.DOCS);
    view.setMimeTypes("application/vnd.google-apps.document,image/png,image/jpeg,image/webp,application/pdf");

    const picker = new google.picker.PickerBuilder()
        .enableFeature(google.picker.Feature.NAV_HIDDEN)
        .setAppId(apiKey)
        .setOAuthToken(accessToken)
        .addView(view)
        .setDeveloperKey(apiKey)
        .setCallback((data: any) => {
            if (data.action === google.picker.Action.PICKED) {
                onPick(data.docs);
            } else if (data.action === google.picker.Action.CANCEL) {
                onCancel();
            }
        })
        .build();
    picker.setVisible(true);
};

export const downloadDriveFileAsBase64 = async (
    fileId: string,
    mimeType: string,
    accessToken: string
): Promise<string> => {
    let downloadUrl: string;

    if (mimeType === 'application/vnd.google-apps.document') {
        downloadUrl = `https://www.googleapis.com/drive/v3/files/${fileId}/export?mimeType=text/plain`;
    } else {
        downloadUrl = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
    }

    const response = await fetch(downloadUrl, {
        headers: { Authorization: `Bearer ${accessToken}` }
    });

    if (!response.ok) {
        throw new Error(`Failed to download file from Google Drive. Status: ${response.status}`);
    }

    const blob = await response.blob();
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
};