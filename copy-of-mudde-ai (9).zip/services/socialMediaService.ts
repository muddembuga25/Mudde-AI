import type { SocialMediaAccount, SocialMediaPost } from '../types';
import type { SocialPlatform } from './oauthService';

export const postToSocialMedia = async (
    platform: SocialPlatform,
    account: SocialMediaAccount,
    post: SocialMediaPost
): Promise<{ success: boolean; message?: string }> => {
    
    console.log(`
        --- [Social Media Post Simulation] ---
        Attempting to post to ${platform} for account "${account.name}".
        Content: "${post.content.substring(0, 50)}..."
        
        This simulation has a chance to fail to demonstrate how the app handles
        posting errors, like an expired token.
        -------------------------------------------
    `);

    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Randomly fail about 15% of the time to simulate an API error
    if (Math.random() < 0.15) {
        return { 
            success: false, 
            message: `Failed to post to ${platform}. The API token may have expired or permissions were revoked. Please reconnect.` 
        };
    }

    return { success: true };
};

export const postCommentToSocialMedia = async (
    platform: SocialPlatform,
    account: SocialMediaAccount,
    postUrlToCommentOn: string,
    commentText: string
): Promise<{ success: boolean; message?: string }> => {
    
    console.log(`
        --- [Social Media Comment Simulation] ---
        Attempting to post a comment to ${platform} for account "${account.name}".
        Target Post: ${postUrlToCommentOn}
        Comment: "${commentText.substring(0, 50)}..."
        -------------------------------------------
    `);
    await new Promise(resolve => setTimeout(resolve, 1500));
    if (Math.random() < 0.1) {
        return { success: false, message: `Failed to post comment. The API token may be invalid.` };
    }
    return { success: true };
};
