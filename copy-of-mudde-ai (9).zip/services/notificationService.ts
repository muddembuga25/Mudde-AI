import type { Site, Draft } from '../types';

export const sendDraftNotification = async (site: Site, draft: Draft): Promise<void> => {
    if (!site.isDraftNotificationEnabled || !site.draftNotificationMethods || site.draftNotificationMethods.length === 0) {
        return;
    }

    const title = draft.blogPost.title;
    const message = `A new draft titled "${title}" has been generated for your site "${site.name}" and is ready for your review.`;

    for (const method of site.draftNotificationMethods) {
        try {
            switch (method) {
                case 'email':
                    if (site.draftNotificationEmail) {
                        console.log(`[Notification Service] SIMULATING sending EMAIL to ${site.draftNotificationEmail}: ${message}`);
                    }
                    break;
                case 'whatsapp':
                    const waAccount = site.socialMediaSettings.whatsapp?.find(acc => acc.isConnected && acc.isAutomationEnabled);
                    if (waAccount) {
                        console.log(`[Notification Service] SIMULATING sending WHATSAPP to ${waAccount.destination}: ${message}`);
                    }
                    break;
                case 'telegram':
                    const tgAccount = site.socialMediaSettings.telegram?.find(acc => acc.isConnected && acc.isAutomationEnabled);
                    if (tgAccount) {
                        console.log(`[Notification Service] SIMULATING sending TELEGRAM to ${tgAccount.chatId}: ${message}`);
                    }
                    break;
            }
        } catch (error) {
            console.error(`[Notification Service] Failed to send ${method} notification for draft "${title}":`, error);
        }
    }
};
