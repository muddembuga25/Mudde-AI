import { AppStatus } from '../types';
import type { StoredUser, User, Site, ApiKeys, RssItem, Draft, PostHistoryItem, SocialMediaPost, EmailMarketingCampaign, BacklinksHistoryItem, MonitoredBacklink, CommentingProspect, SocialCommentingProspect, StrategicBrief, PostPerformanceData, AnalyticsInsight, SocialMediaAccount, WhatsAppAccount, TelegramAccount, MailchimpAccount, SeoChecklist, BlogPost } from '../types';
import { AiProvider } from '../types';
import * as aiServiceInternal from './aiServiceInternal';
import { aiProviderToApiKey } from './aiServiceInternal';
import * as wordpressService from './wordpressService';
import * as socialMediaService from './socialMediaService';
import * as googleApiService from './googleApiService';
import * as oauthService from './oauthService';
import * as dataforseoService from './dataforseoService';
import { sendDraftNotification } from './notificationService';
import { fetchAndParseRssFeed } from './rssService';
import { fetchGoogleSheetData } from './googleSheetsService';
import type { GoogleSheetRow } from './googleSheetsService';
import type { SocialPlatform } from './oauthService';
import { calculateSeoScore } from './seoService';


const FAKE_LATENCY = 400; // ms

// --- Mock Database (localStorage) ---
const getUsersDB = (): StoredUser[] => JSON.parse(localStorage.getItem('mcp-users') || '[]');
const setUsersDB = (users: StoredUser[]) => localStorage.setItem('mcp-users', JSON.stringify(users));
const getSitesDB = (): Site[] => JSON.parse(localStorage.getItem('mcp-sites') || '[]');
const setSitesDB = (sites: Site[]) => localStorage.setItem('mcp-sites', JSON.stringify(sites));

// --- Auth Token Simulation ---
const JWT_SECRET = 'this-is-a-super-secret-key-for-local-dev-only';
const createToken = (username: string) => `header.${btoa(JSON.stringify({ username, exp: Date.now() + 86400000 }))}.${JWT_SECRET}`;
const decodeToken = (token: string): { username: string; exp: number } | null => {
    try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        if (token.split('.')[2] !== JWT_SECRET) return null; // Invalid signature
        return payload;
    } catch {
        return null;
    }
};

// --- Helper Functions ---
const getSiteForTask = async (siteId: string): Promise<Site> => {
    await new Promise(resolve => setTimeout(resolve, FAKE_LATENCY / 4));
    const site = getSitesDB().find(s => s.id === siteId);
    if (!site) throw new Error(`Site with ID ${siteId} not found for task.`);
    return JSON.parse(JSON.stringify(site)); // Return a copy to prevent mutation issues
};

const updateSiteInDB = (updatedSite: Site): Site => {
    const sites = getSitesDB();
    const index = sites.findIndex(s => s.id === updatedSite.id);
    if (index !== -1) {
        sites[index] = updatedSite;
        setSitesDB(sites);
    }
    // In a real app, you'd be very careful about what you send back.
    // For this simulation, the client-side state needs the full site object, including API keys.
    return updatedSite;
};

const logApiUsage = (site: Site, provider: keyof ApiKeys, cost: number): Site => {
    if (!provider || cost === 0) return site;
    const currentCost = site.apiUsage?.[provider] || 0;
    const newApiUsage = { ...(site.apiUsage || {}), [provider]: currentCost + cost };
    return { ...site, apiUsage: newApiUsage };
};

const createResponse = <T>(result: T, updatedSite: Site) => {
    return { result, updatedSite: updateSiteInDB(updatedSite) };
};

const _publishSocialMediaPosts = async (site: Site, posts: Record<string, SocialMediaPost>): Promise<any[]> => {
    const publishingLog: any[] = [];
    const enabledPlatforms = (Object.keys(site.socialMediaSettings) as (keyof typeof site.socialMediaSettings)[]);

    for (const platform of enabledPlatforms) {
        const platformKey = platform as oauthService.SocialPlatform;
        if (posts[platformKey]) {
            const enabledAccounts = (site.socialMediaSettings[platformKey] as SocialMediaAccount[] || [])
                .filter(acc => acc.isConnected && acc.isAutomationEnabled);

            for (const account of enabledAccounts) {
                try {
                    const result = await socialMediaService.postToSocialMedia(platformKey, account, posts[platformKey]);
                    if (result.success) {
                        publishingLog.push({ platform, accountName: account.name, status: 'success' });
                    } else {
                        publishingLog.push({ platform, accountName: account.name, status: 'failed', message: result.message });
                    }
                } catch (e: any) {
                    publishingLog.push({ platform, accountName: account.name, status: 'failed', message: e.message });
                }
            }
        }
    }
    console.log('[MCP Service] Social Publishing Log:', publishingLog);
    return publishingLog;
};

// --- Progress Callback Type ---
type ProgressCallback = (update: { status: AppStatus; message: string; topic?: string; cost?: { provider: keyof ApiKeys; amount: number; }}) => void;
const noOpProgress: ProgressCallback = () => {};


// --- API Service Functions ---

// Authentication
export async function login(username: string, passwordHash: string): Promise<{ user: User; token: string }> {
    await new Promise(resolve => setTimeout(resolve, FAKE_LATENCY));
    const users = getUsersDB();
    const userRecord = users.find(u => u.username.toLowerCase() === username.toLowerCase() && u.passwordHash === passwordHash);
    if (!userRecord) {
        throw new Error("Invalid username or password.");
    }
    const { passwordHash: _, ...userForClient } = userRecord;
    const token = createToken(username);
    return { user: userForClient, token };
}

export async function signup(newUser: StoredUser): Promise<{ user: User; token: string }> {
    await new Promise(resolve => setTimeout(resolve, FAKE_LATENCY));
    const users = getUsersDB();
    if (users.some(u => u.username.toLowerCase() === newUser.username.toLowerCase())) {
        throw new Error("Username already exists.");
    }
    users.push(newUser);
    setUsersDB(users);
    const { passwordHash: _, ...userForClient } = newUser;
    const token = createToken(newUser.username);
    return { user: userForClient, token };
}

export async function validateToken(token: string): Promise<User | null> {
    await new Promise(resolve => setTimeout(resolve, FAKE_LATENCY / 2));
    const payload = decodeToken(token);
    if (!payload || payload.exp < Date.now()) {
        return null;
    }
    const users = getUsersDB();
    const userRecord = users.find(u => u.username === payload.username);
    if (!userRecord) return null;
    const { passwordHash, ...userForClient } = userRecord;
    return userForClient;
}

// Site Management
export async function getSitesForUser(username: string): Promise<Site[]> {
    await new Promise(resolve => setTimeout(resolve, FAKE_LATENCY));
    // Return the full site object, including API keys.
    // In a real client-server app, this would be a security risk.
    // For this simulation, the client needs the keys to function.
    return getSitesDB();
}

export async function updateSitesForUser(username: string, sites: Site[]): Promise<Site[]> {
    await new Promise(resolve => setTimeout(resolve, FAKE_LATENCY / 2));
    const currentSites = getSitesDB();
    const updatedSitesWithKeys = sites.map(clientSite => {
        const serverSite = currentSites.find(s => s.id === clientSite.id);
        // Ensure API keys from the "DB" are preserved if they exist,
        // otherwise use what the client sent (e.g., for a new site).
        return { ...clientSite, apiKeys: serverSite ? serverSite.apiKeys : clientSite.apiKeys };
    });
    setSitesDB(updatedSitesWithKeys);
    // Return the full site objects back to the client state management hook.
    return updatedSitesWithKeys;
}

// --- Proxied AI Operations ---

export const generateStrategicBrief = async (siteId: string, sourceType: 'keyword' | 'rss' | 'video' | 'google_sheet', sourceDetails: any, options?: any) => {
    let site = await getSiteForTask(siteId);
    let briefResult;
    switch(sourceType) {
        case 'keyword': briefResult = await aiServiceInternal.generateStrategicBriefFromKeyword(sourceDetails as string, site); break;
        case 'rss': briefResult = await aiServiceInternal.generateStrategicBriefFromRssItem(sourceDetails, site); break;
        case 'video': briefResult = await aiServiceInternal.generateStrategicBriefFromVideoUrl(sourceDetails, site, options); break;
        case 'google_sheet': briefResult = await aiServiceInternal.generateStrategicBriefFromGoogleSheetRow(sourceDetails, site); break;
        default: throw new Error('Unsupported source type');
    }
    site = logApiUsage(site, briefResult.cost.provider, briefResult.cost.amount);
    return { brief: briefResult.brief, updatedSite: updateSiteInDB(site) };
};

export const fleshOutBrief = async (siteId: string, partialBrief: Partial<StrategicBrief>) => {
    let site = await getSiteForTask(siteId);
    const { brief, cost } = await aiServiceInternal.fleshOutBrief(partialBrief, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { brief, updatedSite: updateSiteInDB(site) };
};

export const generateArticle = async (siteId: string, brief: StrategicBrief) => {
    let site = await getSiteForTask(siteId);
    const { postData, cost } = await aiServiceInternal.generateArticleFromBrief(brief, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { postData, updatedSite: updateSiteInDB(site) };
};

export const optimizeArticle = async (siteId: string, rawHtmlContent: string, brief: StrategicBrief) => {
    let site = await getSiteForTask(siteId);
    const { finalHtmlContent, cost } = await aiServiceInternal.optimizeAndFinalizeArticle(rawHtmlContent, brief, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { finalHtmlContent, updatedSite: updateSiteInDB(site) };
};

export const generateImage = async (siteId: string, prompt: string) => {
    let site = await getSiteForTask(siteId);
    const { base64Image, cost } = await aiServiceInternal.generateFeaturedImage(prompt, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { base64Image, updatedSite: updateSiteInDB(site) };
};

export const generateSocialGraphicAndCaption = async (siteId: string, prompt: string, aspectRatio: '16:9' | '1:1' | '9:16', platformDescription: string, modelConfigOverride?: Partial<Site['modelConfig']>, characterId?: string) => {
    let site = await getSiteForTask(siteId);
    const { generationResult, totalCost } = await aiServiceInternal.generateSocialGraphicAndCaption(site, prompt, aspectRatio, platformDescription, modelConfigOverride, characterId);
    site = logApiUsage(site, totalCost.provider, totalCost.amount);
    return { generationResult, updatedSite: updateSiteInDB(site) };
};

export const generateSocialVideoAndCaption = async (siteId: string, prompt: string, characterId?: string) => {
    let site = await getSiteForTask(siteId);
    const { generationResult, totalCost } = await aiServiceInternal.generateSocialVideoAndCaption(site, prompt, characterId);
    site = logApiUsage(site, totalCost.provider, totalCost.amount);
    return { generationResult, updatedSite: updateSiteInDB(site) };
};

export const generateSocialGraphicPrompt = async (siteId: string) => {
    let site = await getSiteForTask(siteId);
    const { prompt, cost } = await aiServiceInternal.generateSocialGraphicPrompt(site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { prompt, updatedSite: updateSiteInDB(site) };
};

export const brainstormContentIdeas = async (siteId: string, theme: string, contentType: 'blog_post' | 'social_graphic' | 'email_campaign') => {
    let site = await getSiteForTask(siteId);
    const { ideas, cost } = await aiServiceInternal.brainstormContentIdeas(site, theme, contentType);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { ideas, updatedSite: updateSiteInDB(site) };
};

export const suggestKeywords = async (siteId: string, existingKeywords: string) => {
    let site = await getSiteForTask(siteId);
    const { suggestions, cost } = await aiServiceInternal.suggestKeywords(existingKeywords, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { suggestions, updatedSite: updateSiteInDB(site) };
};

export const suggestKeywordsFromUrl = async (siteId: string, url: string, existingKeywords: string) => {
    let site = await getSiteForTask(siteId);
    const { suggestions, cost } = await aiServiceInternal.suggestKeywordsFromUrl(url, existingKeywords, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { suggestions, updatedSite: updateSiteInDB(site) };
};

export const generateBrandGuidelineFromUrl = async (siteId: string, url: string) => {
    let site = await getSiteForTask(siteId);
    const { guideline, cost } = await aiServiceInternal.generateBrandGuidelineFromUrl(url, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    site.brandGuideline = guideline;
    return { guideline, updatedSite: updateSiteInDB(site) };
};

export const findBestKeyword = async (siteId: string, seedKeyword: string) => {
    let site = await getSiteForTask(siteId);
    const { bestKeyword, cost } = await aiServiceInternal.findBestKeyword(seedKeyword, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { bestKeyword, updatedSite: updateSiteInDB(site) };
};

export const findCommentingProspects = async (siteId: string, topic: string) => {
    let site = await getSiteForTask(siteId);
    const { prospects, cost } = await aiServiceInternal.findCommentingProspects(topic, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { prospects, updatedSite: updateSiteInDB(site) };
};

export const generateBlogComment = async (siteId: string, prospectUrl: string, ownPostTopic: string) => {
    let site = await getSiteForTask(siteId);
    const { comment, cost } = await aiServiceInternal.generateBlogComment(prospectUrl, ownPostTopic, site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { comment, updatedSite: updateSiteInDB(site) };
};

export const checkBacklinkStatus = async (siteId: string, link: MonitoredBacklink) => {
    let site = await getSiteForTask(siteId);
    const result = await aiServiceInternal.checkBacklinkStatus(site, link);
    
    const updatedLinks = (site.monitoredBacklinks || []).map(l => 
        l.id === link.id ? { ...l, status: result.status, anchorText: result.anchorText, lastChecked: Date.now() } : l
    );
    site.monitoredBacklinks = updatedLinks;
    
    return { updatedSite: updateSiteInDB(site) };
};

export const findSocialMediaProspects = async (siteId: string) => {
    let site = await getSiteForTask(siteId);
    const { prospects, cost } = await aiServiceInternal.findSocialMediaProspects(site);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { prospects, updatedSite: updateSiteInDB(site) };
};

export const generateSocialMediaComment = async (siteId: string, prospect: SocialCommentingProspect, sourcePost: PostHistoryItem) => {
    let site = await getSiteForTask(siteId);
    const { comment, cost } = await aiServiceInternal.generateSocialMediaComment(site, prospect, sourcePost);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { comment, updatedSite: updateSiteInDB(site) };
};

export const postSocialMediaComment = async (siteId: string, prospect: SocialCommentingProspect) => {
    let site = await getSiteForTask(siteId);
    const platform = prospect.platform as SocialPlatform;
    const account = (site.socialMediaSettings[platform] as SocialMediaAccount[] | undefined)?.find(a => a.id === prospect.postingAccountId);
    
    if (!account) {
        throw new Error(`Could not find account with ID ${prospect.postingAccountId} for platform ${platform}`);
    }
    
    await socialMediaService.postCommentToSocialMedia(platform, account, prospect.prospectPostUrl, prospect.generatedComment || '');
    
    // Update prospect status in site data
    site.socialCommentingProspects = (site.socialCommentingProspects || []).map(p =>
        p.id === prospect.id ? { ...p, status: 'posted' as const } : p
    );

    return { updatedSite: updateSiteInDB(site) };
};

export const regenerateArticleSection = async (siteId: string, brief: StrategicBrief, heading: string, sectionHtml: string) => {
    let site = await getSiteForTask(siteId);
    const { regeneratedHtml, cost } = await aiServiceInternal.regenerateArticleSection(site, brief, heading, sectionHtml);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { regeneratedHtml, updatedSite: updateSiteInDB(site) };
};


// --- Social Media & OAuth ---
export const exchangeCodeForToken = async (siteId: string, platform: oauthService.SocialPlatform, accountId: string, code: string): Promise<{ updatedSite: Site }> => {
    let site = await getSiteForTask(siteId);
    const platformAccounts = (site.socialMediaSettings[platform] as SocialMediaAccount[] | undefined) || [];
    const account = platformAccounts.find(a => a.id === accountId);
    if (!account || !account.clientId || !account.clientSecret) {
        throw new Error(`Configuration for ${platform} account ${accountId} not found or is incomplete.`);
    }

    const { accessToken } = await oauthService.exchangeCodeForToken(platform, code, account.clientId, account.clientSecret);

    // After getting token, update account status
    const updatedAccounts = platformAccounts.map(acc => {
        if (acc.id === accountId) {
            return {
                ...acc,
                accessToken,
                isConnected: true,
                status: 'connected' as const,
                statusMessage: 'Connected successfully.'
            };
        }
        return acc;
    });

    site.socialMediaSettings = { ...site.socialMediaSettings, [platform]: updatedAccounts };
    return { updatedSite: updateSiteInDB(site) };
};

export const verifySocialConnection = async (siteId: string, platform: oauthService.SocialPlatform, accountId: string, accessToken: string): Promise<{ updatedSite: Site }> => {
    let site = await getSiteForTask(siteId);
    const result = await oauthService.verifyConnection(platform, accessToken);
    
    const platformAccounts = (site.socialMediaSettings[platform] as SocialMediaAccount[] | undefined) || [];
    const updatedAccounts = platformAccounts.map(acc => {
        if (acc.id === accountId) {
            return {
                ...acc,
                isConnected: result.success,
                status: result.success ? 'connected' as const : 'needs_reauth' as const,
                statusMessage: result.message
            };
        }
        return acc;
    });

    site.socialMediaSettings = { ...site.socialMediaSettings, [platform]: updatedAccounts };
    return { updatedSite: updateSiteInDB(site) };
};

export const verifyCredentialConnection = async (siteId: string, platform: 'whatsapp' | 'telegram', account: WhatsAppAccount | TelegramAccount): Promise<{ updatedSite: Site }> => {
    let site = await getSiteForTask(siteId);
    const result = await oauthService.verifyCredentialBasedConnection(platform, account);

    const platformAccounts = (site.socialMediaSettings[platform] as (WhatsAppAccount | TelegramAccount)[] | undefined) || [];
    const updatedAccounts = platformAccounts.map(acc => {
        if (acc.id === account.id) {
            return {
                ...acc,
                ...account, // update with potentially changed credentials from UI
                isConnected: result.success,
                status: result.success ? 'connected' as const : 'disconnected' as const,
                statusMessage: result.message
            };
        }
        return acc;
    });
    
    site.socialMediaSettings = { ...site.socialMediaSettings, [platform]: updatedAccounts };
    return { updatedSite: updateSiteInDB(site) };
};

export const publishSocialGraphic = async (siteId: string, generationResult: { imageUrl: string; caption: string; }): Promise<{ updatedSite: Site }> => {
    let site = await getSiteForTask(siteId);
    await aiServiceInternal.publishSocialGraphic(site, generationResult);
    
    const newHistoryItem: PostHistoryItem = {
        id: crypto.randomUUID(),
        topic: `Social Graphic: "${generationResult.caption.substring(0, 50)}..."`,
        url: '#',
        date: Date.now(),
        type: 'Social Graphic',
        socialGraphics: {
            custom: { // A generic key for the single generated graphic
                imageUrl: generationResult.imageUrl,
                caption: generationResult.caption
            }
        },
    };
    
    site.history = [newHistoryItem, ...(site.history || [])];
    
    return { updatedSite: updateSiteInDB(site) };
};


// --- Analytics ---
export const connectGoogleAnalytics = async (siteId: string): Promise<{ updatedSite: Site }> => {
    let site = await getSiteForTask(siteId);
    // In a real app, this would trigger the OAuth flow. Here we just simulate success.
    site.googleAnalytics = { isConnected: true, userEmail: 'demo@example.com' };
    return { updatedSite: updateSiteInDB(site) };
};

export const disconnectGoogleAnalytics = async (siteId: string): Promise<{ updatedSite: Site }> => {
    let site = await getSiteForTask(siteId);
    site.googleAnalytics = { isConnected: false, userEmail: '' };
    return { updatedSite: updateSiteInDB(site) };
};

// FIX: Add missing connect/disconnect functions for Google Drive
// --- Google Drive Integration ---
export const connectGoogleDrive = async (siteId: string, accessToken: string): Promise<{ updatedSite: Site }> => {
    let site = await getSiteForTask(siteId);
    // In a real app, you might fetch user info from the token. Here, we'll just simulate it.
    site.googleDrive = { isConnected: true, userEmail: 'drive.user@example.com' };
    return { updatedSite: updateSiteInDB(site) };
};

export const disconnectGoogleDrive = async (siteId: string): Promise<{ updatedSite: Site }> => {
    let site = await getSiteForTask(siteId);
    site.googleDrive = { isConnected: false, userEmail: '' };
    return { updatedSite: updateSiteInDB(site) };
};

export const getAnalyticsData = async (siteId: string): Promise<{ performanceData: PostPerformanceData[] }> => {
    const site = await getSiteForTask(siteId);
    // This is a direct pass-through in simulation, but in a real app,
    // the backend would handle fetching with stored credentials.
    const performanceData = await googleApiService.fetchCombinedPerformanceData(site);
    return { performanceData };
};

export const generateAnalyticsInsights = async (siteId: string, postData: PostPerformanceData): Promise<{ insights: AnalyticsInsight; updatedSite: Site; }> => {
    let site = await getSiteForTask(siteId);
    const { insights, cost } = await aiServiceInternal.generateAnalyticsInsights(site, postData);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { insights, updatedSite: updateSiteInDB(site) };
};

// --- New Mailchimp Integration ---
export const connectMailchimp = async (siteId: string, apiKey: string, serverPrefix: string): Promise<{ updatedSite: Site }> => {
    let site = await getSiteForTask(siteId);
    try {
        const { availableAudiences } = await aiServiceInternal.verifyMailchimpConnection(apiKey, serverPrefix);
        const newMailchimpConfig: MailchimpAccount = {
            isConnected: true,
            apiKey,
            serverPrefix,
            status: 'connected',
            statusMessage: `Connected successfully. Found ${availableAudiences.length} audience(s).`,
            availableAudiences,
            defaultAudienceId: availableAudiences.length > 0 ? availableAudiences[0].id : undefined,
        };
        site.mailchimp = newMailchimpConfig;
    } catch (e: any) {
        site.mailchimp = {
            ...site.mailchimp || { apiKey: '', serverPrefix: '' },
            isConnected: false,
            status: 'error',
            statusMessage: e.message || "Failed to connect to Mailchimp.",
        };
    }
    return { updatedSite: updateSiteInDB(site) };
};

export const disconnectMailchimp = async (siteId: string): Promise<{ updatedSite: Site }> => {
    let site = await getSiteForTask(siteId);
    site.mailchimp = {
        isConnected: false,
        apiKey: '',
        serverPrefix: '',
        status: 'disconnected',
        statusMessage: '',
        availableAudiences: [],
        defaultAudienceId: undefined,
    };
    return { updatedSite: updateSiteInDB(site) };
};

export const generateManualEmailCampaign = async (siteId: string, topic: string): Promise<{ campaign: EmailMarketingCampaign; updatedSite: Site }> => {
    let site = await getSiteForTask(siteId);
    const { campaign, cost } = await aiServiceInternal.generateStandaloneEmailCampaign(site, topic);
    site = logApiUsage(site, cost.provider, cost.amount);
    return { campaign, updatedSite: updateSiteInDB(site) };
};

export const sendAndRecordEmailCampaign = async (siteId: string, campaign: EmailMarketingCampaign): Promise<{ updatedSite: Site }> => {
    let site = await getSiteForTask(siteId);

    if (site.mailchimp?.isConnected) {
        await aiServiceInternal.sendMailchimpCampaign(site, campaign);
    } else {
        console.warn("[MCP Service] Mailchimp not connected. Skipping actual send, but saving to history.");
    }
    
    const newHistoryItem: PostHistoryItem = {
        id: crypto.randomUUID(),
        topic: campaign.subject,
        url: '#', // No URL for a standalone email
        date: Date.now(),
        type: 'Email Marketing',
        emailCampaign: campaign,
    };
    site.history = [newHistoryItem, ...(site.history || [])];

    return { updatedSite: updateSiteInDB(site) };
};


// --- New Verification Functions for Integrations Tab ---
export const verifyGoogleConnection = async (siteId: string, service: 'drive' | 'analytics'): Promise<{ success: boolean; message: string; }> => {
    const site = await getSiteForTask(siteId);
    const connection = service === 'drive' ? site.googleDrive : site.googleAnalytics;
    if (connection?.isConnected) {
        // In a real app, you might make a lightweight API call to confirm the token is still valid.
        return { success: true, message: `Successfully connected as ${connection.userEmail}.` };
    }
    return { success: false, message: `Google ${service} is not connected. Please connect it in the References or Analytics tab.` };
};

export const verifyMailchimpConnection = async (siteId: string): Promise<{ success: boolean; message: string; }> => {
    const site = await getSiteForTask(siteId);
    if (!site.mailchimp || !site.mailchimp.apiKey || !site.mailchimp.serverPrefix) {
        return { success: false, message: "API Key or Server Prefix is missing in Automation settings." };
    }
    try {
        await aiServiceInternal.verifyMailchimpConnection(site.mailchimp.apiKey, site.mailchimp.serverPrefix);
        return { success: true, message: "Connection to Mailchimp is active." };
    } catch (e: any) {
        return { success: false, message: e.message || "Connection failed." };
    }
};

export const verifyWordPressConnection = async (siteId: string) => {
    const site = await getSiteForTask(siteId);
    return wordpressService.verifyWordPressConnection({
        url: site.wordpressUrl,
        username: site.wordpressUsername,
        password: site.applicationPassword
    });
};

export const verifyDataForSeoConnection = async (siteId: string): Promise<{ success: boolean; message: string; }> => {
    const site = await getSiteForTask(siteId);
    return dataforseoService.verifyConnection(site);
};

export const verifyApiKey = async (siteId: string, provider: keyof ApiKeys, apiKey: string) => {
    return aiServiceInternal.verifyApiKey(provider, apiKey);
};

export const fetchAvailableModels = async (siteId: string, provider: AiProvider, apiKey: string) => {
    let site = await getSiteForTask(siteId);
    const models = await aiServiceInternal.fetchAvailableModels(provider, apiKey);
    site.fetchedModels = { ...(site.fetchedModels || {}), [provider]: models };
    return { models, updatedSite: updateSiteInDB(site) };
};

export const runWpCliCommand = async (siteId: string, command: string): Promise<{ output: string }> => {
    const site = await getSiteForTask(siteId);
    if (!site.wordpressUrl || !site.wordpressUsername || !site.applicationPassword) {
        throw new Error("WordPress credentials are not configured for this site.");
    }
    const output = await wordpressService.runWpCliCommand({
        url: site.wordpressUrl,
        username: site.wordpressUsername,
        password: site.applicationPassword
    }, command);
    
    // This action doesn't change site config, so we don't need to return updatedSite.
    return { output };
};

export const runRawDataForSeoQuery = async (siteId: string, endpoint: string, payload: any) => {
    const site = await getSiteForTask(siteId);
    const result = await dataforseoService.runRawDataForSeoQuery(site, endpoint, payload);
    return { result };
};

export const publishPostAndFollowUps = async (siteId: string, draft: Draft, finalBlogPost: BlogPost): Promise<{ postUrl: string; publishingLog: any[]; updatedSite: Site }> => {
    let site = await getSiteForTask(siteId);

    // 1. Publish to WordPress
    const postUrl = await wordpressService.publishPost(
        { url: site.wordpressUrl, username: site.wordpressUsername, password: site.applicationPassword },
        finalBlogPost, finalBlogPost.focusKeyword, site.authorId
    );

    // 2. Generate Social Posts
    const socialPostsResult = await aiServiceInternal.generateSocialMediaPosts(finalBlogPost, postUrl, site);
    site = logApiUsage(site, socialPostsResult.cost.provider, socialPostsResult.cost.amount);

    // 3. Publish to Social Media
    const publishingLog = site.isSocialFollowUpEnabled ? await _publishSocialMediaPosts(site, socialPostsResult.posts) : [];

    // 4. Generate & Send Email Campaign
    let emailCampaign: EmailMarketingCampaign | undefined = undefined;
    if (site.isEmailFollowUpEnabled) {
        try {
            const emailResult = await aiServiceInternal.generateEmailCampaignFromPost(finalBlogPost, postUrl, site);
            site = logApiUsage(site, emailResult.cost.provider, emailResult.cost.amount);
            emailCampaign = emailResult.campaign;
            if (site.mailchimp?.isConnected) {
                await aiServiceInternal.sendMailchimpCampaign(site, emailCampaign);
            }
        } catch (e) {
            console.error("Failed to process email follow-up:", e);
        }
    }

    // 5. Create History Item
    const newHistoryItem: PostHistoryItem = { 
        id: crypto.randomUUID(), 
        topic: draft.sourceTopic, 
        url: postUrl, 
        date: Date.now(), 
        type: draft.sourceDetails.type === 'google_sheet' ? 'Google Sheet' : draft.sourceDetails.type === 'rss' ? 'RSS' : draft.sourceDetails.type === 'video' ? 'Video' : 'Keyword',
        socialMediaPosts: socialPostsResult.posts, 
        emailCampaign 
    };
    site.history = [newHistoryItem, ...(site.history || [])];

    // 6. Mark Source as Processed
    const { type, value, source, videoItem } = draft.sourceDetails;
    switch (type) {
        case 'keyword':
            site.keywordList = site.keywordList.split('\n').map(k => k.trim() === value.trim() ? `[DONE] ${k.trim()}` : k).join('\n');
            break;
        case 'rss':
            site.processedRssGuids = [...new Set([...(site.processedRssGuids || []), (value as RssItem).guid])];
            break;
        case 'google_sheet':
            site.googleSheetProcessedRows = [...new Set([...(site.googleSheetProcessedRows || []), (value as GoogleSheetRow).rowIndex])];
            break;
        case 'video':
            if (source && videoItem) { // From a channel
                 site.videoSources = site.videoSources.map(s => s.id === source.id ? { ...s, processedVideoGuids: [...new Set([...s.processedVideoGuids, videoItem.guid])] } : s);
            }
            break;
    }

    // 7. Remove draft from list
    site.drafts = site.drafts.filter(d => d.id !== draft.id);

    return { postUrl, publishingLog, updatedSite: updateSiteInDB(site) };
};

// --- Automation Job Runners ---

export const runManualGenerationPipeline = async (
    siteId: string,
    sourceType: 'keyword' | 'rss' | 'video' | 'google_sheet' | 'ai_assistant',
    sourceDetails: any,
    options: any,
    onProgress: ProgressCallback
) => {
    let site = await getSiteForTask(siteId);
    let topicToTrack = typeof sourceDetails === 'string' ? sourceDetails : sourceDetails.title || sourceDetails.topic || 'New Content';

    const addToTotalCost = (cost: { provider: keyof ApiKeys, amount: number }) => {
        site = logApiUsage(site, cost.provider, cost.amount);
    };

    const serviceSourceType = sourceType === 'ai_assistant' ? 'keyword' : sourceType;

    onProgress({ status: AppStatus.AUTOMATION_TRIGGERED, message: "Manual generation started...", topic: topicToTrack });
    onProgress({ status: AppStatus.GENERATING_STRATEGY, message: "Generating SEO strategy...", topic: topicToTrack });
    const briefResult = await aiServiceInternal.generateStrategicBriefFromKeyword(topicToTrack, site); // Simplified for now
    addToTotalCost(briefResult.cost);
    const brief = briefResult.brief;
    
    onProgress({ status: AppStatus.GENERATING_ARTICLE, message: "Writing article draft...", topic: topicToTrack });
    const articleResult = await aiServiceInternal.generateArticleFromBrief(brief, site);
    addToTotalCost(articleResult.cost);

    onProgress({ status: AppStatus.GENERATING_IMAGE, message: "Creating featured image...", topic: topicToTrack });
    const imageResult = await aiServiceInternal.generateFeaturedImage(articleResult.postData.imagePrompt, site);
    addToTotalCost(imageResult.cost);
    
    onProgress({ status: AppStatus.OPTIMIZING_ARTICLE, message: "Optimizing for SEO...", topic: topicToTrack });
    const optimizationResult = await aiServiceInternal.optimizeAndFinalizeArticle(articleResult.postData.content, brief, site);
    addToTotalCost(optimizationResult.cost);

    const humanizedPost = { ...articleResult.postData, content: optimizationResult.finalHtmlContent };
    const score = calculateSeoScore({ ...humanizedPost, imageUrl: `data:image/jpeg;base64,${imageResult.base64Image}` }, brief);
    
    const finalBlogPost = { ...humanizedPost, imageUrl: `data:image/jpeg;base64,${imageResult.base64Image}` };
    
    const draft: Draft = {
        id: 'manual-draft',
        date: Date.now(),
        sourceTopic: topicToTrack,
        sourceDetails: { type: serviceSourceType, value: sourceDetails, ...options },
        blogPost: finalBlogPost
    };

    onProgress({ status: AppStatus.READY_TO_PUBLISH, message: "Ready to publish!", topic: topicToTrack });

    return { draft, score, updatedSite: updateSiteInDB(site) };
};

export const runBlogPostAutomation = async (siteId: string, recurringScheduleId: string | null, onProgress: ProgressCallback = noOpProgress): Promise<Site> => {
    let site = await getSiteForTask(siteId);
    let topicToTrack = 'New Automated Post';

    const addToTotalCost = (cost: { provider: keyof ApiKeys, amount: number }) => {
        site = logApiUsage(site, cost.provider, cost.amount);
    };

    try {
        onProgress({ status: AppStatus.AUTOMATION_TRIGGERED, message: "Automation triggered...", topic: topicToTrack });
        onProgress({ status: AppStatus.FETCHING_SOURCE, message: "Finding next topic...", topic: topicToTrack });
        // Simplified source finding for simulation
        const sourceDetails = "Automated Topic";
        const sourceType = "Keyword";
        topicToTrack = "Automated Topic";
        onProgress({ status: AppStatus.GENERATING_STRATEGY, message: `Found topic: "${topicToTrack}"`, topic: topicToTrack });

        const briefResult = await aiServiceInternal.generateStrategicBriefFromKeyword(topicToTrack, site);
        addToTotalCost(briefResult.cost);
        const brief = briefResult.brief;
        onProgress({ status: AppStatus.GENERATING_ARTICLE, message: "Writing article...", topic: topicToTrack });
        
        const articleResult = await aiServiceInternal.generateArticleFromBrief(brief, site);
        addToTotalCost(articleResult.cost);

        onProgress({ status: AppStatus.GENERATING_IMAGE, message: "Creating image...", topic: topicToTrack });
        const imageResult = await aiServiceInternal.generateFeaturedImage(articleResult.postData.imagePrompt, site);
        addToTotalCost(imageResult.cost);
        
        onProgress({ status: AppStatus.OPTIMIZING_ARTICLE, message: "Optimizing for SEO...", topic: topicToTrack });
        const optimizationResult = await aiServiceInternal.optimizeAndFinalizeArticle(articleResult.postData.content, brief, site);
        addToTotalCost(optimizationResult.cost);
        const optimizedPost = { ...articleResult.postData, content: optimizationResult.finalHtmlContent };
        
        const finalBlogPost = { ...optimizedPost, imageUrl: `data:image/jpeg;base64,${imageResult.base64Image}` };
        
        const draft: Draft = { id: crypto.randomUUID(), date: Date.now(), sourceTopic: topicToTrack, sourceDetails: { type: 'keyword' as const, value: sourceDetails }, blogPost: finalBlogPost };

        if (site.isAutoPublishEnabled) {
            onProgress({ status: AppStatus.PUBLISHING, message: "Publishing to WordPress...", topic: topicToTrack });
            const { postUrl } = await publishPostAndFollowUps(site.id, draft, finalBlogPost);
            onProgress({ status: AppStatus.PUBLISHED, message: `Published successfully!`, topic: topicToTrack });

        } else {
            onProgress({ status: AppStatus.READY_TO_PUBLISH, message: "Saving draft for review...", topic: topicToTrack });
            site.drafts = [draft, ...(site.drafts || [])];
            await sendDraftNotification(site, draft);
        }

        if (recurringScheduleId) {
            site.recurringSchedules = (site.recurringSchedules || []).map(s => s.id === recurringScheduleId ? { ...s, lastRun: Date.now() } : s);
        } else {
            site.lastAutoPilotRun = Date.now();
        }

    } catch (error) {
        onProgress({ status: AppStatus.ERROR, message: (error as Error).message, topic: topicToTrack });
        throw error;
    }
    
    return updateSiteInDB(site);
};

export const runSocialGraphicAutomation = async (siteId: string, recurringScheduleId: string | null, onProgress: ProgressCallback = noOpProgress): Promise<Site> => {
    let site = await getSiteForTask(siteId);
    const topic = "Automated Social Graphic";

    try {
        onProgress({ status: AppStatus.GENERATING_IMAGE, message: "Finding topic for social graphic...", topic });
        
        onProgress({ status: AppStatus.GENERATING_IMAGE, message: "Generating image and caption...", topic });
        const { generationResult, totalCost } = await aiServiceInternal.generateSocialGraphicAndCaption(site, topic, '1:1', 'Instagram', site.socialGraphicAutomationModelConfig);
        site = logApiUsage(site, totalCost.provider, totalCost.amount);

        onProgress({ status: AppStatus.PUBLISHING, message: "Publishing to social accounts...", topic });
        await aiServiceInternal.publishSocialGraphic(site, { imageUrl: generationResult.base64Image, caption: generationResult.caption });

        const newHistoryItem: PostHistoryItem = { id: crypto.randomUUID(), topic, url: '#', date: Date.now(), type: 'Social Graphic', socialGraphics: { custom: { imageUrl: generationResult.base64Image, caption: generationResult.caption } } };
        site.history = [newHistoryItem, ...(site.history || [])];

        if (recurringScheduleId) site.socialGraphicRecurringSchedules = (site.socialGraphicRecurringSchedules || []).map(s => s.id === recurringScheduleId ? { ...s, lastRun: Date.now() } : s);
        else site.lastSocialGraphicAutoPilotRun = Date.now();
        
        onProgress({ status: AppStatus.PUBLISHED, message: "Social graphic published.", topic });

    } catch (error) {
        onProgress({ status: AppStatus.ERROR, message: (error as Error).message, topic });
        throw error;
    }

    return updateSiteInDB(site);
};

export const runSocialVideoAutomation = async (siteId: string, recurringScheduleId: string | null, onProgress: ProgressCallback = noOpProgress): Promise<Site> => {
    let site = await getSiteForTask(siteId);
    const topic = "Automated Social Video";

    try {
        onProgress({ status: AppStatus.GENERATING_IMAGE, message: "Finding topic for social video...", topic });
        
        onProgress({ status: AppStatus.GENERATING_IMAGE, message: "Generating video and caption (this can take a few minutes)...", topic });
        const { generationResult, totalCost } = await aiServiceInternal.generateSocialVideoAndCaption(site, topic);
        site = logApiUsage(site, totalCost.provider, totalCost.amount);

        onProgress({ status: AppStatus.PUBLISHING, message: "Publishing video...", topic });
        await aiServiceInternal.publishSocialVideo(site, generationResult);

        const newHistoryItem: PostHistoryItem = { id: crypto.randomUUID(), topic, url: '#', date: Date.now(), type: 'Social Video', socialVideos: { custom: { videoUrl: generationResult.videoUrl, caption: generationResult.caption } } };
        site.history = [newHistoryItem, ...(site.history || [])];
        
        if (recurringScheduleId) site.socialVideoRecurringSchedules = (site.socialVideoRecurringSchedules || []).map(s => s.id === recurringScheduleId ? { ...s, lastRun: Date.now() } : s);
        else site.lastSocialVideoAutoPilotRun = Date.now();
        
        onProgress({ status: AppStatus.PUBLISHED, message: "Social video published.", topic });

    } catch (error) {
        onProgress({ status: AppStatus.ERROR, message: (error as Error).message, topic });
        throw error;
    }

    return updateSiteInDB(site);
};

export const runEmailMarketingAutomation = async (siteId: string, recurringScheduleId: string | null, onProgress: ProgressCallback = noOpProgress): Promise<Site> => {
    let site = await getSiteForTask(siteId);
    const topic = "Automated Email Newsletter";

    try {
        onProgress({ status: AppStatus.GENERATING_ARTICLE, message: "Finding topic for email campaign...", topic });

        onProgress({ status: AppStatus.GENERATING_ARTICLE, message: "Generating email content...", topic });
        const { campaign, cost } = await aiServiceInternal.generateStandaloneEmailCampaign(site, topic);
        site = logApiUsage(site, cost.provider, cost.amount);

        onProgress({ status: AppStatus.PUBLISHING, message: "Sending campaign...", topic });
        if (site.mailchimp?.isConnected) {
            await aiServiceInternal.sendMailchimpCampaign(site, campaign);
        }

        const newHistoryItem: PostHistoryItem = { id: crypto.randomUUID(), topic: campaign.subject, url: '#', date: Date.now(), type: 'Email Marketing', emailCampaign: campaign };
        site.history = [newHistoryItem, ...(site.history || [])];

        if (recurringScheduleId) site.emailMarketingRecurringSchedules = (site.emailMarketingRecurringSchedules || []).map(s => s.id === recurringScheduleId ? { ...s, lastRun: Date.now() } : s);
        else site.lastEmailMarketingAutoPilotRun = Date.now();
        
        onProgress({ status: AppStatus.PUBLISHED, message: "Email campaign sent.", topic });

    } catch (error) {
        onProgress({ status: AppStatus.ERROR, message: (error as Error).message, topic });
        throw error;
    }

    return updateSiteInDB(site);
};

export const runDigestAutomation = async (siteId: string, recurringScheduleId: string | null, onProgress: ProgressCallback = noOpProgress): Promise<Site> => {
    let site = await getSiteForTask(siteId);
    const topic = "Email Digest";

    if (site.masterAutomationSource !== 'rss' || !site.rssFeedUrl) throw new Error("Digest Automation requires a valid Master RSS Feed.");

    try {
        onProgress({ status: AppStatus.GENERATING_STRATEGY, message: "Fetching new RSS items...", topic });
        const { items } = await fetchAndParseRssFeed(site.rssFeedUrl);
        const newItems = items.filter(item => !(site.processedDigestGuids || []).includes(item.guid));

        if (newItems.length === 0) {
            onProgress({ status: AppStatus.IDLE, message: "No new items for digest.", topic });
            return updateSiteInDB(site); // No work to do
        }

        onProgress({ status: AppStatus.GENERATING_ARTICLE, message: `Summarizing ${newItems.length} new articles...`, topic });
        const { campaign, cost } = await aiServiceInternal.generateRssDigestEmail(site, newItems);
        site = logApiUsage(site, cost.provider, cost.amount);

        onProgress({ status: AppStatus.PUBLISHING, message: "Sending digest email...", topic });
        if (site.mailchimp?.isConnected) {
            await aiServiceInternal.sendMailchimpCampaign(site, campaign);
        }

        site.history = [{ id: crypto.randomUUID(), topic: campaign.subject, url: '#', date: Date.now(), type: 'Email Digest', emailCampaign: campaign }, ...(site.history || [])];
        site.processedDigestGuids = [...new Set([...(site.processedDigestGuids || []), ...newItems.map(item => item.guid)])];

        if (recurringScheduleId) site.digestRecurringSchedules = (site.digestRecurringSchedules || []).map(s => s.id === recurringScheduleId ? { ...s, lastRun: Date.now() } : s);
        
        onProgress({ status: AppStatus.PUBLISHED, message: "Email digest sent.", topic });

    } catch (error) {
        onProgress({ status: AppStatus.ERROR, message: (error as Error).message, topic });
        throw error;
    }

    return updateSiteInDB(site);
};

// --- WordPress Self-Test Proxies ---
export const testWpAuthorPermissions = async (siteId: string): Promise<{ success: boolean; message: string }> => {
    const site = await getSiteForTask(siteId);
    await wordpressService.testAuthorPermissions({ url: site.wordpressUrl, username: site.wordpressUsername, password: site.applicationPassword });
    return { success: true, message: 'Can successfully fetch authors.' };
};
export const testWpCategoryPermissions = async (siteId: string): Promise<{ success: boolean; message: string }> => {
    const site = await getSiteForTask(siteId);
    await wordpressService.testCategoryPermissions({ url: site.wordpressUrl, username: site.wordpressUsername, password: site.applicationPassword });
    return { success: true, message: 'Can successfully fetch categories.' };
};
export const testWpMediaPermissions = async (siteId: string): Promise<{ success: boolean; message: string }> => {
    const site = await getSiteForTask(siteId);
    await wordpressService.testMediaPermissions({ url: site.wordpressUrl, username: site.wordpressUsername, password: site.applicationPassword });
    return { success: true, message: 'Media upload and delete permissions are correct.' };
};
export const testWpPostPermissions = async (siteId: string): Promise<{ success: boolean; message: string }> => {
    const site = await getSiteForTask(siteId);
    await wordpressService.testPostPermissions({ url: site.wordpressUrl, username: site.wordpressUsername, password: site.applicationPassword });
    return { success: true, message: 'Post create and delete permissions are correct.' };
};