import { AiProvider, SubscriptionPlan } from './types';

export const providerDisplayNames: Record<AiProvider, string> = {
  [AiProvider.GOOGLE]: 'Google',
  [AiProvider.OPENAI]: 'OpenAI',
  [AiProvider.OPENROUTER]: 'OpenRouter',
  [AiProvider.ANTHROPIC]: 'Anthropic',
  [AiProvider.XAI]: 'X.AI Grok',
  [AiProvider.REPLICATE]: 'Replicate',
  [AiProvider.FREEPIK]: 'Freepik',
  [AiProvider.FALAI]: 'Fal.ai',
  [AiProvider.PERPLEXITY]: 'Perplexity AI',
};

export const AVAILABLE_MODELS = {
  [AiProvider.GOOGLE]: {
    text: ['gemini-2.5-flash'],
    image: ['imagen-4.0-generate-001'],
    video: ['veo-2.0-generate-001'],
  },
  [AiProvider.OPENAI]: {
    text: ['gpt-4o', 'gpt-4-turbo', 'gpt-3.5-turbo-0125'],
    image: ['dall-e-3', 'dall-e-2'],
    video: [],
  },
  [AiProvider.ANTHROPIC]: {
    text: ['claude-3-opus-20240229', 'claude-3-sonnet-20240229', 'claude-3-haiku-20240307'],
    image: [],
    video: [],
  },
  [AiProvider.OPENROUTER]: {
    text: [
        'openai/gpt-4o',
        'google/gemini-1.5-flash',
        'anthropic/claude-3.5-sonnet',
        'meta-llama/llama-3-70b-instruct',
        'mistralai/mistral-large',
    ],
    image: [
        'openai/dall-e-3',
        'google/imagen-3',
        'stabilityai/stable-diffusion-3',
    ],
    video: [],
  },
  [AiProvider.XAI]: {
    text: ['grok-1'],
    image: [],
    video: [],
  },
  [AiProvider.REPLICATE]: {
    text: [],
    image: [
        'stability-ai/sdxl:39ed52f2a78e934b3ba6e2a89f5b1c712de7dfea535525255b1aa35c5565e08b',
        'ai-forever/kandinsky-2.2:ea1addaab376f4dc227f5368bbd8eff901820fd1cc14ed8cad63b29249e9d463'
    ],
    video: [],
  },
  [AiProvider.FREEPIK]: {
    text: [],
    image: ['freepik/pikaso-v1'],
    video: ['freepik/motion-v1'],
  },
  [AiProvider.FALAI]: {
    text: [],
    image: [
        'fal-ai/fast-sdxl',
        'fal-ai/latent-consistency-model',
        'fal-ai/fast-stable-diffusion',
    ],
    video: [
        'fal-ai/stable-video-diffusion'
    ],
  },
  [AiProvider.PERPLEXITY]: {
    text: ['llama-3-sonar-small-32k-online', 'llama-3-sonar-large-32k-online', 'llama-3-8b-instruct', 'mixtral-8x7b-instruct'],
    image: [],
    video: [],
  },
};

export const PLAN_LIMITS = {
  [SubscriptionPlan.FREE]: { 
    sites: 1, 
    posts: 3, 
    features: { 
      assistant: true,
      socialGraphics: false,
      socialVideo: false, 
      emailMarketing: false,
      backlinksCommenting: false, 
      backlinksOutreach: false, 
      autoPublish: false,
      backlinksMonitoring: false,
      viewAnalytics: false,
      advancedSeoProviders: false,
      postPublishFollowups: false,
    } 
  },
  [SubscriptionPlan.CREATOR]: { 
    sites: 1, 
    posts: 20, 
    features: { 
      assistant: true,
      socialGraphics: true,
      socialVideo: false, 
      emailMarketing: false,
      backlinksCommenting: false, 
      backlinksOutreach: false, 
      autoPublish: true,
      backlinksMonitoring: true,
      viewAnalytics: true,
      advancedSeoProviders: false,
      postPublishFollowups: true,
    } 
  },
  [SubscriptionPlan.PRO]: { 
    sites: 5, 
    posts: 75, 
    features: { 
      assistant: true,
      socialGraphics: true,
      socialVideo: true, 
      emailMarketing: true,
      backlinksCommenting: true, 
      backlinksOutreach: false, 
      autoPublish: true,
      backlinksMonitoring: true,
      viewAnalytics: true,
      advancedSeoProviders: true,
      postPublishFollowups: true,
    } 
  },
  [SubscriptionPlan.AGENCY]: { 
    sites: 25, 
    posts: 250, 
    features: { 
      assistant: true,
      socialGraphics: true,
      socialVideo: true, 
      emailMarketing: true,
      backlinksCommenting: true, 
      backlinksOutreach: true, 
      autoPublish: true,
      backlinksMonitoring: true,
      viewAnalytics: true,
      advancedSeoProviders: true,
      postPublishFollowups: true,
    } 
  },
};