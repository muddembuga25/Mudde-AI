import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { SparklesIcon, UserCircleIcon, ChartBarIcon, ShieldCheckIcon } from './Icons';
import { SubscriptionPlan } from '../types';

export const ClientsTab: React.FC = () => {
    const { currentUser, updateSubscription } = useAuth();

    if (!currentUser || currentUser.subscription.plan === SubscriptionPlan.AGENCY) {
        // Placeholder for when the user is on the Agency plan
        return (
            <div className="text-center p-8 bg-panel/50 rounded-2xl border-2 border-dashed border-border animate-fade-in max-w-2xl mx-auto">
                <SparklesIcon className="mx-auto h-12 w-12 text-text-secondary" />
                <h3 className="mt-4 text-lg font-medium text-white">Agency Dashboard</h3>
                <p className="mt-1 text-sm text-text-secondary">
                    Your full client and team management dashboard is coming soon!
                </p>
            </div>
        );
    }
    
    // Upgrade prompt for non-agency users
    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-gradient-to-br from-panel to-panel-light rounded-2xl shadow-2xl w-full max-w-4xl border border-border animate-modal-pop overflow-hidden">
                <div className="p-8 md:p-12 text-center">
                    <div className="inline-block bg-purple-600/30 p-4 rounded-2xl border border-purple-500/50">
                        <SparklesIcon className="h-10 w-10 text-purple-300" />
                    </div>
                    <h2 className="text-3xl md:text-4xl font-extrabold mt-6 text-white">
                        Manage Your Business Like a Pro
                    </h2>
                    <p className="text-text-secondary mt-4 max-w-2xl mx-auto">
                        Upgrade to the <span className="text-purple-300 font-semibold">Agency Plan</span> to unlock a powerful suite of tools designed to help you scale your operations, manage clients effortlessly, and collaborate with your team.
                    </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-border">
                    <div className="bg-panel p-6">
                        <UserCircleIcon className="h-8 w-8 text-purple-400" />
                        <h3 className="text-lg font-bold text-white mt-3">Team Collaboration</h3>
                        <p className="text-sm text-text-secondary mt-1">Invite team members with specific roles (Admin, Editor) and grant clients view-only access to their dashboards.</p>
                    </div>
                    <div className="bg-panel p-6">
                        <ChartBarIcon className="h-8 w-8 text-purple-400" />
                        <h3 className="text-lg font-bold text-white mt-3">White-Labeled Reporting</h3>
                        <p className="text-sm text-text-secondary mt-1">Generate beautiful, professional PDF reports with your own logo to impress your clients and showcase your results.</p>
                    </div>
                    <div className="bg-panel p-6">
                        <ShieldCheckIcon className="h-8 w-8 text-purple-400" />
                        <h3 className="text-lg font-bold text-white mt-3">Client Management</h3>
                        <p className="text-sm text-text-secondary mt-1">Keep all your client sites organized under one roof, with dedicated settings and performance tracking for each one.</p>
                    </div>
                </div>
                <div className="p-8 bg-panel-light/30">
                     <button 
                        onClick={() => updateSubscription(SubscriptionPlan.AGENCY)}
                        className="w-full max-w-xs mx-auto btn btn-primary text-lg py-3 animate-pulse-bright"
                    >
                        Upgrade to Agency Plan
                    </button>
                </div>
            </div>
        </div>
    );
};