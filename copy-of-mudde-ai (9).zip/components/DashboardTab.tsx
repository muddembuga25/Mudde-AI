import React from 'react';
import type { Site, RecurringSchedule } from '../types';
import {
  ArchiveBoxIcon, DocumentTextIcon, ClockIcon, SparklesIcon,
  PenIcon, PhotoIcon
} from './Icons';

const StatCard: React.FC<{ title: string; value: string | number; icon: React.FC<any>; }> = ({ title, value, icon: Icon }) => (
    <div className="bg-panel p-6 rounded-lg border border-border-subtle">
        <div className="flex items-center gap-4">
            <div className="bg-panel-light p-3 rounded-lg">
                <Icon className="h-6 w-6 text-purple-400" />
            </div>
            <div>
                <p className="text-sm font-medium text-text-secondary">{title}</p>
                <p className="text-2xl font-bold text-white">{value}</p>
            </div>
        </div>
    </div>
);

interface DashboardTabProps {
    site: Site;
    setActiveTab: (tab: string) => void;
}

export const DashboardTab: React.FC<DashboardTabProps> = ({ site, setActiveTab }) => {

    const getNextAutomationRun = (): string => {
        const now = Date.now();
        let nextRunTime = Infinity;
        let nextRunJob = '';

        const checkSchedules = (schedules: RecurringSchedule[] | undefined, jobName: string) => {
            if (!schedules) return null;
            const enabledSchedule = schedules.find(s => s.isEnabled);
            if (enabledSchedule) {
                // This is a simplified logic for display purposes. A full date calculation is complex.
                return `Scheduled`;
            }
            return null;
        };
        
        if (site.isAutomationEnabled) {
             if(site.automationTrigger === 'interval') {
                const next = (site.lastAutoPilotRun || now) + site.automationIntervalHours * 3600 * 1000;
                if(next < nextRunTime) {
                    nextRunTime = next;
                    nextRunJob = 'Blog Post';
                }
             } else {
                 const scheduledTime = checkSchedules(site.recurringSchedules, 'Blog Post');
                 if(scheduledTime) return `Blog Post: ${scheduledTime}`;
             }
        }
        
        if (site.isSocialGraphicAutomationEnabled) {
            if (site.socialGraphicAutomationTrigger === 'interval') {
                const next = (site.lastSocialGraphicAutoPilotRun || now) + site.socialGraphicAutomationIntervalHours * 3600 * 1000;
                 if(next < nextRunTime) {
                    nextRunTime = next;
                    nextRunJob = 'Social Graphic';
                }
            } else {
                 const scheduledTime = checkSchedules(site.socialGraphicRecurringSchedules, 'Social Graphic');
                 if(scheduledTime) return `Social Graphic: ${scheduledTime}`;
            }
        }

        if (nextRunTime === Infinity) return 'Not Scheduled';

        const diffHours = Math.round((nextRunTime - now) / (1000 * 60 * 60));
        if (diffHours < 0) return 'Overdue';
        if (diffHours === 0) return `${nextRunJob} soon`;
        return `${nextRunJob} in ~${diffHours}h`;
    };

    const totalSpend = Object.values(site.apiUsage || {}).reduce<number>((sum, current) => sum + (Number(current) || 0), 0);
    const recentHistory = (site.history || []).slice(0, 3);

    return (
        <div className="max-w-7xl mx-auto space-y-8 animate-fade-in">
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-3xl font-bold text-white">Dashboard for {site.name}</h2>
                <p className="text-text-secondary mt-1">An overview of your site's content automation and performance.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard title="Total Posts Generated" value={site.history?.length || 0} icon={ArchiveBoxIcon} />
                <StatCard title="Drafts for Review" value={site.drafts?.length || 0} icon={DocumentTextIcon} />
                <StatCard title="Next Automation Job" value={getNextAutomationRun()} icon={ClockIcon} />
                <StatCard title="Estimated API Spend" value={`$${totalSpend.toFixed(5)}`} icon={SparklesIcon} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 bg-panel/50 p-6 rounded-2xl border border-border">
                    <h3 className="text-xl font-bold text-white mb-4">Recent Activity</h3>
                    <div className="space-y-4">
                        {recentHistory.length > 0 ? recentHistory.map(item => (
                            <div key={item.id} className="bg-panel p-3 rounded-lg flex items-center justify-between gap-4 border border-border-subtle">
                                <div>
                                    <p className="font-semibold text-text-primary truncate">{item.topic}</p>
                                    <p className="text-sm text-text-secondary">{new Date(item.date).toLocaleDateString()}</p>
                                </div>
                                <span className="px-2 py-0.5 text-xs font-medium rounded-full bg-gray-700">{item.type}</span>
                            </div>
                        )) : (
                            <p className="text-text-secondary text-center py-4">No activity yet.</p>
                        )}
                        <button onClick={() => setActiveTab('history')} className="w-full btn btn-secondary mt-4">View All History</button>
                    </div>
                </div>

                <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                    <h3 className="text-xl font-bold text-white mb-4">Quick Actions</h3>
                    <div className="space-y-3">
                        <button onClick={() => setActiveTab('content-keywords')} className="w-full btn btn-primary flex items-center justify-center gap-2"><PenIcon className="h-4 w-4" /> Generate New Post</button>
                        <button onClick={() => setActiveTab('social-graphics')} className="w-full btn btn-secondary flex items-center justify-center gap-2"><PhotoIcon className="h-4 w-4" /> Create Social Graphic</button>
                    </div>

                    <h3 className="text-xl font-bold text-white mb-4 mt-8">Automation Status</h3>
                    <ul className="space-y-2 text-sm">
                        <li className="flex items-center gap-2">
                           <div className={`w-2 h-2 rounded-full ${site.isAutomationEnabled ? 'bg-green-500' : 'bg-gray-500'}`}></div>
                           <span className="text-text-primary">Blog Post Automation</span>
                        </li>
                         <li className="flex items-center gap-2">
                           <div className={`w-2 h-2 rounded-full ${site.isSocialGraphicAutomationEnabled ? 'bg-green-500' : 'bg-gray-500'}`}></div>
                           <span className="text-text-primary">Social Graphics</span>
                        </li>
                         <li className="flex items-center gap-2">
                           <div className={`w-2 h-2 rounded-full ${site.isSocialVideoAutomationEnabled ? 'bg-green-500' : 'bg-gray-500'}`}></div>
                           <span className="text-text-primary">Social Videos</span>
                        </li>
                         <li className="flex items-center gap-2">
                           <div className={`w-2 h-2 rounded-full ${site.isEmailMarketingAutomationEnabled ? 'bg-green-500' : 'bg-gray-500'}`}></div>
                           <span className="text-text-primary">Email Marketing</span>
                        </li>
                    </ul>
                    <button onClick={() => setActiveTab('automation')} className="w-full btn btn-secondary mt-4 text-sm">Manage Automations</button>
                </div>
            </div>
        </div>
    );
};