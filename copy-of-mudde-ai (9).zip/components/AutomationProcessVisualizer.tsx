import React from 'react';
import { CheckCircleIcon, SpinnerIcon } from './Icons';

export interface AutomationStep {
  title: string;
  icon: React.FC<React.SVGProps<SVGSVGElement> & { title?: string }>;
}

interface AutomationProcessVisualizerProps {
  steps: AutomationStep[];
  currentStepIndex: number;
  isError?: boolean;
  errorMessage?: string;
  isComplete?: boolean;
  layout?: 'vertical' | 'horizontal';
}

export const AutomationProcessVisualizer: React.FC<AutomationProcessVisualizerProps> = ({ steps, currentStepIndex, isError = false, errorMessage, isComplete = false, layout = 'vertical' }) => {
  if (layout === 'horizontal') {
    return (
      <div className="w-full">
        <ul className="flex items-start justify-between">
            {steps.map((step, index) => {
              const isCompleted = isComplete || index < currentStepIndex;
              const isActive = index === currentStepIndex && !isComplete && !isError;
              const isStepError = isActive && isError;

              let statusColor = 'bg-gray-700/50 border-border text-text-secondary';
              let textColor = 'text-text-secondary';
              let IconComponent = step.icon;
              
              if (isCompleted) {
                statusColor = 'bg-green-600/30 border-green-500 text-green-300';
                textColor = 'text-green-300';
                IconComponent = CheckCircleIcon;
              } else if (isActive) {
                statusColor = 'bg-purple-600 border-purple-500 text-white animate-pulse-bright';
                textColor = 'text-purple-300 font-semibold';
                IconComponent = SpinnerIcon;
              }

              return (
                  <li key={step.title} className="relative flex-1 text-center px-1">
                      {index < steps.length - 1 && (
                          <div
                              aria-hidden="true"
                              className={`absolute left-1/2 top-4 h-0.5 w-full transition-colors duration-500 ${isCompleted ? 'bg-green-500' : 'bg-border-subtle'}`}
                          />
                      )}
                      <div className={`relative z-10 mx-auto flex h-8 w-8 items-center justify-center rounded-full border-2 transition-all duration-300 ${statusColor}`}>
                        {isActive ? <IconComponent className="h-4 w-4 animate-spin" /> : <IconComponent className="h-4 w-4" />}
                      </div>
                      <p className={`mt-2 text-xs font-medium transition-colors duration-300 ${textColor}`}>{step.title}</p>
                  </li>
              );
            })}
        </ul>
        {isError && (
          <div className="mt-4 text-center text-xs text-red-400 bg-red-900/20 p-2 rounded-md border border-red-500/30">
            <p className="font-semibold">Error:</p>
            <p>{errorMessage || 'The automation job failed at the current step.'}</p>
          </div>
        )}
      </div>
    );
  }

  // --- VERTICAL LAYOUT (Original) ---
  return (
    <div className="p-4 bg-panel rounded-lg border border-border-subtle w-full max-w-md mx-auto">
      <ul className="relative space-y-1">
        <div className="absolute left-5 top-5 bottom-5 w-0.5 bg-border-subtle" aria-hidden="true"></div>
        
        {steps.map((step, index) => {
          const isCompleted = isComplete || index < currentStepIndex;
          const isActive = index === currentStepIndex && !isComplete && !isError;
          const isStepError = isActive && isError;

          let statusColor = 'bg-gray-700 border-border text-text-secondary';
          let textColor = 'text-text-secondary';
          let IconComponent = step.icon;
          
          if (isCompleted) {
            statusColor = 'bg-green-500 border-green-400 text-white';
            textColor = 'text-text-primary';
            IconComponent = CheckCircleIcon;
          } else if (isActive) {
            statusColor = 'bg-purple-600 border-purple-500 text-white animate-pulse-bright';
            textColor = 'text-purple-300 font-semibold';
            IconComponent = SpinnerIcon;
          }

          return (
            <li key={step.title} className="relative flex items-start gap-4 py-1">
              <div className={`relative z-10 flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full border-2 transition-all duration-300 ${statusColor}`}>
                {isActive ? <IconComponent className="h-5 w-5 animate-spin" /> : <IconComponent className="h-5 w-5" />}
              </div>
              <div className="min-w-0 flex-1 pt-2">
                <p className={`text-sm font-medium transition-colors duration-300 ${textColor}`}>{step.title}</p>
              </div>
            </li>
          );
        })}
      </ul>
      {isError && (
        <div className="mt-4 text-center text-sm text-red-400 bg-red-900/20 p-3 rounded-md border border-red-500/30">
          <p className="font-semibold">An error occurred:</p>
          <p>{errorMessage || 'The automation job failed at the current step.'}</p>
        </div>
      )}
    </div>
  );
};