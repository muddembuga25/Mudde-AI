import React, { useState, useCallback } from 'react';
import type { Site, SocialMediaSettings, SocialMediaAccount, WhatsAppAccount, TelegramAccount } from '../types';
import * as oauthService from '../services/oauthService';
import { TrashIcon, ArrowPathIcon, XIconSocial, FacebookIcon, LinkedInIcon, InstagramIcon, PinterestIcon, WhatsAppIcon, YouTubeIcon, TikTokIcon, TelegramIcon, SnapchatIcon } from './Icons';

interface SocialMediaTabProps {
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    isConnectingSocial: string | null;
    onConnect: (platform: keyof Omit<SocialMediaSettings, 'whatsapp' | 'telegram'>, accountId: string) => void;
    onVerify: (platformId: oauthService.SocialPlatform, accountId: string, accessToken: string) => void;
    onVerifyCredentials: (platformId: 'whatsapp' | 'telegram', account: WhatsAppAccount | TelegramAccount) => void;
}

export const SocialMediaTab: React.FC<SocialMediaTabProps> = ({ site, onSiteUpdate, isConnectingSocial, onConnect, onVerify, onVerifyCredentials }) => {
    const [verifyingAccount, setVerifyingAccount] = useState<string | null>(null);

    const handleVerify = async (platform: oauthService.SocialPlatform, accountId: string, accessToken: string) => {
        setVerifyingAccount(`${platform}-${accountId}`);
        await onVerify(platform, accountId, accessToken);
        setVerifyingAccount(null);
    };

    const handleCredentialVerify = async (platform: 'whatsapp' | 'telegram', account: WhatsAppAccount | TelegramAccount) => {
        setVerifyingAccount(`${platform}-${account.id}`);
        await onVerifyCredentials(platform, account);
        setVerifyingAccount(null);
    };

    const handleSocialMediaAccountUpdate = useCallback((platformId: keyof SocialMediaSettings, accountId: string, key: string, value: any) => {
        const platformAccounts = (site.socialMediaSettings[platformId] as any[]) || [];
        const updatedAccounts = platformAccounts.map(acc => 
            acc.id === accountId ? { ...acc, [key]: value } : acc
        );
        const newSettings = { ...site.socialMediaSettings, [platformId]: updatedAccounts };
        onSiteUpdate('socialMediaSettings', newSettings);
    }, [site, onSiteUpdate]);
    
    const handleAddSocialMediaAccount = (platformId: keyof SocialMediaSettings, platformName: string) => {
        const baseProps = { id: crypto.randomUUID(), name: `New ${platformName} Account`, isAutomationEnabled: false, isConnected: false, status: 'disconnected' as const };
        if (platformId === 'whatsapp') {
            const newAccount: WhatsAppAccount = { ...baseProps, accessToken: '', phoneNumberId: '', destination: '', destinationType: 'number' };
            const newSettings = { ...site.socialMediaSettings, whatsapp: [...(site.socialMediaSettings.whatsapp || []), newAccount] };
            onSiteUpdate('socialMediaSettings', newSettings);
        } else if (platformId === 'telegram') {
            const newAccount: TelegramAccount = { ...baseProps, botToken: '', chatId: '' };
            const newSettings = { ...site.socialMediaSettings, telegram: [...(site.socialMediaSettings.telegram || []), newAccount] };
            onSiteUpdate('socialMediaSettings', newSettings);
        } else {
            const newAccount: SocialMediaAccount = { ...baseProps, clientId: '', clientSecret: '', destinationType: platformId === 'linkedin' ? 'profile' : 'page' };
            const platformAccounts = (site.socialMediaSettings[platformId] as SocialMediaAccount[]) || [];
            const newSettings = { ...site.socialMediaSettings, [platformId]: [...platformAccounts, newAccount] };
            onSiteUpdate('socialMediaSettings', newSettings);
        }
    };
    
    const handleDeleteSocialMediaAccount = (platformId: keyof SocialMediaSettings, accountId: string) => {
        const platformAccounts = (site.socialMediaSettings[platformId] as any[]) || [];
        const updatedAccounts = platformAccounts.filter(acc => acc.id !== accountId);
        const newSettings = { ...site.socialMediaSettings, [platformId]: updatedAccounts };
        onSiteUpdate('socialMediaSettings', newSettings);
    };
    
    const handleDisconnectSocialMedia = useCallback((platformId: keyof SocialMediaSettings, accountId: string) => {
        const platformAccounts = (site.socialMediaSettings[platformId] as any[]) || [];
        const updatedAccounts = platformAccounts.map(acc => {
            if (acc.id === accountId) {
                const baseReset = { isConnected: false, isAutomationEnabled: false, status: 'disconnected' as const, statusMessage: '' };
                if (platformId === 'whatsapp') {
                    return { ...acc, ...baseReset, accessToken: '', phoneNumberId: '', destination: '' };
                }
                if (platformId === 'telegram') {
                    return { ...acc, ...baseReset, botToken: '', chatId: '' };
                }
                return { ...acc, ...baseReset, accessToken: null };
            }
            return acc;
        });
        const newSettings = { ...site.socialMediaSettings, [platformId]: updatedAccounts };
        onSiteUpdate('socialMediaSettings', newSettings);
    }, [site.socialMediaSettings, onSiteUpdate]);

    const socialPlatforms = [
        { id: 'twitter', name: 'X (Twitter)', icon: XIconSocial, description: "Connect your X account to share posts via the X API v2.", docLink: 'https://developer.x.com/en/docs/authentication/oauth-2-0/authorization-code' },
        { id: 'facebook', name: 'Facebook', icon: FacebookIcon, description: "Publish to Facebook Pages or Groups via the Meta Graph API.", docLink: 'https://developers.facebook.com/docs/development/create-an-app/' },
        { id: 'linkedin', name: 'LinkedIn', icon: LinkedInIcon, description: "Publish to personal profiles or company Pages via the LinkedIn API.", docLink: 'https://learn.microsoft.com/en-us/linkedin/shared/getting-started' },
        { id: 'youtube', name: 'YouTube', icon: YouTubeIcon, description: "Connect your YouTube channel via Google's OAuth API.", docLink: 'https://developers.google.com/youtube/v3/getting-started' },
        { id: 'tiktok', name: 'TikTok', icon: TikTokIcon, description: "Connect your account using the TikTok Login Kit.", docLink: 'https://developers.tiktok.com/doc/login-kit-web/' },
        { id: 'telegram', name: 'Telegram', icon: TelegramIcon, description: "Send updates to channels via a Telegram Bot.", docLink: 'https://core.telegram.org/bots/api' },
        { id: 'whatsapp', name: 'WhatsApp', icon: WhatsAppIcon, description: "Send updates via the WhatsApp Business API.", docLink: 'https://developers.facebook.com/docs/whatsapp/cloud-api/get-started' },
        { id: 'snapchat', name: 'Snapchat', icon: SnapchatIcon, description: "Connect your account using Snap Kit.", docLink: 'https://docs.snap.com/snap-kit/login-kit/app-setup' },
        { id: 'instagram', name: 'Instagram', icon: InstagramIcon, description: "Publish to professional Instagram accounts via the Graph API.", docLink: 'https://developers.facebook.com/docs/instagram-api/getting-started' },
        { id: 'pinterest', name: 'Pinterest', icon: PinterestIcon, description: "Share your featured images as Pins on Pinterest boards.", docLink: 'https://developers.pinterest.com/docs/getting-started/' },
    ];
    
    return (
        <div className="space-y-8 max-w-7xl mx-auto">
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-2xl font-bold text-white">Social Media Connections</h2>
                <p className="text-text-secondary mt-1">Add multiple accounts, enter developer credentials, and connect to enable automatic sharing.</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {socialPlatforms.map(platform => {
                    const platformId = platform.id as keyof SocialMediaSettings;
                    const isCredentialBased = platformId === 'whatsapp' || platformId === 'telegram';
                    return (
                        <div key={platform.id} className="bg-panel p-6 rounded-lg border border-border-subtle flex flex-col">
                            <div className="flex items-center gap-4"> <platform.icon className="h-8 w-8 text-gray-300" /> <div> <h3 className="text-xl font-bold text-white">{platform.name}</h3> <p className="text-sm text-text-secondary mt-1"> {platform.description}{' '} <a href={platform.docLink} target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:underline font-medium"> Connection Guide </a> </p> </div> </div>
                            <div className="mt-4 space-y-4">
                                {(site.socialMediaSettings[platformId] as any[] || []).map(account => {
                                    const accountKey = `${platformId}-${account.id}`;
                                    const isThisAccountConnecting = isConnectingSocial === accountKey;
                                    const isThisAccountVerifying = verifyingAccount === accountKey;
                                    const token = (account as any).accessToken || (account as any).botToken;
                                    const statusColor = account.status === 'connected' ? 'bg-green-500' : account.status === 'needs_reauth' ? 'bg-yellow-500' : 'bg-gray-500';

                                    return (
                                        <div key={account.id} className={`p-4 rounded-lg border ${account.status === 'connected' ? 'border-green-500/30 bg-green-900/10' : account.status === 'needs_reauth' ? 'border-yellow-500/30 bg-yellow-900/10' : 'border-border bg-panel-light/40'}`}>
                                            <div className="flex items-center justify-between gap-3">
                                                <div className="flex items-center gap-2 flex-1 min-w-0">
                                                    <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${statusColor}`} title={`Status: ${account.status.replace('_', ' ')}`}></div>
                                                    <input type="text" value={account.name} onChange={(e) => handleSocialMediaAccountUpdate(platformId, account.id, 'name', e.target.value)} className="input-base text-sm !bg-transparent !border-0 !p-0 !ring-0 w-full font-semibold truncate" />
                                                </div>
                                                <div className="flex items-center gap-3">
                                                    <div className="relative" title={account.status !== 'connected' ? 'Connect the account to enable automation' : 'Toggle automation'}>
                                                        <label className={`relative inline-flex items-center ${account.status !== 'connected' ? 'cursor-not-allowed' : 'cursor-pointer'}`}>
                                                            <input type="checkbox" className="sr-only peer" checked={account.isAutomationEnabled} onChange={(e) => handleSocialMediaAccountUpdate(platformId, account.id, 'isAutomationEnabled', e.target.checked)} disabled={account.status !== 'connected'} />
                                                            <div className={`w-9 h-5 bg-gray-600 rounded-full peer peer-focus:ring-1 peer-focus:ring-purple-500 peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-purple-600 ${account.status !== 'connected' ? 'opacity-50' : ''}`}></div>
                                                        </label>
                                                    </div>
                                                    <button onClick={() => handleDeleteSocialMediaAccount(platformId, account.id)} className="p-1 text-red-400 hover:text-red-300 transition-colors"><TrashIcon className="h-4 w-4" /></button>
                                                </div>
                                            </div>
                                            {account.statusMessage && <p className="text-xs text-yellow-300 mt-2 p-2 bg-yellow-900/30 rounded-md border border-yellow-500/30">{account.statusMessage}</p>}
                                            {account.status !== 'connected' && isCredentialBased && (
                                                <div className="mt-4 space-y-3 animate-fade-in">
                                                    {platformId === 'whatsapp' && (
                                                        <>
                                                            <div> <label htmlFor={`${account.id}-wa-token`} className="block text-xs font-medium text-text-secondary mb-1">Access Token</label> <input id={`${account.id}-wa-token`} type="password" value={(account as WhatsAppAccount).accessToken || ''} onChange={(e) => handleSocialMediaAccountUpdate(platformId, account.id, 'accessToken', e.target.value)} placeholder="WhatsApp Business API Token" className="input-base text-sm py-1.5" /> </div>
                                                            <div> <label htmlFor={`${account.id}-wa-phoneid`} className="block text-xs font-medium text-text-secondary mb-1">Phone Number ID</label> <input id={`${account.id}-wa-phoneid`} type="text" value={(account as WhatsAppAccount).phoneNumberId || ''} onChange={(e) => handleSocialMediaAccountUpdate(platformId, account.id, 'phoneNumberId', e.target.value)} placeholder="Enter Phone Number ID" className="input-base text-sm py-1.5" /> </div>
                                                            <div>
                                                                <label className="block text-xs font-medium text-text-secondary mb-1">Destination</label>
                                                                <div className="flex gap-2">
                                                                    <select value={(account as WhatsAppAccount).destinationType} onChange={(e) => handleSocialMediaAccountUpdate(platformId, account.id, 'destinationType', e.target.value)} className="input-base text-sm py-1.5 w-1/3">
                                                                        <option value="number">Number</option>
                                                                        <option value="group">Group ID</option>
                                                                    </select>
                                                                    <input type="text" value={(account as WhatsAppAccount).destination || ''} onChange={(e) => handleSocialMediaAccountUpdate(platformId, account.id, 'destination', e.target.value)} placeholder="Recipient Phone # or Group ID" className="input-base text-sm py-1.5 w-2/3" />
                                                                </div>
                                                            </div>
                                                        </>
                                                    )}
                                                    {platformId === 'telegram' && (
                                                        <>
                                                            <div> <label htmlFor={`${account.id}-tg-token`} className="block text-xs font-medium text-text-secondary mb-1">Bot Token</label> <input id={`${account.id}-tg-token`} type="password" value={(account as TelegramAccount).botToken || ''} onChange={(e) => handleSocialMediaAccountUpdate(platformId, account.id, 'botToken', e.target.value)} placeholder="Bot Token from BotFather" className="input-base text-sm py-1.5" /> </div>
                                                            <div> <label htmlFor={`${account.id}-tg-chatid`} className="block text-xs font-medium text-text-secondary mb-1">Chat ID</label> <input id={`${account.id}-tg-chatid`} type="text" value={(account as TelegramAccount).chatId || ''} onChange={(e) => handleSocialMediaAccountUpdate(platformId, account.id, 'chatId', e.target.value)} placeholder="@yourchannel or numeric ID" className="input-base text-sm py-1.5" /> </div>
                                                        </>
                                                    )}
                                                </div>
                                            )}
                                            {account.status !== 'connected' && !isCredentialBased && (
                                                <div className="mt-4 space-y-3 animate-fade-in">
                                                    <div> <label htmlFor={`${account.id}-client-id`} className="block text-xs font-medium text-text-secondary mb-1">Client ID</label> <input id={`${account.id}-client-id`} type="text" value={account.clientId || ''} onChange={(e) => handleSocialMediaAccountUpdate(platformId, account.id, 'clientId', e.target.value)} placeholder="Enter app Client ID" className="input-base text-sm py-1.5" /> </div>
                                                    <div> <label htmlFor={`${account.id}-client-secret`} className="block text-xs font-medium text-text-secondary mb-1">Client Secret</label> <input id={`${account.id}-client-secret`} type="password" value={account.clientSecret || ''} onChange={(e) => handleSocialMediaAccountUpdate(platformId, account.id, 'clientSecret', e.target.value)} placeholder="Enter app Client Secret" className="input-base text-sm py-1.5" /> </div>
                                                    {(platformId === 'facebook' || platformId === 'linkedin') && (
                                                        <div className="mt-3">
                                                            <label className="block text-xs font-medium text-text-secondary mb-1">Destination Type</label>
                                                            <div className="grid grid-cols-2 gap-1 bg-panel-light rounded-lg p-1">
                                                                {platformId === 'linkedin' && <button onClick={() => handleSocialMediaAccountUpdate(platformId, account.id, 'destinationType', 'profile')} className={`px-2 py-1 text-xs font-semibold rounded-md transition-colors ${account.destinationType === 'profile' ? 'bg-purple-600 text-white' : 'text-text-secondary hover:bg-gray-700/50'}`}>Profile</button>}
                                                                <button onClick={() => handleSocialMediaAccountUpdate(platformId, account.id, 'destinationType', 'page')} className={`px-2 py-1 text-xs font-semibold rounded-md transition-colors ${account.destinationType === 'page' ? 'bg-purple-600 text-white' : 'text-text-secondary hover:bg-gray-700/50'}`}>Page</button>
                                                                {platformId === 'facebook' && <button onClick={() => handleSocialMediaAccountUpdate(platformId, account.id, 'destinationType', 'group')} className={`px-2 py-1 text-xs font-semibold rounded-md transition-colors ${account.destinationType === 'group' ? 'bg-purple-600 text-white' : 'text-text-secondary hover:bg-gray-700/50'}`}>Group</button>}
                                                            </div>
                                                            {(account.destinationType === 'page' || account.destinationType === 'group') && ( <div className="mt-2 animate-fade-in"> <label htmlFor={`${account.id}-dest-id`} className="block text-xs font-medium text-text-secondary mb-1">{account.destinationType === 'page' ? 'Page ID' : 'Group ID'}</label> <input id={`${account.id}-dest-id`} type="text" value={account.destinationId || ''} onChange={(e) => handleSocialMediaAccountUpdate(platformId, account.id, 'destinationId', e.target.value)} placeholder={account.destinationType === 'page' ? 'Enter Page ID' : 'Enter Group ID'} className="input-base text-sm py-1.5" /> </div> )}
                                                        </div>
                                                    )}
                                                </div>
                                            )}
                                            <div className="mt-4">
                                                {isThisAccountConnecting ? <div className="w-full flex items-center justify-center gap-2 btn btn-primary text-sm py-1.5 bg-gray-600 cursor-wait"> <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 * 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Connecting... </div>
                                                    : account.status === 'connected' ? (
                                                        <div className="flex items-center gap-3">
                                                            <button onClick={() => isCredentialBased ? handleCredentialVerify(platformId as any, account) : handleVerify(platformId, account.id, token)} disabled={isThisAccountVerifying} className="btn btn-secondary text-xs px-3 py-1.5"> {isThisAccountVerifying ? (<svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle opacity="25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path opacity="75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>) : "Verify"} </button>
                                                            <button onClick={() => handleDisconnectSocialMedia(platformId, account.id)} className="ml-auto btn bg-red-800/50 hover:bg-red-700 text-white text-xs px-3 py-1.5">Disconnect</button>
                                                        </div>
                                                    ) : isCredentialBased ? (
                                                        <button onClick={() => handleCredentialVerify(platformId as any, account)} className="w-full btn btn-primary text-sm py-1.5" disabled={isThisAccountVerifying}>
                                                            {isThisAccountVerifying ? 'Verifying...' : 'Verify & Connect'}
                                                        </button>
                                                    ) : (
                                                        <button onClick={() => onConnect(platformId as any, account.id)} className="w-full btn btn-primary text-sm py-1.5 disabled:bg-gray-600 disabled:cursor-not-allowed" disabled={!account.clientId || !account.clientSecret}> {account.status === 'needs_reauth' ? 'Reconnect' : 'Connect'} </button>
                                                    )
                                                }
                                            </div>
                                        </div>
                                    )
                                })}
                            </div>
                            <div className="mt-4 border-t border-border-subtle pt-4"> <button onClick={() => handleAddSocialMediaAccount(platformId, platform.name)} className="w-full btn btn-secondary text-sm"> + Add Account </button> </div>
                        </div>
                    )
                })}
            </div>
        </div>
    );
};