import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { SubscriptionPlan } from '../types';
import { CheckCircleIcon, XCircleIcon } from './Icons';

interface PlanFeature {
    text: string;
    included: boolean;
}

interface PlanDetails {
    name: string;
    price: number;
    description: string;
    features: PlanFeature[];
}

const plans: Record<SubscriptionPlan, PlanDetails> = {
    [SubscriptionPlan.FREE]: {
        name: 'Free Forever',
        price: 0,
        description: 'Perfect for trying out the core features on a single project.',
        features: [
            { text: '1 Website', included: true },
            { text: '3 AI Blog Posts/month', included: true },
            { text: 'Mudde AI Assistant', included: true },
            { text: 'Human-in-the-Loop Review', included: true },
            { text: 'Social Graphics & Auto-Publish', included: false },
            { text: 'Analytics & Backlink Monitoring', included: false },
            { text: 'Advanced SEO Providers', included: false },
            { text: 'Pro Marketing Automations', included: false },
            { text: 'Authority Building Suite', included: false },
        ],
    },
    [SubscriptionPlan.CREATOR]: {
        name: 'Creator',
        price: 30,
        description: 'For solopreneurs and bloggers focused on growing a single brand.',
        features: [
            { text: '1 Website', included: true },
            { text: '20 AI Blog Posts/month', included: true },
            { text: 'Fully Automatic Publishing', included: true },
            { text: 'Social Graphics Automation', included: true },
            { text: 'Post-Publish Social Follow-up', included: true },
            { text: 'Analytics Dashboard', included: true },
            { text: 'Backlink Monitoring', included: true },
            { text: 'Advanced SEO Providers', included: false },
            { text: 'Pro Marketing Automations', included: false },
            { text: 'Authority Building Suite', included: false },
        ],
    },
    [SubscriptionPlan.PRO]: {
        name: 'Pro',
        price: 69,
        description: 'For professional marketers and small agencies scaling up.',
        features: [
            { text: 'Up to 5 Websites', included: true },
            { text: '75 AI Blog Posts/month', included: true },
            { text: 'Everything in Creator, plus:', included: true },
            { text: 'Advanced SEO Providers', included: true },
            { text: 'Pro Marketing Automations (Video & Email)', included: true },
            { text: 'Full Authority Building Suite', included: true },
            { text: 'Post-Publish Email Follow-up', included: true },
            { text: 'Email Outreach for Backlinks', included: false },
        ],
    },
    [SubscriptionPlan.AGENCY]: {
        name: 'Agency',
        price: 249,
        description: 'For large agencies managing multiple client campaigns.',
        features: [
            { text: 'Up to 25 Websites', included: true },
            { text: '250 AI Blog Posts/month', included: true },
            { text: 'Everything in Pro, plus:', included: true },
            { text: 'Backlinks Email Outreach', included: true },
            { text: 'Priority Support', included: true },
            { text: 'Team Features (Coming Soon)', included: true },
        ],
    },
};


const PlanCard: React.FC<{
    planId: SubscriptionPlan;
    isCurrent: boolean;
    isMostPopular: boolean;
    onSelect: (plan: SubscriptionPlan) => void;
}> = ({ planId, isCurrent, isMostPopular, onSelect }) => {
    const plan = plans[planId];
    return (
        <div className={`relative flex flex-col rounded-2xl border-2 p-8 ${isCurrent ? 'border-purple-500 bg-purple-900/20' : 'border-border bg-panel/80'}`}>
            {isMostPopular && <div className="absolute top-0 -translate-y-1/2 left-1/2 -translate-x-1/2"><div className="rounded-full bg-purple-500 px-4 py-1.5 text-sm font-semibold text-white">Most Popular</div></div>}
            <h3 className="text-2xl font-bold text-white">{plan.name}</h3>
            <p className="mt-4 text-sm text-text-secondary h-10">{plan.description}</p>
            <div className="mt-6">
                <span className="text-5xl font-extrabold text-white">${plan.price}</span>
                <span className="ml-2 text-lg font-medium text-text-secondary">/month</span>
            </div>
            <ul className="mt-8 space-y-4">
                {plan.features.map(feature => (
                    <li key={feature.text} className="flex items-start gap-3">
                        {feature.included ? <CheckCircleIcon className="h-6 w-6 text-green-400 flex-shrink-0" /> : <XCircleIcon className="h-6 w-6 text-red-400 flex-shrink-0" />}
                        <span className={`text-sm ${feature.included ? 'text-text-primary' : 'text-text-secondary'}`}>{feature.text}</span>
                    </li>
                ))}
            </ul>
            <div className="mt-auto pt-8">
                {isCurrent ? (
                    <button disabled className="w-full btn bg-purple-600 text-white cursor-default">Current Plan</button>
                ) : (
                    <button onClick={() => onSelect(planId)} className="w-full btn btn-secondary">Choose Plan</button>
                )}
            </div>
        </div>
    );
};


export const BillingTab: React.FC = () => {
    const { currentUser, updateSubscription } = useAuth();
    if (!currentUser) return null;

    const { plan } = currentUser.subscription;

    return (
        <div className="space-y-8 max-w-7xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8 items-stretch">
                <PlanCard planId={SubscriptionPlan.FREE} isCurrent={plan === SubscriptionPlan.FREE} isMostPopular={false} onSelect={updateSubscription} />
                <PlanCard planId={SubscriptionPlan.CREATOR} isCurrent={plan === SubscriptionPlan.CREATOR} isMostPopular={false} onSelect={updateSubscription} />
                <PlanCard planId={SubscriptionPlan.PRO} isCurrent={plan === SubscriptionPlan.PRO} isMostPopular={true} onSelect={updateSubscription} />
                <PlanCard planId={SubscriptionPlan.AGENCY} isCurrent={plan === SubscriptionPlan.AGENCY} isMostPopular={false} onSelect={updateSubscription} />
            </div>
        </div>
    );
}