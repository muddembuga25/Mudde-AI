import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Blob, FunctionDeclaration, Type } from '@google/genai';
import type { Site } from '../types';
import { MicrophoneIcon, StopCircleIcon, SparklesIcon, XIcon, SpinnerIcon, PaperAirplaneIcon, ChatBubbleLeftRightIcon, VideoCameraIcon } from './Icons';
import * as mcpApiService from '../services/mcpApiService';

// Audio encoding/decoding functions from the guidelines
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const blobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            const base64String = reader.result as string;
            resolve(base64String.split(',')[1]); // API expects just the base64 part
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
};


interface GeminiLiveAssistantProps {
  site: Site;
  findNextTopic: () => Promise<{ topic: string; sourceType: string; sourceDetails: any } | null>;
  onGenerateAndScore: (topic: string, sourceType: 'ai_assistant', sourceDetails: string, site: Site) => Promise<void>;
  setSites: (updater: (prevSites: Site[]) => Site[]) => void;
  onTriggerAutomation: (jobType: 'social_graphic' | 'social_video' | 'email_marketing' | 'email_digest', siteId: string) => Promise<void>;
}

interface PendingAction {
  name: string;
  args: any;
  description: string;
}

export const GeminiLiveAssistant: React.FC<GeminiLiveAssistantProps> = ({ site, findNextTopic, onGenerateAndScore, setSites, onTriggerAutomation }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [mode, setMode] = useState<'text' | 'voice' | 'video' | null>(null);
    const [isModeSelectorOpen, setIsModeSelectorOpen] = useState(false);
    
    // Live connect state
    const [isRecording, setIsRecording] = useState(false);
    const [transcription, setTranscription] = useState<{ user: string; model: string; isFinal: boolean }[]>([]);
    
    // Text chat state
    const [chatHistory, setChatHistory] = useState<{ role: 'user' | 'model'; text: string }[]>([]);
    const [textInput, setTextInput] = useState('');
    const [isModelThinking, setIsModelThinking] = useState(false);
    
    // Shared state
    const [isProcessing, setIsProcessing] = useState(false);
    const [pendingAction, setPendingAction] = useState<PendingAction | null>(null);

    const aiRef = useRef<GoogleGenAI | null>(null);
    const sessionPromiseRef = useRef<Promise<any> | null>(null);
    const mediaStreamRef = useRef<MediaStream | null>(null);
    const audioContextRef = useRef<AudioContext | null>(null);
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const outputAudioContextRef = useRef<AudioContext | null>(null);
    const sourcesRef = useRef(new Set<AudioBufferSourceNode>());
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const frameIntervalRef = useRef<number | null>(null);
    
    const currentInputTranscriptionRef = useRef('');
    const currentOutputTranscriptionRef = useRef('');
    let nextStartTime = 0;

    const findNextTopicFunctionDeclaration: FunctionDeclaration = { name: 'findNextTopic', description: 'Finds the next available topic from the user\'s configured content sources (keyword list, RSS feed, etc.) that can be used to generate a new blog post.', parameters: { type: Type.OBJECT, properties: {} } };
    const generateArticleFunctionDeclaration: FunctionDeclaration = { name: 'generateArticle', description: 'Initiates the full AI pipeline to generate and score a new blog post based on a provided topic. This is a long-running process.', parameters: { type: Type.OBJECT, properties: { topic: { type: Type.STRING, description: 'The topic or keyword for the new blog post.' } }, required: ['topic'] } };
    const brainstormAndAddTopicsFunctionDeclaration: FunctionDeclaration = { name: 'brainstormAndAddTopics', description: "Brainstorms a list of content ideas or blog post titles based on a general topic and adds them directly to the site's keyword list for future generation.", parameters: { type: Type.OBJECT, properties: { topic: { type: Type.STRING, description: 'The general topic or theme to brainstorm ideas about.' } }, required: ['topic'] } };
    const updateSiteFieldFunctionDeclaration: FunctionDeclaration = { name: 'updateSiteField', description: "Updates a specific text field for the current site configuration, such as the brand guideline or promotional links.", parameters: { type: Type.OBJECT, properties: { field: { type: Type.STRING, description: "The name of the field to update. Supported fields are: 'brandGuideline', 'promoLink1', 'promoLink2', 'nicheTargeting', 'authorName', 'rssFeedUrl', 'googleSheetUrl'." }, value: { type: Type.STRING, description: "The new text value for the field." } }, required: ['field', 'value'] } };
    const researchKeywordFunctionDeclaration: FunctionDeclaration = { name: 'researchKeyword', description: 'Performs in-depth SEO research on a given keyword to find the optimal, high-intent, long-tail keyword to target for a blog post.', parameters: { type: Type.OBJECT, properties: { keyword: { type: Type.STRING, description: 'The keyword or topic to research.' } }, required: ['keyword'] } };
    const runSocialGraphicAutomationFunctionDeclaration: FunctionDeclaration = { name: 'runSocialGraphicAutomation', description: 'Triggers the social graphic automation workflow. The system will find the next topic from the master content source, generate a unique social media image and caption, and publish it to all connected and enabled social media accounts.', parameters: { type: Type.OBJECT, properties: {} } };
    const runSocialVideoAutomationFunctionDeclaration: FunctionDeclaration = { name: 'runSocialVideoAutomation', description: 'Triggers the social video automation workflow. The system will find the next topic from the master content source, generate a short-form video and caption, and publish it to relevant social media accounts like TikTok and YouTube Shorts.', parameters: { type: Type.OBJECT, properties: {} } };
    const runEmailMarketingAutomationFunctionDeclaration: FunctionDeclaration = { name: 'runEmailMarketingAutomation', description: 'Triggers the standalone email marketing automation. The system will find the next topic from the master source, generate a full email newsletter, and send it to the configured mailing list (e.g., via Mailchimp).', parameters: { type: Type.OBJECT, properties: {} } };
    const runEmailDigestAutomationFunctionDeclaration: FunctionDeclaration = { name: 'runEmailDigestAutomation', description: 'Triggers the email digest automation. The system will scan the master RSS feed for new posts since the last digest, generate a summary email of all new content, and send it to the configured mailing list.', parameters: { type: Type.OBJECT, properties: {} } };

    const functionDeclarations = [findNextTopicFunctionDeclaration, generateArticleFunctionDeclaration, brainstormAndAddTopicsFunctionDeclaration, researchKeywordFunctionDeclaration, runSocialGraphicAutomationFunctionDeclaration, runSocialVideoAutomationFunctionDeclaration, runEmailMarketingAutomationFunctionDeclaration, runEmailDigestAutomationFunctionDeclaration, updateSiteFieldFunctionDeclaration];

    const handleFunctionCall = useCallback(async (fc: any) => {
        if (fc.name === 'generateArticle') { setPendingAction({ name: 'generateArticle', args: fc.args, description: `Generate a new blog post on the topic: "${fc.args.topic}"` }); return { result: `I can do that. Please confirm to start generating the article.` }; }
        if (fc.name === 'runSocialGraphicAutomation') { setPendingAction({ name: 'runSocialGraphicAutomation', args: fc.args, description: `Run the Social Graphic Automation.` }); return { result: `I'm ready to run the social graphic automation. Please confirm.` }; }
        if (fc.name === 'runSocialVideoAutomation') { setPendingAction({ name: 'runSocialVideoAutomation', args: fc.args, description: `Run the Social Video Automation.` }); return { result: `I can start the social video automation. Please confirm.` }; }
        if (fc.name === 'runEmailMarketingAutomation') { setPendingAction({ name: 'runEmailMarketingAutomation', args: fc.args, description: `Run the Email Marketing Automation.` }); return { result: `Ready to run the email marketing automation. Please confirm.` }; }
        if (fc.name === 'runEmailDigestAutomation') { setPendingAction({ name: 'runEmailDigestAutomation', args: fc.args, description: `Run the Email Digest Automation.` }); return { result: `I can run the email digest automation now. Please confirm.` }; }
        if (fc.name === 'brainstormAndAddTopics') { setPendingAction({ name: 'brainstormAndAddTopics', args: fc.args, description: `Brainstorm ideas about "${fc.args.topic}" and add them to the keyword list.` }); return { result: `I can brainstorm some ideas for you. Please confirm to add them to your keyword list.` }; }
        if (fc.name === 'updateSiteField') { setPendingAction({ name: 'updateSiteField', args: fc.args, description: `Update the "${fc.args.field}" with the new value.` }); return { result: `I can update the ${fc.args.field}. Please confirm the change.` }; }
        if (fc.name === 'findNextTopic') { const result = await findNextTopic(); return { result: result ? `Found topic: "${result.topic}"` : "No new topics found." }; }
        if (fc.name === 'researchKeyword') { const { bestKeyword } = await mcpApiService.findBestKeyword(site.id, fc.args.keyword); return { result: `A better keyword to target might be: "${bestKeyword}"` }; }
        return { result: "Function not recognized." };
    }, [findNextTopic, site.id]);

    const handleConfirmAction = useCallback(async () => {
        if (!pendingAction) return;
        setIsProcessing(true);
        const action = { ...pendingAction };
        setPendingAction(null);
        try {
            switch (action.name) {
                case 'generateArticle': await onGenerateAndScore(action.args.topic, 'ai_assistant', action.args.topic, site); setIsOpen(false); break;
                case 'runSocialGraphicAutomation': await onTriggerAutomation('social_graphic', site.id); setIsOpen(false); break;
                case 'runSocialVideoAutomation': await onTriggerAutomation('social_video', site.id); setIsOpen(false); break;
                case 'runEmailMarketingAutomation': await onTriggerAutomation('email_marketing', site.id); setIsOpen(false); break;
                case 'runEmailDigestAutomation': await onTriggerAutomation('email_digest', site.id); setIsOpen(false); break;
                case 'brainstormAndAddTopics': const { ideas } = await mcpApiService.brainstormContentIdeas(site.id, action.args.topic, 'blog_post'); setSites(prevSites => prevSites.map(s => s.id === site.id ? { ...s, keywordList: s.keywordList.trim() ? `${s.keywordList.trim()}\n${ideas.join('\n')}` : ideas.join('\n') } : s)); break;
                case 'updateSiteField': const { field, value } = action.args; const supportedFields = ['brandGuideline', 'promoLink1', 'promoLink2', 'nicheTargeting', 'authorName', 'rssFeedUrl', 'googleSheetUrl']; if (supportedFields.includes(field)) { setSites(prevSites => prevSites.map(s => s.id === site.id ? { ...s, [field]: value } : s)); } break;
            }
        } catch (error) { console.error("Error confirming action:", error); } finally { setIsProcessing(false); }
    }, [pendingAction, onGenerateAndScore, onTriggerAutomation, site, setSites]);

    const stopLiveSession = useCallback(() => {
        setIsRecording(false);
        setPendingAction(null);
        if (frameIntervalRef.current) { clearInterval(frameIntervalRef.current); frameIntervalRef.current = null; }
        mediaStreamRef.current?.getTracks().forEach(track => track.stop());
        scriptProcessorRef.current?.disconnect();
        audioContextRef.current?.close().catch(console.error);
        outputAudioContextRef.current?.close().catch(console.error);
        sessionPromiseRef.current?.then(session => session.close());
        sessionPromiseRef.current = null;
    }, []);

    const handleClose = useCallback(() => {
        if (isRecording) { stopLiveSession(); }
        setIsOpen(false);
        setMode(null);
        setChatHistory([]);
        setTextInput('');
        setIsModelThinking(false);
        setTranscription([]);
        setPendingAction(null);
    }, [isRecording, stopLiveSession]);
    
    const startLiveSession = useCallback(async (sessionMode: 'voice' | 'video') => {
        if (!process.env.API_KEY) { console.error("API_KEY not set."); return; }
        if (!aiRef.current) { aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY }); }
        
        setTranscription([]); setIsRecording(true); setIsProcessing(false); setPendingAction(null);
        currentInputTranscriptionRef.current = ''; currentOutputTranscriptionRef.current = '';
        outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        nextStartTime = 0;

        sessionPromiseRef.current = aiRef.current.live.connect({
            model: 'gemini-2.5-flash-native-audio-preview-09-2025',
            callbacks: {
                onopen: async () => {
                    mediaStreamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true, video: sessionMode === 'video' });
                    if (sessionMode === 'video' && videoRef.current) { videoRef.current.srcObject = mediaStreamRef.current; videoRef.current.play().catch(console.error); }
                    audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
                    const source = audioContextRef.current.createMediaStreamSource(mediaStreamRef.current);
                    scriptProcessorRef.current = audioContextRef.current.createScriptProcessor(4096, 1, 1);
                    scriptProcessorRef.current.onaudioprocess = (e) => { const d = e.inputBuffer.getChannelData(0); const i = new Int16Array(d.length); for (let j = 0; j < d.length; j++) { i[j] = d[j] * 32767; } sessionPromiseRef.current?.then((s) => s.sendRealtimeInput({ media: { data: encode(new Uint8Array(i.buffer)), mimeType: 'audio/pcm;rate=16000' } })); };
                    source.connect(scriptProcessorRef.current);
                    scriptProcessorRef.current.connect(audioContextRef.current.destination);

                    if (sessionMode === 'video' && videoRef.current && canvasRef.current) {
                        const v = videoRef.current, c = canvasRef.current, x = c.getContext('2d');
                        if (x) { frameIntervalRef.current = window.setInterval(() => { if (v.readyState >= 2) { c.width = v.videoWidth; c.height = v.videoHeight; x.drawImage(v, 0, 0, v.videoWidth, v.videoHeight); c.toBlob(async (b) => { if (b) { const d = await blobToBase64(b as any); sessionPromiseRef.current?.then((s) => s.sendRealtimeInput({ media: { data: d, mimeType: 'image/jpeg' } })); } }, 'image/jpeg', 0.8); } }, 1000); }
                    }
                },
                onmessage: async (m: LiveServerMessage) => {
                    if (m.serverContent?.inputTranscription) { currentInputTranscriptionRef.current += m.serverContent.inputTranscription.text; setTranscription(p => { const l = p[p.length - 1]; if (l && !l.isFinal) { return [...p.slice(0, -1), { ...l, user: currentInputTranscriptionRef.current }]; } return [...p, { user: currentInputTranscriptionRef.current, model: '', isFinal: false }]; }); }
                    if (m.serverContent?.outputTranscription) { currentOutputTranscriptionRef.current += m.serverContent.outputTranscription.text; setTranscription(p => { const l = p[p.length - 1]; if(l) { return [...p.slice(0, -1), { ...l, model: currentOutputTranscriptionRef.current }]; } return p; }); }
                    const audio = m.serverContent?.modelTurn?.parts[0]?.inlineData.data;
                    if (audio && outputAudioContextRef.current) { const b = await decodeAudioData(decode(audio), outputAudioContextRef.current, 24000, 1); const s = outputAudioContextRef.current.createBufferSource(); s.buffer = b; s.connect(outputAudioContextRef.current.destination); s.addEventListener('ended', () => { sourcesRef.current.delete(s); }); nextStartTime = Math.max(nextStartTime, outputAudioContextRef.current.currentTime); s.start(nextStartTime); nextStartTime += b.duration; sourcesRef.current.add(s); }
                    if (m.serverContent?.interrupted) { for (const s of sourcesRef.current.values()) { s.stop(); sourcesRef.current.delete(s); } nextStartTime = 0; }
                    if (m.serverContent?.turnComplete) { setTranscription(p => { const l = p[p.length - 1]; if(l) { return [...p.slice(0, -1), { ...l, isFinal: true }]; } return p; }); currentInputTranscriptionRef.current = ''; currentOutputTranscriptionRef.current = ''; }
                    if (m.toolCall) { setIsProcessing(true); const s = await sessionPromiseRef.current; for (const fc of m.toolCall.functionCalls) { const res = await handleFunctionCall(fc); s.sendToolResponse({ functionResponses: { id: fc.id, name: fc.name, response: res } }); } setIsProcessing(false); }
                },
                onerror: (e: ErrorEvent) => console.error('Live session error:', e),
                onclose: () => console.log('Live session closed.'),
            },
            config: { responseModalities: [Modality.AUDIO], inputAudioTranscription: {}, outputAudioTranscription: {}, tools: [{ functionDeclarations }], systemInstruction: `You are Mudde, a helpful AI assistant for a content automation tool. You can find topics, brainstorm and add ideas to the keyword list, research keywords, and trigger various automation workflows for the user. You can also update site settings like the brand guideline or RSS feed URL. The current site is named "${site.name}". ${sessionMode === 'video' ? 'You can see the user through their camera.' : ''}` },
        });
    }, [site, handleFunctionCall, functionDeclarations]);

    const handleSendTextMessage = useCallback(async () => {
        if (!textInput.trim() || isModelThinking) return;
        setChatHistory(prev => [...prev, { role: 'user', text: textInput }]);
        const currentInput = textInput;
        setTextInput('');
        setIsModelThinking(true);
        setIsProcessing(true);
        setPendingAction(null);
        try {
            if (!aiRef.current) { aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY! }); }
            const systemInstruction = `You are Mudde, a helpful AI assistant for a content automation tool. You can find topics, brainstorm and add ideas to the keyword list, research keywords, and trigger various automation workflows for the user. You can also update site settings like the brand guideline or RSS feed URL. The current site is named "${site.name}".`;
            const response = await aiRef.current.models.generateContent({ model: 'gemini-2.5-flash', contents: currentInput, config: { systemInstruction: systemInstruction, tools: [{ functionDeclarations }] } });
            if (response.functionCalls) {
                const fc = response.functionCalls[0];
                const toolResult = await handleFunctionCall(fc);
                if (!pendingAction) {
                    const finalResponse = await aiRef.current.models.generateContent({ model: 'gemini-2.5-flash', contents: { parts: [{ text: currentInput }, { functionCall: fc }, { functionResponse: { name: fc.name, id: fc.id, response: toolResult } }] }, config: { systemInstruction, tools: [{ functionDeclarations }] } });
                    setChatHistory(prev => [...prev, { role: 'model', text: finalResponse.text }]);
                } else { setChatHistory(prev => [...prev, { role: 'model', text: toolResult.result }]); }
            } else { setChatHistory(prev => [...prev, { role: 'model', text: response.text }]); }
        } catch (e: any) { setChatHistory(prev => [...prev, { role: 'model', text: `Error: ${e.message}` }]); } 
        finally { setIsModelThinking(false); setIsProcessing(false); }
    }, [site, textInput, isModelThinking, handleFunctionCall, functionDeclarations, pendingAction]);

    useEffect(() => {
        if (isOpen && (mode === 'voice' || mode === 'video')) {
          startLiveSession(mode);
        }
    }, [isOpen, mode, startLiveSession]);

    const handleModeSelect = (selectedMode: 'text' | 'voice' | 'video') => {
        setMode(selectedMode);
        setIsModeSelectorOpen(false);
        setIsOpen(true);
    };

    return (
        <>
            <button onClick={() => setIsModeSelectorOpen(true)} className="fixed bottom-6 right-6 bg-purple-600 hover:bg-purple-500 text-white rounded-full p-4 shadow-2xl transition-transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-background focus:ring-purple-500" aria-label="Open AI Assistant"><SparklesIcon className="h-8 w-8" /></button>
            
            {isModeSelectorOpen && (
                 <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setIsModeSelectorOpen(false)}>
                    <div className="bg-panel rounded-2xl shadow-2xl w-full max-w-lg border border-border p-6 space-y-4" onClick={e => e.stopPropagation()}>
                         <h2 className="text-xl font-bold text-white text-center">Choose Interaction Mode</h2>
                         <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                             <button onClick={() => handleModeSelect('text')} className="p-6 bg-panel-light hover:bg-purple-900/40 rounded-lg border-2 border-border hover:border-purple-500 transition-all text-center"> <ChatBubbleLeftRightIcon className="h-8 w-8 mx-auto text-purple-400" /> <p className="mt-2 font-semibold text-white">Live Text</p> </button>
                             <button onClick={() => handleModeSelect('voice')} className="p-6 bg-panel-light hover:bg-purple-900/40 rounded-lg border-2 border-border hover:border-purple-500 transition-all text-center"> <MicrophoneIcon className="h-8 w-8 mx-auto text-purple-400" /> <p className="mt-2 font-semibold text-white">Live Voice</p> </button>
                             <button onClick={() => handleModeSelect('video')} className="p-6 bg-panel-light hover:bg-purple-900/40 rounded-lg border-2 border-border hover:border-purple-500 transition-all text-center"> <VideoCameraIcon className="h-8 w-8 mx-auto text-purple-400" /> <p className="mt-2 font-semibold text-white">Live Video</p> </button>
                         </div>
                    </div>
                 </div>
            )}

            {isOpen && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={handleClose}>
                    <div className="bg-panel rounded-2xl shadow-2xl w-full max-w-lg border border-border max-h-[80vh] flex flex-col relative" onClick={e => e.stopPropagation()}>
                        {mode === 'video' && <video ref={videoRef} muted playsInline className="absolute top-16 right-4 w-24 h-24 rounded-full object-cover border-2 border-purple-500/50 z-10" />}
                        <canvas ref={canvasRef} className="hidden" />
                        <header className="p-4 border-b border-border flex items-center justify-between flex-shrink-0">
                             <h2 className="text-lg font-bold text-white flex items-center gap-2"><SparklesIcon className="h-5 w-5 text-purple-400" /> Mudde AI Assistant</h2>
                             <button onClick={handleClose} className="p-1 rounded-full text-text-secondary hover:bg-panel-light"><XIcon className="h-6 w-6" /></button>
                        </header>
                        <div className="p-4 flex-grow overflow-y-auto space-y-4">
                            {mode === 'text' && chatHistory.map((turn, i) => (
                                <div key={i} className={`flex ${turn.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                    <p><span className={`${turn.role === 'user' ? 'bg-purple-900/40 text-purple-300' : 'bg-panel-light text-text-primary'} px-3 py-1.5 rounded-lg inline-block whitespace-pre-wrap`}>{turn.text || '...'}</span></p>
                                </div>
                            ))}
                            {(mode === 'voice' || mode === 'video') && transcription.map((turn, i) => (
                                <div key={i} className="space-y-2">
                                    <p className="text-right"><span className="bg-purple-900/40 text-purple-300 px-3 py-1.5 rounded-lg inline-block">{turn.user || '...'}</span></p>
                                    <p><span className="bg-panel-light text-text-primary px-3 py-1.5 rounded-lg inline-block">{turn.model || '...'}</span></p>
                                </div>
                            ))}
                            {isProcessing && !pendingAction && <div className="text-center"><SpinnerIcon className="h-6 w-6 animate-spin text-purple-400 mx-auto" /><p className="text-sm text-text-secondary">Processing...</p></div>}
                        </div>
                        {pendingAction && !isProcessing && (
                            <div className="p-4 bg-purple-900/30 border-t border-b border-purple-500/30 space-y-3 animate-fade-in flex-shrink-0">
                                <p className="text-sm font-semibold text-purple-200 text-center">CONFIRMATION REQUIRED</p>
                                <p className="text-white text-center">{pendingAction.description}</p>
                                <div className="flex gap-3 pt-2">
                                    <button onClick={handleConfirmAction} className="btn btn-primary flex-1">Confirm</button>
                                    <button onClick={() => setPendingAction(null)} className="btn btn-secondary flex-1">Cancel</button>
                                </div>
                            </div>
                        )}
                        <footer className="p-4 border-t border-border flex-shrink-0">
                           {mode === 'text' && (
                                <form onSubmit={(e) => { e.preventDefault(); handleSendTextMessage(); }} className="flex items-center gap-2">
                                    <input type="text" value={textInput} onChange={e => setTextInput(e.target.value)} placeholder="Type your message..." className="input-base flex-grow" disabled={isModelThinking} />
                                    <button type="submit" className="btn btn-primary p-3" disabled={isModelThinking || !textInput.trim()}><PaperAirplaneIcon className="h-5 w-5"/></button>
                                </form>
                           )}
                           {(mode === 'voice' || mode === 'video') && (
                                <button onClick={isRecording ? stopLiveSession : () => startLiveSession(mode!)} className={`w-full btn text-lg py-3 flex items-center justify-center gap-2 ${isRecording ? 'bg-red-600 hover:bg-red-500' : 'btn-primary'} disabled:opacity-50 disabled:cursor-not-allowed`} disabled={!!pendingAction}>
                                    {isRecording ? <><StopCircleIcon className="h-6 w-6" /> Stop Listening</> : <><MicrophoneIcon className="h-6 w-6" /> Start Listening</>}
                                </button>
                           )}
                        </footer>
                    </div>
                </div>
            )}
        </>
    );
};
