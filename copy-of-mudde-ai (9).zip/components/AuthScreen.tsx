import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { LogoIcon, GoogleIcon, ExclamationTriangleIcon, UserIcon, MailIcon, KeyIcon } from './Icons';

export const AuthScreen: React.FC = () => {
  const { login, signup, loginWithGoogle, error: authError, setError } = useAuth();
  const [isLoginView, setIsLoginView] = useState(true);
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [localError, setLocalError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    setIsLoading(true);

    try {
      if (isLoginView) {
        await login(username, password);
      } else {
        if (password !== confirmPassword) {
          setLocalError("Passwords do not match.");
          return;
        }
        await signup({ username, password, displayName, email });
      }
    } finally {
      setIsLoading(false);
    }
  };

  const combinedError = authError || localError;

  return (
    <div className="flex items-center justify-center min-h-full p-4">
      <div className="w-full max-w-md">
        <div className="flex flex-col items-center">
            <div className="bg-purple-600/30 p-4 rounded-2xl border border-purple-500/50">
                <LogoIcon />
            </div>
            <h1 className="text-3xl font-extrabold mt-6 text-white">Welcome to Mudde AI</h1>
            <p className="text-text-secondary mt-2">
                {isLoginView ? 'Sign in to continue to your dashboard.' : 'Create an account to get started.'}
            </p>
        </div>
        
        <div className="mt-8 bg-panel/50 p-8 rounded-2xl border border-border space-y-6 animate-fade-in-up">
            <button
                type="button"
                onClick={loginWithGoogle}
                className="w-full btn bg-white text-gray-800 hover:bg-gray-200 border border-gray-300"
            >
                <GoogleIcon className="h-5 w-5 mr-2" />
                Sign in with Google
            </button>

            <div className="relative flex items-center">
                <div className="flex-grow border-t border-border"></div>
                <span className="flex-shrink mx-4 text-xs font-semibold text-text-secondary uppercase">Or continue with</span>
                <div className="flex-grow border-t border-border"></div>
            </div>

            {combinedError && (
              <div className="bg-red-900/30 border border-red-500/50 text-red-300 px-3 py-2.5 rounded-lg flex items-center gap-3 text-sm animate-fade-in">
                <ExclamationTriangleIcon className="h-5 w-5 flex-shrink-0" />
                <span>{combinedError}</span>
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-4">
              {!isLoginView && (
                  <div className="animate-fade-in space-y-4">
                    <div className="relative">
                        <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4"><UserIcon className="h-5 w-5 text-gray-400"/></div>
                        <input id="displayName" name="displayName" type="text" required value={displayName} onChange={(e) => setDisplayName(e.target.value)} className="input-base pl-12 pr-4 py-3" placeholder="Display Name" />
                    </div>
                    <div className="relative">
                        <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4"><MailIcon className="h-5 w-5 text-gray-400"/></div>
                        <input id="email" name="email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="input-base pl-12 pr-4 py-3" placeholder="Email Address" />
                    </div>
                  </div>
              )}
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4"><UserIcon className="h-5 w-5 text-gray-400"/></div>
                <input id="username" name="username" type="text" autoComplete="username" required value={username} onChange={(e) => setUsername(e.target.value)} className="input-base pl-12 pr-4 py-3" placeholder="Username" />
              </div>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4"><KeyIcon className="h-5 w-5 text-gray-400"/></div>
                <input id="password-auth" name="password" type="password" autoComplete={isLoginView ? "current-password" : "new-password"} required value={password} onChange={(e) => setPassword(e.target.value)} className="input-base pl-12 pr-4 py-3" placeholder="Password" />
              </div>
              {!isLoginView && (
                <div className="animate-fade-in relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4"><KeyIcon className="h-5 w-5 text-gray-400"/></div>
                  <input id="confirm-password-auth" name="confirm-password" type="password" autoComplete="new-password" required value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} className="input-base pl-12 pr-4 py-3" placeholder="Confirm Password" />
                </div>
              )}
              
              <button
                type="submit"
                className="w-full btn btn-primary text-base py-3 disabled:opacity-50 disabled:cursor-wait"
                disabled={isLoading}
              >
                {isLoading ? (
                  <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                ) : (isLoginView ? 'Sign In' : 'Create Account')}
              </button>
            </form>
        </div>
        
        <div className="mt-6 text-center">
          <p className="text-sm text-text-secondary">
            {isLoginView ? "Don't have an account?" : "Already have an account?"}
            <button
              onClick={() => {
                setIsLoginView(!isLoginView);
                setLocalError(null);
                authError && setError(null); // Clear server error on view toggle
              }}
              className="font-semibold text-purple-400 hover:text-purple-300 ml-2"
            >
              {isLoginView ? 'Sign up' : 'Sign in'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};