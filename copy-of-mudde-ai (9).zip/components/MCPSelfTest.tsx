// components/MCPSelfTest.tsx
import React from 'react';
import type { SelfTestResult } from '../types';
import { CheckCircleIcon, XCircleIcon, ChevronDownIcon, SparklesIcon, SpinnerIcon } from './Icons';

interface MCPSelfTestProps {
    testResults: Record<string, SelfTestResult>;
    onRunTest: (testId: string) => void;
    onRunAllTests: () => void;
    testCategories: Record<string, string[]>;
    getTestName: (testId: string) => string;
}

export const MCPSelfTest: React.FC<MCPSelfTestProps> = ({ testResults, onRunTest, onRunAllTests, testCategories, getTestName }) => {
    const statusInfo: Record<SelfTestResult['status'], { text: string; color: string; icon: React.FC<any> }> = {
        untested: { text: 'Untested', color: 'text-gray-400', icon: SparklesIcon },
        running: { text: 'Running...', color: 'text-yellow-400', icon: SpinnerIcon },
        pass: { text: 'Pass', color: 'text-green-400', icon: CheckCircleIcon },
        fail: { text: 'Fail', color: 'text-red-400', icon: XCircleIcon },
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h3 className="text-lg font-bold text-white">System Self-Test</h3>
                <button onClick={onRunAllTests} className="btn btn-primary">Run All Tests</button>
            </div>
            <div className="space-y-4">
                {Object.entries(testCategories).map(([category, testIds]) => (
                    <details key={category} className="bg-panel/50 rounded-lg border border-border-subtle" open>
                        <summary className="p-4 cursor-pointer font-semibold text-text-primary flex items-center justify-between">
                            {category}
                            <ChevronDownIcon className="h-5 w-5 transition-transform" />
                        </summary>
                        <div className="border-t border-border-subtle p-2 space-y-2">
                            {(testIds as string[]).map(testId => {
                                const result = testResults[testId];
                                if (!result) return null;

                                const StatusIcon = statusInfo[result.status].icon;
                                const isRunning = result.status === 'running';

                                return (
                                    <div key={testId} className="bg-panel p-3 rounded-md">
                                        <div className="flex items-center justify-between gap-4">
                                            <div className="flex-1">
                                                <p className="font-medium text-text-primary">{getTestName(testId)}</p>
                                                {result.status === 'fail' && result.message && (
                                                    <p className="text-xs text-red-300 mt-1">{result.message}</p>
                                                )}
                                            </div>
                                            <div className="flex items-center gap-3">
                                                <span className={`flex items-center gap-1.5 text-xs font-semibold ${statusInfo[result.status].color}`}>
                                                    <StatusIcon className={`h-4 w-4 ${isRunning ? 'animate-spin' : ''}`} />
                                                    {statusInfo[result.status].text}
                                                </span>
                                                <button onClick={() => onRunTest(testId)} disabled={isRunning} className="btn btn-secondary text-xs px-3 py-1.5 disabled:opacity-50">Test</button>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </details>
                ))}
            </div>
        </div>
    );
};