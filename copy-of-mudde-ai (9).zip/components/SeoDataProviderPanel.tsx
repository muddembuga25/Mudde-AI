import React, { useState, useEffect } from 'react';
import type { Site, SubscriptionPlan } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { PLAN_LIMITS } from '../constants';
import * as mcpApiService from '../services/mcpApiService';
import { CheckCircleIcon, ExclamationTriangleIcon, InfoIcon } from './Icons';

type VerificationStatus = 'idle' | 'verifying' | 'success' | 'error';

const DataForSeoStrategyPanel: React.FC<{
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
}> = ({ site, onSiteUpdate }) => {
    const [verificationStatus, setVerificationStatus] = useState<VerificationStatus>('idle');
    const [verificationMessage, setVerificationMessage] = useState('');

    useEffect(() => {
        // Reset verification status if the key changes
        setVerificationStatus('idle');
        setVerificationMessage('');
    }, [site.apiKeys.dataforseo]);
    
    const handleVerify = async () => {
        setVerificationStatus('verifying');
        setVerificationMessage('');
        try {
            const result = await mcpApiService.verifyDataForSeoConnection(site.id);
            if (result.success) {
                setVerificationStatus('success');
                setVerificationMessage('Connection successful!');
            } else {
                setVerificationStatus('error');
                setVerificationMessage(result.message);
            }
        } catch (e: any) {
            setVerificationStatus('error');
            setVerificationMessage(e.message || "An unknown error occurred.");
        }
    };
    
    const getStatusIndicator = () => {
        if (!site.apiKeys.dataforseo) {
            return <span className="text-xs font-semibold text-yellow-400">Not Configured</span>;
        }
        switch (verificationStatus) {
            case 'success':
                return <span className="text-xs font-semibold text-green-400 flex items-center gap-1"><CheckCircleIcon className="h-4 w-4" /> Ready</span>;
            case 'error':
                 return <span className="text-xs font-semibold text-red-400 flex items-center gap-1"><ExclamationTriangleIcon className="h-4 w-4" /> Error</span>;
            default:
                 return <span className="text-xs font-semibold text-text-secondary">Needs Verification</span>;
        }
    };

    return (
        <div className="mt-4 p-4 rounded-lg border-2 border-purple-500/30 bg-purple-900/10 animate-fade-in">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                <div>
                    <h4 className="text-lg font-bold text-purple-300">DataForSEO Keyword Research</h4>
                    <p className="text-sm text-text-secondary mt-1">Configure automated keyword discovery with premium data.</p>
                </div>
                <div className="flex items-center gap-3">
                    {getStatusIndicator()}
                    <button onClick={handleVerify} disabled={!site.apiKeys.dataforseo || verificationStatus === 'verifying'} className="btn btn-secondary text-xs">
                        {verificationStatus === 'verifying' ? 'Verifying...' : 'Verify Connection'}
                    </button>
                </div>
            </div>
             {verificationStatus === 'error' && <p className="text-xs text-red-300 mt-2">{verificationMessage}</p>}
             {verificationStatus === 'success' && <p className="text-xs text-green-300 mt-2">{verificationMessage}</p>}
            <div className="mt-4 pt-4 border-t border-purple-500/20 space-y-4">
                 <p className="text-xs text-text-secondary bg-panel/50 p-2 rounded-md"><strong>Note:</strong> When automation is active, it will dynamically use your selected <strong>Master Content Source</strong> as the seed for keyword research. The settings below define the parameters for that research.</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="df-location" className="block text-sm font-medium text-text-primary mb-2">Target Location</label>
                        <input id="df-location" type="text" value={site.dataforseoTargetLocation} onChange={(e) => onSiteUpdate('dataforseoTargetLocation', e.target.value)} placeholder="e.g., us" className="input-base text-sm" />
                    </div>
                    <div>
                        <label htmlFor="df-lang" className="block text-sm font-medium text-text-primary mb-2">Target Language</label>
                        <input id="df-lang" type="text" value={site.dataforseoTargetLanguage} onChange={(e) => onSiteUpdate('dataforseoTargetLanguage', e.target.value)} placeholder="e.g., en" className="input-base text-sm" />
                    </div>
                </div>
                <div>
                    <label className="block text-sm font-medium text-text-primary mb-2">Search Volume Range</label>
                    <div className="grid grid-cols-2 gap-4">
                        <input type="number" value={site.dataforseoSearchVolumeMin} onChange={(e) => onSiteUpdate('dataforseoSearchVolumeMin', parseInt(e.target.value, 10) || 0)} placeholder="Min (e.g., 500)" className="input-base text-sm" />
                        <input type="number" value={site.dataforseoSearchVolumeMax} onChange={(e) => onSiteUpdate('dataforseoSearchVolumeMax', parseInt(e.target.value, 10) || 0)} placeholder="Max (e.g., 10000)" className="input-base text-sm" />
                    </div>
                </div>
                <div>
                    <label className="block text-sm font-medium text-text-primary mb-2">Keyword Difficulty Range</label>
                     <div className="grid grid-cols-2 gap-4">
                        <input type="number" value={site.dataforseoKeywordDifficultyMin} onChange={(e) => onSiteUpdate('dataforseoKeywordDifficultyMin', parseInt(e.target.value, 10) || 0)} placeholder="Min (0-100)" className="input-base text-sm" />
                        <input type="number" value={site.dataforseoKeywordDifficultyMax} onChange={(e) => onSiteUpdate('dataforseoKeywordDifficultyMax', parseInt(e.target.value, 10) || 0)} placeholder="Max (0-100)" className="input-base text-sm" />
                    </div>
                </div>
            </div>
        </div>
    );
};

interface ProviderButtonProps {
    title: string;
    subtext: string;
    description: string;
    isActive: boolean;
    isDisabled: boolean;
    badge?: string;
    onClick: () => void;
}

const ProviderButton: React.FC<ProviderButtonProps> = ({ title, subtext, description, isActive, isDisabled, badge, onClick }) => {
    const baseClass = "relative p-4 text-sm rounded-md transition-colors flex flex-col items-center justify-start text-center h-full border-2";
    const activeClass = "bg-purple-600/30 border-purple-500 text-white shadow-md";
    const inactiveClass = "bg-panel-light/60 border-border text-text-secondary hover:border-gray-600";
    const disabledClass = "opacity-60 cursor-not-allowed hover:bg-panel-light/60 hover:border-border";

    return (
        <button
            onClick={onClick}
            disabled={isDisabled}
            className={`${baseClass} ${isActive ? activeClass : inactiveClass} ${isDisabled ? disabledClass : ''}`}
        >
            <span className="font-semibold text-text-primary">{title}</span>
            <span className="text-xs font-normal opacity-80">{subtext}</span>
            <p className="text-xs font-normal opacity-80 mt-2 leading-snug flex-grow">{description}</p>
            {badge && (
                <div className="absolute top-2 right-2 text-xs font-bold text-yellow-400 bg-yellow-900/50 px-2 py-1 rounded-full pointer-events-none">
                    {badge}
                </div>
            )}
        </button>
    );
};

interface SeoDataProviderPanelProps {
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
}

export const SeoDataProviderPanel: React.FC<SeoDataProviderPanelProps> = ({ site, onSiteUpdate }) => {
    const { currentUser } = useAuth();
    const plan = currentUser ? currentUser.subscription.plan : 'free' as SubscriptionPlan;
    const planFeatures = PLAN_LIMITS[plan].features;

    return (
        <div className="bg-panel/50 p-6 rounded-2xl border border-border">
            <h2 className="text-xl font-bold text-white">SEO Data & Analysis Provider</h2>
            <p className="text-sm text-text-secondary mt-1">Choose your source for raw SEO data and the AI model used to analyze it.</p>
            
            <div className="mt-6 space-y-8">
                <div>
                    <h3 className="text-lg font-semibold text-white">Real-time Data Providers</h3>
                    <p className="text-sm text-text-secondary mt-1">Use live search data for the most accurate, up-to-date analysis. Recommended for most use cases.</p>
                    <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        <ProviderButton title="Google Search" subtext="with Gemini Analysis" description="Best for real-time analysis of current topics. A great default for most use cases." isActive={site.seoDataProvider === 'google_search'} isDisabled={false} onClick={() => onSiteUpdate('seoDataProvider', 'google_search')} />
                        <ProviderButton title="DataForSEO" subtext="with Gemini Analysis" description="Uses a dedicated SEO API for deep, data-driven analysis. Requires DataForSEO key." isActive={site.seoDataProvider === 'dataforseo_gemini'} isDisabled={!planFeatures.advancedSeoProviders} badge={!planFeatures.advancedSeoProviders ? 'PRO+' : undefined} onClick={() => onSiteUpdate('seoDataProvider', 'dataforseo_gemini')} />
                        <ProviderButton title="DataForSEO" subtext="with OpenAI Analysis" description="Leverages OpenAI models with DataForSEO's rich data for an alternative analytical perspective." isActive={site.seoDataProvider === 'dataforseo_openai'} isDisabled={!planFeatures.advancedSeoProviders} badge={!planFeatures.advancedSeoProviders ? 'PRO+' : undefined} onClick={() => onSiteUpdate('seoDataProvider', 'dataforseo_openai')} />
                        <ProviderButton title="DataForSEO" subtext="with XAI (Grok) Analysis" description="Uses XAI's Grok model with DataForSEO's rich data for a unique analytical approach." isActive={site.seoDataProvider === 'dataforseo_xai'} isDisabled={!planFeatures.advancedSeoProviders} badge={!planFeatures.advancedSeoProviders ? 'PRO+' : undefined} onClick={() => onSiteUpdate('seoDataProvider', 'dataforseo_xai')} />
                        <ProviderButton title="DataForSEO" subtext="with Perplexity Analysis" description="Combines Perplexity's online models with DataForSEO's rich data." isActive={site.seoDataProvider === 'dataforseo_perplexity'} isDisabled={!planFeatures.advancedSeoProviders} badge={!planFeatures.advancedSeoProviders ? 'PRO+' : undefined} onClick={() => onSiteUpdate('seoDataProvider', 'dataforseo_perplexity')} />
                    </div>
                </div>

                <div>
                    <h3 className="text-lg font-semibold text-white">Standalone Providers</h3>
                    <p className="text-sm text-text-secondary mt-1">Use the model's internal knowledge without real-time data. Faster, but may not be up-to-date. Best for evergreen topics.</p>
                    <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        <ProviderButton title="Gemini" subtext="(Standalone)" description="Generates strategy based on Google Gemini's internal knowledge base." isActive={site.seoDataProvider === 'standalone_gemini'} isDisabled={false} onClick={() => onSiteUpdate('seoDataProvider', 'standalone_gemini')} />
                        <ProviderButton title="OpenAI" subtext="(Standalone)" description="Fastest option, using the model's internal knowledge. Best for evergreen topics." isActive={site.seoDataProvider === 'standalone_openai'} isDisabled={false} onClick={() => onSiteUpdate('seoDataProvider', 'standalone_openai')} />
                        <ProviderButton title="XAI (Grok)" subtext="(Standalone)" description="Quickly generates strategy based on the model's internal knowledge." isActive={site.seoDataProvider === 'standalone_xai'} isDisabled={false} onClick={() => onSiteUpdate('seoDataProvider', 'standalone_xai')} />
                        <ProviderButton title="Perplexity" subtext="(Standalone)" description="Uses Perplexity's online models for analysis. Great for topics requiring up-to-date information." isActive={site.seoDataProvider === 'standalone_perplexity'} isDisabled={false} onClick={() => onSiteUpdate('seoDataProvider', 'standalone_perplexity')} />
                        <ProviderButton title="OpenRouter" subtext="(Standalone)" description="Flexible option using your chosen OpenRouter model's knowledge." isActive={site.seoDataProvider === 'standalone_openrouter'} isDisabled={false} onClick={() => onSiteUpdate('seoDataProvider', 'standalone_openrouter')} />
                    </div>
                </div>
            </div>

            {(site.seoDataProvider.startsWith('dataforseo')) && <DataForSeoStrategyPanel site={site} onSiteUpdate={onSiteUpdate} />}
        </div>
    );
};