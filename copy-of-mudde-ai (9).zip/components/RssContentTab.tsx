import React, { useCallback, useMemo } from 'react';
import type { Site, RssItem } from '../types';
import { fetchAndParseRssFeed } from '../services/rssService';
import { RssIcon } from './Icons';
import type { GoogleSheetRow } from '../services/googleSheetsService';

interface RssContentTabProps {
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    onGenerateAndScore: (topicToTrack: string, generationSource: 'keyword' | 'rss' | 'video' | 'google_sheet' | 'ai_assistant', sourceDetails: RssItem | string | GoogleSheetRow, site: Site, options?: {sourceId?: string, videoItem?: RssItem}) => Promise<void>;
    setError: (error: string | null) => void;
    rssFeed: RssItem[] | null;
    setRssFeed: (items: RssItem[] | null) => void;
    isFetchingRss: boolean;
    setIsFetchingRss: (isFetching: boolean) => void;
}

export const RssContentTab: React.FC<RssContentTabProps> = ({ site, onSiteUpdate, onGenerateAndScore, setError, rssFeed, setRssFeed, isFetchingRss, setIsFetchingRss }) => {

    const handleFetchRss = useCallback(async () => {
        if (!site.rssFeedUrl) return;
        setIsFetchingRss(true);
        setError(null);
        try {
            const { items } = await fetchAndParseRssFeed(site.rssFeedUrl);
            setRssFeed(items);
        } catch (error: any) {
            setError(error.message || 'Failed to fetch or parse RSS feed.');
            setRssFeed(null);
        } finally {
            setIsFetchingRss(false);
        }
    }, [site.rssFeedUrl, setRssFeed, setIsFetchingRss, setError]);

    const unprocessedRssItems = useMemo(() => rssFeed?.filter(item => !site.processedRssGuids.includes(item.guid)) || [], [rssFeed, site.processedRssGuids]);

    return (
        <div className="max-w-4xl mx-auto space-y-8">
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-2xl font-bold text-white flex items-center gap-3"><RssIcon className="h-6 w-6" /> RSS Feed Content</h2>
                <p className="text-text-secondary mt-1">Provide an RSS feed URL. The app will fetch the latest items for you to generate content from.</p>
            </div>
            <div className="bg-panel/50 p-6 rounded-2xl border border-border animate-fade-in space-y-4">
                <div className="flex items-center gap-2">
                    <input type="url" value={site.rssFeedUrl} onChange={(e) => onSiteUpdate('rssFeedUrl', e.target.value)} placeholder="Enter RSS feed URL" className="input-base flex-grow" />
                    <button onClick={handleFetchRss} disabled={isFetchingRss || !site.rssFeedUrl} className="btn btn-primary">
                        {isFetchingRss ? 'Fetching...' : 'Fetch Feed'}
                    </button>
                </div>
                <div className="space-y-2 pt-4 border-t border-border-subtle">
                    {isFetchingRss && <p className="text-text-secondary text-center">Fetching RSS items...</p>}
                    {!isFetchingRss && unprocessedRssItems.length === 0 && (
                        <p className="text-text-secondary text-center py-4">
                            {rssFeed ? 'All items from this feed have been processed.' : 'Fetch a feed to see available items.'}
                        </p>
                    )}
                    {unprocessedRssItems.map((item) => (
                        <div key={item.guid} className="flex items-center justify-between p-3 rounded-md bg-panel gap-4">
                            <div className="min-w-0">
                                <p className="text-sm font-medium text-text-primary truncate" title={item.title}>{item.title}</p>
                                <p className="text-xs text-text-secondary truncate">{item.contentSnippet}</p>
                            </div>
                            <button onClick={() => onGenerateAndScore(item.title, 'rss', item, site)} className="btn btn-primary text-xs px-3 py-1.5 flex-shrink-0">
                                Generate
                            </button>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};
