import React, { useState, useCallback, useRef, useEffect } from 'react';
import type { BlogPost, SeoScoreResult, Site, StrategicBrief, User } from '../types';
import { AppStatus } from '../types';
import { WordPressIcon, ChevronDownIcon, GoogleDriveIcon, ArrowPathIcon } from './Icons';
import { HtmlRenderer } from './HtmlRenderer';
import { SEOScore } from './SEOScore';
import * as mcpApiService from '../services/mcpApiService';
import { calculateSeoScore } from '../services/seoService';

interface ArticleViewerProps {
    blogPost: BlogPost;
    brief: StrategicBrief;
    seoScore: SeoScoreResult | null;
    status: AppStatus;
    statusMessage: string;
    site: Site;
    currentUser: User;
    onPublish: (editedPost: BlogPost) => void;
    onCancel: () => void;
    onSaveToDrive: (title: string, content: string) => Promise<void>;
    setSites: (updater: (prevSites: Site[]) => Site[]) => void;
}

export const ArticleViewer: React.FC<ArticleViewerProps> = ({ blogPost, brief, seoScore, status, statusMessage, site, currentUser, onPublish, onCancel, onSaveToDrive, setSites }) => {
    const [isExportMenuOpen, setIsExportMenuOpen] = useState(false);
    const editorRef = useRef<HTMLDivElement>(null);
    const [regeneratingSection, setRegeneratingSection] = useState<number | null>(null);
    const [isSavingToDrive, setIsSavingToDrive] = useState(false);

    // State for all editable fields
    const [editedContent, setEditedContent] = useState(blogPost.content);
    const [editedSeoTitle, setEditedSeoTitle] = useState(blogPost.seoTitle);
    const [editedMetaDescription, setEditedMetaDescription] = useState(blogPost.metaDescription);
    const [editedSlug, setEditedSlug] = useState(blogPost.slug);
    const [editedImageAltText, setEditedImageAltText] = useState(blogPost.imageAltText);
    const [currentSeoScore, setCurrentSeoScore] = useState<SeoScoreResult | null>(seoScore);
    
    const isGoogleDriveConnected = site.googleDrive?.isConnected === true;

    useEffect(() => {
        setEditedContent(blogPost.content);
        if (editorRef.current) {
            editorRef.current.innerHTML = blogPost.content;
        }
        setEditedSeoTitle(blogPost.seoTitle);
        setEditedMetaDescription(blogPost.metaDescription);
        setEditedSlug(blogPost.slug);
        setEditedImageAltText(blogPost.imageAltText);
        setCurrentSeoScore(seoScore);
    }, [blogPost, seoScore]);

    // Debounced effect to recalculate SEO score on edit
    useEffect(() => {
        const handler = setTimeout(() => {
            const updatedPost: BlogPost = {
                ...blogPost,
                content: editedContent,
                seoTitle: editedSeoTitle,
                metaDescription: editedMetaDescription,
                slug: editedSlug,
                imageAltText: editedImageAltText,
            };
            const newScore = calculateSeoScore(updatedPost, brief);
            setCurrentSeoScore(newScore);
        }, 500); // 500ms debounce

        return () => clearTimeout(handler);
    }, [editedContent, editedSeoTitle, editedMetaDescription, editedSlug, editedImageAltText, blogPost, brief]);


    const handleContentChange = (e: React.FormEvent<HTMLDivElement>) => {
        setEditedContent(e.currentTarget.innerHTML);
    };
    
    const handlePublish = () => {
        const finalPost: BlogPost = {
            ...blogPost,
            content: editedContent,
            seoTitle: editedSeoTitle,
            metaDescription: editedMetaDescription,
            slug: editedSlug,
            imageAltText: editedImageAltText,
        };
        onPublish(finalPost);
    };

    const handleSaveToDrive = async () => {
        setIsSavingToDrive(true);
        setIsExportMenuOpen(false);
        await onSaveToDrive(editedSeoTitle, editedContent);
        setIsSavingToDrive(false);
    };

    const handleRegenerateSection = useCallback(async (sectionIndex: number, sectionHtml: string) => {
        setRegeneratingSection(sectionIndex);
        try {
            const headingMatch = sectionHtml.match(/<h2[^>]*>(.*?)<\/h2>/i);
            const heading = headingMatch ? headingMatch[1] : `Section ${sectionIndex + 1}`;

            const { regeneratedHtml, updatedSite } = await mcpApiService.regenerateArticleSection(site.id, brief, heading, sectionHtml);
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
            
            const sections = editedContent.split(/(?=<h2)/i);
            if (sections[sectionIndex]) {
                sections[sectionIndex] = regeneratedHtml;
                const newContent = sections.join('');
                setEditedContent(newContent);
                if (editorRef.current) {
                    editorRef.current.innerHTML = newContent;
                }
            }
        } catch (e) {
            console.error("Failed to regenerate section", e);
        } finally {
            setRegeneratingSection(null);
        }
    }, [site.id, brief, editedContent, setSites]);

    const sections = editedContent.split(/(?=<h2)/i);

    return (
        <div className="w-full max-w-7xl mx-auto">
            <header className="p-4 md:p-0 mb-8 flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                <div className="flex-1">
                    <h1 className="text-2xl md:text-3xl font-extrabold text-white">{blogPost.title}</h1>
                    <p className="text-purple-400 mt-1">Your SEO-optimized article is ready.</p>
                </div>
                <div className="flex space-x-4 w-full sm:w-auto">
                    <button onClick={onCancel} className="flex-1 sm:flex-none btn btn-secondary" disabled={isSavingToDrive}> Cancel </button>
                    <div className="relative">
                        <button onMouseEnter={() => setIsExportMenuOpen(true)} onMouseLeave={() => setIsExportMenuOpen(false)} className="flex-1 sm:flex-none btn btn-secondary flex items-center justify-center gap-2" disabled={isSavingToDrive}>
                            <span>{isSavingToDrive ? 'Saving...' : 'Export'}</span>
                            <ChevronDownIcon className="h-4 w-4" />
                        </button>
                        {isExportMenuOpen && (
                             <div onMouseEnter={() => setIsExportMenuOpen(true)} onMouseLeave={() => setIsExportMenuOpen(false)} className="absolute right-0 top-full mt-2 w-56 rounded-md shadow-lg bg-panel-light ring-1 ring-black ring-opacity-5 focus:outline-none z-10 animate-fade-in-up">
                                <div className="py-1">
                                    <button
                                        onClick={handleSaveToDrive}
                                        disabled={!isGoogleDriveConnected}
                                        className={`w-full text-left flex items-center gap-3 px-4 py-2 text-sm transition-colors ${isGoogleDriveConnected ? 'text-text-primary hover:bg-panel' : 'text-text-secondary cursor-not-allowed opacity-50'}`}
                                    >
                                        <GoogleDriveIcon className="h-5 w-5" />
                                        <span>Save to Google Drive</span>
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                    <button onClick={handlePublish} disabled={status === AppStatus.PUBLISHING || isSavingToDrive} className={`flex-1 sm:flex-none btn bg-green-600 hover:bg-green-500 text-white flex items-center justify-center gap-2 shadow-lg shadow-green-900/50 disabled:opacity-50 disabled:cursor-wait ${status !== AppStatus.PUBLISHING && 'animate-subtle-glow'}`}>
                        <WordPressIcon title="Publish to WordPress" />
                        {status === AppStatus.PUBLISHING ? statusMessage : 'Publish'}
                    </button>
                </div>
            </header>
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                <main className="lg:col-span-8 order-2 lg:order-1 bg-panel/50 border border-border rounded-2xl shadow-2xl overflow-hidden">
                    <img src={blogPost.imageUrl} alt={editedImageAltText} className="w-full aspect-video object-cover" />
                    <div className="p-4 md:p-8">
                        <div
                            ref={editorRef}
                            contentEditable={!isSavingToDrive}
                            onInput={handleContentChange}
                            dangerouslySetInnerHTML={{ __html: blogPost.content }}
                            className="prose prose-invert max-w-none 
                                     prose-h2:text-2xl prose-h2:font-bold prose-h2:mt-12 prose-h2:mb-4 prose-h2:border-b prose-h2:border-border prose-h2:pb-3 prose-h2:text-purple-300
                                     prose-p:my-4 prose-p:text-text-secondary prose-p:leading-relaxed
                                     prose-ul:list-disc prose-ul:ml-5 prose-ul:text-text-secondary
                                     prose-a:text-purple-400 prose-a:font-medium hover:prose-a:text-purple-300 prose-a:transition-colors prose-a:no-underline hover:prose-a:underline
                                     prose-strong:text-text-primary
                                     prose-blockquote:border-l-4 prose-blockquote:border-purple-500 prose-blockquote:pl-4 prose-blockquote:text-text-secondary prose-blockquote:italic
                                     focus:outline-none focus:ring-2 focus:ring-purple-500 rounded-lg -m-2 p-2"
                        />
                    </div>
                </main>
                <aside className="lg:col-span-4 order-1 lg:order-2 h-fit lg:sticky top-6 space-y-6">
                     <div className="bg-panel/50 p-4 md:p-6 rounded-2xl border border-border shadow-2xl">
                        <h3 className="text-xl font-bold text-purple-300">On-Page SEO Tracker</h3>
                        <p className="text-sm text-text-secondary mt-1 mb-6">Edit the fields below and the content to see your score update in real-time.</p>
                        
                        <div className="space-y-4 mb-6">
                            <div>
                                <label htmlFor="seo-title" className="block text-sm font-medium text-text-primary mb-1">SEO Title</label>
                                <input id="seo-title" type="text" value={editedSeoTitle} onChange={e => setEditedSeoTitle(e.target.value)} className="input-base text-sm" />
                                <p className="text-xs text-right mt-1 text-text-secondary">{editedSeoTitle.length} / 60</p>
                            </div>
                            <div>
                                <label htmlFor="meta-desc" className="block text-sm font-medium text-text-primary mb-1">Meta Description</label>
                                <textarea id="meta-desc" value={editedMetaDescription} onChange={e => setEditedMetaDescription(e.target.value)} className="input-base text-sm" rows={4}></textarea>
                                <p className="text-xs text-right mt-1 text-text-secondary">{editedMetaDescription.length} / 155</p>
                            </div>
                             <div>
                                <label htmlFor="slug" className="block text-sm font-medium text-text-primary mb-1">URL Slug</label>
                                <input id="slug" type="text" value={editedSlug} onChange={e => setEditedSlug(e.target.value)} className="input-base text-sm" />
                            </div>
                             <div>
                                <label htmlFor="alt-text" className="block text-sm font-medium text-text-primary mb-1">Image Alt Text</label>
                                <input id="alt-text" type="text" value={editedImageAltText} onChange={e => setEditedImageAltText(e.target.value)} className="input-base text-sm" />
                            </div>
                        </div>

                        {currentSeoScore && <SEOScore score={currentSeoScore.score} checklist={currentSeoScore.checklist} currentUser={currentUser} />}

                        <div className="mt-6 pt-6 border-t border-border-subtle">
                             <h3 className="text-lg font-bold mb-2 text-purple-300">Taxonomies</h3>
                             <p className="text-xs text-text-secondary mb-3">These are generated by the AI and can be edited in WordPress after publishing.</p>
                            <div className="flex flex-wrap gap-2">{blogPost.categories.map((c) => (<span key={c} className="bg-blue-900/50 text-blue-300 text-xs font-medium px-2.5 py-1 rounded-full">{c}</span>))}</div>
                            <div className="flex flex-wrap gap-2 mt-2">{blogPost.tags.map((t) => (<span key={t} className="bg-gray-700/50 text-text-secondary text-xs font-medium px-2.5 py-1 rounded-full">{t}</span>))}</div>
                        </div>
                    </div>
                </aside>
            </div>
        </div>
    );
};