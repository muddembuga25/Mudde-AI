import React from 'react';
import type { PostHistoryItem } from '../types';
import { ShareIcon, PhotoIcon, VideoCameraIcon, MailIcon } from './Icons';

interface HistoryTabProps {
    history: PostHistoryItem[];
    onViewDetails: (item: PostHistoryItem) => void;
}

export const HistoryTab: React.FC<HistoryTabProps> = ({ history, onViewDetails }) => {
    const publishedPosts = [...history].sort((a, b) => b.date - a.date);
    const typeStyles: Record<string, string> = { 
        Keyword: 'bg-blue-900/50 text-blue-300 border-blue-500/30', 
        RSS: 'bg-orange-900/50 text-orange-300 border-orange-500/30', 
        Video: 'bg-red-900/50 text-red-300 border-red-500/30',
        'Google Sheet': 'bg-green-900/50 text-green-300 border-green-500/30',
        'Social Graphic': 'bg-teal-900/50 text-teal-300 border-teal-500/30',
        'Social Video': 'bg-indigo-900/50 text-indigo-300 border-indigo-500/30',
        'Email Marketing': 'bg-pink-900/50 text-pink-300 border-pink-500/30',
        'Email Digest': 'bg-cyan-900/50 text-cyan-300 border-cyan-500/30',
    };

    return (
        <div className="max-w-4xl mx-auto">
             <div className="bg-panel/50 p-6 rounded-2xl border border-border mb-8">
                <h2 className="text-2xl font-bold text-white">Content History</h2>
                <p className="text-text-secondary mt-1">Browse all the blog posts and social media content that have been generated for this site.</p>
            </div>
            {publishedPosts.length === 0 ? (
                <p className="text-text-secondary text-center py-8">No content has been generated for this site yet.</p>
            ) : (
                <div className="space-y-4 max-h-[70vh] overflow-y-auto -mr-2 pr-2">
                    {publishedPosts.map((item, index) => {
                        const isSocialOnlyAsset = item.type === 'Social Graphic' || item.type === 'Social Video' || item.type === 'Email Marketing' || item.type === 'Email Digest';
                        const hasDetails = (item.socialMediaPosts && Object.keys(item.socialMediaPosts).length > 0) ||
                                           (item.socialGraphics && Object.keys(item.socialGraphics).length > 0) ||
                                           (item.socialVideos && Object.keys(item.socialVideos).length > 0) ||
                                           !!item.emailCampaign;
                        
                        const thumbnailGraphic = item.type === 'Social Graphic' && item.socialGraphics ? (Object.values(item.socialGraphics) as { imageUrl: string; caption: string; }[])[0] : null;

                        return (
                            <div key={item.id} className="bg-panel p-4 rounded-lg flex items-start sm:items-center justify-between gap-4 border border-border-subtle animate-fade-in-up" style={{ animationDelay: `${index * 60}ms`, opacity: 0, animationFillMode: 'forwards' }}>
                                {thumbnailGraphic && (
                                     <img src={thumbnailGraphic.imageUrl} alt="Social graphic thumbnail" className="w-16 h-16 rounded-md object-cover bg-panel-light flex-shrink-0" />
                                )}
                                {item.type === 'Social Video' && (
                                    <div className="w-16 h-16 rounded-md bg-panel-light flex-shrink-0 flex items-center justify-center">
                                        <VideoCameraIcon className="h-8 w-8 text-indigo-400" />
                                    </div>
                                )}
                                {(item.type === 'Email Marketing' || item.type === 'Email Digest') && (
                                     <div className="w-16 h-16 rounded-md bg-panel-light flex-shrink-0 flex items-center justify-center">
                                        <MailIcon className={`h-8 w-8 ${item.type === 'Email Digest' ? 'text-cyan-400' : 'text-pink-400'}`} />
                                    </div>
                                )}
                                <div className='flex-1 min-w-0'>
                                    <p className="font-semibold text-text-primary truncate" title={item.topic}>{item.topic}</p>
                                    <div className="flex items-center flex-wrap gap-x-3 gap-y-1 mt-1.5">
                                        <span className={`px-2 py-0.5 text-xs font-medium rounded-full border ${typeStyles[item.type] || 'bg-gray-700'}`}>{item.type}</span>
                                        <p className="text-sm text-text-secondary">Generated on: {new Date(item.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-3 w-full sm:w-auto flex-shrink-0">
                                    <button onClick={() => onViewDetails(item)} disabled={!hasDetails} className="w-full sm:w-auto text-center btn btn-secondary text-sm flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed">
                                        {item.type === 'Social Graphic' ? <PhotoIcon className="h-4 w-4" /> : item.type === 'Social Video' ? <VideoCameraIcon className="h-4 w-4" /> : item.type.startsWith('Email') ? <MailIcon className="h-4 w-4" /> : <ShareIcon className="h-4 w-4" />}
                                        View Details
                                    </button>
                                    {!isSocialOnlyAsset && (
                                    <a href={item.url} target="_blank" rel="noopener noreferrer" className={`w-full sm:w-auto text-center btn btn-secondary text-sm ${item.url === '#' && 'pointer-events-none opacity-50'}`}>
                                        View Post
                                    </a>
                                    )}
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
};