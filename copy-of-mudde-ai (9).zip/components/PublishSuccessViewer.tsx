import React from 'react';
import type { Site, SocialMediaPost, SocialMediaSettings } from '../types';
import { CheckCircleIcon, XCircleIcon, XIconSocial, FacebookIcon, LinkedInIcon } from './Icons';

interface PublishSuccessViewerProps {
    publishedPostUrl: string | null;
    publishingLog: { platform: string; accountName: string; status: 'success' | 'failed'; message?: string; }[];
    onReset: () => void;
}

const platformIcons: Record<string, React.FC<any>> = {
  twitter: XIconSocial,
  facebook: FacebookIcon,
  linkedin: LinkedInIcon,
};

export const PublishSuccessViewer: React.FC<PublishSuccessViewerProps> = ({ publishedPostUrl, publishingLog, onReset }) => {
    return (
        <div className="text-center bg-panel/50 p-6 md:p-8 rounded-2xl shadow-2xl w-full max-w-2xl border border-green-500/30 animate-modal-pop">
            <div className="mx-auto bg-green-500/10 rounded-full h-20 w-20 flex items-center justify-center border-2 border-green-500/30">
                <CheckCircleIcon className="h-12 w-12 text-green-400" />
            </div>
            <h2 className="text-2xl md:text-3xl font-bold mt-6 text-green-300">Published Successfully!</h2>
            <p className="text-text-secondary mt-2">Your blog post is live. See below for the social media publishing results.</p>
            
            {publishingLog && publishingLog.length > 0 && (
                <div className="mt-8 text-left">
                    <h3 className="text-lg font-bold text-white mb-4">Social Media Publishing Log</h3>
                    <div className="space-y-3 bg-panel p-4 rounded-lg max-h-60 overflow-y-auto">
                       {publishingLog.map((log, index) => {
                           const Icon = platformIcons[log.platform] || CheckCircleIcon;
                           return (
                               <div key={index} className={`flex items-start gap-3 p-3 rounded-md ${log.status === 'success' ? 'bg-green-900/20' : 'bg-red-900/20'}`}>
                                   <div className={`flex-shrink-0 mt-0.5 ${log.status === 'success' ? 'text-green-400' : 'text-red-400'}`}>
                                       {log.status === 'success' ? <CheckCircleIcon className="h-5 w-5" /> : <XCircleIcon className="h-5 w-5" />}
                                   </div>
                                   <div>
                                       <p className="font-semibold text-text-primary flex items-center gap-2">
                                           <Icon className="h-4 w-4" />
                                           {log.accountName}
                                       </p>
                                       {log.status === 'success' ? (
                                           <p className="text-sm text-green-300">Successfully posted to {log.platform}.</p>
                                       ) : (
                                           <p className="text-sm text-red-300">Failed: {log.message}</p>
                                       )}
                                   </div>
                               </div>
                           );
                       })}
                    </div>
                </div>
            )}

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-8">
                {publishedPostUrl && ( <a href={publishedPostUrl} target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto btn bg-green-600 hover:bg-green-500 text-white shadow-lg shadow-green-900/50"> View Post </a> )}
                <button onClick={onReset} className="w-full sm:w-auto btn btn-primary"> Create Another Post </button>
            </div>
        </div>
    );
};