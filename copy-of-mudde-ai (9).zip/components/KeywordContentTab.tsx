import React, { useState, useCallback, useMemo } from 'react';
import type { Site, RssItem } from '../types';
import * as aiService from '../services/aiService';
import { ExclamationTriangleIcon, LinkIcon, LightbulbIcon, TrashIcon, DocumentTextIcon } from './Icons';
import type { GoogleSheetRow } from '../services/googleSheetsService';

interface KeywordContentTabProps {
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    setSites: (updater: (prevSites: Site[]) => Site[]) => void;
    onGenerateAndScore: (topicToTrack: string, generationSource: 'keyword' | 'rss' | 'video' | 'google_sheet' | 'ai_assistant', sourceDetails: RssItem | string | GoogleSheetRow, site: Site, options?: {sourceId?: string, videoItem?: RssItem}) => Promise<void>;
    setError: (error: string | null) => void;
}

export const KeywordContentTab: React.FC<KeywordContentTabProps> = ({ site, onSiteUpdate, setSites, onGenerateAndScore, setError }) => {
    const [isSuggestingKeywords, setIsSuggestingKeywords] = useState(false);
    const [isSuggestUrlModalOpen, setIsSuggestUrlModalOpen] = useState(false);
    const [suggestUrlInput, setSuggestUrlInput] = useState('');
    const [isSuggestingFromUrl, setIsSuggestingFromUrl] = useState(false);
    const [isClearKeywordsModalOpen, setIsClearKeywordsModalOpen] = useState(false);

    const handleSuggestFromUrl = useCallback(async () => {
        if (!suggestUrlInput.trim()) return;
        setIsSuggestingFromUrl(true);
        setError(null);
        try {
          const { suggestions, updatedSite } = await aiService.suggestKeywordsFromUrl(suggestUrlInput, site.keywordList, site.id);
          setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
          const newKeywords = suggestions.join('\n');
          onSiteUpdate('keywordList', site.keywordList.trim() ? `${site.keywordList.trim()}\n${newKeywords}` : newKeywords);
          setSuggestUrlInput('');
          setIsSuggestUrlModalOpen(false);
        } catch (error: any) {
          setError(error.message || 'An unknown error occurred while suggesting keywords from URL.');
        } finally {
          setIsSuggestingFromUrl(false);
        }
    }, [site, suggestUrlInput, onSiteUpdate, setSites, setError]);

    const handleSuggestKeywords = useCallback(async () => {
        setIsSuggestingKeywords(true);
        setError(null);
        try {
            const { suggestions, updatedSite } = await aiService.suggestKeywords(site.keywordList, site.id);
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
            const newKeywords = suggestions.join('\n');
            onSiteUpdate('keywordList', site.keywordList.trim() ? `${site.keywordList.trim()}\n${newKeywords}` : newKeywords);
        } catch (error: any) {
            setError(error.message || 'An unknown error occurred while suggesting keywords.');
        } finally {
            setIsSuggestingKeywords(false);
        }
    }, [site, onSiteUpdate, setSites, setError]);

    const handleClearKeywords = () => {
        onSiteUpdate('keywordList', '');
        setIsClearKeywordsModalOpen(false);
    };

    const keywords = useMemo(() => site.keywordList.split('\n').filter(k => k.trim()), [site.keywordList]);

    return (
        <div className="max-w-4xl mx-auto space-y-8">
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-2xl font-bold text-white flex items-center gap-3"><DocumentTextIcon className="h-6 w-6" /> Keyword Content</h2>
                <p className="text-text-secondary mt-1">Enter one keyword or topic per line. The AI will write an article for the first available keyword.</p>
            </div>
            
            <div className="bg-panel/50 p-6 rounded-2xl border border-border animate-fade-in space-y-4">
                <textarea value={site.keywordList} onChange={(e) => onSiteUpdate('keywordList', e.target.value)} placeholder="e.g., best espresso machines 2024" className="input-base text-sm leading-relaxed" rows={8}></textarea>
                <div className="flex flex-wrap gap-3">
                    <button onClick={handleSuggestKeywords} disabled={isSuggestingKeywords} className="btn bg-teal-600 hover:bg-teal-500 text-white shadow-lg shadow-teal-900/50 flex items-center gap-2"><LightbulbIcon className="h-4 w-4" /> Suggest Keywords</button>
                    <button onClick={() => setIsSuggestUrlModalOpen(true)} className="btn btn-secondary flex items-center gap-2"><LinkIcon className="h-4 w-4" /> Suggest from URL</button>
                    <button onClick={() => setIsClearKeywordsModalOpen(true)} className="btn btn-secondary flex items-center gap-2" disabled={!site.keywordList.trim()}><TrashIcon className="h-4 w-4" /> Clear All</button>
                </div>
                <div className="space-y-2 pt-4 border-t border-border-subtle">
                    {keywords.length === 0 && <p className="text-center text-text-secondary py-4">Add some keywords to get started.</p>}
                    {keywords.map((keyword, i) => {
                        const isDone = keyword.trim().startsWith('[DONE]');
                        const topic = isDone ? keyword.replace('[DONE]', '').trim() : keyword;
                        return (
                            <div key={i} className={`flex items-center justify-between p-2 rounded-md ${isDone ? 'bg-green-900/20' : 'bg-panel'}`}>
                                <span className={`text-sm ${isDone ? 'text-gray-500 line-through' : 'text-text-primary'}`}>{topic}</span>
                                <button onClick={() => onGenerateAndScore(topic, 'keyword', topic, site)} disabled={isDone} className="btn btn-primary text-xs px-3 py-1.5 disabled:opacity-40 disabled:cursor-not-allowed">Generate</button>
                            </div>
                        )
                    })}
                </div>
            </div>

            {isSuggestUrlModalOpen && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
                    <div className="bg-panel rounded-lg shadow-2xl w-full max-w-md p-6 border border-border animate-modal-pop">
                        <h3 className="text-lg font-bold text-white">Suggest Keywords from URL</h3>
                        <p className="text-sm text-text-secondary mt-2">Enter a URL (like a competitor's blog post) to get relevant keyword ideas.</p>
                        <input type="url" value={suggestUrlInput} onChange={e => setSuggestUrlInput(e.target.value)} className="input-base mt-4" placeholder="https://example.com/blog/post" />
                        <div className="mt-4 flex justify-end gap-3">
                            <button onClick={() => setIsSuggestUrlModalOpen(false)} className="btn btn-secondary">Cancel</button>
                            <button onClick={handleSuggestFromUrl} disabled={isSuggestingFromUrl || !suggestUrlInput.trim()} className="btn btn-primary disabled:opacity-50"> {isSuggestingFromUrl ? 'Suggesting...' : 'Suggest'} </button>
                        </div>
                    </div>
                </div>
            )}
            {isClearKeywordsModalOpen && (
                 <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
                    <div className="bg-panel rounded-lg shadow-2xl w-full max-w-md p-6 border border-red-500/50 animate-modal-pop">
                        <div className="flex items-start gap-4">
                            <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-900/50 sm:mx-0 sm:h-10 sm:w-10"> <ExclamationTriangleIcon className="h-6 w-6 text-red-400" /> </div>
                            <div className="mt-0 text-left flex-1">
                                <h3 className="text-lg leading-6 font-bold text-white">Clear All Keywords?</h3>
                                <div className="mt-2"> <p className="text-sm text-text-secondary"> Are you sure you want to delete all keywords from the list? This action cannot be undone. </p> </div>
                            </div>
                        </div>
                        <div className="mt-5 sm:mt-4 sm:flex sm:flex-row-reverse gap-3">
                            <button type="button" className="w-full btn bg-red-600 hover:bg-red-700 text-white sm:w-auto" onClick={handleClearKeywords}> Clear List </button>
                            <button type="button" className="mt-3 w-full btn btn-secondary sm:mt-0 sm:w-auto" onClick={() => setIsClearKeywordsModalOpen(false)}> Cancel </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
