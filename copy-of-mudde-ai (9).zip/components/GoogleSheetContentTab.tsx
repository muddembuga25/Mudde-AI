import React, { useCallback, useMemo } from 'react';
import type { Site, RssItem } from '../types';
import * as googleSheetsService from '../services/googleSheetsService';
import type { GoogleSheetRow } from '../services/googleSheetsService';
import { GoogleSheetsIcon } from './Icons';

interface GoogleSheetContentTabProps {
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    onGenerateAndScore: (topicToTrack: string, generationSource: 'keyword' | 'rss' | 'video' | 'google_sheet' | 'ai_assistant', sourceDetails: RssItem | string | GoogleSheetRow, site: Site, options?: {sourceId?: string, videoItem?: RssItem}) => Promise<void>;
    setError: (error: string | null) => void;
    sheetData: GoogleSheetRow[] | null;
    setSheetData: (data: GoogleSheetRow[] | null) => void;
    isFetchingSheet: boolean;
    setIsFetchingSheet: (isFetching: boolean) => void;
}

export const GoogleSheetContentTab: React.FC<GoogleSheetContentTabProps> = ({ site, onSiteUpdate, onGenerateAndScore, setError, sheetData, setSheetData, isFetchingSheet, setIsFetchingSheet }) => {
    
    const handleFetchSheet = useCallback(async () => {
        if (!site.googleSheetUrl) return;
        setIsFetchingSheet(true);
        setError(null);
        try {
            const data = await googleSheetsService.fetchGoogleSheetData(site);
            setSheetData(data);
        } catch (error: any) {
            setError(error.message || 'Failed to fetch Google Sheet data.');
            setSheetData(null);
        } finally {
            setIsFetchingSheet(false);
        }
    }, [site, setSheetData, setIsFetchingSheet, setError]);

    const unprocessedSheetRows = useMemo(() => sheetData?.filter(row => !site.googleSheetProcessedRows.includes(row.rowIndex)) || [], [sheetData, site.googleSheetProcessedRows]);

    return (
         <div className="max-w-4xl mx-auto space-y-8">
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-2xl font-bold text-white flex items-center gap-3"><GoogleSheetsIcon className="h-6 w-6" /> Google Sheet Content</h2>
                <p className="text-text-secondary mt-1">Connect a public Google Sheet. The AI will use the first column as the topic. Ensure your Google API Key is set in the API Keys tab.</p>
            </div>
            <div className="bg-panel/50 p-6 rounded-2xl border border-border animate-fade-in space-y-4">
                <div className="flex items-center gap-2">
                    <input type="url" value={site.googleSheetUrl} onChange={(e) => onSiteUpdate('googleSheetUrl', e.target.value)} placeholder="Enter public Google Sheet URL" className="input-base flex-grow" />
                    <button onClick={handleFetchSheet} disabled={isFetchingSheet || !site.googleSheetUrl || !site.apiKeys.google} className="btn btn-primary disabled:opacity-50">
                        {isFetchingSheet ? 'Fetching...' : 'Fetch Sheet'}
                    </button>
                </div>
                {!site.apiKeys.google && <p className="text-xs text-yellow-400 mt-2">A Google API Key is required to fetch sheet data. Please add one in the API Keys tab.</p>}
                <div className="space-y-2 pt-4 border-t border-border-subtle">
                    {isFetchingSheet && <p className="text-text-secondary text-center">Fetching sheet data...</p>}
                    {!isFetchingSheet && unprocessedSheetRows.length === 0 && (
                        <p className="text-text-secondary text-center py-4">
                            {sheetData ? 'All rows from this sheet have been processed.' : 'Fetch a sheet to see available rows.'}
                        </p>
                    )}
                    {unprocessedSheetRows.map((row) => (
                        <div key={row.rowIndex} className="flex items-center justify-between p-3 rounded-md bg-panel gap-4">
                            <div className="min-w-0">
                                <p className="text-sm font-medium text-text-primary truncate" title={row.topic}>{row.topic}</p>
                                <p className="text-xs text-text-secondary">Row {row.rowIndex + 1}</p>
                            </div>
                            <button onClick={() => onGenerateAndScore(row.topic, 'google_sheet', row, site)} className="btn btn-primary text-xs px-3 py-1.5 flex-shrink-0">
                                Generate
                            </button>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};
