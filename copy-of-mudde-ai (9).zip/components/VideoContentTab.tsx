import React, { useState, useCallback } from 'react';
import type { Site, RssItem, VideoSource } from '../types';
import { fetchAndParseRssFeed } from '../services/rssService';
import { VideoCameraIcon, TrashIcon } from './Icons';
import type { GoogleSheetRow } from '../services/googleSheetsService';

interface VideoContentTabProps {
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    onGenerateAndScore: (topicToTrack: string, generationSource: 'keyword' | 'rss' | 'video' | 'google_sheet' | 'ai_assistant', sourceDetails: RssItem | string | GoogleSheetRow, site: Site, options?: {sourceId?: string, videoItem?: RssItem}) => Promise<void>;
    setError: (error: string | null) => void;
    channelVideos: Record<string, RssItem[]>;
    setChannelVideos: (updater: (prev: Record<string, RssItem[]>) => Record<string, RssItem[]>) => void;
    isFetchingChannel: string | null;
    setIsFetchingChannel: (sourceId: string | null) => void;
}

export const VideoContentTab: React.FC<VideoContentTabProps> = ({ site, onSiteUpdate, onGenerateAndScore, setError, channelVideos, setChannelVideos, isFetchingChannel, setIsFetchingChannel }) => {
    const [videoSourceUrl, setVideoSourceUrl] = useState('');
    const [isAddingVideoSource, setIsAddingVideoSource] = useState(false);

    const handleAddVideoSource = useCallback(async () => {
        if (!videoSourceUrl.trim()) return;
        setIsAddingVideoSource(true);
        setError(null);
        try {
            const { title } = await fetchAndParseRssFeed(videoSourceUrl);
            const newSource: VideoSource = {
                id: crypto.randomUUID(), url: videoSourceUrl, type: 'channel',
                name: title || videoSourceUrl, processedVideoGuids: [],
            };
            onSiteUpdate('videoSources', [...(site.videoSources || []), newSource]);
            setVideoSourceUrl('');
        } catch (e) {
            // If RSS fails, assume it's a single video URL
            const newSource: VideoSource = {
                id: crypto.randomUUID(), url: videoSourceUrl, type: 'video', name: videoSourceUrl, processedVideoGuids: [],
            };
            onSiteUpdate('videoSources', [...(site.videoSources || []), newSource]);
            setVideoSourceUrl('');
        } finally {
            setIsAddingVideoSource(false);
        }
    }, [videoSourceUrl, site.videoSources, onSiteUpdate, setError]);

    const handleDeleteVideoSource = (id: string) => {
        onSiteUpdate('videoSources', site.videoSources.filter(s => s.id !== id));
    };

    const handleFetchChannelVideos = useCallback(async (source: VideoSource) => {
        setIsFetchingChannel(source.id);
        setError(null);
        try {
            const { items } = await fetchAndParseRssFeed(source.url);
            setChannelVideos(prev => ({ ...prev, [source.id]: items }));
        } catch (error: any) {
            setError(error.message || 'Failed to fetch videos for this channel.');
        } finally {
            setIsFetchingChannel(null);
        }
    }, [setChannelVideos, setIsFetchingChannel, setError]);

    return (
        <div className="max-w-4xl mx-auto space-y-8">
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-2xl font-bold text-white flex items-center gap-3"><VideoCameraIcon className="h-6 w-6" /> Video Content</h2>
                <p className="text-text-secondary mt-1">Add YouTube channel URLs or individual video URLs as a source for content ideas.</p>
            </div>
            <div className="bg-panel/50 p-6 rounded-2xl border border-border animate-fade-in space-y-4">
                <div className="flex items-center gap-2">
                    <input type="url" value={videoSourceUrl} onChange={e => setVideoSourceUrl(e.target.value)} placeholder="Enter YouTube channel or video URL" className="input-base flex-grow" />
                    <button onClick={handleAddVideoSource} disabled={isAddingVideoSource || !videoSourceUrl.trim()} className="btn btn-primary">
                        {isAddingVideoSource ? 'Adding...' : 'Add Source'}
                    </button>
                </div>
                <div className="space-y-3 pt-4 border-t border-border-subtle">
                     {(!site.videoSources || site.videoSources.length === 0) && (
                        <p className="text-text-secondary text-center py-4">No video sources added yet.</p>
                    )}
                    {(site.videoSources || []).map(source => (
                        <div key={source.id} className="bg-panel p-3 rounded-lg border border-border-subtle">
                            <div className="flex items-center justify-between">
                                <p className="font-medium text-text-primary truncate">{source.name}</p>
                                <button onClick={() => handleDeleteVideoSource(source.id)} className="text-red-500 hover:text-red-400"><TrashIcon className="h-4 w-4" /></button>
                            </div>
                            {source.type === 'channel' && (
                                <button onClick={() => handleFetchChannelVideos(source)} disabled={isFetchingChannel === source.id} className="btn btn-secondary text-xs mt-2">
                                    {isFetchingChannel === source.id ? 'Fetching...' : 'Fetch Videos'}
                                </button>
                            )}
                            {source.type === 'video' && (
                                <button onClick={() => onGenerateAndScore(source.name, 'video', source.url, site, { sourceId: source.id })} className="btn btn-primary text-xs mt-2">Generate from Video</button>
                            )}
                            {isFetchingChannel === source.id && <p className="text-xs text-text-secondary mt-2">Fetching videos...</p>}
                            {channelVideos[source.id] && (
                                <div className="mt-3 pt-3 border-t border-border-subtle space-y-2">
                                    {channelVideos[source.id].filter(video => !source.processedVideoGuids.includes(video.guid)).map(videoItem => (
                                        <div key={videoItem.guid} className="flex items-center justify-between p-2 rounded-md bg-panel-light">
                                            <p className="text-sm text-text-primary truncate">{videoItem.title}</p>
                                            <button onClick={() => onGenerateAndScore(videoItem.title, 'video', videoItem.link, site, { sourceId: source.id, videoItem })} className="btn btn-primary text-xs px-3 py-1.5 flex-shrink-0">Generate</button>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};
