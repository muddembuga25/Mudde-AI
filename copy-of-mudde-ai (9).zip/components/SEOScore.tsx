import React, { useState, useEffect } from 'react';
import { RadialBarChart, RadialBar, PolarAngleAxis, ResponsiveContainer } from 'recharts';
import { SeoChecklist, User } from '../types';
import { SubscriptionPlan } from '../types';
import { CheckCircleIcon, XCircleIcon, SparklesIcon } from './Icons';

interface SEOScoreProps {
  score: number;
  checklist: SeoChecklist;
  currentUser: User;
}

const ChecklistItem: React.FC<{ label: string; checked: boolean; delay: number; isBlurred?: boolean }> = ({ label, checked, delay, isBlurred = false }) => (
  <li className={`flex items-center text-sm animate-fade-in-up transition-all duration-300 ${isBlurred ? 'blur-sm opacity-60 pointer-events-none' : ''}`} style={{ animationDelay: `${delay}ms`, opacity: 0, animationFillMode: 'forwards' }}>
    {checked ? (
      <CheckCircleIcon className="h-5 w-5 text-green-400 mr-3 flex-shrink-0" />
    ) : (
      <XCircleIcon className="h-5 w-5 text-red-400 mr-3 flex-shrink-0" />
    )}
    <span className={checked ? 'text-text-primary' : 'text-text-secondary'}>{label}</span>
  </li>
);

export const SEOScore: React.FC<SEOScoreProps> = ({ score, checklist, currentUser }) => {
  const [displayScore, setDisplayScore] = useState(0);
  const isFreePlan = currentUser.subscription.plan === SubscriptionPlan.FREE;

  useEffect(() => {
    const animationDuration = 800; // ms
    const frameRate = 60; // fps
    const totalFrames = (animationDuration / 1000) * frameRate;
    let frame = 0;

    const counter = setInterval(() => {
      frame++;
      const progress = Math.min(frame / totalFrames, 1);
      const currentScore = Math.floor(score * progress);
      setDisplayScore(currentScore);
      
      if (frame >= totalFrames) {
        clearInterval(counter);
      }
    }, 1000 / frameRate);

    return () => clearInterval(counter);
  }, [score]);


  const scoreColor = score > 85 ? '#22c55e' : score > 60 ? '#f59e0b' : '#ef4444';
  const data = [{ name: 'score', value: score }];

  const checklistItems = [
    { label: "Optimal title length (50-60 chars)", checked: checklist.titleLength },
    { label: "Meta description length (120-155 chars)", checked: checklist.metaDescriptionLength },
    { label: "Keyword in SEO Title", checked: checklist.keywordInTitle },
    { label: "Keyword in Meta Description", checked: checklist.keywordInMetaDescription },
    { label: "Keyword in URL Slug", checked: checklist.keywordInSlug },
    { label: "Keyword in H2/H3 headings", checked: checklist.keywordInHeadings },
    { label: "Sufficient keyword density", checked: checklist.keywordInContent },
    { label: "Image alt text includes keyword", checked: checklist.imageAltText },
    { label: "Sufficient content length (>300 words)", checked: checklist.contentLength },
    { label: "Includes dedicated FAQ section", checked: checklist.faqSection },
    { label: "Includes 'About the Author' section", checked: checklist.aboutTheAuthorSection },
    { label: "Author's name mentioned in content", checked: checklist.authorMentioned },
    { label: "Signals first-person experience (E-E-A-T)", checked: checklist.firstPersonExperience },
    { label: "Contextual internal links (2+)", checked: checklist.sufficientInternalLinks },
    { label: "Authoritative external links (2+)", checked: checklist.sufficientExternalLinks },
    { label: "Content is easy to read", checked: checklist.readability },
    { label: "Advanced Schema Markup (e.g., FAQPage)", checked: checklist.schemaMarkupValid },
  ];

  return (
    <div className="w-full">
        <h3 className="text-xl font-bold mb-4 border-b border-border pb-2 text-purple-300">Optimization Checklist</h3>
      <div className="relative w-40 h-40 mx-auto my-4">
        <ResponsiveContainer width="100%" height="100%">
          <RadialBarChart
            innerRadius="80%"
            outerRadius="100%"
            barSize={12}
            data={data}
            startAngle={90}
            endAngle={-270}
          >
            <PolarAngleAxis
              type="number"
              domain={[0, 100]}
              angleAxisId={0}
              tick={false}
            />
            <RadialBar
              background={{ fill: 'rgba(255, 255, 255, 0.05)' }}
              dataKey="value"
              cornerRadius={6}
              fill={scoreColor}
            />
          </RadialBarChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-4xl font-extrabold animate-count-up" style={{ color: scoreColor }}>
            {displayScore}
          </span>
        </div>
      </div>
      <p className="text-center font-semibold text-lg mt-1 mb-6 text-text-primary">Overall Score</p>
      
      <div className="relative">
        <ul className="space-y-3">
            {checklistItems.map((item, index) => (
                 <ChecklistItem key={item.label} label={item.label} checked={item.checked} delay={200 + index * 40} isBlurred={isFreePlan && index > 4} />
            ))}
        </ul>
        {isFreePlan && (
            <div className="absolute inset-0 bg-gradient-to-t from-panel/90 to-transparent flex items-end justify-center p-4">
                <div className="text-center bg-purple-900/50 p-4 rounded-lg border border-purple-500/50">
                    <SparklesIcon className="h-6 w-6 mx-auto text-purple-300" />
                    <p className="text-sm font-semibold text-white mt-2">Unlock Full SEO Checklist</p>
                    <p className="text-xs text-text-secondary mt-1">Upgrade to the Creator plan to see all 17+ optimization checks.</p>
                </div>
            </div>
        )}
      </div>
    </div>
  );
};