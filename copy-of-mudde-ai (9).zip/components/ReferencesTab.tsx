import React, { useState, useCallback } from 'react';
import type { Site, ReferenceItem, ApiKeys, Site as ClientSite, CharacterReference } from '../types';
import * as aiService from '../services/aiService';
import { LinkIcon, PhotoIcon, DocumentTextIcon, ArrowUpTrayIcon, XIcon, GoogleDriveIcon, GoogleIcon, TrashIcon, UserIcon, PlusIcon, PenIcon } from './Icons';

interface ReferencesTabProps {
    site: ClientSite;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    setSites: (updater: (prevSites: Site[]) => Site[]) => void;
    setError: (error: string | null) => void;
    onConnectGoogleDrive: () => void;
    onDisconnectGoogleDrive: () => void;
    onShowGooglePicker: () => void;
}

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};

const BrandingPanel: React.FC<ReferencesTabProps> = ({ site, onSiteUpdate }) => {
    
    const handleLogoChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files && event.target.files[0]) {
            const file = event.target.files[0];
            const base64 = await fileToBase64(file);
            onSiteUpdate('brandLogo', base64);
        }
    };

    const handleRemoveLogo = () => {
        onSiteUpdate('brandLogo', '');
    };

    const handleColorChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const colors = event.target.value.split(',').map(c => c.trim()).filter(Boolean);
        onSiteUpdate('brandColors', colors);
    };

    const handleFontChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const fonts = event.target.value.split(',').map(f => f.trim()).filter(Boolean);
        onSiteUpdate('brandFonts', fonts);
    };

    return (
        <div className="bg-panel/50 p-6 rounded-2xl border border-border">
            <h2 className="text-xl font-bold text-white">Branding Materials</h2>
            <p className="text-sm text-text-secondary mt-1">Upload your logo and define brand elements. The AI will use these to maintain brand consistency in generated content and images.</p>
            
            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                {/* Logo Uploader */}
                <div>
                    <label className="block text-sm font-medium text-text-primary mb-2">Brand Logo</label>
                    <div className="mt-2 flex items-center gap-4">
                        <div className="w-20 h-20 bg-panel-light rounded-lg border border-border flex items-center justify-center p-1">
                            {site.brandLogo ? <img src={site.brandLogo} alt="Brand Logo" className="max-w-full max-h-full object-contain" /> : <PhotoIcon className="h-8 w-8 text-text-secondary" />}
                        </div>
                        <div className="flex-1 space-y-2">
                            <label htmlFor="logo-upload" className="btn btn-secondary text-sm w-full cursor-pointer text-center block">
                                Upload Logo
                            </label>
                            <input id="logo-upload" type="file" accept="image/png, image/jpeg, image/webp, image/svg+xml" className="hidden" onChange={handleLogoChange} />
                            {site.brandLogo && <button onClick={handleRemoveLogo} className="btn bg-red-900/40 hover:bg-red-800/60 text-red-300 text-sm w-full">Remove</button>}
                        </div>
                    </div>
                </div>

                {/* Colors and Fonts */}
                <div className="space-y-4">
                    <div>
                        <label htmlFor="brand-colors" className="block text-sm font-medium text-text-primary mb-2">Brand Colors</label>
                        <input id="brand-colors" type="text" value={(site.brandColors || []).join(', ')} onChange={handleColorChange} placeholder="#FFFFFF, #0A0A0F, #A855F7" className="input-base" />
                        <div className="flex flex-wrap gap-2 mt-2 h-6 items-center">
                            {(site.brandColors || []).map(color => (
                                <div key={color} className="h-6 w-6 rounded-full border-2 border-panel" style={{ backgroundColor: color }} title={color} />
                            ))}
                        </div>
                    </div>
                    <div>
                        <label htmlFor="brand-fonts" className="block text-sm font-medium text-text-primary mb-2">Brand Fonts</label>
                        <input id="brand-fonts" type="text" value={(site.brandFonts || []).join(', ')} onChange={handleFontChange} placeholder="Inter, Roboto, Open Sans" className="input-base" />
                    </div>
                </div>
            </div>
        </div>
    );
};


const KnowledgeBasePanel: React.FC<ReferencesTabProps> = ({ site, onSiteUpdate, onConnectGoogleDrive, onDisconnectGoogleDrive, onShowGooglePicker }) => {
    const [newUrl, setNewUrl] = useState('');
    
    const handleAddUrl = () => {
        if (!newUrl.trim()) return;
        const newRef: ReferenceItem = { id: crypto.randomUUID(), type: 'url', value: newUrl, name: newUrl, mimeType: 'text/uri-list' };
        onSiteUpdate('references', [...site.references, newRef]);
        setNewUrl('');
    };
    
    const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files) {
            const files = Array.from(event.target.files);
            const newRefs: ReferenceItem[] = await Promise.all(
                files.map(async (file: File) => {
                    const base64 = await fileToBase64(file);
                    return { id: crypto.randomUUID(), type: 'file', value: base64, name: file.name, mimeType: file.type };
                })
            );
            onSiteUpdate('references', [...site.references, ...newRefs]);
        }
    };
    
    const handleDeleteReference = (id: string) => {
        onSiteUpdate('references', site.references.filter(ref => ref.id !== id));
    };

    const getIconForType = (mimeType: string | null) => {
        if (!mimeType) return DocumentTextIcon;
        if (mimeType.startsWith('image/')) return PhotoIcon;
        if (mimeType === 'text/uri-list') return LinkIcon;
        return DocumentTextIcon;
    };

    return (
        <div className="bg-panel/50 p-6 rounded-2xl border border-border">
            <h2 className="text-xl font-bold text-white">Knowledge Base</h2>
            <p className="text-sm text-text-secondary mt-1">Add files or URLs to this site's knowledge base. The AI will use these references for context during content generation.</p>
            
            <div className="mt-4 p-4 rounded-lg bg-panel border border-border-subtle space-y-4">
                 <div className="flex flex-col sm:flex-row items-center gap-3">
                    <button onClick={onConnectGoogleDrive} className="w-full sm:w-auto btn btn-secondary flex items-center justify-center gap-2">
                        <GoogleIcon className="h-5 w-5" /> Connect Google Drive
                    </button>
                    <button onClick={onShowGooglePicker} disabled={!site.googleDrive?.isConnected} className="w-full sm:w-auto btn btn-primary flex items-center justify-center gap-2 disabled:opacity-50">
                        <GoogleDriveIcon className="h-5 w-5" /> Add from Drive
                    </button>
                    {site.googleDrive?.isConnected && (
                        <div className="text-xs text-green-300 flex items-center gap-2">
                            <span>Connected as {site.googleDrive.userEmail}</span>
                            <button onClick={onDisconnectGoogleDrive} className="font-bold hover:underline"> (Disconnect) </button>
                        </div>
                    )}
                 </div>
                 <div className="relative flex items-center">
                    <div className="flex-grow border-t border-border"></div>
                    <span className="flex-shrink mx-4 text-xs font-semibold text-text-secondary uppercase">Or add manually</span>
                    <div className="flex-grow border-t border-border"></div>
                </div>

                <div className="flex items-center gap-2">
                    <div className="relative flex-grow">
                        <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3"><LinkIcon className="h-5 w-5 text-gray-400"/></div>
                        <input type="url" value={newUrl} onChange={e => setNewUrl(e.target.value)} placeholder="Add a URL reference..." className="input-base pl-10 pr-4 py-2 text-sm" />
                    </div>
                    <button onClick={handleAddUrl} className="btn btn-secondary text-sm">Add URL</button>
                </div>

                <div>
                    <label htmlFor="file-upload" className="w-full btn btn-secondary flex items-center justify-center gap-2 cursor-pointer">
                        <ArrowUpTrayIcon className="h-5 w-5" />
                        Upload Files
                    </label>
                    <input id="file-upload" type="file" multiple onChange={handleFileChange} className="hidden" />
                </div>
            </div>

            <div className="mt-4 space-y-2">
                {site.references.length === 0 ? (
                    <p className="text-sm text-center text-text-secondary py-4">No references added.</p>
                ) : (
                    site.references.map(ref => {
                        const Icon = getIconForType(ref.mimeType);
                        return (
                            <div key={ref.id} className="bg-panel p-2 pl-3 rounded-lg flex items-center justify-between gap-3 border border-border-subtle">
                                <div className="flex items-center gap-3 min-w-0">
                                    <Icon className="h-5 w-5 text-text-secondary flex-shrink-0" />
                                    <span className="text-sm text-text-primary truncate" title={ref.name || ref.value}>{ref.name || ref.value}</span>
                                </div>
                                <button onClick={() => handleDeleteReference(ref.id)} className="p-1 text-red-400 hover:text-red-300 rounded-full transition-colors">
                                    <TrashIcon className="h-4 w-4" />
                                </button>
                            </div>
                        )
                    })
                )}
            </div>
        </div>
    );
};

const ContentStrategyPanel: React.FC<{ site: Site, onSiteUpdate: (field: keyof Site, value: any) => void, setSites: (updater: (prevSites: Site[]) => Site[]) => void, setError: (error: string | null) => void }> = ({ site, onSiteUpdate, setSites, setError }) => {
    const [brandGuidelineUrl, setBrandGuidelineUrl] = useState('');
    const [isGeneratingGuideline, setIsGeneratingGuideline] = useState(false);

    const handleGenerateGuideline = useCallback(async () => {
        if (!brandGuidelineUrl.trim()) return;
        setIsGeneratingGuideline(true);
        setError(null);
        try {
            const { updatedSite } = await aiService.generateBrandGuidelineFromUrl(brandGuidelineUrl, site.id);
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
        } catch (error: any) {
            setError(error.message || 'An unknown error occurred while generating the brand guideline.');
        } finally {
            setIsGeneratingGuideline(false);
        }
    }, [brandGuidelineUrl, site.id, setSites, setError]);
    
    return (
        <div className="bg-panel/50 p-6 rounded-2xl border border-border">
            <h2 className="text-xl font-bold text-white">Content Strategy</h2>
            <p className="text-sm text-text-secondary mt-1">Provide guidelines and promotional materials for the AI to use when writing blog posts.</p>
            <div className="mt-6 space-y-6">
                <div>
                    <h3 className="text-base font-semibold text-text-primary">Brand Guideline</h3>
                    <p className="text-sm text-text-secondary">Provide tone, style, or other instructions for the AI to use as context.</p>
                    <div className="mt-2">
                        <div className="flex items-center gap-2">
                            <div className="relative flex-grow">
                                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3"><LinkIcon className="h-5 w-5 text-gray-400"/></div>
                                <input type="url" value={brandGuidelineUrl} onChange={(e) => setBrandGuidelineUrl(e.target.value)} placeholder="Generate guidelines from a URL..." className="input-base pl-10 pr-4 py-2 text-sm" disabled={isGeneratingGuideline} />
                            </div>
                            <button onClick={handleGenerateGuideline} disabled={isGeneratingGuideline || !brandGuidelineUrl.trim()} className="btn bg-teal-600 hover:bg-teal-500 text-white shadow-lg shadow-teal-900/50 text-sm flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed flex-shrink-0 px-3">
                                {isGeneratingGuideline ? (<><svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg><span>Generating...</span></>) : 'Generate'}
                            </button>
                        </div>
                        <div className="mt-2">
                            <textarea value={site.brandGuideline} onChange={(e) => onSiteUpdate('brandGuideline', e.target.value)} placeholder="e.g., Write in a friendly and professional tone..." className="input-base px-4 py-3 text-sm leading-relaxed" rows={6} disabled={isGeneratingGuideline} />
                        </div>
                    </div>
                </div>

                <div>
                    <h3 className="text-base font-semibold text-text-primary">Promotional Links</h3>
                    <p className="text-sm text-text-secondary">The AI will try to naturally include these links in generated articles.</p>
                     <div className="mt-2 space-y-3">
                        <div className="relative">
                           <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3"><LinkIcon className="h-5 w-5 text-gray-400"/></div>
                           <input type="url" value={site.promoLink1} onChange={(e) => onSiteUpdate('promoLink1', e.target.value)} placeholder="Primary promo link (e.g., your product page)" className="input-base pl-10 pr-4 py-2 text-sm" />
                        </div>
                         <div className="relative">
                           <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3"><LinkIcon className="h-5 w-5 text-gray-400"/></div>
                           <input type="url" value={site.promoLink2} onChange={(e) => onSiteUpdate('promoLink2', e.target.value)} placeholder="Secondary promo link (e.g., a relevant affiliate link)" className="input-base pl-10 pr-4 py-2 text-sm" />
                        </div>
                    </div>
                </div>
                
                <div>
                    <h3 className="text-base font-semibold text-text-primary">Niche Targeting</h3>
                    <p className="text-sm text-text-secondary">Describe your specific niche to tailor content more accurately. If left blank, the AI will attempt to infer the niche from your WordPress URL during content creation.</p>
                    <div className="mt-2">
                        <textarea
                            value={site.nicheTargeting || ''}
                            onChange={(e) => onSiteUpdate('nicheTargeting', e.target.value)}
                            placeholder="e.g., 'sustainable coffee brewing for home baristas', 'vintage synthesizer repair for hobbyists'"
                            className="input-base px-4 py-3 text-sm leading-relaxed"
                            rows={3}
                        />
                    </div>
                </div>
                 <div>
                    <h3 className="text-base font-semibold text-text-primary">Author Name for Schema</h3>
                    <p className="text-sm text-text-secondary">This name is used in the article's schema markup. The author for publishing is set in the WordPress tab.</p>
                    <div className="mt-2 relative">
                        <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3"><UserIcon className="h-5 w-5 text-gray-400"/></div>
                        <input type="text" value={site.authorName} onChange={(e) => onSiteUpdate('authorName', e.target.value)} placeholder="e.g., John Doe" className="input-base pl-10 pr-4 py-2" />
                    </div>
                </div>
            </div>
        </div>
    )
};

const AddEditCharacterModal: React.FC<{
    character: Partial<CharacterReference> | null;
    onClose: () => void;
    onSave: (character: CharacterReference) => void;
}> = ({ character, onClose, onSave }) => {
    const [name, setName] = useState(character?.name || '');
    const [visualReferenceText, setVisualReferenceText] = useState(character?.visualReferenceText || '');
    const [personality, setPersonality] = useState(character?.personality || '');
    const [visualReferenceImage, setVisualReferenceImage] = useState(character?.visualReferenceImage || '');
    const [error, setError] = useState('');

    const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            try {
                const base64 = await fileToBase64(e.target.files[0]);
                setVisualReferenceImage(base64);
            } catch (err) {
                setError("Failed to load image.");
            }
        }
    };

    const handleSave = () => {
        if (!name.trim()) {
            setError("Character Name is required.");
            return;
        }
        if (!visualReferenceText.trim() && !visualReferenceImage) {
            setError("Please provide either a reference image or a detailed text description.");
            return;
        }
        onSave({
            id: character?.id || crypto.randomUUID(),
            name,
            visualReferenceImage,
            visualReferenceText,
            personality,
        });
    };

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-panel rounded-lg shadow-2xl w-full max-w-2xl border border-border animate-modal-pop max-h-[90vh] flex flex-col">
                <header className="p-4 border-b border-border flex items-center justify-between">
                    <h2 className="text-xl font-bold text-white">{character?.id ? 'Edit Character' : 'Add New Character'}</h2>
                    <button onClick={onClose} className="p-1 rounded-full text-text-secondary hover:bg-panel-light"><XIcon className="h-6 w-6" /></button>
                </header>
                <div className="p-6 space-y-6 overflow-y-auto">
                    {error && <p className="text-red-400 text-sm bg-red-900/30 p-2 rounded-md">{error}</p>}
                    <div>
                        <label className="block text-sm font-medium text-text-primary mb-2">Character Name</label>
                        <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="e.g., Captain Coffee" className="input-base" />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label className="block text-sm font-medium text-text-primary mb-2">Visual Reference Image (Optional)</label>
                            <div className="w-full aspect-square bg-panel-light rounded-lg border-2 border-dashed border-border flex items-center justify-center p-1">
                                {visualReferenceImage ? <img src={visualReferenceImage} alt="Character preview" className="max-w-full max-h-full object-contain rounded-md" /> : <PhotoIcon className="h-12 w-12 text-text-secondary" />}
                            </div>
                             <label htmlFor="char-img-upload" className="btn btn-secondary text-sm w-full mt-2">Upload Image</label>
                             <input id="char-img-upload" type="file" accept="image/*" className="hidden" onChange={handleImageChange} />
                        </div>
                        <div>
                             <label className="block text-sm font-medium text-text-primary mb-2">Visual Description</label>
                            <textarea value={visualReferenceText} onChange={e => setVisualReferenceText(e.target.value)} placeholder="Describe the character's appearance, clothing, art style..." className="input-base h-full" rows={8} />
                        </div>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-text-primary mb-2">Personality & Vibe</label>
                        <textarea value={personality} onChange={e => setPersonality(e.target.value)} placeholder="Describe the character's personality, mood, and way of speaking..." className="input-base" rows={4} />
                    </div>
                </div>
                 <footer className="p-4 border-t border-border flex justify-end gap-3">
                    <button onClick={onClose} className="btn btn-secondary">Cancel</button>
                    <button onClick={handleSave} className="btn btn-primary">Save Character</button>
                </footer>
            </div>
        </div>
    );
};

const CharacterLibraryPanel: React.FC<ReferencesTabProps> = ({ site, onSiteUpdate }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingCharacter, setEditingCharacter] = useState<Partial<CharacterReference> | null>(null);

    const handleOpenModal = (character: Partial<CharacterReference> | null = null) => {
        setEditingCharacter(character);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingCharacter(null);
    };

    const handleSaveCharacter = (character: CharacterReference) => {
        const currentLibrary = site.characterLibrary || [];
        const existingIndex = currentLibrary.findIndex(c => c.id === character.id);
        if (existingIndex > -1) {
            const updatedLibrary = [...currentLibrary];
            updatedLibrary[existingIndex] = character;
            onSiteUpdate('characterLibrary', updatedLibrary);
        } else {
            onSiteUpdate('characterLibrary', [...currentLibrary, character]);
        }
        handleCloseModal();
    };
    
    const handleDeleteCharacter = (id: string) => {
        if (window.confirm("Are you sure you want to delete this character?")) {
            onSiteUpdate('characterLibrary', (site.characterLibrary || []).filter(c => c.id !== id));
        }
    };

    return (
        <div className="bg-panel/50 p-6 rounded-2xl border border-border">
            <div className="flex justify-between items-center">
                <div>
                    <h2 className="text-xl font-bold text-white">Character Library</h2>
                    <p className="text-sm text-text-secondary mt-1">Define recurring characters or mascots for consistent use in generated media.</p>
                </div>
                <button onClick={() => handleOpenModal()} className="btn btn-primary flex items-center gap-2"><PlusIcon className="h-5 w-5" /> Add Character</button>
            </div>
            <div className="mt-6 space-y-3">
                {(site.characterLibrary || []).length === 0 ? (
                    <p className="text-center text-text-secondary py-4">No characters defined yet.</p>
                ) : (
                    (site.characterLibrary || []).map(char => (
                        <div key={char.id} className="bg-panel p-3 rounded-lg flex items-center gap-4 border border-border-subtle">
                            {char.visualReferenceImage ? (
                                <img src={char.visualReferenceImage} alt={char.name} className="w-12 h-12 rounded-md object-cover flex-shrink-0 bg-panel-light" />
                            ) : (
                                <div className="w-12 h-12 rounded-md flex-shrink-0 bg-panel-light flex items-center justify-center"><UserIcon className="h-6 w-6 text-text-secondary"/></div>
                            )}
                            <div className="flex-1 min-w-0">
                                <p className="font-semibold text-white truncate">{char.name}</p>
                                <p className="text-xs text-text-secondary truncate">{char.personality || 'No personality defined'}</p>
                            </div>
                            <div className="flex items-center gap-2">
                                <button onClick={() => handleOpenModal(char)} className="btn btn-secondary p-2"><PenIcon className="h-4 w-4" /></button>
                                <button onClick={() => handleDeleteCharacter(char.id)} className="btn bg-red-900/40 hover:bg-red-800/60 p-2"><TrashIcon className="h-4 w-4 text-red-300" /></button>
                            </div>
                        </div>
                    ))
                )}
            </div>
            {isModalOpen && <AddEditCharacterModal character={editingCharacter} onClose={handleCloseModal} onSave={handleSaveCharacter} />}
        </div>
    );
};

export const ReferencesTab: React.FC<ReferencesTabProps> = (props) => {
    return (
        <div className="space-y-8 max-w-4xl mx-auto">
             <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-2xl font-bold text-white">Knowledge & Branding</h2>
                <p className="text-text-secondary mt-1">Manage a persistent knowledge base and brand identity for this site. The AI will use these materials as context during all content generation tasks.</p>
            </div>
            <BrandingPanel {...props} />
            <CharacterLibraryPanel {...props} />
            <ContentStrategyPanel {...props} />
            <KnowledgeBasePanel {...props} />
        </div>
    );
};