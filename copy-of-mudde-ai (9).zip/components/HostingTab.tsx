import React from 'react';
import type { Site } from '../types';
import { SparklesIcon, CheckCircleIcon, ShieldCheckIcon, ArchiveBoxIcon } from './Icons';

interface HostingTabProps {
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
}

const FeaturePill: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <div className="flex items-center gap-2 text-sm text-text-primary bg-panel-light px-3 py-1.5 rounded-full">
        <CheckCircleIcon className="h-5 w-5 text-green-400" />
        <span>{children}</span>
    </div>
);

const MetricCard: React.FC<{ title: string; value: string; subtext: string; icon: React.FC<any>; }> = ({ title, value, subtext, icon: Icon }) => (
    <div className="bg-panel p-6 rounded-lg border border-border-subtle text-center">
        <Icon className="h-8 w-8 text-purple-400 mx-auto" />
        <p className="text-4xl font-extrabold text-white mt-3">{value}</p>
        <p className="text-sm font-medium text-text-primary">{title}</p>
        <p className="text-xs text-text-secondary mt-1">{subtext}</p>
    </div>
);


export const HostingTab: React.FC<HostingTabProps> = ({ site, onSiteUpdate }) => {
    
    // In a real app, this would be based on site.hosting.isConnected
    // For this simulation, we'll make the first site connected and others not.
    const isConnected = site.name.includes("1");

    // Mocked data for the connected view
    const performanceScore = 98;
    const securityStatus = "No Vulnerabilities Found";
    const lastBackup = "Today at 2:15 AM";

    if (!isConnected) {
        return (
             <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
                <div className="text-center bg-gradient-to-br from-purple-900/30 to-panel-light p-10 rounded-2xl border border-purple-500/30">
                    <SparklesIcon className="mx-auto h-12 w-12 text-purple-300" />
                    <h2 className="text-3xl font-extrabold text-white mt-4">Supercharge Your Site with 10Web</h2>
                    <p className="text-lg text-text-secondary mt-2 max-w-xl mx-auto">
                        Deploy your content to a blazing-fast, AI-powered WordPress host.
                        Achieve a 90+ PageSpeed score automatically and manage your site with ease.
                    </p>
                </div>

                <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                    <h3 className="text-xl font-bold text-white text-center mb-6">Key Features</h3>
                    <div className="flex flex-wrap justify-center gap-4">
                        <FeaturePill>Automated 90+ PageSpeed</FeaturePill>
                        <FeaturePill>AI Website Recreation</FeaturePill>
                        <FeaturePill>Automated Backups</FeaturePill>
                        <FeaturePill>Enterprise-Grade Security</FeaturePill>
                        <FeaturePill>Staging Environments</FeaturePill>
                    </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 items-center justify-center p-4">
                     <button className="w-full sm:w-auto btn btn-primary text-lg py-3 px-8">Deploy a New Site on 10Web</button>
                     <button className="w-full sm:w-auto btn btn-secondary text-lg py-3 px-8">Connect Existing 10Web Site</button>
                </div>
            </div>
        )
    }

    return (
        <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                    <div>
                        <h2 className="text-2xl font-bold text-white">10Web Hosting Dashboard</h2>
                        <p className="text-text-secondary mt-1">An overview of your site's performance and health, powered by 10Web.</p>
                    </div>
                    <div className="flex items-center gap-3 text-sm text-green-400 font-semibold bg-green-900/30 px-3 py-1.5 rounded-full border border-green-500/30">
                        <CheckCircleIcon className="h-5 w-5" />
                        Connected
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <MetricCard title="PageSpeed Score" value={`${performanceScore}/100`} subtext="Last analyzed: 2 hours ago" icon={SparklesIcon} />
                <MetricCard title="Security Status" value="Secure" subtext={securityStatus} icon={ShieldCheckIcon} />
                <MetricCard title="Backup Status" value="Healthy" subtext={lastBackup} icon={ArchiveBoxIcon} />
            </div>

            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h3 className="text-xl font-bold text-white mb-4">Management Actions</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                    <button className="btn btn-secondary">Manage Backups</button>
                    <button className="btn btn-secondary">Open Staging</button>
                    <button className="btn btn-secondary">Run Security Scan</button>
                    <button className="btn btn-primary">Go to 10Web Dashboard</button>
                </div>
            </div>
        </div>
    );
};