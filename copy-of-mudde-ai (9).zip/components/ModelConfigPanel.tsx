import React, { useState } from 'react';
import type { Site, ModelConfig, GeminiModelConfig } from '../types';
import { AiProvider } from '../types';
import { AVAILABLE_MODELS, providerDisplayNames } from '../constants';

interface ModelConfigPanelProps {
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
}

export const ModelConfigPanel: React.FC<ModelConfigPanelProps> = ({ site, onSiteUpdate }) => {
    const [activeModelTab, setActiveModelTab] = useState<'text' | 'image' | 'video'>('text');

    const handleModelConfigUpdate = (field: keyof ModelConfig, value: any) => {
        const newConfig = { ...site.modelConfig, [field]: value };
        
        const setDefaults = (provider: AiProvider, type: 'text' | 'image' | 'video') => {
          const fetchedProviderModels = site.fetchedModels?.[provider];
          
          if (fetchedProviderModels) {
              if (type === 'text' && fetchedProviderModels.text.length > 0) {
                  newConfig.textModel = fetchedProviderModels.text[0];
                  return;
              }
              if (type === 'image' && fetchedProviderModels.image.length > 0) {
                  newConfig.imageModel = fetchedProviderModels.image[0];
                  return;
              }
              if (type === 'video' && fetchedProviderModels.video && fetchedProviderModels.video.length > 0) {
                  newConfig.videoModel = fetchedProviderModels.video[0];
                  return;
              }
          }
    
          const models = AVAILABLE_MODELS[provider as keyof typeof AVAILABLE_MODELS];
          if (type === 'text' && models.text.length > 0) newConfig.textModel = models.text[0];
          else if (type === 'image' && models.image.length > 0) newConfig.imageModel = models.image[0];
          else if (type === 'video' && models.video && models.video.length > 0) newConfig.videoModel = models.video[0];
          else if (type === 'image') newConfig.imageModel = '';
          else if (type === 'video') newConfig.videoModel = '';
        };
  
        if (field === 'textProvider') setDefaults(value, 'text');
        if (field === 'imageProvider') setDefaults(value, 'image');
        if (field === 'videoProvider') setDefaults(value, 'video');
  
        onSiteUpdate('modelConfig', newConfig);
    };
    
    const handleGeminiConfigChange = (field: keyof GeminiModelConfig, value: string) => {
        const geminiConfig = site.modelConfig.geminiConfig || {};
        const numValue = value === '' ? undefined : parseFloat(value);
        const newGeminiConfig = { ...geminiConfig, [field]: numValue };
        // Clean up undefined keys
        Object.keys(newGeminiConfig).forEach(key => {
            if (newGeminiConfig[key as keyof GeminiModelConfig] === undefined) {
                delete newGeminiConfig[key as keyof GeminiModelConfig];
            }
        });
        handleModelConfigUpdate('geminiConfig', newGeminiConfig);
    };

    const textModelsForProvider = site.fetchedModels?.[site.modelConfig.textProvider]?.text || AVAILABLE_MODELS[site.modelConfig.textProvider as keyof typeof AVAILABLE_MODELS]?.text || [];
    const imageModelsForProvider = site.fetchedModels?.[site.modelConfig.imageProvider]?.image || AVAILABLE_MODELS[site.modelConfig.imageProvider as keyof typeof AVAILABLE_MODELS]?.image || [];
    const videoProviders = (Object.keys(AVAILABLE_MODELS) as AiProvider[]).filter(p => AVAILABLE_MODELS[p as keyof typeof AVAILABLE_MODELS].video && AVAILABLE_MODELS[p as keyof typeof AVAILABLE_MODELS].video!.length > 0);
    const videoModelsForProvider = site.modelConfig.videoProvider ? (site.fetchedModels?.[site.modelConfig.videoProvider]?.video || AVAILABLE_MODELS[site.modelConfig.videoProvider as keyof typeof AVAILABLE_MODELS]?.video || []) : [];
    
    const geminiConfig = site.modelConfig.geminiConfig || {};

    const TabButton = ({ id, label }: { id: 'text' | 'image' | 'video', label: string }) => (
        <button
            onClick={() => setActiveModelTab(id)}
            className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${activeModelTab === id ? 'bg-purple-600 text-white shadow-sm' : 'text-text-secondary hover:bg-gray-700/50'}`}
        >
            {label}
        </button>
    );

    return (
        <div className="bg-panel/50 p-6 rounded-2xl border border-border">
            <h2 className="text-xl font-bold text-white">AI Model Configuration</h2>
            <p className="text-sm text-text-secondary mt-1">Mix and match providers for text, image, and video generation.</p>
            <p className="text-xs text-purple-300 bg-purple-900/30 p-2 rounded-md mt-2"> <strong>Note:</strong> Advanced SEO functions like keyword research will always use Google's models for their search capabilities. </p>
            
            <div className="mt-6">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 bg-panel-light rounded-lg p-1 w-full sm:max-w-md mb-4">
                    <TabButton id="text" label="Text Models" />
                    <TabButton id="image" label="Image Models" />
                    <TabButton id="video" label="Video Models" />
                </div>

                <div className="p-4 bg-panel rounded-lg border border-border-subtle min-h-[180px]">
                    {activeModelTab === 'text' && (
                        <div className="animate-fade-in">
                            <h3 className="font-semibold text-white mb-3">Text Generation Models</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label htmlFor="text-provider" className="block text-sm font-medium text-text-primary mb-2">Provider</label>
                                    <select id="text-provider" value={site.modelConfig.textProvider} onChange={e => handleModelConfigUpdate('textProvider', e.target.value)} className="input-base px-4 py-2 w-full">
                                        <option value={AiProvider.GOOGLE}>Google Gemini (Default)</option>
                                        <option value={AiProvider.OPENAI}>OpenAI</option>
                                        <option value={AiProvider.ANTHROPIC}>Anthropic Claude</option>
                                        <option value={AiProvider.OPENROUTER}>OpenRouter</option>
                                        <option value={AiProvider.XAI}>X.AI Grok</option>
                                        <option value={AiProvider.PERPLEXITY}>Perplexity AI</option>
                                    </select>
                                </div>
                                <div>
                                    <label htmlFor="text-model" className="block text-sm font-medium text-text-primary mb-2">Text Model</label>
                                    <input
                                        id="text-model"
                                        type="text"
                                        list="text-models-list-settings"
                                        value={site.modelConfig.textModel}
                                        onChange={e => handleModelConfigUpdate('textModel', e.target.value)}
                                        className="input-base px-4 py-2 w-full"
                                        placeholder="Select or type a model name"
                                    />
                                    <datalist id="text-models-list-settings">
                                        {textModelsForProvider.map(model => <option key={model} value={model} />)}
                                    </datalist>
                                </div>
                            </div>
                            {site.modelConfig.textProvider === AiProvider.GOOGLE && (
                                <div className="mt-4 pt-4 border-t border-border-subtle animate-fade-in">
                                    <h4 className="font-semibold text-purple-300 mb-3">Gemini Advanced Settings</h4>
                                    <div className="space-y-4">
                                        <div>
                                            <label htmlFor="gemini-temp" className="block text-sm font-medium text-text-primary mb-1">Temperature: <span className="font-mono text-purple-300">{geminiConfig.temperature ?? 0.7}</span></label>
                                            <input id="gemini-temp" type="range" min="0" max="1" step="0.05" value={geminiConfig.temperature ?? 0.7} onChange={e => handleGeminiConfigChange('temperature', e.target.value)} className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer range-lg" />
                                            <p className="text-xs text-text-secondary mt-1">Controls randomness. Lower is more predictable, higher is more creative.</p>
                                        </div>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <div>
                                                <label htmlFor="gemini-topp" className="block text-sm font-medium text-text-primary mb-1">Top-P: <span className="font-mono text-purple-300">{geminiConfig.topP ?? 0.95}</span></label>
                                                <input id="gemini-topp" type="range" min="0" max="1" step="0.05" value={geminiConfig.topP ?? 0.95} onChange={e => handleGeminiConfigChange('topP', e.target.value)} className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer range-lg" />
                                            </div>
                                             <div>
                                                <label htmlFor="gemini-topk" className="block text-sm font-medium text-text-primary mb-1">Top-K</label>
                                                <input id="gemini-topk" type="number" value={geminiConfig.topK ?? 40} onChange={e => handleGeminiConfigChange('topK', e.target.value)} className="input-base w-full" placeholder="e.g., 40" />
                                            </div>
                                        </div>
                                        <div>
                                            <label htmlFor="gemini-maxtokens" className="block text-sm font-medium text-text-primary mb-1">Max Output Tokens</label>
                                            <input id="gemini-maxtokens" type="number" value={geminiConfig.maxOutputTokens ?? ''} onChange={e => handleGeminiConfigChange('maxOutputTokens', e.target.value)} className="input-base w-full" placeholder="Optional, e.g., 2048" />
                                            <p className="text-xs text-text-secondary mt-1">Limits the response length. If using `gemini-2.5-flash`, half this value is reserved for the AI's "thinking" process.</p>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                    {activeModelTab === 'image' && (
                        <div className="animate-fade-in">
                            <h3 className="font-semibold text-white mb-3">Image Generation Models</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label htmlFor="image-provider" className="block text-sm font-medium text-text-primary mb-2">Provider</label>
                                    <select id="image-provider" value={site.modelConfig.imageProvider} onChange={e => handleModelConfigUpdate('imageProvider', e.target.value)} className="input-base px-4 py-2 w-full">
                                        <option value={AiProvider.GOOGLE}>Google Gemini (Default)</option>
                                        <option value={AiProvider.OPENAI}>OpenAI</option>
                                        <option value={AiProvider.OPENROUTER}>OpenRouter</option>
                                        <option value={AiProvider.REPLICATE}>Replicate</option>
                                        <option value={AiProvider.FREEPIK}>Freepik</option>
                                        <option value={AiProvider.FALAI}>Fal.ai</option>
                                        <option value={AiProvider.ANTHROPIC}>Anthropic Claude</option>
                                        <option value={AiProvider.XAI}>X.AI Grok</option>
                                        <option value={AiProvider.PERPLEXITY}>Perplexity AI</option>
                                    </select>
                                </div>
                                <div>
                                    <label htmlFor="image-model" className="block text-sm font-medium text-text-primary mb-2">Image Model</label>
                                    <input
                                        id="image-model"
                                        type="text"
                                        list="image-models-list-settings"
                                        value={site.modelConfig.imageModel}
                                        onChange={e => handleModelConfigUpdate('imageModel', e.target.value)}
                                        className="input-base px-4 py-2 w-full"
                                        placeholder="Select or type a model name"
                                        disabled={imageModelsForProvider.length === 0}
                                    />
                                    <datalist id="image-models-list-settings">
                                        {imageModelsForProvider.map(model => <option key={model} value={model} />)}
                                    </datalist>
                                    {imageModelsForProvider.length === 0 && site.modelConfig.imageProvider && (
                                        <p className="text-xs text-yellow-400 bg-yellow-900/30 p-2 rounded-md mt-2">
                                            Provider '{providerDisplayNames[site.modelConfig.imageProvider]}' does not offer image models.
                                        </p>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                    {activeModelTab === 'video' && (
                        <div className="animate-fade-in">
                            <h3 className="font-semibold text-white mb-3">Video Generation Models</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label htmlFor="video-provider" className="block text-sm font-medium text-text-primary mb-2">Provider</label>
                                    <select id="video-provider" value={site.modelConfig.videoProvider || ''} onChange={e => handleModelConfigUpdate('videoProvider', e.target.value)} className="input-base px-4 py-2 w-full">
                                        {videoProviders.map(p => <option key={p} value={p}>{providerDisplayNames[p]}</option>)}
                                    </select>
                                </div>
                                <div>
                                    <label htmlFor="video-model" className="block text-sm font-medium text-text-primary mb-2">Video Model</label>
                                    <input
                                        id="video-model"
                                        type="text"
                                        list="video-models-list-settings"
                                        value={site.modelConfig.videoModel || ''}
                                        onChange={e => handleModelConfigUpdate('videoModel', e.target.value)}
                                        className="input-base px-4 py-2 w-full"
                                        placeholder="Select or type a model name"
                                        disabled={!site.modelConfig.videoProvider || videoModelsForProvider.length === 0}
                                    />
                                    <datalist id="video-models-list-settings">
                                        {videoModelsForProvider.map(model => <option key={model} value={model} />)}
                                    </datalist>
                                     {videoModelsForProvider.length === 0 && site.modelConfig.videoProvider && (
                                        <p className="text-xs text-yellow-400 bg-yellow-900/30 p-2 rounded-md mt-2">
                                            Provider '{providerDisplayNames[site.modelConfig.videoProvider]}' does not offer video models.
                                        </p>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};