import React, { useState, useCallback, useEffect } from 'react';
import type { Site } from '../types';
import { fetchAuthors, fetchCategories } from '../services/wordpressService';
import * as mcpApiService from '../services/mcpApiService';
import type { WordPressConnectionResult } from '../services/wordpressService';
import { UserIcon, KeyIcon, LinkIcon, ArrowPathIcon, CheckCircleIcon, ExclamationTriangleIcon, InfoIcon } from './Icons';

// --- PROPS INTERFACE ---
interface WordPressTabProps {
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    onMultipleSiteUpdates: (updates: Partial<Site>) => void;
    setError: (error: string | null) => void;
}

// --- SUB-COMPONENTS FOR SECTIONS ---

const ConnectionPanel: React.FC<WordPressTabProps> = ({ site, onSiteUpdate, setError }) => {
    const [verificationStatus, setVerificationStatus] = useState<'idle' | 'verifying' | 'success' | 'error'>('idle');
    const [verificationMessage, setVerificationMessage] = useState<string | null>(null);

    const handleTestConnection = useCallback(async () => {
        setVerificationStatus('verifying');
        setVerificationMessage(null);
        setError(null);
        
        try {
            const result: WordPressConnectionResult = await mcpApiService.verifyWordPressConnection(site.id);

            if (result.success) {
                setVerificationStatus('success');
                setVerificationMessage(result.message);
            } else {
                setVerificationStatus('error');
                setVerificationMessage(result.message);
            }
        } catch (e: any) {
            setVerificationStatus('error');
            setVerificationMessage(e.message || "An unknown error occurred.");
            setError(e.message);
        }
    }, [site.id, setError]);
    
    useEffect(() => {
        // Reset status if credentials change
        setVerificationStatus('idle');
        setVerificationMessage(null);
    }, [site.wordpressUrl, site.wordpressUsername, site.applicationPassword]);

    return (
        <div className="bg-panel/50 p-6 rounded-2xl border border-border">
            <h2 className="text-xl font-bold text-white">WordPress Connection</h2>
            <p className="text-sm text-text-secondary mt-1">Enter your site details to publish directly. <a href="https://wordpress.org/support/article/application-passwords/" target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:underline">How to get an Application Password.</a></p>
            <div className="space-y-4 mt-6">
                 <div>
                    <label htmlFor="wp-url" className="block text-sm font-medium text-text-primary mb-2">WordPress URL</label>
                    <div className="relative"> <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3"><LinkIcon className="h-5 w-5 text-gray-400"/></div> <input id="wp-url" type="url" value={site.wordpressUrl} onChange={(e) => onSiteUpdate('wordpressUrl', e.target.value)} placeholder="https://your-wordpress-site.com" className="input-base pl-10 pr-4 py-2" /> </div>
                </div>
                <div>
                    <label htmlFor="wp-user" className="block text-sm font-medium text-text-primary mb-2">WordPress Username</label>
                    <div className="relative"> <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3"><UserIcon className="h-5 w-5 text-gray-400"/></div> <input id="wp-user" type="text" value={site.wordpressUsername} onChange={(e) => onSiteUpdate('wordpressUsername', e.target.value)} placeholder="WordPress Username" className="input-base pl-10 pr-4 py-2" /> </div>
                </div>
                <div>
                    <div className="flex items-center gap-2 mb-2">
                        <label htmlFor="app-password" className="block text-sm font-medium text-text-primary">Application Password</label>
                        <div className="group relative" tabIndex={0}>
                            <InfoIcon className="h-4 w-4 text-gray-400 cursor-help"/>
                            <div className="absolute bottom-full right-0 mb-2 w-64 p-3 bg-panel-light text-xs text-text-secondary rounded-lg shadow-lg z-20 border border-border opacity-0 group-hover:opacity-100 group-focus:opacity-100 transition-opacity duration-300 pointer-events-none" role="tooltip">
                                Application Passwords are specific to your WordPress user and allow this app to publish posts securely without your main password. You can create one in your WP Admin under Users &gt; Profile.
                            </div>
                        </div>
                    </div>
                    <div className="relative"> <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3"><KeyIcon className="h-5 w-5 text-gray-400"/></div> <input id="app-password" type="password" value={site.applicationPassword} onChange={(e) => onSiteUpdate('applicationPassword', e.target.value)} placeholder="Application Password" className="input-base pl-10 pr-4 py-2" /> </div>
                </div>
                <div className="pt-4 border-t border-border-subtle">
                    <button onClick={handleTestConnection} disabled={verificationStatus === 'verifying'} className="btn btn-primary w-full sm:w-auto">
                        {verificationStatus === 'verifying' ? 'Verifying...' : 'Test Connection'}
                    </button>
                    {verificationMessage && (
                        <div className={`mt-4 flex items-center gap-3 text-sm p-3 rounded-lg border animate-fade-in ${verificationStatus === 'success' ? 'bg-green-900/20 border-green-500/30 text-green-300' : 'bg-red-900/20 border-red-500/30 text-red-300'}`}>
                            {verificationStatus === 'success' ? <CheckCircleIcon className="h-5 w-5"/> : <ExclamationTriangleIcon className="h-5 w-5"/>}
                            <span>{verificationMessage}</span>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const AuthorSettings: React.FC<{
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    onMultipleSiteUpdates: (updates: Partial<Site>) => void;
}> = ({ site, onSiteUpdate, onMultipleSiteUpdates }) => {
    const [isFetching, setIsFetching] = useState(false);
    const [fetchError, setFetchError] = useState<string | null>(null);

    const handleFetchAuthors = useCallback(async () => {
        if (!site.wordpressUrl || !site.wordpressUsername || !site.applicationPassword) {
            setFetchError("Please fill in and verify your WordPress credentials first.");
            return;
        }
        setIsFetching(true);
        setFetchError(null);
        try {
            const authors = await fetchAuthors({
                url: site.wordpressUrl,
                username: site.wordpressUsername,
                password: site.applicationPassword,
            });
            const updates: Partial<Site> = { availableAuthors: authors };
            // Auto-select the first author if none is selected or the current one is invalid
            if (authors.length > 0 && (!site.authorId || !authors.some(a => a.id === site.authorId))) {
                updates.authorId = authors[0].id;
            }
            onMultipleSiteUpdates(updates);

        } catch (error: any) {
            setFetchError(error.message || "Failed to fetch authors. Your user might not have permission to list other users.");
            onMultipleSiteUpdates({ availableAuthors: [], authorId: undefined }); // Clear list and selection on error
        } finally {
            setIsFetching(false);
        }
    }, [site.wordpressUrl, site.wordpressUsername, site.applicationPassword, site.authorId, onMultipleSiteUpdates]);

    // Fetch authors on mount/credential change if list is empty
    useEffect(() => {
        if (site.wordpressUrl && site.wordpressUsername && site.applicationPassword && (!site.availableAuthors || site.availableAuthors.length === 0)) {
            handleFetchAuthors();
        }
    }, [site.wordpressUrl, site.wordpressUsername, site.applicationPassword, site.availableAuthors, handleFetchAuthors]);

    const showAuthorDropdown = site.availableAuthors && site.availableAuthors.length > 0;

    return (
        <div>
            <h3 className="text-base font-semibold text-text-primary">Post Author</h3>
            <p className="text-sm text-text-secondary">Select the default WordPress author for new posts. The author's bio will be used to enhance E-E-A-T signals.</p>
            <div className="mt-2">
                <div className="flex items-center gap-2">
                    {showAuthorDropdown ? (
                        <select 
                            value={site.authorId || ''} 
                            onChange={(e) => onSiteUpdate('authorId', e.target.value ? parseInt(e.target.value, 10) : undefined)}
                            className="input-base px-3 py-2 flex-grow"
                            disabled={isFetching}
                        >
                            <option value="" disabled>Select an author...</option>
                            {site.availableAuthors?.map(author => (
                                <option key={author.id} value={author.id}>{author.name} {author.bio ? '✓' : '(No bio)'}</option>
                            ))}
                        </select>
                    ) : (
                        <div className="input-base px-3 py-2 flex-grow bg-panel-light text-text-secondary italic text-sm">
                            {isFetching ? 'Fetching authors...' : 'Connect to WP to see authors'}
                        </div>
                    )}
                    <button onClick={handleFetchAuthors} disabled={isFetching} className="btn btn-secondary p-2 flex-shrink-0" title="Refresh author list">
                        {isFetching ? (
                            <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 * 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                        ) : (
                            <ArrowPathIcon className="h-5 w-5"/>
                        )}
                    </button>
                </div>
                {fetchError && !isFetching && (
                    <p className="text-xs text-yellow-400 mt-2">{fetchError}</p>
                )}
            </div>
        </div>
    );
}

const CategorySettings: React.FC<{
    site: Site;
    onSiteUpdate: (field: keyof Site, value: any) => void;
}> = ({ site, onSiteUpdate }) => {
    const [isFetching, setIsFetching] = useState(false);
    const [fetchError, setFetchError] = useState<string | null>(null);

    const handleFetchCategories = useCallback(async () => {
        if (!site.wordpressUrl || !site.wordpressUsername || !site.applicationPassword) {
            setFetchError("Please fill in your WordPress credentials first.");
            return;
        }
        setIsFetching(true);
        setFetchError(null);
        try {
            const categories = await fetchCategories({
                url: site.wordpressUrl,
                username: site.wordpressUsername,
                password: site.applicationPassword,
            });
            onSiteUpdate('availableCategories', categories);
        } catch (error: any) {
            setFetchError(error.message || "Failed to fetch categories.");
            onSiteUpdate('availableCategories', []);
        } finally {
            setIsFetching(false);
        }
    }, [site.wordpressUrl, site.wordpressUsername, site.applicationPassword, onSiteUpdate]);

    useEffect(() => {
        if (site.wordpressUrl && site.wordpressUsername && site.applicationPassword && (!site.availableCategories || site.availableCategories.length === 0)) {
            handleFetchCategories();
        }
    }, [site.wordpressUrl, site.wordpressUsername, site.applicationPassword, site.availableCategories, handleFetchCategories]);

    return (
        <div>
            <div className="flex items-center justify-between">
                <div>
                    <h3 className="text-base font-semibold text-text-primary">Site Categories</h3>
                    <p className="text-sm text-text-secondary">Your existing WordPress categories. The AI will use these to organize new posts.</p>
                </div>
                <button onClick={handleFetchCategories} disabled={isFetching} className="btn btn-secondary p-2 flex-shrink-0" title="Refresh category list">
                    {isFetching ? <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle opacity="25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path opacity="75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : <ArrowPathIcon className="h-5 w-5" />}
                </button>
            </div>
            {fetchError && !isFetching && <p className="text-xs text-yellow-400 mt-2">{fetchError}</p>}
            <div className="mt-3 bg-panel-light border border-border-subtle rounded-lg p-3 max-h-40 overflow-y-auto">
                {site.availableCategories && site.availableCategories.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                        {site.availableCategories.map(cat => (
                            <span key={cat.id} className="bg-gray-700/50 text-text-secondary text-xs font-medium px-2.5 py-1 rounded-full">{cat.name}</span>
                        ))}
                    </div>
                ) : (
                    <p className="text-sm text-text-secondary italic text-center py-2">{isFetching ? 'Loading categories...' : 'No categories found or not connected.'}</p>
                )}
            </div>
        </div>
    );
};

// --- MAIN TAB COMPONENT ---
export const WordPressTab: React.FC<WordPressTabProps> = (props) => {
    return (
        <div className="space-y-8 max-w-4xl mx-auto">
            <ConnectionPanel {...props} />
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-xl font-bold text-white">Publishing Defaults</h2>
                <p className="text-sm text-text-secondary mt-1">Configure default authors and view categories for new posts.</p>
                <div className="mt-6 space-y-6">
                    <AuthorSettings {...props} />
                    <CategorySettings site={props.site} onSiteUpdate={props.onSiteUpdate} />
                </div>
            </div>
        </div>
    );
};