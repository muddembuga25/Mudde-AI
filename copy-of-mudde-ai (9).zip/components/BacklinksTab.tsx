import React, { useState, useCallback } from 'react';
import type { Site, BacklinksHistoryItem, PostHistoryItem, ApiKeys, CommentingProspect, MonitoredBacklink, Site as ClientSite, SocialCommentingProspect, SocialMediaAccount, User } from '../types';
import * as mcpApiService from '../services/mcpApiService';
import { useAuth } from '../contexts/AuthContext';
import { PLAN_LIMITS } from '../constants';
import { PaperAirplaneIcon, InfoIcon, CheckCircleIcon, XCircleIcon, ExclamationTriangleIcon, ChatBubbleLeftRightIcon, LinkIcon, TrashIcon, SparklesIcon, ArrowPathIcon, ChevronDownIcon, XIconSocial } from './Icons';
import type { SocialPlatform } from '../services/oauthService';
import { SubscriptionPlan } from '../types';

interface BacklinksTabProps {
    site: ClientSite;
    currentUser: User;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    setSites: (updater: (prevSites: Site[]) => Site[]) => void;
    onRunBacklinksJob: (siteId: string) => void;
    isBacklinksJobRunning: boolean;
    setError: (error: string | null) => void;
}

const LockedFeature: React.FC<{ title: string; message: string; requiredPlan: string; }> = ({ title, message, requiredPlan }) => (
    <div className="text-center p-8 bg-panel/50 rounded-2xl border-2 border-dashed border-border animate-fade-in">
        <SparklesIcon className="mx-auto h-12 w-12 text-text-secondary" />
        <h3 className="mt-4 text-lg font-medium text-white">{title}</h3>
        <p className="mt-1 text-sm text-text-secondary">{message}</p>
        <div className="mt-4 text-xs font-bold text-yellow-400 bg-yellow-900/50 px-3 py-1.5 rounded-full inline-block">
            Requires {requiredPlan} Plan
        </div>
    </div>
);


const EmailOutreach: React.FC<Omit<BacklinksTabProps, 'setError' | 'setSites'>> = ({ site, onSiteUpdate, onRunBacklinksJob, isBacklinksJobRunning }) => {
    return (
        <div className="space-y-6">
           <LockedFeature title="Coming Soon: Email Outreach" message="This section for automated email outreach campaigns is under development." requiredPlan="Agency" />
        </div>
    );
};

const BlogCommentingAssistant: React.FC<BacklinksTabProps> = ({ site, currentUser, onSiteUpdate, setSites, setError }) => {
    const { incrementCommentingActions } = useAuth();
    const [selectedPostUrl, setSelectedPostUrl] = useState<string | null>(null);
    const [isFindingProspects, setIsFindingProspects] = useState(false);
    const [generatingCommentId, setGeneratingCommentId] = useState<string | null>(null);

    const isCreatorPlan = currentUser.subscription.plan === SubscriptionPlan.CREATOR;
    const commentsUsed = currentUser.subscription.commentingActionsThisMonth || 0;
    const commentLimit = 5;
    const canGenerateComment = !isCreatorPlan || commentsUsed < commentLimit;

    const publishedPosts = (site.history || []).filter(p => 
        p.url && p.url !== '#' && 
        (p.type === 'Keyword' || p.type === 'RSS' || p.type === 'Video' || p.type === 'Google Sheet')
    ).sort((a, b) => b.date - a.date);
    
    const handleFindProspects = useCallback(async () => {
        if (!selectedPostUrl) {
            setError("Please select one of your posts first.");
            return;
        }
        const selectedPost = publishedPosts.find(p => p.url === selectedPostUrl);
        if (!selectedPost) {
            setError("Could not find the selected post.");
            return;
        }

        setIsFindingProspects(true);
        setError(null);
        try {
            const { prospects, updatedSite } = await mcpApiService.findCommentingProspects(selectedPost.topic, site.id);
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
            
            const newProspects: CommentingProspect[] = prospects.map((p: any) => ({
                id: crypto.randomUUID(), prospectUrl: p.url, prospectTitle: p.title, prospectDescription: p.description, status: 'found', sourcePostUrl: selectedPost.url,
            }));

            onSiteUpdate('commentingProspects', [...(site.commentingProspects || []), ...newProspects]);

        } catch (error: any) {
            setError(error.message);
        } finally {
            setIsFindingProspects(false);
        }
    }, [selectedPostUrl, publishedPosts, site.id, site.commentingProspects, onSiteUpdate, setSites, setError]);

    const handleGenerateComment = async (prospect: CommentingProspect) => {
        if (!canGenerateComment) {
            setError(`You have reached your monthly limit of ${commentLimit} AI-generated comments.`);
            return;
        }

        const selectedPost = publishedPosts.find(p => p.url === prospect.sourcePostUrl);
        if (!selectedPost) {
            setError("Source post for this prospect could not be found.");
            return;
        }
        setGeneratingCommentId(prospect.id);
        setError(null);
        try {
            const { comment, updatedSite } = await mcpApiService.generateBlogComment(prospect.prospectUrl, selectedPost.topic, site.id);
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));

            const updatedProspects = (site.commentingProspects || []).map(p => 
                p.id === prospect.id ? { ...p, status: 'comment_generated' as const, generatedComment: comment } : p
            );
            onSiteUpdate('commentingProspects', updatedProspects);
            if (isCreatorPlan) {
                incrementCommentingActions();
            }
        } catch (error: any) {
            setError(error.message);
        } finally {
            setGeneratingCommentId(null);
        }
    };
    
    const handleUpdateProspectStatus = (prospectId: string, status: CommentingProspect['status']) => {
        const updatedProspects = (site.commentingProspects || []).map(p => 
            p.id === prospectId ? { ...p, status } : p
        );
        onSiteUpdate('commentingProspects', updatedProspects);
    };

     const handleUpdateCommentText = (prospectId: string, newText: string) => {
        const updatedProspects = (site.commentingProspects || []).map(p => 
            p.id === prospectId ? { ...p, generatedComment: newText } : p
        );
        onSiteUpdate('commentingProspects', updatedProspects);
    };
    
    const handleClearProspects = () => {
        onSiteUpdate('commentingProspects', []);
    };
    
    const prospects = site.commentingProspects || [];

    return (
        <div className="space-y-6">
            {isCreatorPlan && (
                <div className="bg-purple-900/30 border border-purple-500/50 p-4 rounded-lg text-center text-sm text-purple-200">
                    You have used <span className="font-bold text-white">{commentsUsed} of {commentLimit}</span> AI comments this month. Upgrade to Pro for unlimited usage.
                </div>
            )}
            <div className="bg-panel/50 p-6 rounded-2xl border border-border space-y-4">
                <h3 className="text-xl font-bold text-white">1. Select Your Post</h3>
                <p className="text-sm text-text-secondary">Choose one of your published blog posts to provide context for the comments.</p>
                <select value={selectedPostUrl || ''} onChange={e => setSelectedPostUrl(e.target.value)} className="input-base w-full max-w-lg">
                    <option value="" disabled>Select a post...</option>
                    {publishedPosts.map(p => <option key={p.id} value={p.url}>{p.topic}</option>)}
                </select>
            </div>

            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h3 className="text-xl font-bold text-white">2. Find Prospects & Generate Comments</h3>
                <div className="mt-4 flex flex-col sm:flex-row gap-4">
                    <button onClick={handleFindProspects} disabled={!selectedPostUrl || isFindingProspects} className="btn btn-primary w-full sm:w-auto disabled:opacity-50 disabled:cursor-wait">
                        {isFindingProspects ? 'Finding...' : 'Find Prospect Blogs'}
                    </button>
                    <button onClick={handleClearProspects} disabled={prospects.length === 0} className="btn btn-secondary w-full sm:w-auto disabled:opacity-50">Clear List</button>
                </div>
                <div className="mt-6 space-y-4">
                    {isFindingProspects && prospects.length === 0 && <p className="text-text-secondary text-center py-4">Searching for relevant blogs...</p>}
                    {!isFindingProspects && prospects.length === 0 && <p className="text-text-secondary text-center py-4">No prospects found yet. Click "Find Prospect Blogs" to start.</p>}
                    {prospects.map(prospect => (
                        <div key={prospect.id} className="bg-panel p-4 rounded-lg border border-border-subtle">
                             <div className="flex justify-between items-start gap-4">
                                <div className="flex-1">
                                    <a href={prospect.prospectUrl} target="_blank" rel="noopener noreferrer" className="font-semibold text-purple-300 hover:underline">{prospect.prospectTitle}</a>
                                    <p className="text-xs text-text-secondary break-all">{prospect.prospectUrl}</p>
                                    <p className="text-sm text-text-secondary mt-2">{prospect.prospectDescription}</p>
                                </div>
                                <div className="flex-shrink-0">
                                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${prospect.status === 'found' ? 'bg-blue-900/50 text-blue-300' : 'bg-green-900/50 text-green-300'}`}>
                                        {prospect.status.replace('_', ' ')}
                                    </span>
                                </div>
                            </div>
                            {prospect.status === 'found' && (
                                <div className="mt-4 border-t border-border-subtle pt-4">
                                    <button onClick={() => handleGenerateComment(prospect)} disabled={generatingCommentId === prospect.id || !canGenerateComment} className="btn btn-secondary text-sm w-full disabled:opacity-50">
                                        {generatingCommentId === prospect.id ? 'Generating...' : 'Generate Comment'}
                                    </button>
                                </div>
                            )}
                            {prospect.status === 'comment_generated' && prospect.generatedComment && (
                                <div className="mt-4 border-t border-border-subtle pt-4 space-y-3 animate-fade-in">
                                    <textarea 
                                        value={prospect.generatedComment}
                                        onChange={(e) => handleUpdateCommentText(prospect.id, e.target.value)}
                                        className="input-base w-full text-sm" 
                                        rows={5}
                                    />
                                    <div className="flex gap-2">
                                        <button onClick={() => handleUpdateProspectStatus(prospect.id, 'commented')} className="btn btn-primary text-xs flex-grow">Mark as Commented</button>
                                        <button onClick={() => handleGenerateComment(prospect)} disabled={generatingCommentId === prospect.id || !canGenerateComment} className="btn btn-secondary text-xs p-2 disabled:opacity-50" title="Regenerate">
                                            <ArrowPathIcon className={`h-4 w-4 ${generatingCommentId === prospect.id ? 'animate-spin' : ''}`} />
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

const BacklinkMonitoring: React.FC<BacklinksTabProps> = ({ site, onSiteUpdate, setError, setSites }) => {
    const [newLinkUrl, setNewLinkUrl] = useState('');
    const [newTargetUrl, setNewTargetUrl] = useState('');
    const [checkingLinkId, setCheckingLinkId] = useState<string | null>(null);

    const handleAddLink = () => {
        if (!newLinkUrl.trim() || !newTargetUrl.trim()) {
            setError("Both the backlink URL and your target URL are required.");
            return;
        }
        const newLink: MonitoredBacklink = {
            id: crypto.randomUUID(), url: newLinkUrl, targetUrl: newTargetUrl, status: 'pending', anchorText: null, dateFound: Date.now(), lastChecked: null, domainAuthority: null,
        };
        onSiteUpdate('monitoredBacklinks', [...(site.monitoredBacklinks || []), newLink]);
        setNewLinkUrl('');
        setNewTargetUrl('');
    };
    
    const handleRemoveLink = (id: string) => {
        onSiteUpdate('monitoredBacklinks', (site.monitoredBacklinks || []).filter(link => link.id !== id));
    };

    const handleCheckLink = async (link: MonitoredBacklink) => {
        setCheckingLinkId(link.id);
        setError(null);
        try {
            const { updatedSite } = await mcpApiService.checkBacklinkStatus(site.id, link);
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
        } catch(e: any) {
            setError(e.message);
        } finally {
            setCheckingLinkId(null);
        }
    };
    
    const statusInfo: Record<MonitoredBacklink['status'], { text: string; color: string; icon: React.FC<any> }> = {
        active: { text: 'Active', color: 'text-green-400', icon: CheckCircleIcon },
        inactive: { text: 'Inactive', color: 'text-yellow-400', icon: ExclamationTriangleIcon },
        not_found: { text: 'Not Found', color: 'text-red-400', icon: XCircleIcon },
        pending: { text: 'Pending', color: 'text-text-secondary', icon: InfoIcon },
    };

    return (
        <div className="space-y-6">
            <div className="bg-panel/50 p-6 rounded-2xl border border-border space-y-4">
                <h3 className="text-xl font-bold text-white">Add a Backlink to Monitor</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-text-primary mb-2">Backlink URL</label>
                        <input type="url" value={newLinkUrl} onChange={e => setNewLinkUrl(e.target.value)} placeholder="https://othersite.com/their-post" className="input-base" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-text-primary mb-2">Your Target URL</label>
                        <input type="url" value={newTargetUrl} onChange={e => setNewTargetUrl(e.target.value)} placeholder="https://yoursite.com/your-post" className="input-base" />
                    </div>
                </div>
                <button onClick={handleAddLink} className="btn btn-primary w-full md:w-auto">Add & Monitor Link</button>
            </div>
            
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                 <h3 className="text-xl font-bold text-white">Monitored Links</h3>
                 <div className="mt-4 flow-root">
                     <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                         <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
                            <table className="min-w-full divide-y divide-border">
                                <thead>
                                    <tr>
                                        <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-white sm:pl-0">Status</th>
                                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-white">Backlink</th>
                                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-white">Anchor Text</th>
                                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-white">Last Checked</th>
                                        <th scope="col" className="relative py-3.5 pl-3 pr-4 sm:pr-0"><span className="sr-only">Actions</span></th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-border-subtle">
                                    {(site.monitoredBacklinks || []).map(link => {
                                        const StatusIcon = statusInfo[link.status].icon;
                                        return (
                                            <tr key={link.id}>
                                                <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium sm:pl-0">
                                                    <div className={`flex items-center gap-2 ${statusInfo[link.status].color}`}>
                                                        <StatusIcon className="h-5 w-5" /> {statusInfo[link.status].text}
                                                    </div>
                                                </td>
                                                <td className="whitespace-nowrap px-3 py-4 text-sm text-text-secondary max-w-xs truncate" title={link.url}>{link.url}</td>
                                                <td className="whitespace-nowrap px-3 py-4 text-sm text-text-secondary max-w-xs truncate" title={link.anchorText || ''}>{link.anchorText || 'N/A'}</td>
                                                <td className="whitespace-nowrap px-3 py-4 text-sm text-text-secondary">{link.lastChecked ? new Date(link.lastChecked).toLocaleString() : 'Never'}</td>
                                                <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-0">
                                                    <div className="flex items-center justify-end gap-2">
                                                        <button onClick={() => handleCheckLink(link)} disabled={checkingLinkId === link.id} className="p-1.5 text-purple-400 hover:text-purple-300 disabled:opacity-50" title="Check Now">
                                                           <ArrowPathIcon className={`h-4 w-4 ${checkingLinkId === link.id ? 'animate-spin' : ''}`} />
                                                        </button>
                                                        <button onClick={() => handleRemoveLink(link.id)} className="p-1.5 text-red-500 hover:text-red-400" title="Remove">
                                                           <TrashIcon className="h-4 w-4" />
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                             {(site.monitoredBacklinks || []).length === 0 && (
                                <p className="text-center py-8 text-text-secondary">No backlinks are being monitored yet.</p>
                             )}
                         </div>
                     </div>
                 </div>
            </div>
        </div>
    );
};

const SocialCommentingAssistant: React.FC<BacklinksTabProps> = ({ site, onSiteUpdate, setSites, setError }) => {
    const [selectedPostUrl, setSelectedPostUrl] = useState<string | null>(null);
    const [isFindingProspects, setIsFindingProspects] = useState(false);
    const [generatingCommentId, setGeneratingCommentId] = useState<string | null>(null);
    const [postingCommentId, setPostingCommentId] = useState<string | null>(null);

    const publishedPosts = (site.history || []).filter(p => p.url && p.url !== '#').sort((a, b) => b.date - a.date);
    
    const allConnectedAccounts = Object.entries(site.socialMediaSettings)
        .flatMap(([platform, accounts]) => 
            (accounts as SocialMediaAccount[]).filter(acc => acc.isConnected).map(acc => ({...acc, platform: platform as SocialPlatform}))
        );

    const handleFindProspects = useCallback(async () => {
        setIsFindingProspects(true);
        setError(null);
        try {
            const { prospects, updatedSite } = await mcpApiService.findSocialMediaProspects(site.id);
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
            
            const newProspects: SocialCommentingProspect[] = prospects.map((p: any) => ({
                id: crypto.randomUUID(),
                platform: p.platform.toLowerCase() as any,
                prospectPostUrl: p.url,
                prospectPostAuthor: p.author,
                prospectPostContent: p.content,
                status: 'found',
                sourcePostUrl: selectedPostUrl || '', // Can be empty if no post is selected
                postingAccountId: '', // User needs to select this
                postingAccountName: '',
            }));

            onSiteUpdate('socialCommentingProspects', [...(site.socialCommentingProspects || []), ...newProspects]);

        } catch (error: any) {
            setError(error.message);
        } finally {
            setIsFindingProspects(false);
        }
    }, [selectedPostUrl, site.id, site.socialCommentingProspects, onSiteUpdate, setSites, setError]);
    
    const handleGenerateComment = async (prospect: SocialCommentingProspect) => {
        const sourcePost = publishedPosts.find(p => p.url === prospect.sourcePostUrl);
        if (prospect.sourcePostUrl && !sourcePost) {
            setError("Context post for this prospect could not be found. Please select it again.");
            return;
        }
        setGeneratingCommentId(prospect.id);
        setError(null);
        try {
            const { comment, updatedSite } = await mcpApiService.generateSocialMediaComment(site.id, prospect, sourcePost!);
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
            handleUpdateProspect(prospect.id, { generatedComment: comment, status: 'comment_generated' });
        } catch (error: any) {
            setError(error.message);
        } finally {
            setGeneratingCommentId(null);
        }
    };
    
    const handlePostComment = async (prospect: SocialCommentingProspect) => {
        if (!prospect.postingAccountId) {
            setError("Please select an account to post from.");
            return;
        }
        setPostingCommentId(prospect.id);
        setError(null);
        try {
            const { updatedSite } = await mcpApiService.postSocialMediaComment(site.id, prospect);
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
        } catch (error: any) {
            setError(error.message);
        } finally {
            setPostingCommentId(null);
        }
    }
    
    const handleUpdateProspect = (prospectId: string, updates: Partial<SocialCommentingProspect>) => {
        const updatedProspects = (site.socialCommentingProspects || []).map(p => 
            p.id === prospectId ? { ...p, ...updates } : p
        );
        onSiteUpdate('socialCommentingProspects', updatedProspects);
    };

    const handleDiscardProspect = (prospectId: string) => {
        onSiteUpdate('socialCommentingProspects', (site.socialCommentingProspects || []).filter(p => p.id !== prospectId));
    };

    const prospects = site.socialCommentingProspects || [];

    return (
        <div className="space-y-6">
            <div className="bg-panel/50 p-6 rounded-2xl border border-border space-y-4">
                <h3 className="text-xl font-bold text-white">Configuration</h3>
                <div>
                    <label className="block text-sm font-medium text-text-primary mb-2">Monitoring Keywords/Hashtags</label>
                    <textarea value={site.socialCommentingKeywords || ''} onChange={(e) => onSiteUpdate('socialCommentingKeywords', e.target.value)} className="input-base" rows={3} placeholder="Enter keywords or #hashtags, one per line"/>
                </div>
                <div>
                    <label className="block text-sm font-medium text-text-primary mb-2">Commenting Guidelines</label>
                    <textarea value={site.socialCommentingGuideline || ''} onChange={(e) => onSiteUpdate('socialCommentingGuideline', e.target.value)} className="input-base" rows={4} placeholder="e.g., Be positive, ask a question..."/>
                </div>
                <div>
                    <label className="block text-sm font-medium text-text-primary mb-2">Context Post (Optional)</label>
                    <p className="text-xs text-text-secondary mb-2">Select one of your posts to give the AI context for writing comments.</p>
                    <select value={selectedPostUrl || ''} onChange={e => setSelectedPostUrl(e.target.value)} className="input-base w-full">
                        <option value="">No context post</option>
                        {publishedPosts.map(p => <option key={p.id} value={p.url}>{p.topic}</option>)}
                    </select>
                </div>
            </div>
             <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h3 className="text-xl font-bold text-white">Prospects</h3>
                <div className="mt-4 flex flex-col sm:flex-row gap-4">
                    <button onClick={handleFindProspects} disabled={isFindingProspects} className="btn btn-primary w-full sm:w-auto disabled:opacity-50 disabled:cursor-wait">
                        {isFindingProspects ? 'Finding...' : 'Find Social Posts'}
                    </button>
                    <button onClick={() => onSiteUpdate('socialCommentingProspects', [])} disabled={prospects.length === 0} className="btn btn-secondary w-full sm:w-auto disabled:opacity-50">Clear List</button>
                </div>
                <div className="mt-6 space-y-4">
                    {prospects.map(prospect => (
                        <div key={prospect.id} className="bg-panel p-4 rounded-lg border border-border-subtle">
                             <div className="flex justify-between items-start gap-4">
                                <div className="flex-1 min-w-0">
                                    <p className="font-semibold text-text-primary">@{prospect.prospectPostAuthor} on <span className="capitalize">{prospect.platform}</span></p>
                                    <a href={prospect.prospectPostUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-purple-400 hover:underline break-all">{prospect.prospectPostUrl}</a>
                                    <p className="text-sm text-text-secondary mt-2 bg-panel-light p-3 rounded-md border border-border-subtle whitespace-pre-wrap">{prospect.prospectPostContent}</p>
                                </div>
                                <div className="flex-shrink-0">
                                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${prospect.status === 'found' ? 'bg-blue-900/50 text-blue-300' : prospect.status === 'posted' ? 'bg-green-900/50 text-green-300' : 'bg-purple-900/50 text-purple-300'}`}>
                                        {prospect.status.replace('_', ' ')}
                                    </span>
                                </div>
                            </div>
                            {prospect.status === 'found' && (
                                <div className="mt-4 border-t border-border-subtle pt-4">
                                    <button onClick={() => handleGenerateComment(prospect)} disabled={generatingCommentId === prospect.id} className="btn btn-secondary text-sm w-full">
                                        {generatingCommentId === prospect.id ? 'Generating...' : 'Generate Comment'}
                                    </button>
                                </div>
                            )}
                            {prospect.status === 'comment_generated' && (
                                <div className="mt-4 border-t border-border-subtle pt-4 space-y-3 animate-fade-in">
                                    <textarea value={prospect.generatedComment || ''} onChange={(e) => handleUpdateProspect(prospect.id, { generatedComment: e.target.value })} className="input-base w-full text-sm" rows={4}/>
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
                                        <select value={prospect.postingAccountId} onChange={(e) => handleUpdateProspect(prospect.id, { postingAccountId: e.target.value, postingAccountName: allConnectedAccounts.find(a=>a.id === e.target.value)?.name || '' })} className="input-base text-sm">
                                            <option value="">Select account to post from...</option>
                                            {allConnectedAccounts.map(acc => <option key={acc.id} value={acc.id}>@{acc.name} ({acc.platform})</option>)}
                                        </select>
                                        <div className="flex gap-2">
                                            <button onClick={() => handlePostComment(prospect)} disabled={postingCommentId === prospect.id} className="btn btn-primary text-xs flex-grow">{postingCommentId === prospect.id ? 'Posting...' : 'Approve & Post'}</button>
                                            <button onClick={() => handleGenerateComment(prospect)} disabled={generatingCommentId === prospect.id} className="btn btn-secondary text-xs p-2" title="Regenerate"><ArrowPathIcon className={`h-4 w-4 ${generatingCommentId === prospect.id ? 'animate-spin' : ''}`} /></button>
                                            <button onClick={() => handleDiscardProspect(prospect.id)} className="btn btn-secondary text-xs p-2" title="Discard"><TrashIcon className="h-4 w-4 text-red-400" /></button>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};


export const BacklinksTab: React.FC<BacklinksTabProps> = (props) => {
    const [activeView, setActiveView] = useState<'blogCommenting' | 'socialCommenting' | 'monitoring' | 'outreach'>('blogCommenting');
    const { currentUser } = useAuth();
    if (!currentUser) return null;

    const planFeatures = PLAN_LIMITS[currentUser.subscription.plan].features;
    
    const TabButton: React.FC<{ view: typeof activeView; label: string; icon: React.FC<any> }> = ({ view, label, icon: Icon }) => (
        <button onClick={() => setActiveView(view)} className={`${activeView === view ? 'bg-purple-600 text-white shadow-sm' : 'text-text-secondary hover:bg-gray-700/50'} px-4 py-2 text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2`}>
            <Icon className="h-5 w-5" /> {label}
        </button>
    );

    return (
        <div className="space-y-8 max-w-4xl mx-auto">
             <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-2xl font-bold text-white">Backlinks & Authority Building</h2>
                <p className="text-text-secondary mt-1">Tools to help you build your site's reputation and SEO authority.</p>
            </div>
            
            <div className="bg-panel/50 p-2 rounded-xl border border-border">
                 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 bg-panel-light rounded-lg p-1 w-full">
                    <TabButton view="blogCommenting" label="Blog Commenting" icon={ChatBubbleLeftRightIcon} />
                    <TabButton view="socialCommenting" label="Social Commenting" icon={SparklesIcon} />
                    <TabButton view="monitoring" label="Backlink Monitoring" icon={LinkIcon} />
                    <TabButton view="outreach" label="Email Outreach" icon={PaperAirplaneIcon} />
                </div>
            </div>
            
            <div className="animate-fade-in">
                {activeView === 'outreach' && (planFeatures.backlinksOutreach ? <EmailOutreach {...props} /> : <LockedFeature title="Email Outreach Automation" message="This feature is exclusive to the Agency plan." requiredPlan="Agency" />)}
                {activeView === 'blogCommenting' && (planFeatures.backlinksCommenting ? <BlogCommentingAssistant {...props} /> : <LockedFeature title="Blog Commenting Assistant" message="This feature is available on the Pro and Agency plans." requiredPlan="Pro+" />)}
                {activeView === 'socialCommenting' && (planFeatures.backlinksCommenting ? <SocialCommentingAssistant {...props} /> : <LockedFeature title="Social Commenting Assistant" message="This feature is available on the Pro and Agency plans." requiredPlan="Pro+" />)}
                {activeView === 'monitoring' && (planFeatures.backlinksMonitoring ? <BacklinkMonitoring {...props} /> : <LockedFeature title="Backlink Monitoring" message="This feature is available on the Pro and Agency plans." requiredPlan="Pro+" />)}
            </div>
        </div>
    );
}