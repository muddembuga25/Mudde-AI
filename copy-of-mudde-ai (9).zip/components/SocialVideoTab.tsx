import React, { useState, useCallback, useEffect } from 'react';
import type { Site, PostHistoryItem, Site as ClientSite } from '../types';
import { SubscriptionPlan } from '../types';
import * as mcpApiService from '../services/mcpApiService';
import { useAuth } from '../contexts/AuthContext';
import { PLAN_LIMITS } from '../constants';
import { SparklesIcon, VideoCameraIcon, ArchiveBoxIcon, LightbulbIcon, PaperAirplaneIcon } from './Icons';

interface SocialVideoTabProps {
    site: ClientSite;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    setSites: (updater: (prevSites: Site[]) => Site[]) => void;
    setError: (error: string | null) => void;
    addLog: (message: string, type: 'SUCCESS' | 'ERROR' | 'INFO', siteId: string) => void;
}

interface GenerationResult {
    videoUrl: string;
    caption: string;
}

const LockedFeature: React.FC<{ title: string; message: string; requiredPlan: string; }> = ({ title, message, requiredPlan }) => (
    <div className="text-center p-8 bg-panel/50 rounded-2xl border-2 border-dashed border-border animate-fade-in max-w-lg mx-auto">
        <SparklesIcon className="mx-auto h-12 w-12 text-text-secondary" />
        <h3 className="mt-4 text-lg font-medium text-white">{title}</h3>
        <p className="mt-1 text-sm text-text-secondary">{message}</p>
        <div className="mt-4 text-xs font-bold text-yellow-400 bg-yellow-900/50 px-3 py-1.5 rounded-full inline-block">
            Requires {requiredPlan} Plan
        </div>
    </div>
);


export const SocialVideoTab: React.FC<SocialVideoTabProps> = ({ site, onSiteUpdate, setSites, setError, addLog }) => {
    const { currentUser, useFeatureCredit } = useAuth();
    const [prompt, setPrompt] = useState('');
    const [isSuggestingPrompt, setIsSuggestingPrompt] = useState(false);
    const [selectedCharacterId, setSelectedCharacterId] = useState<string>('');
    const [result, setResult] = useState<GenerationResult | { error: string } | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [isPublishing, setIsPublishing] = useState(false);

    const handleSuggestPrompt = useCallback(async () => {
        // Re-use brainstorming for a similar content type
        setIsSuggestingPrompt(true);
        setError(null);
        try {
            const { ideas, updatedSite } = await mcpApiService.brainstormContentIdeas(site.id, 'short-form video', 'social_graphic');
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
            if (ideas.length > 0) {
                setPrompt(ideas[0]);
            }
        } catch (error: any) {
            setError(error.message || "Failed to suggest a prompt.");
        } finally {
            setIsSuggestingPrompt(false);
        }
    }, [site.id, setSites, setError]);
    
    useEffect(() => { 
        if (!prompt) {
            handleSuggestPrompt();
        }
    }, [handleSuggestPrompt, prompt]);
    
    const handleGenerate = async () => {
        if (!prompt.trim()) {
            setError("Please provide a prompt.");
            return;
        }
        setIsLoading(true);
        setResult(null);
        setError(null);

        try {
            const { generationResult, updatedSite } = await mcpApiService.generateSocialVideoAndCaption(site.id, prompt, selectedCharacterId || undefined);
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
            setResult({ videoUrl: generationResult.videoUrl, caption: generationResult.caption });
            
            if (currentUser?.subscription.plan === SubscriptionPlan.CREATOR) {
                useFeatureCredit('socialVideo');
            }

        } catch (error: any) {
            setResult({ error: error.message || 'Generation failed.' });
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleSaveToHistory = () => {
        if (!result || !('videoUrl' in result)) return;
        
        const newHistoryItem: PostHistoryItem = {
            id: crypto.randomUUID(), topic: `Social Video: "${prompt.substring(0, 50)}..."`, url: '#', date: Date.now(), type: 'Social Video', 
            socialVideos: { custom: { videoUrl: result.videoUrl, caption: result.caption } },
        };
        onSiteUpdate('history', [newHistoryItem, ...site.history]);
        handleDiscard();
    };
    
    const handleDiscard = () => {
        setResult(null);
        setPrompt('');
        handleSuggestPrompt();
    };

    if (!currentUser) return null;
    const planFeatures = PLAN_LIMITS[currentUser.subscription.plan].features;
    if (!planFeatures.socialVideo && currentUser.subscription.plan !== SubscriptionPlan.CREATOR) {
        return <LockedFeature title="Social Video Generator" message="This feature is available on the Pro plan and above." requiredPlan="Pro+" />;
    }

    const videoCredits = currentUser.subscription.featureCredits?.socialVideo || 0;
    const canGenerate = planFeatures.socialVideo || (currentUser.subscription.plan === SubscriptionPlan.CREATOR && videoCredits > 0);

    return (
        <div className="w-full max-w-5xl mx-auto space-y-8">
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-2xl font-bold text-white">Social Video Generator</h2>
                <p className="text-text-secondary mt-1">Create and publish a one-off short-form video for social media.</p>
            </div>
             {currentUser.subscription.plan === SubscriptionPlan.CREATOR && (
                <div className="bg-purple-900/30 border border-purple-500/50 p-4 rounded-lg text-center text-sm text-purple-200">
                    You have <span className="font-bold text-white">{videoCredits}</span> free Pro feature credit(s) to generate a social video.
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* --- CONTROL PANEL --- */}
                <div className="bg-panel/50 p-6 rounded-2xl border border-border space-y-6">
                     <div>
                        <div className="flex justify-between items-center mb-2">
                            <label className="text-sm font-medium text-text-primary">1. Write a Prompt</label>
                            <button onClick={handleSuggestPrompt} disabled={isSuggestingPrompt || isLoading} className="btn text-xs px-3 py-1.5 flex items-center justify-center gap-1.5 bg-teal-600/80 hover:bg-teal-500 text-white shadow-lg shadow-teal-900/50">
                                <LightbulbIcon title="Suggest Prompt" className="h-4 w-4" /> Suggest
                            </button>
                        </div>
                        <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="e.g., A cinematic shot of a coffee cup..." className="input-base w-full p-4 text-sm" rows={4} />
                    </div>

                    <div>
                        <label htmlFor="char-ref-video" className="text-sm font-medium text-text-primary mb-2">2. Character Reference (Optional)</label>
                        <select id="char-ref-video" value={selectedCharacterId} onChange={e => setSelectedCharacterId(e.target.value)} className="input-base w-full">
                            <option value="">None</option>
                            {(site.characterLibrary || []).map(char => <option key={char.id} value={char.id}>{char.name}</option>)}
                        </select>
                    </div>
                    
                    <button onClick={handleGenerate} disabled={isLoading || isPublishing || !prompt.trim() || !canGenerate} className="w-full btn btn-primary text-base flex items-center justify-center gap-3 disabled:opacity-50">
                       {isLoading ? 'Generating...' : <><VideoCameraIcon /> 3. Generate Video</>}
                    </button>
                     {!canGenerate && currentUser.subscription.plan === SubscriptionPlan.CREATOR && (
                        <div className="text-center text-xs text-yellow-300 p-2 bg-yellow-900/30 rounded-md">You've used your free credit. Upgrade to Pro for unlimited video generation.</div>
                     )}
                </div>

                {/* --- RESULT PANEL --- */}
                <div className="bg-panel/50 p-4 rounded-2xl border border-border space-y-3 flex flex-col">
                    <div className="flex-grow aspect-w-9 aspect-h-16 bg-panel-light rounded-lg flex items-center justify-center border border-border-subtle overflow-hidden">
                       {isLoading ? <div className="text-center"><p className="text-sm text-text-secondary mt-2">Video generation can take a few minutes...</p></div>
                       : result && 'videoUrl' in result ? <video src={result.videoUrl} controls autoPlay muted loop className="w-full h-full object-cover" />
                       : result && 'error' in result ? <div className="p-4 text-center text-red-400">{result.error}</div>
                       : <VideoCameraIcon className="h-12 w-12 text-text-secondary/50" />}
                    </div>
                    <div>
                        <label className="text-xs font-medium text-text-primary mb-1">Caption</label>
                        <textarea readOnly value={result && 'caption' in result ? result.caption : ''} className="input-base w-full p-2 text-sm" rows={3} />
                    </div>
                    {result && !('error' in result) && (
                         <div className="flex flex-col sm:flex-row items-center gap-3 animate-fade-in">
                            <button onClick={handleSaveToHistory} disabled={isPublishing} className="w-full btn btn-secondary text-sm flex items-center justify-center gap-2"><ArchiveBoxIcon className="h-4 w-4" /> Save to History</button>
                            <button onClick={() => {}} disabled={true} className="w-full btn btn-primary text-sm flex items-center justify-center gap-2 opacity-50 cursor-not-allowed">
                                <PaperAirplaneIcon className="h-4 w-4" /> Publish Now (Coming Soon)
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};