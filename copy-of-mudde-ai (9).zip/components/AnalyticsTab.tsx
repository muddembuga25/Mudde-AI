import React, { useState, useCallback } from 'react';
import type { Site, PostPerformanceData, AnalyticsInsight, User } from '../types';
import * as mcpApiService from '../services/mcpApiService';
import { useAuth } from '../contexts/AuthContext';
import { PLAN_LIMITS } from '../constants';
import { SubscriptionPlan } from '../types';
import { GoogleIcon, ChartBarIcon, SparklesIcon, XIcon, LightbulbIcon } from './Icons';

interface AnalyticsTabProps {
    site: Site;
    currentUser: User;
    performanceData: PostPerformanceData[] | undefined;
    isFetching: boolean;
    onConnect: () => void;
    onDisconnect: () => void;
    setError: (error: string | null) => void;
    logApiUsage: (provider: any, cost: number) => void;
}

const StatCard: React.FC<{ title: string; value: string; }> = ({ title, value }) => (
    <div className="bg-panel p-4 rounded-lg border border-border-subtle">
        <p className="text-sm text-text-secondary font-medium">{title}</p>
        <p className="text-3xl font-extrabold text-white mt-1">{value}</p>
    </div>
);

const InsightsModal: React.FC<{ 
    isOpen: boolean; 
    onClose: () => void; 
    post: PostPerformanceData;
    insights: AnalyticsInsight | null;
    isLoading: boolean;
    currentUser: User;
}> = ({ isOpen, onClose, post, insights, isLoading, currentUser }) => {
    if (!isOpen) return null;
    const isPro = currentUser.subscription.plan === SubscriptionPlan.PRO || currentUser.subscription.plan === SubscriptionPlan.AGENCY;

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-panel rounded-2xl shadow-2xl w-full max-w-2xl border border-border animate-modal-pop max-h-[90vh] flex flex-col">
                <header className="p-4 border-b border-border flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <SparklesIcon className="h-6 w-6 text-purple-400" />
                        <div>
                            <h2 className="text-xl font-bold text-white">AI Insights</h2>
                            <p className="text-sm text-text-secondary truncate max-w-md" title={post.title}>For: "{post.title}"</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-1 rounded-full text-text-secondary hover:bg-panel-light hover:text-white transition-colors">
                        <XIcon className="h-6 w-6" />
                    </button>
                </header>
                <div className="p-6 overflow-y-auto">
                    {isLoading && (
                        <div className="text-center py-12">
                            <svg className="animate-spin h-8 w-8 text-purple-400 mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle opacity="25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path opacity="75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                            <p className="mt-4 text-text-secondary">Analyzing performance data...</p>
                        </div>
                    )}
                    {insights && (
                        <div className="space-y-6 animate-fade-in">
                            <div>
                                <h3 className="text-lg font-semibold text-purple-300 mb-2">Key Insights</h3>
                                <ul className="space-y-2 list-disc list-inside text-text-primary">
                                    {insights.insights.map((insight, i) => <li key={i}>{insight}</li>)}
                                </ul>
                            </div>
                            <div className="relative">
                                <h3 className="text-lg font-semibold text-green-300 mb-2">Recommendations</h3>
                                <ul className="space-y-2 list-disc list-inside text-text-primary">
                                    {insights.recommendations.map((rec, i) => (
                                      <li key={i} className={rec.pro && !isPro ? 'blur-sm opacity-60 pointer-events-none' : ''}>
                                        {rec.text} {rec.pro && <span className="text-xs font-bold text-yellow-400 bg-yellow-900/50 px-2 py-0.5 rounded-full ml-2">PRO</span>}
                                      </li>
                                    ))}
                                </ul>
                                {!isPro && (
                                     <div className="absolute inset-0 bg-gradient-to-t from-panel/90 to-transparent flex items-end justify-center p-4">
                                        <div className="text-center bg-purple-900/50 p-4 rounded-lg border border-purple-500/50">
                                            <SparklesIcon className="h-6 w-6 mx-auto text-purple-300" />
                                            <p className="text-sm font-semibold text-white mt-2">Unlock Pro Recommendations</p>
                                            <p className="text-xs text-text-secondary mt-1">Upgrade to get advanced strategic advice.</p>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const LockedFeature: React.FC<{ title: string; message: string; requiredPlan: string; }> = ({ title, message, requiredPlan }) => (
    <div className="text-center p-8 bg-panel/50 rounded-2xl border-2 border-dashed border-border animate-fade-in max-w-lg mx-auto">
        <SparklesIcon className="mx-auto h-12 w-12 text-text-secondary" />
        <h3 className="mt-4 text-lg font-medium text-white">{title}</h3>
        <p className="mt-1 text-sm text-text-secondary">{message}</p>
        <div className="mt-4 text-xs font-bold text-yellow-400 bg-yellow-900/50 px-3 py-1.5 rounded-full inline-block">
            Requires {requiredPlan} Plan
        </div>
    </div>
);

export const AnalyticsTab: React.FC<AnalyticsTabProps> = ({ site, currentUser, performanceData, isFetching, onConnect, onDisconnect, setError, logApiUsage }) => {
    const planFeatures = PLAN_LIMITS[currentUser.subscription.plan].features;

    const [selectedPostForInsight, setSelectedPostForInsight] = useState<PostPerformanceData | null>(null);
    const [insights, setInsights] = useState<AnalyticsInsight | null>(null);
    const [isFetchingInsights, setIsFetchingInsights] = useState(false);

    const handleGetInsights = useCallback(async (post: PostPerformanceData) => {
        setSelectedPostForInsight(post);
        setIsFetchingInsights(true);
        setError(null);
        try {
            const { insights, updatedSite } = await mcpApiService.generateAnalyticsInsights(site.id, post);
            setInsights(insights);
            logApiUsage('google', 0.0003); // Placeholder cost
        } catch (e: any) {
            setError(e.message);
            setSelectedPostForInsight(null); // Close modal on error
        } finally {
            setIsFetchingInsights(false);
        }
    }, [site.id, setError, logApiUsage]);

    const totalClicks = performanceData?.reduce((sum, p) => sum + p.searchConsole.clicks, 0) || 0;
    const totalImpressions = performanceData?.reduce((sum, p) => sum + p.searchConsole.impressions, 0) || 0;
    const avgPosition = performanceData && performanceData.length > 0
        ? performanceData.reduce((sum, p) => sum + p.searchConsole.position, 0) / performanceData.length
        : 0;
    
    if (!planFeatures.viewAnalytics) {
        return <LockedFeature title="Analytics Dashboard" message="This feature is available on the Creator plan and above." requiredPlan="Creator+" />;
    }

    if (!site.googleAnalytics?.isConnected) {
        return (
            <div className="text-center p-8 bg-panel/50 rounded-2xl border-2 border-dashed border-border animate-fade-in max-w-lg mx-auto">
                <ChartBarIcon className="mx-auto h-12 w-12 text-text-secondary" />
                <h3 className="mt-4 text-lg font-medium text-white">Connect Your Google Account</h3>
                <p className="mt-1 text-sm text-text-secondary">Get performance data and AI-powered insights by connecting your Google Search Console and Google Analytics accounts.</p>
                <button onClick={onConnect} className="mt-6 btn btn-primary flex items-center justify-center gap-2 mx-auto">
                    <GoogleIcon className="h-5 w-5" />
                    Connect Google Account
                </button>
            </div>
        );
    }
    
    return (
        <div className="space-y-8 max-w-7xl mx-auto">
             <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                    <div>
                        <h2 className="text-2xl font-bold text-white">Analytics Dashboard</h2>
                        <p className="text-text-secondary mt-1">Review your content's performance and get AI-driven advice.</p>
                    </div>
                    <div className="flex items-center gap-3">
                         <span className="text-sm text-green-400 flex items-center gap-2"><GoogleIcon className="h-4 w-4" /> Connected as {site.googleAnalytics.userEmail}</span>
                         <button onClick={onDisconnect} className="btn btn-secondary text-xs">Disconnect</button>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard title="Total Clicks (30d)" value={totalClicks.toLocaleString()} />
                <StatCard title="Total Impressions (30d)" value={totalImpressions.toLocaleString()} />
                <StatCard title="Avg. Position" value={avgPosition.toFixed(1)} />
            </div>
            
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                 <h3 className="text-xl font-bold text-white">Content Performance</h3>
                 <div className="mt-4 flow-root">
                     <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                         <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
                            <table className="min-w-full divide-y divide-border">
                                <thead>
                                    <tr>
                                        <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-white sm:pl-0">Post</th>
                                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-white">Clicks</th>
                                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-white">Impressions</th>
                                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-white">CTR</th>
                                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-white">Position</th>
                                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-white">Pageviews</th>
                                        <th scope="col" className="relative py-3.5 pl-3 pr-4 sm:pr-0"><span className="sr-only">Actions</span></th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-border-subtle">
                                    {isFetching && (
                                        <tr><td colSpan={7} className="text-center py-8 text-text-secondary">Loading performance data...</td></tr>
                                    )}
                                    {!isFetching && performanceData && performanceData.length === 0 && (
                                        <tr><td colSpan={7} className="text-center py-8 text-text-secondary">No published posts with performance data found.</td></tr>
                                    )}
                                    {performanceData?.map(post => (
                                        <tr key={post.postId}>
                                            <td className="py-4 pl-4 pr-3 text-sm sm:pl-0 max-w-xs">
                                                <div className="font-medium text-text-primary truncate" title={post.title}>{post.title}</div>
                                                <a href={post.url} target="_blank" rel="noopener noreferrer" className="text-text-secondary hover:text-purple-400 truncate">{post.url.replace(/^https?:\/\//, '')}</a>
                                            </td>
                                            <td className="whitespace-nowrap px-3 py-4 text-sm text-text-secondary font-semibold">{post.searchConsole.clicks.toLocaleString()}</td>
                                            <td className="whitespace-nowrap px-3 py-4 text-sm text-text-secondary">{post.searchConsole.impressions.toLocaleString()}</td>
                                            <td className="whitespace-nowrap px-3 py-4 text-sm text-text-secondary">{(post.searchConsole.ctr * 100).toFixed(2)}%</td>
                                            <td className="whitespace-nowrap px-3 py-4 text-sm text-text-secondary">{post.searchConsole.position.toFixed(1)}</td>
                                            <td className="whitespace-nowrap px-3 py-4 text-sm text-text-secondary">{post.analytics.pageviews.toLocaleString()}</td>
                                            <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-0">
                                                <button onClick={() => handleGetInsights(post)} className="btn btn-secondary text-xs flex items-center gap-1.5">
                                                   <LightbulbIcon className="h-4 w-4" /> Get AI Insights
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                         </div>
                     </div>
                 </div>
            </div>
            
            <InsightsModal 
                isOpen={!!selectedPostForInsight}
                onClose={() => setSelectedPostForInsight(null)}
                post={selectedPostForInsight!}
                insights={insights}
                isLoading={isFetchingInsights}
                currentUser={currentUser}
            />
        </div>
    );
};