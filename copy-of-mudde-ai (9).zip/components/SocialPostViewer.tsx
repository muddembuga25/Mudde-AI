import React, { useState, useEffect, useRef } from 'react';
import type { PostHistoryItem } from '../types';
import { XIconSocial, FacebookIcon, LinkedInIcon, InstagramIcon, PinterestIcon, PhotoIcon } from './Icons';

const platformDetails: Record<string, { name: string, icon: React.FC<any> }> = {
    twitter: { name: 'X (Twitter)', icon: XIconSocial },
    facebook: { name: 'Facebook', icon: FacebookIcon },
    linkedin: { name: 'LinkedIn', icon: LinkedInIcon },
    instagram: { name: 'Instagram', icon: InstagramIcon },
    pinterest: { name: 'Pinterest', icon: PinterestIcon },
    custom: { name: 'Custom Graphic', icon: PhotoIcon }
};

export const HistoryDetailViewer: React.FC<{ post: PostHistoryItem }> = ({ post }) => {
    
    if (post.type === 'Social Graphic') {
        const availablePlatforms = post.socialGraphics ? Object.keys(post.socialGraphics) : [];
        const [activePlatform, setActivePlatform] = useState(availablePlatforms[0] || null);

        if (!activePlatform || !post.socialGraphics) {
            return <div><h3 className="text-lg font-bold text-white mb-2">Social Graphic Details</h3><p className="text-text-secondary">No graphics found for this entry.</p></div>
        }
        
        const currentGraphic = post.socialGraphics[activePlatform];

        return (
            <div>
                <h3 className="text-2xl font-bold text-white mb-2 truncate" title={post.topic}>{post.topic}</h3>
                <div className="my-6">
                    <div className="border-b border-border">
                        <nav className="-mb-px flex space-x-4 overflow-x-auto" aria-label="Tabs">
                            {availablePlatforms.map(platformKey => {
                                const platform = platformDetails[platformKey] || { name: platformKey.charAt(0).toUpperCase() + platformKey.slice(1), icon: PhotoIcon };
                                const Icon = platform.icon;
                                return (
                                <button key={platformKey} onClick={() => setActivePlatform(platformKey)} className={`${ activePlatform === platformKey ? 'border-purple-500 text-purple-400' : 'border-transparent text-text-secondary hover:text-text-primary hover:border-gray-500' } flex items-center gap-2 whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors`}>
                                    <Icon className="h-5 w-5" /> {platform.name}
                                </button>
                                )}
                            )}
                        </nav>
                    </div>
                </div>

                {currentGraphic && (
                <div className="mt-4 space-y-6 animate-fade-in">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                        <div>
                            <img src={currentGraphic.imageUrl} alt={`Generated graphic for ${post.topic} on ${activePlatform}`} className="w-full rounded-lg border border-border shadow-lg" />
                        </div>
                        <div>
                            <label className="text-sm font-semibold text-text-primary">Generated Caption</label>
                            <textarea readOnly value={currentGraphic.caption} className="input-base w-full p-3 text-sm leading-relaxed bg-panel mt-2" rows={10} />
                        </div>
                    </div>
                </div>
                )}
            </div>
        );
    }
    
    // --- Existing logic for Blog Post types ---
    const [activePlatform, setActivePlatform] = useState('twitter');
    const socialPlatforms = [
      { id: 'twitter', name: 'X (Twitter)', icon: XIconSocial },
      { id: 'facebook', name: 'Facebook', icon: FacebookIcon },
      { id: 'linkedin', name: 'LinkedIn', icon: LinkedInIcon },
      { id: 'instagram', name: 'Instagram', icon: InstagramIcon },
      { id: 'pinterest', name: 'Pinterest', icon: PinterestIcon },
    ];
    const [copySuccess, setCopySuccess] = useState(false);
    const copyTimeoutRef = useRef<number | null>(null);

    const handleCopy = (text: string) => {
        navigator.clipboard.writeText(text);
        setCopySuccess(true);
        if(copyTimeoutRef.current) clearTimeout(copyTimeoutRef.current);
        copyTimeoutRef.current = window.setTimeout(() => setCopySuccess(false), 2000);
    };

    useEffect(() => {
        if (post.socialMediaPosts && Object.keys(post.socialMediaPosts).length > 0) {
            const firstAvailable = socialPlatforms.find(p => post.socialMediaPosts![p.id]);
            if (firstAvailable) { setActivePlatform(firstAvailable.id); }
        }
        return () => { if(copyTimeoutRef.current) clearTimeout(copyTimeoutRef.current) };
    }, [post]);

    if (!post.socialMediaPosts || Object.keys(post.socialMediaPosts).length === 0) {
        return (
            <div>
                <h3 className="text-lg font-bold text-white mb-2 truncate">Social Posts for: "{post.topic}"</h3>
                <p className="text-text-secondary">No social media posts were generated for this article. This may be because no social platforms were enabled for automation at the time of publishing.</p>
            </div>
        );
    }
    
    const currentPost = post.socialMediaPosts[activePlatform];

    return (
        <div>
            <h3 className="text-2xl font-bold text-white mb-1 truncate">{post.topic}</h3>
            <a href={post.url} target="_blank" rel="noopener noreferrer" className="text-sm text-purple-400 hover:underline break-all">{post.url}</a>
            <div className="my-6">
                <div className="border-b border-border">
                    <nav className="-mb-px flex space-x-4 overflow-x-auto" aria-label="Tabs">
                        {socialPlatforms.map(p => post.socialMediaPosts![p.id] && (
                            <button key={p.id} onClick={() => setActivePlatform(p.id)} className={`${ activePlatform === p.id ? 'border-purple-500 text-purple-400' : 'border-transparent text-text-secondary hover:text-text-primary hover:border-gray-500' } flex items-center gap-2 whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors`}>
                                <p.icon className="h-5 w-5" /> {p.name}
                            </button>
                        ))}
                    </nav>
                </div>
            </div>
            {currentPost ? (
                <div className="animate-fade-in space-y-4">
                    <div>
                        <div className="flex justify-between items-center mb-2">
                            <label className="text-sm font-semibold text-text-primary">Generated Post</label>
                             <button onClick={() => handleCopy(currentPost.content)} className={`btn text-xs px-3 py-1.5 ${copySuccess ? 'bg-green-600 hover:bg-green-500 border-green-500' : 'btn-secondary'}`}> {copySuccess ? 'Copied!' : 'Copy Content'} </button>
                        </div>
                        <textarea readOnly value={currentPost.content} className="input-base w-full p-3 text-sm leading-relaxed bg-panel" rows={8} />
                    </div>
                    <div>
                        <label className="text-sm font-semibold text-text-primary">Suggested Hashtags</label>
                        <div className="mt-2 flex flex-wrap gap-2">
                            {currentPost.hashtags.map(tag => ( <span key={tag} className="bg-gray-700/50 border border-border text-text-secondary text-sm font-medium px-3 py-1 rounded-full">{tag}</span> ))}
                        </div>
                    </div>
                </div>
            ) : <p className="text-text-secondary">No content generated for this platform.</p>}
        </div>
    );
};