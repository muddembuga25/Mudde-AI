import React, { useState, useEffect, useRef } from 'react';
import type { PostHistoryItem } from '../types';
import { XIconSocial, FacebookIcon, LinkedInIcon, InstagramIcon, PinterestIcon, PhotoIcon, VideoCameraIcon, MailIcon } from './Icons';

const platformDetails: Record<string, { name: string, icon: React.FC<any> }> = {
    twitter: { name: 'X (Twitter)', icon: XIconSocial },
    facebook: { name: 'Facebook', icon: FacebookIcon },
    linkedin: { name: 'LinkedIn', icon: LinkedInIcon },
    instagram: { name: 'Instagram', icon: InstagramIcon },
    pinterest: { name: 'Pinterest', icon: PinterestIcon },
    custom: { name: 'Custom Graphic', icon: PhotoIcon }
};

export const HistoryDetailViewer: React.FC<{ post: PostHistoryItem }> = ({ post }) => {
    
    if (post.type === 'Email Marketing' || post.type === 'Email Digest') {
        if (!post.emailCampaign) {
            return <div><h3 className="text-lg font-bold text-white mb-2">Email Campaign Details</h3><p className="text-text-secondary">No campaign data found for this entry.</p></div>
        }
        return (
             <div>
                <h3 className="text-2xl font-bold text-white mb-2 truncate" title={post.topic}>{post.topic}</h3>
                 <div className="mt-4 space-y-4 animate-fade-in">
                    <div>
                        <label className="text-sm font-semibold text-text-primary">Subject</label>
                        <input readOnly value={post.emailCampaign.subject} className="input-base w-full p-2 text-sm bg-panel mt-2" />
                    </div>
                     <div>
                        <label className="text-sm font-semibold text-text-primary">HTML Body</label>
                        <textarea readOnly value={post.emailCampaign.body} className="input-base w-full p-3 text-sm leading-relaxed bg-panel mt-2" rows={12} />
                    </div>
                </div>
            </div>
        )
    }

    if (post.type === 'Social Graphic' || post.type === 'Social Video') {
        const isVideo = post.type === 'Social Video';
        const assets = isVideo ? post.socialVideos : post.socialGraphics;
        const availablePlatforms = assets ? Object.keys(assets) : [];
        const [activePlatform, setActivePlatform] = useState(availablePlatforms[0] || null);

        if (!activePlatform || !assets) {
            return <div><h3 className="text-lg font-bold text-white mb-2">{isVideo ? "Social Video" : "Social Graphic"} Details</h3><p className="text-text-secondary">No assets found for this entry.</p></div>
        }
        
        const currentAsset = assets[activePlatform];

        return (
            <div>
                <h3 className="text-2xl font-bold text-white mb-2 truncate" title={post.topic}>{post.topic}</h3>
                <div className="my-6">
                    <div className="border-b border-border">
                        <nav className="-mb-px flex space-x-4 overflow-x-auto" aria-label="Tabs">
                            {availablePlatforms.map(platformKey => {
                                const platform = platformDetails[platformKey] || { name: platformKey.charAt(0).toUpperCase() + platformKey.slice(1), icon: isVideo ? VideoCameraIcon : PhotoIcon };
                                const Icon = platform.icon;
                                return (
                                <button key={platformKey} onClick={() => setActivePlatform(platformKey)} className={`${ activePlatform === platformKey ? 'border-purple-500 text-purple-400' : 'border-transparent text-text-secondary hover:text-text-primary hover:border-gray-500' } flex items-center gap-2 whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors`}>
                                    <Icon className="h-5 w-5" /> {platform.name}
                                </button>
                                )}
                            )}
                        </nav>
                    </div>
                </div>

                {currentAsset && (
                <div className="mt-4 space-y-6 animate-fade-in">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                        <div>
                            {isVideo ? (
                                <video controls src={(currentAsset as any).videoUrl} className="w-full rounded-lg border border-border shadow-lg bg-black" />
                            ) : (
                                <img src={(currentAsset as any).imageUrl} alt={`Generated asset for ${post.topic} on ${activePlatform}`} className="w-full rounded-lg border border-border shadow-lg" />
                            )}
                        </div>
                        <div>
                            <label className="text-sm font-semibold text-text-primary">Generated Caption</label>
                            <textarea readOnly value={currentAsset.caption} className="input-base w-full p-3 text-sm leading-relaxed bg-panel mt-2" rows={10} />
                        </div>
                    </div>
                </div>
                )}
            </div>
        );
    }
    
    // --- Logic for Blog Post types with potential social and email follow-ups ---
    const initialPlatforms = [
        { id: 'twitter', name: 'X (Twitter)', icon: XIconSocial },
        { id: 'facebook', name: 'Facebook', icon: FacebookIcon },
        { id: 'linkedin', name: 'LinkedIn', icon: LinkedInIcon },
        { id: 'instagram', name: 'Instagram', icon: InstagramIcon },
        { id: 'pinterest', name: 'Pinterest', icon: PinterestIcon },
    ];

    if (post.emailCampaign) {
        initialPlatforms.push({ id: 'email', name: 'Email Campaign', icon: MailIcon });
    }

    const availablePlatforms = initialPlatforms.filter(p => 
        (p.id === 'email' && post.emailCampaign) || (post.socialMediaPosts && post.socialMediaPosts[p.id])
    );
    
    const [activePlatform, setActivePlatform] = useState(availablePlatforms.length > 0 ? availablePlatforms[0].id : '');

    const [copySuccess, setCopySuccess] = useState(false);
    const copyTimeoutRef = useRef<number | null>(null);

    const handleCopy = (text: string) => {
        navigator.clipboard.writeText(text);
        setCopySuccess(true);
        if(copyTimeoutRef.current) clearTimeout(copyTimeoutRef.current);
        copyTimeoutRef.current = window.setTimeout(() => setCopySuccess(false), 2000);
    };

    useEffect(() => {
        return () => { if(copyTimeoutRef.current) clearTimeout(copyTimeoutRef.current) };
    }, []);

    if (!post.socialMediaPosts && !post.emailCampaign) {
        return (
            <div>
                <h3 className="text-lg font-bold text-white mb-2 truncate">Details for: "{post.topic}"</h3>
                <p className="text-text-secondary">No social media posts or email campaigns were generated for this article.</p>
            </div>
        );
    }
    
    const currentPost = post.socialMediaPosts?.[activePlatform];

    return (
        <div>
            <h3 className="text-2xl font-bold text-white mb-1 truncate">{post.topic}</h3>
            <a href={post.url} target="_blank" rel="noopener noreferrer" className="text-sm text-purple-400 hover:underline break-all">{post.url}</a>
            <div className="my-6">
                <div className="border-b border-border">
                    <nav className="-mb-px flex space-x-4 overflow-x-auto" aria-label="Tabs">
                        {availablePlatforms.map(p => (
                            <button key={p.id} onClick={() => setActivePlatform(p.id)} className={`${ activePlatform === p.id ? 'border-purple-500 text-purple-400' : 'border-transparent text-text-secondary hover:text-text-primary hover:border-gray-500' } flex items-center gap-2 whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors`}>
                                <p.icon className="h-5 w-5" /> {p.name}
                            </button>
                        ))}
                    </nav>
                </div>
            </div>

            {activePlatform === 'email' && post.emailCampaign ? (
                <div className="animate-fade-in space-y-4">
                    <div>
                        <label className="text-sm font-semibold text-text-primary">Subject</label>
                        <input readOnly value={post.emailCampaign.subject} className="input-base w-full p-2 text-sm bg-panel mt-2" />
                    </div>
                    <div>
                        <label className="text-sm font-semibold text-text-primary">HTML Body</label>
                        <textarea readOnly value={post.emailCampaign.body} className="input-base w-full p-3 text-sm leading-relaxed bg-panel mt-2" rows={12} />
                    </div>
                </div>
            ) : currentPost ? (
                <div className="animate-fade-in space-y-4">
                    <div>
                        <div className="flex justify-between items-center mb-2">
                            <label className="text-sm font-semibold text-text-primary">Generated Post</label>
                             <button onClick={() => handleCopy(currentPost.content)} className={`btn text-xs px-3 py-1.5 ${copySuccess ? 'bg-green-600 hover:bg-green-500 border-green-500' : 'btn-secondary'}`}> {copySuccess ? 'Copied!' : 'Copy Content'} </button>
                        </div>
                        <textarea readOnly value={currentPost.content} className="input-base w-full p-3 text-sm leading-relaxed bg-panel" rows={8} />
                    </div>
                    <div>
                        <label className="text-sm font-semibold text-text-primary">Suggested Hashtags</label>
                        <div className="mt-2 flex flex-wrap gap-2">
                            {currentPost.hashtags.map(tag => ( <span key={tag} className="bg-gray-700/50 border border-border text-text-secondary text-sm font-medium px-3 py-1 rounded-full">{tag}</span> ))}
                        </div>
                    </div>
                </div>
            ) : <p className="text-text-secondary">No content generated for this platform.</p>}
        </div>
    );
};