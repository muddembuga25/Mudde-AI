import React, { useState, useCallback, useMemo, useEffect } from 'react';
import type { Site, RssItem, VideoSource, Site as ClientSite } from '../types';
import * as aiService from '../services/aiService';
import { fetchAndParseRssFeed } from '../services/rssService';
import * as googleSheetsService from '../services/googleSheetsService';
import type { GoogleSheetRow } from '../services/googleSheetsService';
import { ExclamationTriangleIcon, LinkIcon, LightbulbIcon, TrashIcon, DocumentTextIcon, RssIcon, VideoCameraIcon, GoogleSheetsIcon, ArrowUpTrayIcon, XIcon } from './Icons';

interface GenerateTabProps {
    site: ClientSite;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    setSites: (updater: (prevSites: Site[]) => Site[]) => void;
    onGenerateAndScore: (topicToTrack: string, generationSource: 'keyword' | 'rss' | 'video' | 'google_sheet' | 'ai_assistant', sourceDetails: RssItem | string | GoogleSheetRow, site: ClientSite, options?: {sourceId?: string, videoItem?: RssItem}) => Promise<void>;
    setActiveTab: (tab: string) => void;
    setError: (error: string | null) => void;
    
    // Props for fetched data cache
    rssFeed: RssItem[] | null;
    setRssFeed: (items: RssItem[] | null) => void;
    isFetchingRss: boolean;
    setIsFetchingRss: (isFetching: boolean) => void;

    sheetData: GoogleSheetRow[] | null;
    setSheetData: (data: GoogleSheetRow[] | null) => void;
    isFetchingSheet: boolean;
    setIsFetchingSheet: (isFetching: boolean) => void;

    channelVideos: Record<string, RssItem[]>;
    setChannelVideos: (updater: (prev: Record<string, RssItem[]>) => Record<string, RssItem[]>) => void;
    isFetchingChannel: string | null;
    setIsFetchingChannel: (sourceId: string | null) => void;
}

export const GenerateTab: React.FC<GenerateTabProps> = ({ 
    site, onSiteUpdate, setSites, onGenerateAndScore, setActiveTab, setError,
    rssFeed, setRssFeed, isFetchingRss, setIsFetchingRss,
    sheetData, setSheetData, isFetchingSheet, setIsFetchingSheet,
    channelVideos, setChannelVideos, isFetchingChannel, setIsFetchingChannel
}) => {
    const [manualGenerationSource, setManualGenerationSource] = useState<'keyword' | 'rss' | 'video' | 'google_sheet'>('keyword');
    const [isSuggestingKeywords, setIsSuggestingKeywords] = useState(false);
    const [isSuggestUrlModalOpen, setIsSuggestUrlModalOpen] = useState(false);
    const [suggestUrlInput, setSuggestUrlInput] = useState('');
    const [isSuggestingFromUrl, setIsSuggestingFromUrl] = useState(false);
    const [isClearKeywordsModalOpen, setIsClearKeywordsModalOpen] = useState(false);
    const [videoSourceUrl, setVideoSourceUrl] = useState('');
    const [isAddingVideoSource, setIsAddingVideoSource] = useState(false);
    
    const handleSuggestFromUrl = useCallback(async () => {
        if (!suggestUrlInput.trim()) return;
        setIsSuggestingFromUrl(true);
        setError(null);
        try {
          const { suggestions, updatedSite } = await aiService.suggestKeywordsFromUrl(suggestUrlInput, site.keywordList, site.id);
          setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
          const newKeywords = suggestions.join('\n');
          onSiteUpdate('keywordList', site.keywordList.trim() ? `${site.keywordList.trim()}\n${newKeywords}` : newKeywords);
          setSuggestUrlInput('');
          setIsSuggestUrlModalOpen(false);
        } catch (error: any) {
          setError(error.message || 'An unknown error occurred while suggesting keywords from URL.');
        } finally {
          setIsSuggestingFromUrl(false);
        }
    }, [site, suggestUrlInput, onSiteUpdate, setSites, setError]);

    const handleSuggestKeywords = useCallback(async () => {
        setIsSuggestingKeywords(true);
        setError(null);
        try {
            const { suggestions, updatedSite } = await aiService.suggestKeywords(site.keywordList, site.id);
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
            const newKeywords = suggestions.join('\n');
            onSiteUpdate('keywordList', site.keywordList.trim() ? `${site.keywordList.trim()}\n${newKeywords}` : newKeywords);
        } catch (error: any) {
            setError(error.message || 'An unknown error occurred while suggesting keywords.');
        } finally {
            setIsSuggestingKeywords(false);
        }
    }, [site, onSiteUpdate, setSites, setError]);

    const handleClearKeywords = () => {
        onSiteUpdate('keywordList', '');
        setIsClearKeywordsModalOpen(false);
    };

    const handleFetchRss = useCallback(async () => {
        if (!site.rssFeedUrl) return;
        setIsFetchingRss(true);
        setError(null);
        try {
            const { items } = await fetchAndParseRssFeed(site.rssFeedUrl);
            setRssFeed(items);
        } catch (error: any) {
            setError(error.message || 'Failed to fetch or parse RSS feed.');
        } finally {
            setIsFetchingRss(false);
        }
    }, [site.rssFeedUrl, setRssFeed, setIsFetchingRss, setError]);

    const handleFetchSheet = useCallback(async () => {
        if (!site.googleSheetUrl) return;
        setIsFetchingSheet(true);
        setError(null);
        try {
            const data = await googleSheetsService.fetchGoogleSheetData(site);
            setSheetData(data);
        } catch (error: any) {
            setError(error.message || 'Failed to fetch Google Sheet data.');
        } finally {
            setIsFetchingSheet(false);
        }
    }, [site, setSheetData, setIsFetchingSheet, setError]);
    
    // --- VIDEO SOURCE MANAGEMENT ---
    const handleAddVideoSource = useCallback(async () => {
        if (!videoSourceUrl.trim()) return;
        setIsAddingVideoSource(true);
        setError(null);
        try {
            const { title } = await fetchAndParseRssFeed(videoSourceUrl); // Use RSS parser to validate and get name
            const newSource: VideoSource = {
                id: crypto.randomUUID(), url: videoSourceUrl, type: 'channel', // Assuming channel for now
                name: title || videoSourceUrl, processedVideoGuids: [],
            };
            onSiteUpdate('videoSources', [...(site.videoSources || []), newSource]);
            setVideoSourceUrl('');
        } catch (e) {
            // If RSS fails, it might be a single video URL
            const newSource: VideoSource = {
                id: crypto.randomUUID(), url: videoSourceUrl, type: 'video', name: videoSourceUrl, processedVideoGuids: [],
            };
            onSiteUpdate('videoSources', [...(site.videoSources || []), newSource]);
            setVideoSourceUrl('');
        } finally {
            setIsAddingVideoSource(false);
        }
    }, [videoSourceUrl, site.videoSources, onSiteUpdate, setError]);

    const handleDeleteVideoSource = (id: string) => {
        onSiteUpdate('videoSources', site.videoSources.filter(s => s.id !== id));
    };

    const handleFetchChannelVideos = useCallback(async (source: VideoSource) => {
        setIsFetchingChannel(source.id);
        setError(null);
        try {
            const { items } = await fetchAndParseRssFeed(source.url);
            setChannelVideos(prev => ({ ...prev, [source.id]: items }));
        } catch (error: any) {
            setError(error.message || 'Failed to fetch videos for this channel.');
        } finally {
            setIsFetchingChannel(null);
        }
    }, [setChannelVideos, setIsFetchingChannel, setError]);

    const TabButton: React.FC<{ source: 'keyword' | 'rss' | 'video' | 'google_sheet'; label: string; icon: React.FC<any> }> = ({ source, label, icon: Icon }) => (
        <button onClick={() => setManualGenerationSource(source)} className={`px-4 py-3 text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${manualGenerationSource === source ? 'bg-purple-600 text-white shadow-sm' : 'text-text-secondary hover:bg-gray-700/50'}`}>
            <Icon className="h-5 w-5" /> {label}
        </button>
    );

    const keywords = useMemo(() => site.keywordList.split('\n').filter(k => k.trim()), [site.keywordList]);
    const unprocessedRssItems = useMemo(() => rssFeed?.filter(item => !site.processedRssGuids.includes(item.guid)) || [], [rssFeed, site.processedRssGuids]);
    const unprocessedSheetRows = useMemo(() => sheetData?.filter(row => !site.googleSheetProcessedRows.includes(row.rowIndex)) || [], [sheetData, site.googleSheetProcessedRows]);
    
    return (
        <div className="max-w-4xl mx-auto space-y-8">
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-2xl font-bold text-white">Generate Content</h2>
                <p className="text-text-secondary mt-1">Choose your source and generate a new SEO-optimized blog post.</p>
            </div>
            
            <div className="bg-panel/50 p-2 rounded-xl border border-border">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 bg-panel-light rounded-lg p-1 w-full">
                    <TabButton source="keyword" label="Keyword List" icon={DocumentTextIcon} />
                    <TabButton source="rss" label="RSS Feed" icon={RssIcon} />
                    <TabButton source="video" label="Video" icon={VideoCameraIcon} />
                    <TabButton source="google_sheet" label="Google Sheet" icon={GoogleSheetsIcon} />
                </div>
            </div>

            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                {manualGenerationSource === 'keyword' && (
                    <div className="animate-fade-in space-y-4">
                        <h3 className="text-xl font-bold text-white">Keyword List</h3>
                        <p className="text-sm text-text-secondary">Enter one keyword or topic per line. The AI will write an article for the first available keyword.</p>
                        <textarea value={site.keywordList} onChange={(e) => onSiteUpdate('keywordList', e.target.value)} placeholder="e.g., best espresso machines 2024" className="input-base text-sm leading-relaxed" rows={8}></textarea>
                        <div className="flex flex-wrap gap-3">
                            <button onClick={handleSuggestKeywords} disabled={isSuggestingKeywords} className="btn bg-teal-600 hover:bg-teal-500 text-white shadow-lg shadow-teal-900/50 flex items-center gap-2"><LightbulbIcon className="h-4 w-4" /> Suggest Keywords</button>
                            <button onClick={() => setIsSuggestUrlModalOpen(true)} className="btn btn-secondary flex items-center gap-2"><LinkIcon className="h-4 w-4" /> Suggest from URL</button>
                            <button onClick={() => setIsClearKeywordsModalOpen(true)} className="btn btn-secondary flex items-center gap-2" disabled={!site.keywordList.trim()}><TrashIcon className="h-4 w-4" /> Clear All</button>
                        </div>
                        <div className="space-y-2 pt-4 border-t border-border-subtle">
                            {keywords.map((keyword, i) => {
                                const isDone = keyword.trim().startsWith('[DONE]');
                                const topic = isDone ? keyword.replace('[DONE]', '').trim() : keyword;
                                return (
                                    <div key={i} className={`flex items-center justify-between p-2 rounded-md ${isDone ? 'bg-green-900/20' : 'bg-panel'}`}>
                                        <span className={`text-sm ${isDone ? 'text-gray-500 line-through' : 'text-text-primary'}`}>{topic}</span>
                                        <button onClick={() => onGenerateAndScore(topic, 'keyword', topic, site)} disabled={isDone} className="btn btn-primary text-xs px-3 py-1.5 disabled:opacity-40 disabled:cursor-not-allowed">Generate</button>
                                    </div>
                                )
                            })}
                        </div>
                    </div>
                )}

                {manualGenerationSource === 'rss' && (
                    <div className="animate-fade-in space-y-4">
                        <h3 className="text-xl font-bold text-white">RSS Feed</h3>
                        <p className="text-sm text-text-secondary">Provide an RSS feed URL. The app will fetch the latest items for you to generate content from.</p>
                        <div className="flex items-center gap-2">
                            <input type="url" value={site.rssFeedUrl} onChange={(e) => onSiteUpdate('rssFeedUrl', e.target.value)} placeholder="Enter RSS feed URL" className="input-base flex-grow" />
                            <button onClick={handleFetchRss} disabled={isFetchingRss || !site.rssFeedUrl} className="btn btn-primary">
                                {isFetchingRss ? 'Fetching...' : 'Fetch Feed'}
                            </button>
                        </div>
                        <div className="space-y-2 pt-4 border-t border-border-subtle">
                            {isFetchingRss && <p className="text-text-secondary text-center">Fetching RSS items...</p>}
                            {!isFetchingRss && unprocessedRssItems.length === 0 && (
                                <p className="text-text-secondary text-center">
                                    {rssFeed ? 'All items from this feed have been processed.' : 'Fetch a feed to see available items.'}
                                </p>
                            )}
                            {unprocessedRssItems.map((item) => (
                                <div key={item.guid} className="flex items-center justify-between p-2 rounded-md bg-panel">
                                    <div>
                                        <p className="text-sm font-medium text-text-primary">{item.title}</p>
                                        <p className="text-xs text-text-secondary">{item.contentSnippet}</p>
                                    </div>
                                    <button onClick={() => onGenerateAndScore(item.title, 'rss', item, site)} className="btn btn-primary text-xs px-3 py-1.5 flex-shrink-0">
                                        Generate
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {manualGenerationSource === 'video' && (
                    <div className="animate-fade-in space-y-4">
                        <h3 className="text-xl font-bold text-white">Video Sources</h3>
                        <p className="text-sm text-text-secondary">Add YouTube channel URLs or individual video URLs as a source for content ideas.</p>
                        <div className="flex items-center gap-2">
                            <input type="url" value={videoSourceUrl} onChange={e => setVideoSourceUrl(e.target.value)} placeholder="Enter YouTube channel or video URL" className="input-base flex-grow" />
                            <button onClick={handleAddVideoSource} disabled={isAddingVideoSource || !videoSourceUrl.trim()} className="btn btn-primary">
                                {isAddingVideoSource ? 'Adding...' : 'Add Source'}
                            </button>
                        </div>
                        <div className="space-y-3 pt-4 border-t border-border-subtle">
                             {(!site.videoSources || site.videoSources.length === 0) && (
                                <p className="text-text-secondary text-center py-4">No video sources added yet.</p>
                            )}
                            {(site.videoSources || []).map(source => (
                                <div key={source.id} className="bg-panel p-3 rounded-lg border border-border-subtle">
                                    <div className="flex items-center justify-between">
                                        <p className="font-medium text-text-primary truncate">{source.name}</p>
                                        <button onClick={() => handleDeleteVideoSource(source.id)} className="text-red-500 hover:text-red-400"><TrashIcon className="h-4 w-4" /></button>
                                    </div>
                                    {source.type === 'channel' && (
                                        <button onClick={() => handleFetchChannelVideos(source)} disabled={isFetchingChannel === source.id} className="btn btn-secondary text-xs mt-2">
                                            {isFetchingChannel === source.id ? 'Fetching...' : 'Fetch Videos'}
                                        </button>
                                    )}
                                    {source.type === 'video' && (
                                        <button onClick={() => onGenerateAndScore(source.name, 'video', source.url, site, { sourceId: source.id })} className="btn btn-primary text-xs mt-2">Generate from Video</button>
                                    )}
                                    {isFetchingChannel === source.id && <p className="text-xs text-text-secondary mt-2">Fetching videos...</p>}
                                    {channelVideos[source.id] && (
                                        <div className="mt-3 pt-3 border-t border-border-subtle space-y-2">
                                            {channelVideos[source.id].filter(video => !source.processedVideoGuids.includes(video.guid)).map(videoItem => (
                                                <div key={videoItem.guid} className="flex items-center justify-between p-2 rounded-md bg-panel-light">
                                                    <p className="text-sm text-text-primary truncate">{videoItem.title}</p>
                                                    <button onClick={() => onGenerateAndScore(videoItem.title, 'video', videoItem.link, site, { sourceId: source.id, videoItem })} className="btn btn-primary text-xs px-3 py-1.5 flex-shrink-0">Generate</button>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            
                {manualGenerationSource === 'google_sheet' && (
                    <div className="animate-fade-in space-y-4">
                        <h3 className="text-xl font-bold text-white">Google Sheet</h3>
                        <p className="text-sm text-text-secondary">Connect a public Google Sheet. The AI will use the first column as the topic. Ensure your Google API Key is set in the API Keys tab.</p>
                        <div className="flex items-center gap-2">
                            <input type="url" value={site.googleSheetUrl} onChange={(e) => onSiteUpdate('googleSheetUrl', e.target.value)} placeholder="Enter public Google Sheet URL" className="input-base flex-grow" />
                            <button onClick={handleFetchSheet} disabled={isFetchingSheet || !site.googleSheetUrl || !site.apiKeys.google} className="btn btn-primary disabled:opacity-50">
                                {isFetchingSheet ? 'Fetching...' : 'Fetch Sheet'}
                            </button>
                        </div>
                        {!site.apiKeys.google && <p className="text-xs text-yellow-400 mt-2">A Google API Key is required to fetch sheet data. Please add one in the API Keys tab.</p>}
                        <div className="space-y-2 pt-4 border-t border-border-subtle">
                            {isFetchingSheet && <p className="text-text-secondary text-center">Fetching sheet data...</p>}
                            {!isFetchingSheet && unprocessedSheetRows.length === 0 && (
                                <p className="text-text-secondary text-center">
                                    {sheetData ? 'All rows from this sheet have been processed.' : 'Fetch a sheet to see available rows.'}
                                </p>
                            )}
                            {unprocessedSheetRows.map((row) => (
                                <div key={row.rowIndex} className="flex items-center justify-between p-2 rounded-md bg-panel">
                                    <div>
                                        <p className="text-sm font-medium text-text-primary">{row.topic}</p>
                                        <p className="text-xs text-text-secondary">Row {row.rowIndex + 1}</p>
                                    </div>
                                    <button onClick={() => onGenerateAndScore(row.topic, 'google_sheet', row, site)} className="btn btn-primary text-xs px-3 py-1.5 flex-shrink-0">
                                        Generate
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>

            {isSuggestUrlModalOpen && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
                    <div className="bg-panel rounded-lg shadow-2xl w-full max-w-md p-6 border border-border animate-modal-pop">
                        <h3 className="text-lg font-bold text-white">Suggest Keywords from URL</h3>
                        <p className="text-sm text-text-secondary mt-2">Enter a URL (like a competitor's blog post) to get relevant keyword ideas.</p>
                        <input type="url" value={suggestUrlInput} onChange={e => setSuggestUrlInput(e.target.value)} className="input-base mt-4" placeholder="https://example.com/blog/post" />
                        <div className="mt-4 flex justify-end gap-3">
                            <button onClick={() => setIsSuggestUrlModalOpen(false)} className="btn btn-secondary">Cancel</button>
                            <button onClick={handleSuggestFromUrl} disabled={isSuggestingFromUrl || !suggestUrlInput.trim()} className="btn btn-primary disabled:opacity-50"> {isSuggestingFromUrl ? 'Suggesting...' : 'Suggest'} </button>
                        </div>
                    </div>
                </div>
            )}
            {isClearKeywordsModalOpen && (
                 <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
                    <div className="bg-panel rounded-lg shadow-2xl w-full max-w-md p-6 border border-red-500/50 animate-modal-pop">
                        <div className="flex items-start gap-4">
                            <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-900/50 sm:mx-0 sm:h-10 sm:w-10"> <ExclamationTriangleIcon className="h-6 w-6 text-red-400" /> </div>
                            <div className="mt-0 text-left flex-1">
                                <h3 className="text-lg leading-6 font-bold text-white">Clear All Keywords?</h3>
                                <div className="mt-2"> <p className="text-sm text-text-secondary"> Are you sure you want to delete all keywords from the list? This action cannot be undone. </p> </div>
                            </div>
                        </div>
                        <div className="mt-5 sm:mt-4 sm:flex sm:flex-row-reverse gap-3">
                            <button type="button" className="w-full btn bg-red-600 hover:bg-red-700 text-white sm:w-auto" onClick={handleClearKeywords}> Clear List </button>
                            <button type="button" className="mt-3 w-full btn btn-secondary sm:mt-0 sm:w-auto" onClick={() => setIsClearKeywordsModalOpen(false)}> Cancel </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};