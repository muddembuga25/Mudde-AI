import React, { useState, useCallback, useEffect } from 'react';
import type { Site, ApiKeys, PostHistoryItem, Site as ClientSite, CharacterReference } from '../types';
import { AiProvider } from '../types';
import { AVAILABLE_MODELS, PLAN_LIMITS, providerDisplayNames } from '../constants';
import * as aiService from '../services/aiService';
import * as mcpApiService from '../services/mcpApiService';
import { useAuth } from '../contexts/AuthContext';
import { SparklesIcon, PhotoIcon, XIconSocial, InstagramIcon, PinterestIcon, ArchiveBoxIcon, LightbulbIcon, ExclamationTriangleIcon, ChevronDownIcon, PaperAirplaneIcon } from './Icons';

interface SocialGraphicsTabProps {
    site: ClientSite;
    onSiteUpdate: (field: keyof Site, value: any) => void;
    setSites: (updater: (prevSites: Site[]) => Site[]) => void;
    setError: (error: string | null) => void;
    addLog: (message: string, type: 'SUCCESS' | 'ERROR' | 'INFO', siteId: string) => void;
}

interface GenerationResult {
    imageUrl: string;
    caption: string;
}

const platforms = [
    { id: 'instagram', name: 'Instagram Post', icon: InstagramIcon, aspectRatio: '1:1' as const },
    { id: 'pinterest', name: 'Pinterest Pin', icon: PinterestIcon, aspectRatio: '9:16' as const },
    { id: 'twitter', name: 'X (Twitter) Post', icon: XIconSocial, aspectRatio: '16:9' as const },
];

const LockedFeature: React.FC<{ title: string; message: string; requiredPlan: string; }> = ({ title, message, requiredPlan }) => (
    <div className="text-center p-8 bg-panel/50 rounded-2xl border-2 border-dashed border-border animate-fade-in max-w-lg mx-auto">
        <SparklesIcon className="mx-auto h-12 w-12 text-text-secondary" />
        <h3 className="mt-4 text-lg font-medium text-white">{title}</h3>
        <p className="mt-1 text-sm text-text-secondary">{message}</p>
        <div className="mt-4 text-xs font-bold text-yellow-400 bg-yellow-900/50 px-3 py-1.5 rounded-full inline-block">
            Requires {requiredPlan} Plan
        </div>
    </div>
);


export const SocialGraphicsTab: React.FC<SocialGraphicsTabProps> = ({ site, onSiteUpdate, setSites, setError, addLog }) => {
    const { currentUser } = useAuth();
    const [prompt, setPrompt] = useState('');
    const [isSuggestingPrompt, setIsSuggestingPrompt] = useState(false);
    const [selectedPlatform, setSelectedPlatform] = useState<string>('instagram');
    const [selectedCharacterId, setSelectedCharacterId] = useState<string>('');
    const [result, setResult] = useState<GenerationResult | { error: string } | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [isAdvancedOpen, setIsAdvancedOpen] = useState(false);
    const [isPublishing, setIsPublishing] = useState(false);

    const [imageProvider, setImageProvider] = useState<AiProvider>(site.modelConfig.imageProvider);
    const [imageModel, setImageModel] = useState<string>(site.modelConfig.imageModel);

    useEffect(() => {
        setImageProvider(site.modelConfig.imageProvider);
        setImageModel(site.modelConfig.imageModel);
    }, [site.modelConfig.imageProvider, site.modelConfig.imageModel]);

    const handleSuggestPrompt = useCallback(async () => {
        setIsSuggestingPrompt(true);
        setError(null);
        try {
            const { prompt: suggestedPrompt, updatedSite } = await aiService.generateSocialGraphicPrompt(site.id);
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
            setPrompt(suggestedPrompt);
        } catch (error: any) {
            setError(error.message || "Failed to suggest a prompt.");
        } finally {
            setIsSuggestingPrompt(false);
        }
    }, [site.id, setSites, setError]);

    useEffect(() => { 
        if (!prompt) {
            handleSuggestPrompt();
        }
    }, [handleSuggestPrompt, prompt]);
    
    const handleUpdateCaption = (newCaption: string) => {
        setResult(prev => {
            if (prev && 'caption' in prev) {
                return { ...prev, caption: newCaption };
            }
            return prev;
        });
    };

    const handleGenerate = async () => {
        if (!prompt.trim()) {
            setError("Please provide a prompt.");
            return;
        }
        setIsLoading(true);
        setResult(null);
        setError(null);
        const overrides = { imageProvider, imageModel };

        try {
            const platformConfig = platforms.find(p => p.id === selectedPlatform);
            if (!platformConfig) throw new Error(`Configuration for ${selectedPlatform} not found.`);

            const { generationResult, updatedSite } = await mcpApiService.generateSocialGraphicAndCaption(
                site.id, prompt, platformConfig.aspectRatio, platformConfig.name, overrides, selectedCharacterId || undefined
            );
            
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
            setResult({ imageUrl: generationResult.base64Image, caption: generationResult.caption });

        } catch (error: any) {
            console.error(`Error generating for ${selectedPlatform}:`, error);
            setResult({ error: error.message || 'Generation failed.' });
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleGenerateAndPublish = async () => {
        if (!prompt.trim() || !result || !('imageUrl' in result)) {
            setError("Please generate a graphic first before publishing.");
            return;
        }
        setIsPublishing(true);
        setError(null);
        try {
            const { updatedSite } = await mcpApiService.publishSocialGraphic(site.id, result as GenerationResult);
            setSites(prev => prev.map(s => s.id === site.id ? updatedSite : s));
            addLog('Social graphic published successfully to enabled accounts.', 'SUCCESS', site.id);
            handleDiscard(); // Clear the current graphic after successful publish
        } catch (e: any) {
            setError(e.message || "Failed to publish social graphic.");
            addLog(`Failed to publish social graphic: ${e.message}`, 'ERROR', site.id);
        } finally {
            setIsPublishing(false);
        }
    };


    const handleSaveToHistory = () => {
        if (!result || !('imageUrl' in result)) return;
        
        const newHistoryItem: PostHistoryItem = {
            id: crypto.randomUUID(), topic: `Social Graphic: "${prompt.substring(0, 50)}..."`, url: '#', date: Date.now(), type: 'Social Graphic', 
            socialGraphics: { [selectedPlatform]: { imageUrl: result.imageUrl, caption: result.caption } },
        };
        onSiteUpdate('history', [newHistoryItem, ...site.history]);
        handleDiscard();
    };
    
    const handleDiscard = () => {
        setResult(null);
        setPrompt('');
        handleSuggestPrompt();
    };

    const hasResult = !!result;
    
    const imageProviders = (Object.keys(AVAILABLE_MODELS) as AiProvider[]).filter(p => AVAILABLE_MODELS[p as keyof typeof AVAILABLE_MODELS].image.length > 0);
    const modelsForProvider = site.fetchedModels?.[imageProvider]?.image || AVAILABLE_MODELS[imageProvider as keyof typeof AVAILABLE_MODELS]?.image || [];

    if (!currentUser) return null;
    const planFeatures = PLAN_LIMITS[currentUser.subscription.plan].features;
    if (!planFeatures.socialGraphics) {
        return <LockedFeature title="Social Graphics Generator" message="This feature is available on the Starter plan and above." requiredPlan="Starter+" />;
    }
    
    return (
        <div className="w-full max-w-5xl mx-auto space-y-8">
            <div className="bg-panel/50 p-6 rounded-2xl border border-border">
                <h2 className="text-2xl font-bold text-white">Social Graphics Generator</h2>
                <p className="text-text-secondary mt-1">Create and publish a one-off social media graphic.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* --- CONTROL PANEL --- */}
                <div className="bg-panel/50 p-6 rounded-2xl border border-border space-y-6">
                     <div>
                        <div className="flex justify-between items-center mb-2">
                            <label htmlFor="social-graphics-prompt-textarea" className="text-sm font-medium text-text-primary">1. Write a Prompt</label>
                            <button onClick={handleSuggestPrompt} disabled={isSuggestingPrompt || isLoading} className="btn text-xs px-3 py-1.5 flex items-center justify-center gap-1.5 bg-teal-600/80 hover:bg-teal-500 text-white shadow-lg shadow-teal-900/50 disabled:opacity-50 disabled:cursor-not-allowed">
                               {isSuggestingPrompt ? <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle opacity="25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path opacity="75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : <><LightbulbIcon title="Suggest Prompt" className="h-4 w-4" /> Suggest</>}
                            </button>
                        </div>
                        <textarea id="social-graphics-prompt-textarea" value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="e.g., A minimalist graphic of a rising sun..." className="input-base w-full p-4 text-sm leading-relaxed bg-panel border-border-subtle" rows={4} />
                    </div>
                    <div>
                        <label className="text-sm font-medium text-text-primary mb-2">2. Select Platform</label>
                         <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            {platforms.map(p => (
                                <button key={p.id} onClick={() => setSelectedPlatform(p.id)} className={`p-3 text-sm font-semibold rounded-lg transition-all border-2 flex flex-col items-center justify-center gap-2 ${selectedPlatform === p.id ? 'bg-purple-900/40 border-purple-500 text-white' : 'bg-panel-light/60 border-border hover:border-gray-600 text-text-secondary'}`}>
                                    <p.icon className="h-5 w-5" /> {p.name}
                                </button>
                            ))}
                        </div>
                    </div>
                     <div>
                        <label htmlFor="character-ref" className="text-sm font-medium text-text-primary mb-2">3. Character Reference (Optional)</label>
                        <select id="character-ref" value={selectedCharacterId} onChange={e => setSelectedCharacterId(e.target.value)} className="input-base w-full">
                            <option value="">None</option>
                            {(site.characterLibrary || []).map(char => <option key={char.id} value={char.id}>{char.name}</option>)}
                        </select>
                    </div>

                    <details className="bg-panel/50 rounded-lg border border-border-subtle" onToggle={(e) => setIsAdvancedOpen(e.currentTarget.open)}>
                        <summary className="p-3 cursor-pointer text-sm font-medium text-text-primary flex items-center justify-between">Advanced Settings <ChevronDownIcon className={`h-5 w-5 transition-transform ${isAdvancedOpen ? 'rotate-180' : ''}`} /></summary>
                        <div className="p-4 border-t border-border-subtle grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div><label htmlFor="sg-provider" className="block text-xs font-medium text-text-primary mb-1">Image Provider</label><select id="sg-provider" value={imageProvider} onChange={e => setImageProvider(e.target.value as AiProvider)} className="input-base px-3 py-2 w-full text-sm"><option value="" disabled>Select Provider</option>{imageProviders.map(p => <option key={p} value={p}>{p}</option>)}</select></div>
                            <div>
                                <label htmlFor="sg-model" className="block text-xs font-medium text-text-primary mb-1">Image Model</label>
                                <input id="sg-model" type="text" list="sg-models-list" value={imageModel} onChange={e => setImageModel(e.target.value)} className="input-base px-3 py-2 w-full text-sm" placeholder="Select or type model" disabled={modelsForProvider.length === 0} />
                                <datalist id="sg-models-list">{modelsForProvider.map(model => <option key={model} value={model} />)}</datalist>
                                {modelsForProvider.length === 0 && imageProvider && (
                                    <p className="text-xs text-yellow-400 bg-yellow-900/30 p-2 rounded-md mt-2">
                                        Provider '{providerDisplayNames[imageProvider]}' does not offer image models.
                                    </p>
                                )}
                            </div>
                        </div>
                    </details>
                    
                    <button id="social-graphics-generate-button" onClick={handleGenerate} disabled={isLoading || isPublishing || !prompt.trim() || !imageModel} className="w-full btn btn-primary text-base flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-wait">
                       {isLoading ? <><svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle opacity="25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path opacity="75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Generating...</> : <><PhotoIcon /> 4. Generate Graphic</>}
                    </button>
                </div>

                {/* --- RESULT PANEL --- */}
                <div className="bg-panel/50 p-4 rounded-2xl border border-border space-y-3 flex flex-col">
                    <div className="flex items-center gap-2 font-semibold text-text-primary">
                        {isLoading ? "Generating..." : hasResult ? "Result" : "Your generated graphic will appear here"}
                    </div>
                    <div className="flex-grow aspect-[1/1] bg-panel-light rounded-lg flex items-center justify-center border border-border-subtle overflow-hidden">
                       {isLoading ? <div className="text-center"><svg className="animate-spin h-8 w-8 text-purple-400 mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle opacity="25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path opacity="75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg><p className="text-xs text-text-secondary mt-2">Generating...</p></div>
                       : result && 'imageUrl' in result ? <img src={result.imageUrl} alt={prompt} className="w-full h-full object-cover" />
                       : result && 'error' in result ? <div className="p-4 text-center text-red-400"><ExclamationTriangleIcon className="h-8 w-8 mx-auto mb-2" /><p className="text-xs">{result.error}</p></div>
                       : <PhotoIcon className="h-12 w-12 text-text-secondary/50" />}
                    </div>
                    <div>
                        <label className="text-xs font-medium text-text-primary mb-1">Caption</label>
                        <textarea
                            value={result && 'caption' in result ? result.caption : ''}
                            onChange={(e) => handleUpdateCaption(e.target.value)}
                            className="input-base w-full p-2 text-sm leading-relaxed"
                            rows={4}
                            disabled={isLoading || isPublishing || !(result && 'caption' in result)}
                        />
                    </div>
                    {hasResult && !('error' in result) && (
                         <div className="flex flex-col sm:flex-row items-center gap-3 animate-fade-in">
                            <button onClick={handleSaveToHistory} disabled={isPublishing} className="w-full sm:w-auto btn btn-secondary text-sm flex items-center justify-center gap-2"><ArchiveBoxIcon className="h-4 w-4" /> Save to History</button>
                            <button onClick={handleGenerateAndPublish} disabled={isPublishing} className="w-full sm:w-auto btn btn-primary text-sm flex items-center justify-center gap-2">
                               {isPublishing ? <><svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle opacity="25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path opacity="75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>Publishing...</> : <><PaperAirplaneIcon className="h-4 w-4" /> Publish Now</>}
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};