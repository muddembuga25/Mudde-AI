import { LiveServerMessage } from "@google/genai";

export enum AppStatus {
  IDLE,
  AUTOMATION_TRIGGERED,
  FETCHING_SOURCE,
  GENERATING_STRATEGY,
  AWAITING_STRATEGY_SELECTION,
  GENERATING_ARTICLE,
  OPTIMIZING_ARTICLE,
  GENERATING_IMAGE,
  GENERATING_SOCIAL_POSTS,
  READY_TO_PUBLISH,
  PUBLISHING,
  PUBLISHED,
  ERROR,
}

export enum AiProvider {
  GOOGLE = 'GOOGLE',
  OPENROUTER = 'OPENROUTER',
  OPENAI = 'OPENAI',
  ANTHROPIC = 'ANTHROPIC',
  XAI = 'XAI',
  REPLICATE = 'REPLICATE',
  FREEPIK = 'FREEPIK',
  FALAI = 'FALAI',
  PERPLEXITY = 'PERPLEXITY',
}

export enum SubscriptionPlan {
  FREE = 'free',
  CREATOR = 'creator',
  PRO = 'pro',
  AGENCY = 'agency',
}

export interface UserSubscription {
  plan: SubscriptionPlan;
  postsGeneratedThisMonth: number;
  renewalDate: number; // Unix timestamp in ms
  featureCredits?: {
    socialGraphics: number;
    socialVideo: number;
  };
  commentingActionsThisMonth?: number;
}

export interface ApiKeys {
  google: string;
  googleClientId: string;
  openAI: string;
  anthropic: string;
  openRouter: string;
  xai: string;
  replicate: string;
  dataforseo: string;
  freepik: string;
  falai: string;
  perplexity: string;
  mailgun: string;
  sendgrid: string;
}

export interface GeminiModelConfig {
  temperature?: number;
  topP?: number;
  topK?: number;
  maxOutputTokens?: number;
}

export interface ModelConfig {
  textProvider: AiProvider;
  textModel: string;
  imageProvider: AiProvider;
  imageModel: string;
  videoProvider?: AiProvider;
  videoModel?: string;
  geminiConfig?: Partial<GeminiModelConfig>;
}

export interface BlogPost {
  title: string;
  content: string; // HTML format
  seoTitle: string;
  metaDescription: string;
  slug: string;
  excerpt: string;
  categories: string[];
  tags: string[];
  imageUrl: string; // base64 data url
  imagePrompt: string;
  imageAltText: string;
  focusKeyword: string;
  url?: string; // Optional URL for the published post
}

export interface ReferenceItem {
  id: string;
  type: 'url' | 'file';
  value: string; // URL string or Base64 data URL
  name: string | null;
  mimeType: string | null;
}

export interface CharacterReference {
  id: string;
  name: string;
  visualReferenceImage?: string; // base64
  visualReferenceText: string;
  personality: string;
}

export interface RssItem {
  guid: string;
  title: string;
  link: string;
  contentSnippet: string;
}

export interface VideoSource {
  id: string;
  url: string; // The URL of the video or the channel RSS feed
  type: 'video' | 'channel';
  name: string; // Display name for the source
  processedVideoGuids: string[]; // For channels, tracks processed videos. For single videos, contains its own URL if processed.
}

export interface RecurringSchedule {
  id:string;
  type: 'weekly' | 'monthly';
  days: number[]; // 0 (Sun) - 6 (Sat) for weekly, 1-31 for monthly
  time: string; // "HH:mm" format
  isEnabled: boolean;
  lastRun?: number; // Unix timestamp in ms
}

export interface SocialMediaPost {
    content: string;
    hashtags: string[];
}

export interface EmailMarketingCampaign {
  subject: string;
  body: string; // HTML format
}

export interface StrategicBrief {
  topic: string;
  focusKeyword: string;
  keywordCluster: string[];
  targetAudience: string;
  contentAngle: string;
  entities: string[];
  competitorUrls: string[];
  internalLinks: { title: string; link: string; }[];
  seoTitle: string;
  metaDescription: string;
  slug: string;
  imagePrompt: string;
  imageAltText: string;
  categories: string[];
  tags: string[];
  faq: { question: string; answer: string; }[];
  wordCount: number;
  brandGuideline?: string;
  brandLogo?: string;
  brandColors?: string[];
  brandFonts?: string[];
  promoLink1?: string;
  promoLink2?: string;
  authorName?: string;
  authorBio?: string;
  nicheTargeting?: string;
}

export interface PostHistoryItem {
  id: string;
  topic: string;
  url: string;
  date: number; // Unix timestamp in ms
  type: 'Keyword' | 'RSS' | 'Video' | 'Social Graphic' | 'Social Video' | 'Google Sheet' | 'Email Marketing' | 'Email Digest';
  socialMediaPosts?: Record<string, SocialMediaPost>;
  socialGraphics?: Record<string, { imageUrl: string; caption: string; }>;
  socialVideos?: Record<string, { videoUrl: string; caption: string; }>;
  emailCampaign?: EmailMarketingCampaign;
}

export type SocialAccountStatus = 'connected' | 'disconnected' | 'needs_reauth';

export interface SocialMediaAccount {
    id: string;
    name: string;
    isAutomationEnabled: boolean;
    isConnected: boolean;
    accessToken?: string | null;
    clientId?: string;
    clientSecret?: string;
    destinationType?: 'profile' | 'page' | 'group';
    destinationId?: string;
    status: SocialAccountStatus;
    statusMessage?: string;
}

export interface WhatsAppAccount {
    id: string;
    name: string;
    isAutomationEnabled: boolean;
    isConnected: boolean;
    accessToken: string;
    phoneNumberId: string;
    destination: string; // Recipient phone number or group ID
    destinationType: 'number' | 'group';
    status: SocialAccountStatus;
    statusMessage?: string;
}

export interface TelegramAccount {
    id: string;
    name: string;
    isAutomationEnabled: boolean;
    isConnected: boolean;
    botToken: string;
    chatId: string; // e.g., @yourchannel or numeric ID
    status: SocialAccountStatus;
    statusMessage?: string;
}


export interface SocialMediaSettings {
    twitter: SocialMediaAccount[];
    facebook: SocialMediaAccount[];
    linkedin: SocialMediaAccount[];
    instagram: SocialMediaAccount[];
    pinterest: SocialMediaAccount[];
    whatsapp: WhatsAppAccount[];
    youtube: SocialMediaAccount[];
    tiktok: SocialMediaAccount[];
    telegram: TelegramAccount[];
    snapchat: SocialMediaAccount[];
}

export interface MailchimpAccount {
  isConnected: boolean;
  apiKey: string;
  serverPrefix: string;
  status: 'connected' | 'disconnected' | 'error';
  statusMessage?: string;
  defaultAudienceId?: string;
  availableAudiences?: { id: string; name: string; }[];
}

export interface Draft {
  id: string;
  date: number;
  sourceTopic: string;
  sourceDetails: {
    type: 'keyword' | 'rss' | 'video' | 'google_sheet';
    value: any; // Can be keyword string, RssItem, etc.
    source?: VideoSource; // For video channels
    videoItem?: RssItem; // For specific video from a channel
  };
  blogPost: BlogPost;
}

export interface BacklinksHistoryItem {
  date: number;
  type: 'info' | 'prospect' | 'outreach' | 'error' | 'success';
  message: string;
  targetUrl?: string;
}

export interface CommentingProspect {
  id: string;
  prospectUrl: string;
  prospectTitle: string;
  prospectDescription: string;
  status: 'found' | 'comment_generated' | 'commented' | 'approved';
  generatedComment?: string;
  sourcePostUrl?: string; // The user's own post used for the comment
}

export interface SocialCommentingProspect {
  id: string;
  platform: 'twitter' | 'linkedin' | 'facebook' | 'instagram' | 'pinterest' | 'tiktok' | 'youtube' | 'general';
  prospectPostUrl: string;
  prospectPostAuthor: string;
  prospectPostContent: string;
  status: 'found' | 'comment_generated' | 'posted' | 'discarded';
  generatedComment?: string;
  sourcePostUrl: string; // The user's own post used for context
  postingAccountId: string; // ID of the SocialMediaAccount to use
  postingAccountName: string;
}

export interface MonitoredBacklink {
  id: string;
  url: string; // The URL of the backlink
  targetUrl: string; // The URL on the user's site it points to
  status: 'active' | 'inactive' | 'not_found' | 'pending';
  anchorText: string | null;
  dateFound: number;
  lastChecked: number | null;
  domainAuthority: number | null;
}

export interface Site {
  id:string;
  name:string;
  wordpressUrl:string;
  wordpressUsername:string;
  applicationPassword:string;
  brandGuideline:string;
  brandLogo?: string;
  brandColors?: string[];
  brandFonts?: string[];
  promoLink1:string;
  promoLink2:string;
  nicheTargeting?: string;
  keywordList:string;
  videoSources: VideoSource[];
  references: ReferenceItem[];
  characterLibrary?: CharacterReference[];
  authorName:string;
  authorId?: number;
  availableAuthors?: { id: number; name: string; bio: string; }[];
  availableCategories?: { id: number; name: string; }[];
  history: PostHistoryItem[];

  // Blog Post Automation
  isAutomationEnabled:boolean;
  isAutoPublishEnabled: boolean;
  isDraftNotificationEnabled: boolean;
  draftNotificationMethods: ('whatsapp' | 'telegram' | 'email')[];
  draftNotificationEmail: string;
  automationTrigger: 'interval' | 'schedule';
  automationIntervalHours:number;
  lastAutoPilotRun?:number; // Unix timestamp in ms
  recurringSchedules: RecurringSchedule[];
  drafts: Draft[];
  blogPostAutomationModelConfig?: ModelConfig;
  
  // Unified Automation Source
  masterAutomationSource: 'keyword' | 'rss' | 'video' | 'google_sheet';
  
  // Blog Post Generation sources (deprecated by UI, kept for migration)
  intervalGenerationSource: 'keyword' | 'rss' | 'video' | 'google_sheet';
  scheduleGenerationSource: 'keyword' | 'rss' | 'video' | 'google_sheet';
  rssFeedUrl:string;
  processedRssGuids:string[];
  googleSheetUrl: string;
  googleSheetProcessedRows: number[];
  
  socialMediaSettings: SocialMediaSettings;

  // Local SEO Targeting
  isLocalSeoEnabled: boolean;
  localSeoBusinessName?: string;
  localSeoServiceArea?: string;
  localSeoPhoneNumber?: string;
  // Deprecated fields for migration
  localSeoCountry?: string;
  localSeoCity?: string;
  localSeoSuburb?: string;

  // AI model and API key configuration
  seoDataProvider: 'google_search' | 'dataforseo_gemini' | 'dataforseo_openai' | 'dataforseo_xai' | 'dataforseo_perplexity' | 'standalone_gemini' | 'standalone_openai' | 'standalone_xai' | 'standalone_openrouter' | 'standalone_perplexity';
  modelConfig: ModelConfig;
  apiKeys: ApiKeys;
  apiUsage: Partial<Record<keyof ApiKeys, number>>;
  fetchedModels?: Partial<Record<AiProvider, { text: string[], image: string[], video?: string[] }>>;
  
  // DataForSEO Keyword Research Automation
  dataforseoSeedKeywords: string;
  dataforseoTargetLocation: string; // e.g., 'us'
  dataforseoTargetLanguage: string; // e.g., 'en'
  dataforseoKeywordDifficultyMin: number;
  dataforseoKeywordDifficultyMax: number;
  dataforseoSearchVolumeMin: number;
  dataforseoSearchVolumeMax: number;

  // New fields for Social Graphics Automations
  isSocialGraphicAutomationEnabled: boolean;
  socialGraphicAutomationTrigger: 'interval' | 'schedule';
  socialGraphicAutomationIntervalHours: number;
  lastSocialGraphicAutoPilotRun?: number;
  socialGraphicRecurringSchedules: RecurringSchedule[];
  socialGraphicGenerationSource: 'keyword' | 'rss' | 'video' | 'google_sheet'; // deprecated by UI
  socialGraphicAutomationModelConfig?: ModelConfig;

  // New fields for Social Video Automations
  isSocialVideoAutomationEnabled: boolean;
  socialVideoAutomationTrigger: 'interval' | 'schedule';
  socialVideoAutomationIntervalHours: number;
  lastSocialVideoAutoPilotRun?: number;
  socialVideoRecurringSchedules: RecurringSchedule[];
  socialVideoGenerationSource: 'keyword' | 'rss' | 'video' | 'google_sheet'; // deprecated by UI
  socialVideoAutomationModelConfig?: {
    textProvider: AiProvider;
    textModel: string;
    videoProvider?: AiProvider;
    videoModel?: string;
  };

  // Google Drive Integration
  googleDrive?: {
    isConnected: boolean;
    userEmail: string;
  };
  
  // Google Analytics Integration
  googleAnalytics?: {
    isConnected: boolean;
    userEmail: string;
    propertyId?: string;
  };

  // Backlinks Automation
  isBacklinksAutomationEnabled: boolean;
  backlinksCompetitors: string; // Newline-separated domains
  backlinksOwnDomain: string;
  backlinksEmailProvider: 'mailgun' | 'sendgrid';
  backlinksFromName: string;
  backlinksFromEmail: string;
  backlinksEmailSubject: string;
  backlinksEmailBody: string; // Template with placeholders
  backlinksHistory: BacklinksHistoryItem[];
  lastBacklinksRun?: number;
  backlinksIntervalHours: number;

  // Blog Commenting
  commentingProspects?: CommentingProspect[];

  // Social Commenting
  isSocialCommentingEnabled?: boolean;
  socialCommentingKeywords?: string;
  socialCommentingGuideline?: string;
  socialCommentingProspects?: SocialCommentingProspect[];

  // Backlink Monitoring
  monitoredBacklinks?: MonitoredBacklink[];
  isBacklinkMonitoringEnabled?: boolean;
  lastBacklinkCheckRun?: number;

  // Email Marketing Follow-up
  isEmailFollowUpEnabled?: boolean;
  isSocialFollowUpEnabled?: boolean;
  emailMarketingSettings?: {
    fromName: string;
    fromEmail: string;
    targetList: string; // e.g., list name or ID
  };
  emailMarketingModelConfig?: ModelConfig;
  mailchimp?: MailchimpAccount;

  // Standalone Email Marketing Automation
  isEmailMarketingAutomationEnabled?: boolean;
  emailMarketingAutomationTrigger?: 'interval' | 'schedule';
  emailMarketingAutomationIntervalHours?: number;
  lastEmailMarketingAutoPilotRun?: number;
  emailMarketingRecurringSchedules?: RecurringSchedule[];

  // New fields for Weekly Digest Automation
  isDigestAutomationEnabled?: boolean;
  digestRecurringSchedules?: RecurringSchedule[];
  processedDigestGuids?: string[];
  digestAutomationModelConfig?: ModelConfig;
  lastDigestAutoPilotRun?: number;

  // New field for automation locking
  automationLock?: { jobType: string; timestamp: number; } | null;

  // New Hosting integration field
  hosting?: {
    provider: '10web' | 'other' | null;
    accountId?: string;
    isConnected: boolean;
  };
}

export interface SeoChecklist {
  titleLength: boolean;
  metaDescriptionLength: boolean;
  keywordInTitle: boolean;
  keywordInMetaDescription: boolean;
  keywordInSlug: boolean;
  keywordInContent: boolean;
  keywordInHeadings: boolean;
  sufficientInternalLinks: boolean;
  sufficientExternalLinks: boolean;
  imageAltText: boolean;
  contentLength: boolean;
  faqSection: boolean;
  schemaMarkupValid: boolean;
  readability: boolean;
  authorMentioned: boolean;
  firstPersonExperience: boolean;
  aboutTheAuthorSection: boolean;
}

export interface SeoScoreResult {
  score: number;
  checklist: SeoChecklist;
}

export interface User {
  username: string;
  displayName: string;
  email: string;
  subscription: UserSubscription;
  avatarUrl?: string;
}

export interface StoredUser extends User {
  passwordHash: string;
}

export type LogLevel = 'INFO' | 'WARN' | 'ERROR' | 'SUCCESS';

export interface LogEntry {
  timestamp: number;
  message: string;
  type: LogLevel;
  siteId?: string;
}

export interface MCPServer {
  id: string;
  name: string;
  url: string;
  status: 'connected' | 'disconnected' | 'error' | 'connecting';
  statusMessage?: string;
}

export interface PostPerformanceData {
  postId: string;
  title: string;
  url: string;
  focusKeyword: string;
  searchConsole: {
    clicks: number;
    impressions: number;
    ctr: number;
    position: number;
  };
  analytics: {
    pageviews: number;
    users: number;
    avgTimeOnPage: number; // in seconds
  };
}

export interface AnalyticsInsight {
  insights: string[];
  recommendations: { text: string; pro: boolean; }[];
}

export type SelfTestStatus = 'untested' | 'running' | 'pass' | 'fail';

export interface SelfTestResult {
  id: string;
  status: SelfTestStatus;
  message?: string;
}