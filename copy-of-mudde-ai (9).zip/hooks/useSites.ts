import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { Site, ApiKeys, SocialMediaSettings, PostHistoryItem, SocialMediaAccount, ModelConfig, User, GeminiModelConfig } from '../types';
import { AiProvider } from '../types';
import { AVAILABLE_MODELS } from '../constants';
import * as mcpApiService from '../services/mcpApiService';

const defaultApiKeys: ApiKeys = { google: '', googleClientId: '', openAI: '', anthropic: '', openRouter: '', xai: '', replicate: '', dataforseo: '', freepik: '', falai: '', perplexity: '', mailgun: '', sendgrid: '' };
const defaultModelConfig: ModelConfig = {
  textProvider: AiProvider.GOOGLE, textModel: AVAILABLE_MODELS.GOOGLE.text[0],
  imageProvider: AiProvider.GOOGLE, imageModel: AVAILABLE_MODELS.GOOGLE.image[0],
  videoProvider: AiProvider.GOOGLE, videoModel: AVAILABLE_MODELS.GOOGLE.video?.[0] || '',
  geminiConfig: { temperature: 0.7, topK: 40, topP: 0.95 },
};
const defaultSocialSettings: SocialMediaSettings = { twitter: [], facebook: [], linkedin: [], instagram: [], pinterest: [], whatsapp: [], youtube: [], tiktok: [], telegram: [], snapchat: [] };
const defaultApiUsage: Partial<Record<keyof ApiKeys, number>> = { google: 0, openAI: 0, anthropic: 0, openRouter: 0, xai: 0, replicate: 0, dataforseo: 0, freepik: 0, falai: 0, perplexity: 0, mailgun: 0, sendgrid: 0 };


export const useSites = (currentUser: User | null) => {
  const [sites, setSites] = useState<Site[]>([]);
  const [selectedSiteId, setSelectedSiteId] = useState<string | null>(null);
  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState(true);
  const saveTimeoutRef = useRef<number | null>(null);
  
  const saveSitesToServer = useCallback(async (updatedSites: Site[]) => {
      if (!currentUser) return;
      setIsSaving(true);
      setIsSaved(false);
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);

      try {
          await mcpApiService.updateSitesForUser(currentUser.username, updatedSites);
          setIsSaved(true);
      } catch (e) {
          console.error("Failed to save sites to server:", e);
      } finally {
          setIsSaving(false);
          saveTimeoutRef.current = window.setTimeout(() => setIsSaved(false), 2500);
      }
  }, [currentUser]);

  useEffect(() => {
    if (!currentUser) {
        setSites([]);
        setSelectedSiteId(null);
        setIsLoading(false);
        return;
    }
    
    const loadSites = async () => {
        setIsLoading(true);
        try {
            // Data migration is now handled by the mcpApiService on load.
            const finalSites = await mcpApiService.getSitesForUser(currentUser.username);
            setSites(finalSites);
      
            const lastSelectedId = localStorage.getItem(`ai-seo-blog-writer-last-selected-${currentUser.username}`);
            if (lastSelectedId && finalSites.some(s => s.id === lastSelectedId)) {
                setSelectedSiteId(lastSelectedId);
            } else if (finalSites.length > 0) {
                setSelectedSiteId(finalSites[0].id);
            }
        } catch (error: any) { 
            console.warn("Could not load sites from MCP service:", error); 
        } finally {
            setIsLoading(false);
        }
    };
    loadSites();
  }, [currentUser]);

  useEffect(() => {
    // Save selected site ID locally for better UX on refresh
    if (selectedSiteId && currentUser) {
        localStorage.setItem(`ai-seo-blog-writer-last-selected-${currentUser.username}`, selectedSiteId);
    }
  }, [selectedSiteId, currentUser]);
  
  const setSitesWithSave = useCallback((updater: (prevSites: Site[]) => Site[]) => {
    setSites(currentSites => {
        const newSites = updater(currentSites);
        saveSitesToServer(newSites);
        return newSites;
    });
  }, [saveSitesToServer]);

  const handleSiteUpdate = useCallback((field: keyof Site, value: any) => {
    if (!selectedSiteId) return;
    setSitesWithSave(prevSites =>
      prevSites.map(site =>
        site.id === selectedSiteId ? { ...site, [field]: value } : site
      )
    );
  }, [selectedSiteId, setSitesWithSave]);
  
  const handleMultipleSiteUpdates = useCallback((updates: Partial<Site>) => {
    if (!selectedSiteId) return;
    setSitesWithSave(prevSites =>
      prevSites.map(site =>
        site.id === selectedSiteId ? { ...site, ...updates } : site
      )
    );
  }, [selectedSiteId, setSitesWithSave]);

  const handleAddNewSite = useCallback(() => {
    const newSite: Site = {
      id: crypto.randomUUID(), name: `New Site`, // Name will be updated with length later
      wordpressUrl: '', wordpressUsername: '', applicationPassword: '',
      brandGuideline: '',
      brandLogo: '',
      brandColors: [],
      brandFonts: [],
      promoLink1: '', promoLink2: '', nicheTargeting: '', keywordList: '', videoSources: [], references: [], characterLibrary: [], authorName: '', authorId: undefined, availableAuthors: [], availableCategories: [], history: [],
      isAutomationEnabled: true, automationTrigger: 'interval', automationIntervalHours: 24, recurringSchedules: [],
      isAutoPublishEnabled: false, drafts: [],
      isDraftNotificationEnabled: false, draftNotificationMethods: [], draftNotificationEmail: '',
      masterAutomationSource: 'keyword',
      intervalGenerationSource: 'keyword', scheduleGenerationSource: 'keyword', rssFeedUrl: '', processedRssGuids: [],
      googleSheetUrl: '', googleSheetProcessedRows: [],
      isLocalSeoEnabled: false, 
      localSeoBusinessName: '', 
      localSeoServiceArea: '', 
      localSeoPhoneNumber: '',
      socialMediaSettings: { ...defaultSocialSettings },
      seoDataProvider: 'google_search',
      modelConfig: defaultModelConfig,
      apiKeys: { ...defaultApiKeys },
      apiUsage: { ...defaultApiUsage },
      fetchedModels: {},
      dataforseoSeedKeywords: '', dataforseoTargetLocation: 'us', dataforseoTargetLanguage: 'en',
      dataforseoKeywordDifficultyMin: 0, dataforseoKeywordDifficultyMax: 30,
      dataforseoSearchVolumeMin: 500, dataforseoSearchVolumeMax: 10000,
      isSocialGraphicAutomationEnabled: true, socialGraphicAutomationTrigger: 'interval',
      socialGraphicAutomationIntervalHours: 48, socialGraphicRecurringSchedules: [],
      socialGraphicGenerationSource: 'keyword',
      isSocialVideoAutomationEnabled: true, socialVideoAutomationTrigger: 'interval',
      socialVideoAutomationIntervalHours: 72, socialVideoRecurringSchedules: [],
      socialVideoGenerationSource: 'keyword',
      googleDrive: { isConnected: false, userEmail: '' },
      googleAnalytics: { isConnected: false, userEmail: '' },
      isBacklinksAutomationEnabled: false,
      backlinksCompetitors: '',
      backlinksOwnDomain: '',
      backlinksEmailProvider: 'mailgun',
      backlinksFromName: '',
      backlinksFromEmail: '',
      backlinksEmailSubject: 'Regarding your article',
      backlinksEmailBody: 'Hi,\n\nI was just reading your article and really enjoyed it.\n\n[Personalization]\n\nI thought your readers might also find this resource useful. Let me know if you\'d be interested in taking a look.\n\nThanks,\n[Your Name]',
      backlinksHistory: [],
      backlinksIntervalHours: 168,
      commentingProspects: [],
      isSocialCommentingEnabled: false,
      socialCommentingKeywords: 'AI in marketing\n#SEOtips\ndigital strategy',
      socialCommentingGuideline: 'Write a positive and insightful comment. Ask a question to encourage a reply. Do not include links or self-promotion.',
      socialCommentingProspects: [],
      monitoredBacklinks: [],
      isBacklinkMonitoringEnabled: false,
      isEmailFollowUpEnabled: true,
      isSocialFollowUpEnabled: true,
      emailMarketingSettings: {
        fromName: '',
        fromEmail: '',
        targetList: '',
      },
      emailMarketingModelConfig: defaultModelConfig,
      isEmailMarketingAutomationEnabled: false,
      emailMarketingAutomationTrigger: 'interval',
      emailMarketingAutomationIntervalHours: 168,
      emailMarketingRecurringSchedules: [],
      isDigestAutomationEnabled: false,
      digestRecurringSchedules: [],
      processedDigestGuids: [],
      digestAutomationModelConfig: defaultModelConfig,
      mailchimp: { isConnected: false, apiKey: '', serverPrefix: '', status: 'disconnected' },
      automationLock: null,
    };
    setSitesWithSave(prev => {
        const finalNewSite = { ...newSite, name: `New Site ${prev.length + 1}` };
        setSelectedSiteId(finalNewSite.id);
        return [...prev, finalNewSite];
    });
  }, [setSitesWithSave]);

  const handleDeleteSite = useCallback((siteIdToDelete: string) => {
    setSitesWithSave(prevSites => {
      const sitesAfterDeletion = prevSites.filter(s => s.id !== siteIdToDelete);
      if (selectedSiteId === siteIdToDelete) {
        setSelectedSiteId(sitesAfterDeletion.length > 0 ? sitesAfterDeletion[0].id : null);
      }
      return sitesAfterDeletion;
    });
  }, [selectedSiteId, setSitesWithSave]);

  const handleResetAllSitesSpend = useCallback(() => {
    setSitesWithSave(prevSites => 
        prevSites.map(site => {
            const resetUsage: Partial<Record<keyof ApiKeys, number>> = {};
            for (const key in site.apiKeys) {
                resetUsage[key as keyof ApiKeys] = 0;
            }
            return { ...site, apiUsage: resetUsage };
        })
    );
  }, [setSitesWithSave]);

  const selectedSite = sites.find(s => s.id === selectedSiteId);

  return {
    sites,
    setSites: setSitesWithSave,
    selectedSite,
    selectedSiteId,
    setSelectedSiteId,
    isSaved,
    isSaving,
    isLoading,
    handleSiteUpdate,
    handleMultipleSiteUpdates,
    handleAddNewSite,
    handleDeleteSite,
    handleResetAllSitesSpend,
  }
};