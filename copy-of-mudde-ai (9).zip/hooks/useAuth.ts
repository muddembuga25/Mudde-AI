import { useState, useEffect, useCallback } from 'react';
import type { User, StoredUser, UserSubscription } from '../types';
import { SubscriptionPlan } from '../types';
import * as mcpApiService from '../services/mcpApiService';

async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

const JWT_KEY = 'mcp-jwt';

const createDefaultSubscription = (plan: SubscriptionPlan = SubscriptionPlan.FREE): UserSubscription => {
    const credits = { socialGraphics: 0, socialVideo: 0 };
    if (plan === SubscriptionPlan.FREE) {
        credits.socialGraphics = 1; // 1 free credit for Creator feature
    }
    if (plan === SubscriptionPlan.CREATOR) {
        credits.socialVideo = 1; // 1 free credit for Pro feature
    }

    return {
        plan,
        postsGeneratedThisMonth: 0,
        renewalDate: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 days from now
        featureCredits: credits,
        commentingActionsThisMonth: 0,
    };
};

export const useAuth = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const persistSession = (user: User, token: string) => {
      setCurrentUser(user);
      localStorage.setItem(JWT_KEY, token);
  }
  
  useEffect(() => {
    const validateSession = async () => {
        const token = localStorage.getItem(JWT_KEY);
        if (token) {
            try {
                const user = await mcpApiService.validateToken(token);
                if (user) {
                    setCurrentUser(user);
                } else {
                    localStorage.removeItem(JWT_KEY);
                }
            } catch (e) {
                console.error("Session validation failed:", e);
                localStorage.removeItem(JWT_KEY);
            }
        }
        setIsLoading(false);
    };
    validateSession();
  }, []);
  
  const login = useCallback(async (username: string, password: string) => {
    setError(null);
    const passwordHash = await hashPassword(password);
    const { user, token } = await mcpApiService.login(username, passwordHash);
    persistSession(user, token);
  }, []);

  const signup = useCallback(async (details: Omit<StoredUser, 'passwordHash' | 'subscription' | 'avatarUrl'> & { password: string}) => {
    const { username, password, displayName, email } = details;
    setError(null);
    if (!username.trim() || !password.trim() || !displayName.trim() || !email.trim()) {
        const msg = "All fields are required.";
        setError(msg);
        throw new Error(msg);
    }

    const passwordHash = await hashPassword(password);
    const newUserRecord: StoredUser = { username, displayName, email, passwordHash, subscription: createDefaultSubscription(), avatarUrl: '' };
    
    const { user, token } = await mcpApiService.signup(newUserRecord);
    persistSession(user, token);
  }, []);

  const loginWithGoogle = useCallback(async () => {
    setError(null);
    // This is a simplified simulation for the new architecture.
    // In a real app, this would involve a popup, getting a Google token,
    // and sending it to our backend for verification and session creation.
    const googleUsername = "Google User";
    const googlePassword = "simulated_google_password"; // A placeholder
    try {
        await login(googleUsername, googlePassword);
    } catch (e) {
        // If the user doesn't exist, sign them up
        await signup({
            username: googleUsername,
            displayName: 'Google User',
            email: 'google.user@example.com',
            password: googlePassword
        });
    }
  }, [login, signup]);

  const logout = useCallback(() => {
    setCurrentUser(null);
    localStorage.removeItem(JWT_KEY);
  }, []);
  
  const updateSubscription = useCallback((newPlan: SubscriptionPlan) => {
    // In a real app, this would be a server call.
    // For the simulation, we'll update client state and the mock DB.
    setError(null);
    setCurrentUser(prevUser => {
      if (!prevUser) return null;
      
      const newSubscription = createDefaultSubscription(newPlan);
      
      const updatedUser = { ...prevUser, subscription: newSubscription };
      // TODO: Add a mcpApiService.updateUser call here
      persistSession(updatedUser, localStorage.getItem(JWT_KEY)!);
      
      return updatedUser;
    });
  }, []);

  const incrementPostCount = useCallback(() => {
    // In a real app, this would be a server call.
    setCurrentUser(prevUser => {
        if (!prevUser) return null;

        const newCount = prevUser.subscription.postsGeneratedThisMonth + 1;
        const updatedSubscription = { ...prevUser.subscription, postsGeneratedThisMonth: newCount };
        const updatedUser = { ...prevUser, subscription: updatedSubscription };

        // TODO: Add a mcpApiService.updateUser call here
        persistSession(updatedUser, localStorage.getItem(JWT_KEY)!);
        return updatedUser;
    });
  }, []);

  const updateProfile = useCallback(async (updates: Partial<Pick<User, 'displayName' | 'email' | 'avatarUrl'>>) => {
    // TODO: In a real app, this would call mcpApiService.updateProfile
    setError(null);
    setCurrentUser(prevUser => {
        if (!prevUser) return null;
        const updatedUser = { ...prevUser, ...updates };
        persistSession(updatedUser, localStorage.getItem(JWT_KEY)!);
        return updatedUser;
    });
  }, []);

  const changePassword = useCallback(async (currentPassword: string, newPassword: string) => {
    // TODO: In a real app, this would call mcpApiService.changePassword
    if (!currentUser) return;
    setError(null);
    console.log("Simulating password change for user:", currentUser.username);
    // This function would now make a secure call to the backend.
    // The mock service doesn't have a password change endpoint yet, but this is where it would be called.
  }, [currentUser]);

  const useFeatureCredit = useCallback((feature: 'socialGraphics' | 'socialVideo') => {
    setCurrentUser(prevUser => {
        if (!prevUser) return null;
        const currentCredits = prevUser.subscription.featureCredits || { socialGraphics: 0, socialVideo: 0 };
        if (currentCredits[feature] > 0) {
            const newCredits = { ...currentCredits, [feature]: currentCredits[feature] - 1 };
            const updatedSubscription = { ...prevUser.subscription, featureCredits: newCredits };
            const updatedUser = { ...prevUser, subscription: updatedSubscription };
            // TODO: Persist this change via mcpApiService
            persistSession(updatedUser, localStorage.getItem(JWT_KEY)!);
            return updatedUser;
        }
        return prevUser;
    });
  }, []);

  const incrementCommentingActions = useCallback(() => {
      setCurrentUser(prevUser => {
          if (!prevUser) return null;
          const currentCount = prevUser.subscription.commentingActionsThisMonth || 0;
          const updatedSubscription = { ...prevUser.subscription, commentingActionsThisMonth: currentCount + 1 };
          const updatedUser = { ...prevUser, subscription: updatedSubscription };
          // TODO: Persist this change via mcpApiService
          persistSession(updatedUser, localStorage.getItem(JWT_KEY)!);
          return updatedUser;
      });
  }, []);

  return { currentUser, login, signup, loginWithGoogle, logout, updateProfile, changePassword, error, setError, updateSubscription, incrementPostCount, isLoading, useFeatureCredit, incrementCommentingActions };
};