import React, { useState, useCallback, useEffect, useMemo, useRef } from 'react';
import { AppStatus, AiProvider, SubscriptionPlan, StrategicBrief } from './types';
import type { BlogPost, Site, RssItem, PostHistoryItem, ApiKeys, SocialMediaPost, SocialMediaSettings, Draft, WhatsAppAccount, TelegramAccount, SocialMediaAccount, ReferenceItem, LogEntry, LogLevel, MCPServer, PostPerformanceData, SelfTestResult, RecurringSchedule, SeoChecklist } from './types';
import * as mcpApiService from './services/mcpApiService';
import * as selfTestService from './services/selfTestService';
import { calculateSeoScore } from './services/seoService';
import * as oauthService from './services/oauthService';
import * as googleDriveService from './services/googleDriveService';
import { useSites } from './hooks/useSites';
import { useAuth } from './contexts/AuthContext';
// FIX: Import the useAutomatedJobs hook.
import { useAutomatedJobs } from './hooks/useAutomatedJobs';
import { providerDisplayNames, PLAN_LIMITS } from './constants';
import { LogoIcon, CheckCircleIcon, ExclamationTriangleIcon, Cog6ToothIcon, ClockIcon, DocumentTextIcon, ArchiveBoxIcon, MenuIcon, XIcon, KeyIcon, PhotoIcon, PenIcon, ShareIcon, UserCircleIcon, ArrowRightOnRectangleIcon, SparklesIcon, ChevronDownIcon, LinkIcon, CreditCardIcon, CommandLineIcon, ServerIcon, ChartBarIcon, ChatBubbleLeftRightIcon, MicrophoneIcon, WordPressIcon, ShieldCheckIcon, StopCircleIcon, SpinnerIcon, PlusIcon, HomeIcon, RssIcon, VideoCameraIcon, GoogleSheetsIcon, MailIcon, HostingIcon } from './components/Icons';
import { HistoryDetailViewer } from './components/HistoryDetailViewer';
import { AutomationDashboard } from './components/AutomationDashboard';
import { ArticleViewer } from './components/ArticleViewer';
import { DashboardTab } from './components/DashboardTab';
import { KeywordContentTab } from './components/KeywordContentTab';
import { RssContentTab } from './components/RssContentTab';
import { VideoContentTab } from './components/VideoContentTab';
import { GoogleSheetContentTab } from './components/GoogleSheetContentTab';
import { HistoryTab } from './components/HistoryTab';
import { SettingsTab } from './components/SettingsTab';
import { WordPressTab } from './components/WordPressTab';
import { PublishSuccessViewer } from './components/PublishSuccessViewer';
import { DraftsTab } from './components/DraftsTab';
import { ProfileModal } from './components/ProfileModal';
import { APIKeysTab } from './components/APIKeysTab';
import { SocialMediaTab } from './components/SocialMediaTab';
import { ReferencesTab } from './components/ReferencesTab';
import { BacklinksTab } from './components/BacklinksTab';
import { BillingTab } from './components/BillingTab';
import { SocialGraphicsTab } from './components/SocialGraphicsTab';
import { EmailMarketingTab } from './components/EmailMarketingTab';
import { MCPTab } from './components/MCPTab';
import { AnalyticsTab } from './components/AnalyticsTab';
import { IntegrationsTab } from './components/IntegrationsTab';
import { HostingTab } from './components/HostingTab';
import { GeminiLiveAssistant } from './components/GeminiLiveAssistant';
import { GlobalAutomationTracker } from './components/GlobalAutomationTracker';
import { fetchAndParseRssFeed } from './services/rssService';
import { fetchGoogleSheetData } from './services/googleSheetsService';
import type { GoogleSheetRow } from './services/googleSheetsService';

declare global {
  var google: any;
}

const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: HomeIcon },
    {
      id: 'content',
      label: 'Content Sources',
      icon: DocumentTextIcon,
      children: [
        { id: 'content-keywords', label: 'Keywords', icon: PenIcon },
        { id: 'content-rss', label: 'RSS Feeds', icon: RssIcon },
        { id: 'content-video', label: 'Video', icon: VideoCameraIcon },
        { id: 'content-sheets', label: 'Google Sheets', icon: GoogleSheetsIcon },
      ],
    },
    { id: 'social-graphics', label: 'Social Graphics', icon: PhotoIcon, feature: 'socialGraphics' as const },
    { id: 'email-marketing', label: 'Email Marketing', icon: MailIcon, feature: 'emailMarketing' as const },
    { id: 'drafts', label: 'Drafts', icon: DocumentTextIcon },
    { id: 'history', label: 'History', icon: ArchiveBoxIcon },
    { id: 'automation', label: 'Automation', icon: ClockIcon },
    { id: 'wordpress', label: 'WordPress', icon: WordPressIcon },
    { id: 'hosting', label: 'Hosting', icon: HostingIcon },
    { id: 'integrations', label: 'Integrations', icon: ShieldCheckIcon },
    { id: 'analytics', label: 'Analytics', icon: ChartBarIcon, feature: 'viewAnalytics' as const },
    { id: 'backlinks', label: 'Backlinks', icon: LinkIcon },
    { id: 'references', label: 'References', icon: Cog6ToothIcon },
    { id: 'social', label: 'Social Accounts', icon: ShareIcon },
    { id: 'keys', label: 'API Keys', icon: KeyIcon },
    { id: 'billing', label: 'Billing', icon: CreditCardIcon },
    { id: 'mcp', label: 'MCP', icon: CommandLineIcon },
];

type NavItemType = (typeof navItems)[number];
interface NavLinkProps {
    item: NavItemType | NavItemType['children'][number];
    isChild?: boolean;
};

const getInitials = (name: string = '') => {
    const names = name.split(' ');
    if (names.length > 1 && names[0] && names[names.length - 1]) {
        return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
};

interface AutomationState {
  status: AppStatus;
  statusMessage: string;
  topic: string | null;
  siteId: string;
}

export const MainApp: React.FC = () => {
    const { currentUser, logout, incrementPostCount } = useAuth();
    const { sites, setSites, selectedSite, selectedSiteId, setSelectedSiteId, isSaving, isSaved, isLoading: isLoadingSites, handleSiteUpdate, handleMultipleSiteUpdates, handleAddNewSite, handleDeleteSite, handleResetAllSitesSpend } = useSites(currentUser);

    // Generation Flow State
    const [automationStates, setAutomationStates] = useState<Record<string, AutomationState>>({});
    const [seoScore, setSeoScore] = useState<any | null>(null);
    const [publishedPostUrl, setPublishedPostUrl] = useState<string | null>(null);
    const [publishingLog, setPublishingLog] = useState<any[]>([]);
    const [reviewingDraft, setReviewingDraft] = useState<Draft | null>(null);
    
    // UI State
    const [activeTab, setActiveTab] = useState('dashboard');
    const [openNavSections, setOpenNavSections] = useState<Record<string, boolean>>({ content: true });
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const errorTimeoutRef = useRef<number | null>(null);
    const [isSiteListOpen, setIsSiteListOpen] = useState(true);
    
    // Modals & Viewers
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
    const [deleteConfirmationInput, setDeleteConfirmationInput] = useState('');
    const [viewingHistoryItem, setViewingHistoryItem] = useState<PostHistoryItem | null>(null);
    const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
    
    // Social & OAuth
    const [isConnectingSocial, setIsConnectingSocial] = useState<string | null>(null);

    // Data Fetching State for Content Source Tabs
    const [rssFeed, setRssFeed] = useState<RssItem[] | null>(null);
    const [isFetchingRss, setIsFetchingRss] = useState(false);
    const [sheetData, setSheetData] = useState<GoogleSheetRow[] | null>(null);
    const [isFetchingSheet, setIsFetchingSheet] = useState(false);
    const [channelVideos, setChannelVideos] = useState<Record<string, RssItem[]>>({});
    const [isFetchingChannel, setIsFetchingChannel] = useState<string | null>(null);

    // MCP State
    const [logs, setLogs] = useState<LogEntry[]>([]);
    const [mcpServers, setMcpServers] = useState<MCPServer[]>([]);
    const [activeMCPServerId, setActiveMCPServerId] = useState<string | null>(null);
    const [activeMCPView, setActiveMCPView] = useState<'state' | 'logs' | 'actions' | 'servers' | 'selftest' | 'dataforseo'>('selftest');
    const [filteredMCPLogs, setFilteredMCPLogs] = useState<LogEntry[] | null>(null);
    const [testResults, setTestResults] = useState<Record<string, SelfTestResult>>(() => {
        const allTestIds = Object.values(selfTestService.testCategories).flat();
        const initialResults: Record<string, SelfTestResult> = {};
        allTestIds.forEach(id => {
            initialResults[id] = { id, status: 'untested' };
        });
        return initialResults;
    });
    
    // Analytics State
    const [performanceData, setPerformanceData] = useState<PostPerformanceData[] | undefined>(undefined);
    const [isFetchingPerformanceData, setIsFetchingPerformanceData] = useState(false);

    // Google API State
    const gapiTokenClient = useRef<any>(null);

    const planFeatures = useMemo(() => PLAN_LIMITS[currentUser?.subscription.plan || 'free'].features, [currentUser]);
    
    const selectedSiteAutomationState = useMemo(() => selectedSiteId ? automationStates[selectedSiteId] : undefined, [automationStates, selectedSiteId]);
    const isAnyJobRunning = Object.keys(automationStates).length > 0;

    const addLog = useCallback((message: string, type: LogLevel, siteId: string = selectedSiteId || 'global') => {
        setLogs(prev => [{ timestamp: Date.now(), message, type, siteId }, ...prev.slice(0, 199)]);
    }, [selectedSiteId]);
    
    const handleProgressUpdate = useCallback((update: { siteId: string, status: AppStatus, statusMessage: string, topic?: string }) => {
        setAutomationStates(prev => {
            const newStates = { ...prev };
            const isFinalState = [AppStatus.IDLE, AppStatus.PUBLISHED, AppStatus.ERROR].includes(update.status);
            
            if (isFinalState) {
                if (newStates[update.siteId]) {
                     newStates[update.siteId] = {
                        ...newStates[update.siteId],
                        status: update.status,
                        statusMessage: update.statusMessage,
                    };
                    setTimeout(() => {
                        setAutomationStates(p => {
                            const finalStates = { ...p };
                            delete finalStates[update.siteId];
                            return finalStates;
                        });
                    }, 5000);
                }
            } else {
                newStates[update.siteId] = {
                    siteId: update.siteId,
                    status: update.status,
                    statusMessage: update.statusMessage,
                    topic: update.topic || prev[update.siteId]?.topic || null,
                };
            }
            return newStates;
        });
    }, []);

    // FIX: Use the useAutomatedJobs hook to manage the automation scheduler.
    // This replaces the old useEffect which called non-existent functions.
    const { isBacklinksJobRunning, runBacklinksJobNow } = useAutomatedJobs(sites, setSites, addLog, handleProgressUpdate);

    const setErrorWithTimeout = useCallback((errorMessage: string | null) => {
        setError(errorMessage);
        if (errorTimeoutRef.current) clearTimeout(errorTimeoutRef.current);
        if (errorMessage) {
            errorTimeoutRef.current = window.setTimeout(() => setError(null), 8000);
        }
    }, []);

    const resetGenerationState = useCallback(() => {
        setAutomationStates({});
        setSeoScore(null);
        setPublishedPostUrl(null);
        setPublishingLog([]);
        setReviewingDraft(null);
    }, []);
    
    const onGenerateAndScore = useCallback(async (
        topicToTrack: string,
        generationSource: 'keyword' | 'rss' | 'video' | 'google_sheet' | 'ai_assistant',
        sourceDetails: RssItem | string | GoogleSheetRow,
        site: Site,
        options?: { sourceId?: string; videoItem?: RssItem }
    ) => {
        if (!site || !currentUser) return;
        if (currentUser.subscription.postsGeneratedThisMonth >= PLAN_LIMITS[currentUser.subscription.plan].posts) {
            setErrorWithTimeout(`You have reached your monthly limit of ${PLAN_LIMITS[currentUser.subscription.plan].posts} posts. Please upgrade your plan to continue.`);
            return;
        }
        resetGenerationState();
        
        try {
            const serviceSourceType = generationSource === 'ai_assistant' ? 'keyword' : generationSource;
            
            const progressCallback = (update: { status: AppStatus; message: string; cost?: any }) => {
                handleProgressUpdate({ siteId: site.id, status: update.status, statusMessage: update.message, topic: topicToTrack });
                if (update.cost) {
                    handleMultipleSiteUpdates(logApiUsage(site, update.cost.provider, update.cost.amount));
                }
            };

            const { draft, score, updatedSite } = await mcpApiService.runManualGenerationPipeline(
                site.id, serviceSourceType, sourceDetails, options, progressCallback
            );

            handleMultipleSiteUpdates(updatedSite);
            setSeoScore(score);
            addLog(`[${topicToTrack}] Final SEO score: ${score.score}.`, 'INFO', site.id);
            setReviewingDraft(draft);
            incrementPostCount();
        } catch (error: any) {
            handleProgressUpdate({ siteId: site.id, status: AppStatus.ERROR, statusMessage: error.message || 'An unknown error occurred during content generation.', topic: topicToTrack });
            setErrorWithTimeout(error.message || 'An unknown error occurred during content generation.');
            addLog(`[${topicToTrack}] Generation failed: ${error.message}`, 'ERROR', site.id);
        }
    }, [currentUser, setErrorWithTimeout, incrementPostCount, resetGenerationState, handleMultipleSiteUpdates, addLog, handleProgressUpdate]);

    const onPublish = useCallback(async (editedPost: BlogPost) => {
        if (!selectedSite || !reviewingDraft) return;
        const topic = reviewingDraft.sourceTopic;
        handleProgressUpdate({ siteId: selectedSite.id, status: AppStatus.PUBLISHING, statusMessage: "Publishing to WordPress...", topic });
        addLog(`[${topic}] Publishing to WordPress...`, 'INFO', selectedSite.id);
        setErrorWithTimeout(null);
        setPublishingLog([]);

        try {
            const { postUrl, publishingLog, updatedSite } = await mcpApiService.publishPostAndFollowUps(selectedSite.id, reviewingDraft, editedPost);
            setSites(prev => prev.map(s => s.id === updatedSite.id ? updatedSite : s));
            
            setPublishedPostUrl(postUrl);
            setPublishingLog(publishingLog);
            addLog(`[${topic}] Published successfully: ${postUrl}`, 'SUCCESS', selectedSite.id);
            handleProgressUpdate({ siteId: selectedSite.id, status: AppStatus.PUBLISHED, statusMessage: "Published!", topic });
        } catch (error: any) {
            handleProgressUpdate({ siteId: selectedSite.id, status: AppStatus.ERROR, statusMessage: error.message || 'Publishing Failed', topic });
            setErrorWithTimeout(error.message || 'An unknown error occurred during publishing.');
            addLog(`[${topic}] Publishing failed: ${error.message}`, 'ERROR', selectedSite.id);
        }
    }, [selectedSite, reviewingDraft, addLog, setErrorWithTimeout, setSites, handleProgressUpdate]);
    
    const handleDeleteSiteDialog = () => {
        if (deleteConfirmationInput === selectedSite?.name) {
            handleDeleteSite(selectedSite.id);
            setIsDeleteDialogOpen(false);
            setDeleteConfirmationInput('');
        }
    };

    const handleReviewDraft = useCallback((draftId: string) => {
        const draft = selectedSite?.drafts.find(d => d.id === draftId);
        if (draft) {
            setReviewingDraft(draft);
            setSeoScore(calculateSeoScore(draft.blogPost, {} as StrategicBrief));
            handleProgressUpdate({ siteId: selectedSite!.id, status: AppStatus.READY_TO_PUBLISH, statusMessage: "Ready to publish!", topic: draft.sourceTopic });
        }
    }, [selectedSite, handleProgressUpdate]);
    
    const handleDiscardDraft = useCallback((draftId: string) => {
        if (selectedSite) {
            const updatedDrafts = selectedSite.drafts.filter(d => d.id !== draftId);
            handleSiteUpdate('drafts', updatedDrafts);
        }
    }, [selectedSite, handleSiteUpdate]);

    const handleConnectSocial = useCallback((platform: keyof Omit<SocialMediaSettings, 'whatsapp' | 'telegram'>, accountId: string) => {
        if (!selectedSite) return;
        const account = (selectedSite.socialMediaSettings[platform] as SocialMediaAccount[] | undefined)?.find(a => a.id === accountId);
        if (account && account.clientId) {
            setIsConnectingSocial(`${platform}-${accountId}`);
            oauthService.redirectToAuth(platform, account.clientId, selectedSite.id, accountId);
        } else {
            setErrorWithTimeout(`Client ID is missing for this ${platform} account.`);
        }
    }, [selectedSite, setErrorWithTimeout]);

    const handleVerifySocial = useCallback(async (platform: oauthService.SocialPlatform, accountId: string, accessToken: string) => {
        if (!selectedSite) return;
        try {
            const { updatedSite } = await mcpApiService.verifySocialConnection(selectedSite.id, platform, accountId, accessToken);
            handleMultipleSiteUpdates(updatedSite);
        } catch(e: any) {
            setErrorWithTimeout(e.message);
        }
    }, [selectedSite, handleMultipleSiteUpdates, setErrorWithTimeout]);
    
    const handleVerifyCredentials = useCallback(async (platform: 'whatsapp' | 'telegram', account: WhatsAppAccount | TelegramAccount) => {
        if (!selectedSite) return;
        try {
            const { updatedSite } = await mcpApiService.verifyCredentialConnection(selectedSite.id, platform, account);
            handleMultipleSiteUpdates(updatedSite);
        } catch(e: any) {
            setErrorWithTimeout(e.message);
        }
    }, [selectedSite, handleMultipleSiteUpdates, setErrorWithTimeout]);

    useEffect(() => {
        const handleCallback = async () => {
            const callbackData = oauthService.handleOAuthCallback();
            if (callbackData && selectedSite) {
                try {
                    const { platform, accountId, code } = callbackData;
                    const { updatedSite } = await mcpApiService.exchangeCodeForToken(selectedSite.id, platform as oauthService.SocialPlatform, accountId, code);
                    handleMultipleSiteUpdates(updatedSite);
                } catch (e: any) {
                    setErrorWithTimeout(e.message || 'Failed to exchange code for token.');
                } finally {
                    setIsConnectingSocial(null);
                }
            }
        };
        handleCallback();
    }, [selectedSite, handleMultipleSiteUpdates, setErrorWithTimeout]);

    useEffect(() => {
        const fetchAnalytics = async () => {
            if (activeTab === 'analytics' && selectedSite?.googleAnalytics?.isConnected && performanceData === undefined) {
                setIsFetchingPerformanceData(true);
                setErrorWithTimeout(null);
                try {
                    const { performanceData: data } = await mcpApiService.getAnalyticsData(selectedSite.id);
                    setPerformanceData(data);
                } catch (e: any) {
                    setErrorWithTimeout(e.message);
                } finally {
                    setIsFetchingPerformanceData(false);
                }
            }
        };
        fetchAnalytics();
    }, [activeTab, selectedSite, performanceData, setErrorWithTimeout]);
    
    const handleConnectGoogleDrive = useCallback(() => {
        if (!selectedSite?.apiKeys.googleClientId || !selectedSite.apiKeys.google) {
            setErrorWithTimeout("Please set your Google API Key and Google Client ID in the API Keys tab first.");
            return;
        }

        const onTokenResponse = async (tokenResponse: any) => {
            if (tokenResponse.error) {
                setErrorWithTimeout(`Google Drive connection failed: ${tokenResponse.error}`);
                return;
            }
            try {
                const { updatedSite } = await mcpApiService.connectGoogleDrive(selectedSite.id, tokenResponse.access_token);
                setSites(prev => prev.map(s => s.id === selectedSite.id ? updatedSite : s));
            } catch (e: any) {
                setErrorWithTimeout(e.message);
            }
        };

        if (gapiTokenClient.current) {
            gapiTokenClient.current.requestAccessToken({ prompt: 'consent' });
        } else {
            google.accounts.oauth2.initTokenClient({
                client_id: selectedSite.apiKeys.googleClientId,
                scope: 'https://www.googleapis.com/auth/drive.file',
                callback: onTokenResponse,
                error_callback: (error: any) => setErrorWithTimeout(`Google OAuth Error: ${error.message}`),
            }).requestAccessToken({ prompt: 'consent' });
        }
    }, [selectedSite, setErrorWithTimeout, setSites]);
    
    const handleDisconnectGoogleDrive = useCallback(async () => {
        if (!selectedSite) return;
        try {
            const { updatedSite } = await mcpApiService.disconnectGoogleDrive(selectedSite.id);
            setSites(prev => prev.map(s => s.id === selectedSite.id ? updatedSite : s));
        } catch (e: any) {
            setErrorWithTimeout(e.message);
        }
    }, [selectedSite, setErrorWithTimeout, setSites]);

    const handleShowGooglePicker = useCallback(() => {
        console.log("Triggering Google Picker from MainApp (handled in ReferencesTab)");
    }, []);

    const handleSaveToDrive = async (title: string, content: string) => {
        if (!selectedSite?.googleDrive?.isConnected) {
            setErrorWithTimeout("Google Drive is not connected.");
            return;
        }

        try {
            const onTokenResponse = async (tokenResponse: any) => {
                if (tokenResponse.error) throw new Error(tokenResponse.error);
                const docUrl = await googleDriveService.createDocFromHtml(title, content, tokenResponse.access_token);
                addLog(`Successfully saved article to Google Drive: ${docUrl}`, 'SUCCESS', selectedSite.id);
            };
            
            google.accounts.oauth2.initTokenClient({
                client_id: selectedSite.apiKeys.googleClientId,
                scope: 'https://www.googleapis.com/auth/drive.file',
                callback: onTokenResponse,
                error_callback: (error: any) => { throw new Error(error.message) },
            }).requestAccessToken({ prompt: '' });

        } catch (e: any) {
            setErrorWithTimeout(`Failed to save to Google Drive: ${e.message}`);
        }
    };
    
    const logApiUsage = useCallback((provider: keyof ApiKeys, cost: number) => {
        if (!selectedSiteId) return;
        setSites(prevSites =>
            prevSites.map(site => {
                if (site.id === selectedSiteId) {
                    const currentCost = site.apiUsage?.[provider] || 0;
                    const newApiUsage = { ...site.apiUsage, [provider]: currentCost + cost };
                    return { ...site, apiUsage: newApiUsage };
                }
                return site;
            })
        );
    }, [selectedSiteId, setSites]);

    const findNextTopic = useCallback(async () => {
        if (!selectedSite) return null;
        const { masterAutomationSource, keywordList, processedRssGuids, rssFeedUrl, videoSources, googleSheetUrl, googleSheetProcessedRows } = selectedSite;
        switch (masterAutomationSource) {
            case 'keyword': {
                const keywords = keywordList.split('\n').filter(k => k.trim() && !k.trim().startsWith('[DONE]'));
                if (keywords.length > 0) return { topic: keywords[0], sourceType: 'keyword', sourceDetails: keywords[0] };
                break;
            }
            case 'rss': {
                if (!rssFeedUrl) break;
                let currentFeed = rssFeed;
                if (!currentFeed) {
                    try {
                        const { items } = await fetchAndParseRssFeed(rssFeedUrl);
                        setRssFeed(items);
                        currentFeed = items;
                    } catch { return null; }
                }
                const newItem = currentFeed.find(i => !processedRssGuids.includes(i.guid));
                if (newItem) return { topic: newItem.title, sourceType: 'rss', sourceDetails: newItem };
                break;
            }
            case 'video': case 'google_sheet': return null;
        }
        return null;
    }, [selectedSite, rssFeed, setRssFeed]);

    const handleDismissTracker = (siteId: string) => {
        setAutomationStates(prev => {
            const newStates = { ...prev };
            delete newStates[siteId];
            return newStates;
        });
    };

    const triggerAutomation = useCallback(async (
        jobType: 'social_graphic' | 'social_video' | 'email_marketing' | 'email_digest',
        siteId: string
    ) => {
        if (!siteId) return;
        const site = sites.find(s => s.id === siteId);
        if (!site) return;

        const jobNameMap = {
            social_graphic: 'Social Graphic',
            social_video: 'Social Video',
            email_marketing: 'Email Marketing',
            email_digest: 'Email Digest',
        };
        const jobName = jobNameMap[jobType];

        addLog(`[${jobName}] Automation triggered for "${site.name}".`, 'INFO', site.id);
        
        try {
            const progressCallback = (update: { status: AppStatus; message: string; topic?: string }) => {
                handleProgressUpdate({ siteId: site.id, status: update.status, statusMessage: update.message, topic: update.topic || jobName });
            };

            let updatedSite: Site;
            switch (jobType) {
                case 'social_graphic':
                    updatedSite = await mcpApiService.runSocialGraphicAutomation(site.id, null, progressCallback);
                    break;
                case 'social_video':
                    updatedSite = await mcpApiService.runSocialVideoAutomation(site.id, null, progressCallback);
                    break;
                case 'email_marketing':
                    updatedSite = await mcpApiService.runEmailMarketingAutomation(site.id, null, progressCallback);
                    break;
                case 'email_digest':
                    updatedSite = await mcpApiService.runDigestAutomation(site.id, null, progressCallback);
                    break;
            }
            
            setSites(prev => prev.map(s => s.id === siteId ? updatedSite : s));
            addLog(`[${jobName}] Job completed successfully for "${site.name}".`, 'SUCCESS', site.id);
        } catch (error: any) {
            addLog(`[${jobName}] Job failed for site "${site.name}": ${error.message}`, 'ERROR', site.id);
            handleProgressUpdate({ siteId: site.id, status: AppStatus.ERROR, statusMessage: error.message, topic: jobName });
        }
    }, [sites, addLog, handleProgressUpdate, setSites]);


    const renderContent = () => {
        const status = selectedSiteAutomationState?.status;
        const statusMessage = selectedSiteAutomationState?.statusMessage || '';
        
        if (status === AppStatus.PUBLISHED) {
            return <PublishSuccessViewer publishedPostUrl={publishedPostUrl} publishingLog={publishingLog} onReset={resetGenerationState} />;
        }
        if (reviewingDraft) {
            return <ArticleViewer blogPost={reviewingDraft.blogPost} brief={{} as StrategicBrief} seoScore={seoScore} status={status || AppStatus.IDLE} statusMessage={statusMessage} site={selectedSite!} currentUser={currentUser!} onPublish={onPublish} onCancel={resetGenerationState} onSaveToDrive={handleSaveToDrive} setSites={setSites} />;
        }
        if (viewingHistoryItem) {
            return <HistoryDetailViewer post={viewingHistoryItem} />;
        }

        switch (activeTab) {
            case 'dashboard': return <DashboardTab site={selectedSite!} setActiveTab={setActiveTab} />;
            case 'content-keywords': return <KeywordContentTab site={selectedSite!} onSiteUpdate={handleSiteUpdate} setSites={setSites} onGenerateAndScore={onGenerateAndScore} setError={setErrorWithTimeout} />;
            case 'content-rss': return <RssContentTab site={selectedSite!} onSiteUpdate={handleSiteUpdate} onGenerateAndScore={onGenerateAndScore} setError={setErrorWithTimeout} rssFeed={rssFeed} setRssFeed={setRssFeed} isFetchingRss={isFetchingRss} setIsFetchingRss={setIsFetchingRss} />;
            case 'content-video': return <VideoContentTab site={selectedSite!} onSiteUpdate={handleSiteUpdate} onGenerateAndScore={onGenerateAndScore} setError={setErrorWithTimeout} channelVideos={channelVideos} setChannelVideos={setChannelVideos} isFetchingChannel={isFetchingChannel} setIsFetchingChannel={setIsFetchingChannel} />;
            case 'content-sheets': return <GoogleSheetContentTab site={selectedSite!} onSiteUpdate={handleSiteUpdate} onGenerateAndScore={onGenerateAndScore} setError={setErrorWithTimeout} sheetData={sheetData} setSheetData={setSheetData} isFetchingSheet={isFetchingSheet} setIsFetchingSheet={setIsFetchingSheet} />;
            case 'social-graphics': return <SocialGraphicsTab site={selectedSite!} onSiteUpdate={handleSiteUpdate} setSites={setSites} setError={setErrorWithTimeout} addLog={addLog} />;
            case 'email-marketing': return <EmailMarketingTab site={selectedSite!} onSiteUpdate={handleSiteUpdate} setSites={setSites} setError={setErrorWithTimeout} addLog={addLog} />;
            case 'drafts': return <DraftsTab drafts={selectedSite?.drafts || []} onReview={handleReviewDraft} onDiscard={handleDiscardDraft} />;
            case 'history': return <HistoryTab history={selectedSite?.history || []} onViewDetails={setViewingHistoryItem} />;
            case 'automation': return <AutomationDashboard site={selectedSite!} onSiteUpdate={handleSiteUpdate} onMultipleSiteUpdates={handleMultipleSiteUpdates} />;
            case 'wordpress': return <WordPressTab site={selectedSite!} onSiteUpdate={handleSiteUpdate} onMultipleSiteUpdates={handleMultipleSiteUpdates} setError={setErrorWithTimeout} />;
            case 'hosting': return <HostingTab site={selectedSite!} onSiteUpdate={handleSiteUpdate} />;
            case 'integrations': return <IntegrationsTab site={selectedSite!} onSiteUpdate={handleSiteUpdate} setActiveTab={setActiveTab} />;
            case 'analytics': return <AnalyticsTab site={selectedSite!} currentUser={currentUser!} performanceData={performanceData} isFetching={isFetchingPerformanceData} onConnect={() => {}} onDisconnect={() => {}} setError={setErrorWithTimeout} logApiUsage={logApiUsage} />;
            case 'backlinks': return <BacklinksTab site={selectedSite!} currentUser={currentUser!} onSiteUpdate={handleSiteUpdate} setSites={setSites} onRunBacklinksJob={runBacklinksJobNow} isBacklinksJobRunning={isBacklinksJobRunning} setError={setErrorWithTimeout} />;
            case 'references': return <ReferencesTab site={selectedSite!} onSiteUpdate={handleSiteUpdate} setSites={setSites} setError={setErrorWithTimeout} onConnectGoogleDrive={handleConnectGoogleDrive} onDisconnectGoogleDrive={handleDisconnectGoogleDrive} onShowGooglePicker={handleShowGooglePicker} />;
            case 'social': return <SocialMediaTab site={selectedSite!} onSiteUpdate={handleSiteUpdate} isConnectingSocial={isConnectingSocial} onConnect={handleConnectSocial} onVerify={handleVerifySocial} onVerifyCredentials={handleVerifyCredentials} />;
            case 'keys': return <APIKeysTab sites={sites} selectedSite={selectedSite!} onSiteUpdate={handleSiteUpdate} onResetAllSitesSpend={handleResetAllSitesSpend} setError={setErrorWithTimeout} />;
            case 'billing': return <BillingTab />;
            case 'mcp': return <MCPTab sites={sites} selectedSite={selectedSite} currentUser={currentUser} logs={logs} runBacklinksJobNow={runBacklinksJobNow} isBacklinksJobRunning={isBacklinksJobRunning} mcpServers={mcpServers} activeMCPServerId={activeMCPServerId} onAddServer={() => {}} onDeleteServer={() => {}} onConnectServer={() => {}} onDisconnectServer={() => {}} activeView={activeMCPView} setActiveView={setActiveMCPView} filteredLogs={filteredMCPLogs} testResults={testResults} setTestResults={setTestResults} />;
            default: return null;
        }
    };
    
    const NavLink: React.FC<NavLinkProps> = ({ item, isChild = false }) => {
        const isActive = activeTab === item.id;
        const isDisabled = 'feature' in item && item.feature && !planFeatures[item.feature];
        const baseClass = `flex items-center gap-3 py-2.5 rounded-md text-sm font-medium transition-colors w-full text-left relative ${isChild ? 'pl-10 pr-3' : 'px-3'}`;
        const activeClass = 'bg-purple-600/20 text-white';
        const inactiveClass = 'text-text-secondary hover:bg-panel-light hover:text-white';
        const disabledClass = 'opacity-50 cursor-not-allowed';
    
        if ('children' in item && item.children) {
            const isOpen = openNavSections[item.id] || activeTab.startsWith(item.id);
            return (
                <div>
                    <button
                        onClick={() => setOpenNavSections(prev => ({ ...prev, [item.id]: !isOpen }))}
                        className={`${baseClass} ${inactiveClass} ${isDisabled ? disabledClass : ''}`}
                    >
                        <item.icon className="h-5 w-5 flex-shrink-0" />
                        <span className="flex-1">{item.label}</span>
                        <ChevronDownIcon className={`h-4 w-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                    </button>
                    {isOpen && !isDisabled && (
                        <div className="mt-1 space-y-1 animate-fade-in">
                            {item.children.map(child => <NavLink key={child.id} item={child} isChild={true} />)}
                        </div>
                    )}
                </div>
            );
        }

        return (
            <button
                onClick={() => {
                    setActiveTab(item.id);
                    setViewingHistoryItem(null);
                    if (selectedSiteId) {
                        handleProgressUpdate({ siteId: selectedSiteId, status: AppStatus.IDLE, statusMessage: '' });
                    }
                    setIsSidebarOpen(false);
                }}
                disabled={isDisabled}
                className={`${baseClass} ${isActive ? activeClass : inactiveClass} ${isDisabled ? disabledClass : ''}`}
            >
                {'icon' in item && <item.icon className="h-5 w-5 flex-shrink-0" />}
                <span className="flex-1">{item.label}</span>
                {isDisabled && <span className="text-xs font-bold text-yellow-400 bg-yellow-900/50 px-2 py-0.5 rounded-full">UPGRADE</span>}
            </button>
        );
    };

    if (isLoadingSites) {
        return <div className="h-full flex items-center justify-center bg-background"><div className="flex items-center gap-2"><svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> <span className="text-text-secondary">Loading sites...</span></div></div>;
    }

    return (
        <div className="h-full flex flex-col md:flex-row">
            <div className={`fixed inset-y-0 left-0 z-40 w-64 bg-panel border-r border-border transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0 md:flex md:flex-shrink-0 transition-transform duration-300 ease-in-out`}>
                <div className="flex flex-col h-full">
                    <header className="flex items-center justify-between h-16 px-4 border-b border-border flex-shrink-0">
                        <div className="flex items-center gap-3 text-white font-bold"><LogoIcon /> Mudde AI</div>
                        <button onClick={() => setIsSidebarOpen(false)} className="md:hidden p-1 text-text-secondary hover:text-white"><XIcon className="h-6 w-6" /></button>
                    </header>
                    <div className="flex-1 overflow-y-auto p-4 space-y-4">
                        <div className="relative">
                            <button onClick={() => setIsSiteListOpen(!isSiteListOpen)} className="w-full flex items-center justify-between p-2 rounded-md bg-panel-light text-white font-semibold">
                                <span>{selectedSite?.name || 'No Site Selected'}</span>
                                <ChevronDownIcon className={`h-5 w-5 text-text-secondary transition-transform ${isSiteListOpen ? 'rotate-180' : ''}`} />
                            </button>
                            <div className={`site-list-container ${isSiteListOpen ? '' : 'collapsed'}`}>
                                <div className="min-h-0 overflow-hidden">
                                    <div className="p-2 space-y-1">
                                        {sites.map(site => (
                                            <button key={site.id} onClick={() => { setSelectedSiteId(site.id); setIsSidebarOpen(false); resetGenerationState(); }} className={`w-full text-left text-sm p-2 rounded-md ${site.id === selectedSiteId ? 'bg-purple-600/30 text-white' : 'text-text-secondary hover:bg-panel-light/50'}`}>
                                                {site.name}
                                            </button>
                                        ))}
                                        <button onClick={handleAddNewSite} className="w-full text-left text-sm p-2 rounded-md text-purple-400 hover:bg-panel-light/50 flex items-center gap-2"><PlusIcon className="h-4 w-4" /> Add New Site</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <nav className="flex-1 space-y-1">
                            {navItems.map(item => <NavLink key={item.id} item={item} />)}
                        </nav>
                    </div>
                    <footer className="p-4 border-t border-border flex-shrink-0">
                        <div className="flex items-center gap-3">
                            <button onClick={() => setIsProfileModalOpen(true)} className="flex items-center gap-3 w-full text-left p-2 rounded-md hover:bg-panel-light transition-colors">
                                {currentUser?.avatarUrl ? (
                                    <img src={currentUser.avatarUrl} alt="User Avatar" className="h-8 w-8 rounded-full object-cover" />
                                ) : (
                                    <div className="h-8 w-8 rounded-full bg-panel-light flex items-center justify-center text-xs font-bold text-purple-300 border border-border">
                                        {getInitials(currentUser?.displayName || '')}
                                    </div>
                                )}
                                <div className="flex-1 min-w-0">
                                    <p className="text-sm font-semibold text-white truncate">{currentUser?.displayName}</p>
                                    <p className="text-xs text-text-secondary">View Profile</p>
                                </div>
                            </button>
                            <button onClick={logout} className="p-2 text-text-secondary hover:text-white hover:bg-panel-light rounded-md transition-colors" title="Logout"><ArrowRightOnRectangleIcon className="h-6 w-6" /></button>
                        </div>
                        <div className="mt-2 text-xs text-text-secondary text-center">
                           Posts: {currentUser?.subscription.postsGeneratedThisMonth} / {PLAN_LIMITS[currentUser?.subscription.plan || 'free'].posts}
                           <div className="w-full bg-gray-700 rounded-full h-1.5 mt-1"><div className="bg-purple-500 h-1.5 rounded-full" style={{ width: `${Math.min(100, (currentUser?.subscription.postsGeneratedThisMonth || 0) / PLAN_LIMITS[currentUser?.subscription.plan || 'free'].posts * 100)}%` }}></div></div>
                        </div>
                    </footer>
                </div>
            </div>

            <div className="flex-1 flex flex-col overflow-hidden">
                <header className="md:hidden flex items-center justify-between h-16 px-4 border-b border-border bg-panel flex-shrink-0">
                    <button onClick={() => setIsSidebarOpen(true)} className="p-1 text-text-secondary hover:text-white"><MenuIcon className="h-6 w-6" /></button>
                    <div className="flex items-center gap-3 text-white font-bold"><LogoIcon /> Mudde AI</div>
                    <div className="w-6"></div>
                </header>
                <main className={`flex-1 overflow-y-auto p-4 md:p-8 transition-all duration-300 ${isAnyJobRunning ? 'pb-24' : ''}`}>
                    {error && (
                        <div className="fixed top-5 right-5 z-50 w-full max-w-sm bg-red-900/50 border border-red-500/50 text-red-300 p-4 rounded-lg shadow-2xl flex items-start gap-3 animate-fade-in-up">
                            <ExclamationTriangleIcon className="h-6 w-6 flex-shrink-0 mt-0.5" />
                            <div className="flex-1">
                                <p className="font-bold">Error</p>
                                <p className="text-sm">{error}</p>
                            </div>
                            <button onClick={() => setError(null)}><XIcon className="h-5 w-5" /></button>
                        </div>
                    )}
                    {isSaved && (
                         <div className="fixed top-5 right-5 z-50 w-full max-w-sm bg-green-900/50 border border-green-500/50 text-green-300 p-4 rounded-lg shadow-2xl flex items-start gap-3 animate-fade-in-up">
                            <CheckCircleIcon className="h-6 w-6 flex-shrink-0 mt-0.5" />
                            <div className="flex-1"><p className="font-bold">Saved</p><p className="text-sm">Your changes have been saved to the server.</p></div>
                        </div>
                    )}
                    
                    {selectedSite ? (
                        <div className={`${reviewingDraft || selectedSiteAutomationState?.status === AppStatus.PUBLISHED ? 'flex justify-center' : ''}`}>
                            {renderContent()}
                        </div>
                    ) : (
                        <div className="text-center h-full flex flex-col items-center justify-center">
                            <SparklesIcon className="h-16 w-16 text-text-secondary" />
                            <h2 className="text-2xl font-bold mt-4 text-white">Welcome to Mudde AI</h2>
                            <p className="text-text-secondary mt-2 max-w-md">It looks like you don't have any sites configured yet. Add a new site to get started!</p>
                            <button onClick={handleAddNewSite} className="mt-6 btn btn-primary flex items-center gap-2"><PlusIcon className="h-5 w-5" /> Add Your First Site</button>
                        </div>
                    )}
                </main>
                 {selectedSite && planFeatures.assistant && <GeminiLiveAssistant site={selectedSite} findNextTopic={findNextTopic} onGenerateAndScore={onGenerateAndScore} setSites={setSites} onTriggerAutomation={triggerAutomation} />}
                 {isAnyJobRunning && (
                    <GlobalAutomationTracker
                        automationStates={automationStates}
                        sites={sites}
                        onClose={handleDismissTracker}
                    />
                 )}
            </div>
            
            {isDeleteDialogOpen && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
                    <div className="bg-panel rounded-lg shadow-2xl w-full max-w-md p-6 border border-red-500/50 animate-modal-pop">
                        <div className="flex items-start gap-4">
                            <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-900/50 sm:mx-0 sm:h-10 sm:w-10"> <ExclamationTriangleIcon className="h-6 w-6 text-red-400" /> </div>
                            <div className="mt-0 text-left flex-1">
                                <h3 className="text-lg leading-6 font-bold text-white">Delete Site?</h3>
                                <div className="mt-2"> <p className="text-sm text-text-secondary"> Are you sure you want to delete "<strong>{selectedSite?.name}</strong>"? This action cannot be undone. </p> <p className="text-sm text-text-secondary mt-2"> To confirm, type the site name below: </p> </div>
                                <input type="text" value={deleteConfirmationInput} onChange={(e) => setDeleteConfirmationInput(e.target.value)} className="input-base mt-2" />
                            </div>
                        </div>
                        <div className="mt-5 sm:mt-4 sm:flex sm:flex-row-reverse gap-3">
                            <button type="button" className="w-full btn bg-red-600 hover:bg-red-700 text-white sm:w-auto disabled:opacity-50" onClick={handleDeleteSiteDialog} disabled={deleteConfirmationInput !== selectedSite?.name}> Delete </button>
                            <button type="button" className="mt-3 w-full btn btn-secondary sm:mt-0 sm:w-auto" onClick={() => setIsDeleteDialogOpen(false)}> Cancel </button>
                        </div>
                    </div>
                </div>
            )}
             {viewingHistoryItem && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in" onClick={() => setViewingHistoryItem(null)}>
                    <div className="bg-panel rounded-2xl shadow-2xl w-full max-w-4xl p-6 border border-border animate-modal-pop max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
                        <HistoryDetailViewer post={viewingHistoryItem} />
                    </div>
                </div>
            )}
            <ProfileModal isOpen={isProfileModalOpen} onClose={() => setIsProfileModalOpen(false)} setActiveTab={setActiveTab} />
        </div>
    );
};